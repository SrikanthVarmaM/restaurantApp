'use strict';

msaiqApp.controller('MarketCommentaryCtrl', function ($scope, articleResourceFactory,$routeParams) {
    $scope.loading = true;
    $scope.articleCode = $routeParams.articleCode;
    $scope.articleId = $routeParams.articleId;

    $scope.marketCommentaryData = articleResourceFactory.articlesDetailsResource.get({articleCode: $scope.articleCode,articleId:$scope.articleId});



});