'use strict';

msaiqApp.controller('HomePageCtrl', function ($scope, articleResourceFactory, $log, ArticleMessaging, _, $, userResourceResourceFactory) {
    $scope.mostViewedDataForUS = [];
    $scope.loading = true;
    $scope.userLoggedIn = 0;

    userResourceResourceFactory.loginResource.getArrayReq({}, function (response) {
        (response.resourceList  === null)?$scope.userLoggedIn = 0 : $scope.userLoggedIn = 1;
    });

    $scope.relatedTIData = articleResourceFactory.trendsAndIdeasSpotLightResource.get();

    $scope.marketCommentaryData = articleResourceFactory.homeLandingPageResource.get({articleCode: 'MKTCM'});

    $scope.morningBriefingData = articleResourceFactory.morningBriefingPageResource.get({articleCode:'MBRIF',isSpotLightPage:true});

    $scope.mostViewedArticleDataForUS = articleResourceFactory.mostViewedArticlesResource.get({region: 'US'});
    var mostViewedData = [];
    $scope.mostViewedArticleDataForUS.$promise.then(function (articleData) {
        for (var i = 0; i < articleData.topArticles.length; i++) {
            var dataObject = {};
            dataObject.articleId = articleData.topArticles[i].articleId;
            dataObject.lastPublishDate = articleData.topArticles[i].lastPublishDate;
            dataObject.articleCode = articleData.topArticles[i].articleCode;
            switch(dataObject.articleCode)
            {
                case 'ASALOM' :
                    dataObject.headline = 'S&P INVESTMENT STRATEGY - US';
                    dataObject.articleURL = '#/marketscope/investmentStrategy/US';
                    break;
                case 'FSOW' :
                    dataObject.headline = 'FOCUS STOCK OF THE WEEK';
                    dataObject.articleURL = '#/marketscope/focusStock';
                    break;
                case 'MBRIF' :
                    dataObject.headline = 'MORNING BRIEFING - US';
                    dataObject.articleURL = '#/marketscope/morningbriefing';
                    break;
                case 'RNOTS' :
                    dataObject.headline = articleData.topArticles[i].headline;
                    dataObject.articleURL = '#/marketscope/researchNotesDetails/'+articleData.topArticles[i].articleCode + '/'+articleData.topArticles[i].articleId;
                    break;
                default:
                    dataObject.headline = articleData.topArticles[i].headline;
                    dataObject.articleURL = '#/articles/' + articleData.topArticles[i].articleCode + '/'+''+'/' + articleData.topArticles[i].articleId + '';
            }
            mostViewedData.push(dataObject);
        }
        $scope.mostViewedDataForUS = mostViewedData;
    });

    $scope.articleData = articleResourceFactory.homeLandingPageResource.get({articleCode: 'HOME'});
    $scope.articleData.$promise.then(function(articleData){
        angular.forEach($scope.articleData.articles, function(article){
            article.headlineUpdate = $scope.redoArticleTitle(article.headline, article.articleInstruments);
        });
        var param = {};
        param[0] = {sppwId: '', tickerSymbol: ''};
        var symbolsTickers = $.map(param, function(n){ return n; });
        var message = {articleId: articleData.articleId, instruments: symbolsTickers};
        ArticleMessaging.broadcastArticleLoaded($scope, message);
        $scope.articleData.articles  =  $scope.articleData.articles.slice(0,5);
        $scope.loading = false;
    });
    $scope.redoArticleTitle = function(headline, instruments){
        // return back from 'headline'
        // headlineParsed : {headlineStart: '', link: '', headlineEnd: ''}';
        // get article symbol  main
        var mainSymbol = '';  var sppwId = '';
        angular.forEach(instruments, function(instrument){
            if( instrument.articleRelationship === 'main'){
                mainSymbol = instrument.tickerSymbol;
                sppwId = instrument.sppwId;
            }
        });

        if (mainSymbol){
            var indexSearch = headline.indexOf('('+mainSymbol+')');
            if (indexSearch > 0){
                return ({headlineStart: headline.substring(0, indexSearch-1).trim(), 'link': mainSymbol, headlineEnd: headline.substring(indexSearch+mainSymbol.length+2, headline.length), sppwId: sppwId});
            }else{
                return {headlineStart: headline, 'link': mainSymbol, sppwId: sppwId };
            }
        }else{
            return null;
        }
    };
    $scope.getURL = function(articleCode,articleId){
        switch(articleCode) {
            case 'RNOTS' : return '#/marketscope/researchNotesDetails/'+articleCode + '/'+articleId;
            case 'MOVER' : return '#/marketscope/marketMoversDetails/'+articleCode + '/'+articleId;
            case 'SVIEW': return '#/marketscope/brokerViewsDetails/'+articleCode + '/'+articleId;
            case 'ECOCL': return '#/marketscope/economyWatchArticle/'+articleCode + '/'+articleId+'/mainPage';
            //case 'TREND' : return '';
            case 'STALK' : return '#/marketscope/streetTalkDetails/'+articleCode + '/'+articleId;
        }
    };
    /*$scope.openQV = function(sppwId, ticker, report_ind, type){
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
    };*/
  });