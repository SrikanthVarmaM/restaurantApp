'use strict';

msaiqApp.controller('MsaErrorPageCtrl',function ($scope,$routeParams,userResourceResourceFactory,ArticleMessaging,$rootScope,UserInfoLinkServices) {

    $scope.errorObject = $rootScope.errorObject;
    $scope.enableSendMailButton = true;
    $scope.isClickButtonEnabled = false;

    var requestParamPost = {errorCode: $scope.errorObject.errorCode,stackTrace: $scope.errorObject.errorStackTrace,errorTime:$scope.errorObject.errorTime,partnerCode:$scope.errorObject.partnerCode,url:$scope.errorObject.url};

    if(( $scope.errorObject.errorMessage.indexOf("click on the continue button")>-1)){
        $scope.isClickButtonEnabled = true;
    }

    $scope.getRedirectURL =function() {
        window.location.href = $scope.errorObject.url;
    };

    $scope.sendErrorReportMail =function() {
        userResourceResourceFactory.sendMailResource.postReq(requestParamPost, function (response) {
            if(response.mailSent)  {
                UserInfoLinkServices.openErrorMailConfirmWindow({source :$scope,action :'close'});
                $scope.enableSendMailButton = false;
            }
        });
    }




});