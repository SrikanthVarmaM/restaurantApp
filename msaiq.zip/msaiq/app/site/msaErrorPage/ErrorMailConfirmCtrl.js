'use strict';


msaiqApp.controller('ErrorMailConfirmCtrl',
    function ($scope) {
        //------------------------function definition------------------------------------------
        $scope.source= $scope.modelParam.source;
        $scope.action=$scope.modelParam.action

        //-----------------
    }


);