'use strict';

msaiqApp.controller('HomeManagerCtrl', function ($scope, $cookies, $route,$rootScope, $location, AUTH_EVENTS) {
    $scope.AUTH_EVENTS = AUTH_EVENTS;
    $scope.userInfoLinkManager = 'home';
    $rootScope.$watch(function() { return $cookies.ObSSOCookie;},function(cookie){
        if(!cookie){
            if($location.$$path.indexOf('msaErrorPage') > -1 || $location.$$path.indexOf('remoteLogin.html') > -1 || $location.$$path.indexOf('seamlessQV') > -1 || $location.$$absUrl.indexOf('quickview') > -1){
                $scope.userAuthenticationStatusForEnt = AUTH_EVENTS.loginSuccess;
            } else {
                $scope.userAuthenticationStatusForEnt = AUTH_EVENTS.notAuthenticated;
            }
        } else {
            $scope.userAuthenticationStatusForEnt = AUTH_EVENTS.loginSuccess;
        }
    },true);

    $scope.$watch('userInfoLinkManager',function(value){
        switch(value){
            case 'home':
                $scope.mainHeadingTitle = 'MarketScope&reg; Advisor'
                break;
            case 'admin':
                $scope.mainHeadingTitle = 'MarketScope Administrator'
                break;
            case 'outlookAdmin':
                $scope.mainHeadingTitle = 'MarketScope Outlook Administrator'
                break;
            default :
                $scope.mainHeadingTitle = 'MarketScope&reg; Advisor'
        }
    },true)
});