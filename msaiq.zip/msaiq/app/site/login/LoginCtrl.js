'use strict';

msaiqApp.controller('LoginCtrl', function ($scope, $route,$rootScope, $routeParams, AUTH_EVENTS, userResourceResourceFactory, UserInfoLinkServices,$location,$window) {
    $scope.myscope = $rootScope;
    $scope.UserInfoLinkServices = UserInfoLinkServices;
    $scope.AUTH_EVENTS = AUTH_EVENTS;
    var isSecureAccess = (window.location.toString().indexOf('https://')!=-1)? true : false;
    $scope.credentials = { username: '', password: '' ,requestType:'async',rememberMe:false ,redirectURL:'/dist',currentTime:(new Date()).getTime(), isSecureAccess:isSecureAccess};

    $scope.$watch('myscope.loginUserInformation',function(data){
        if(data && data.hasOwnProperty('userDetails')) {
            if(!_.isEmpty(data.userDetails)) {
                $rootScope.loginUserInformation.userAuthenticationStatus = AUTH_EVENTS.loginSuccess;
                $rootScope.currentUser=$scope.myscope.loginUserInformation.userDetails.ERIGHTS_USERID;
                $rootScope.$broadcast('closeAuthenticateModel');

                if ($rootScope.checkHumaneMargins()) {
                    humane.log("You have successfully logged in as "+$scope.myscope.loginUserInformation.userDetails.LOGIN_ID, {addnCls: 'humaneResize'});
                } else {
                    humane.log("You have successfully logged in as "+$scope.myscope.loginUserInformation.userDetails.LOGIN_ID);
                }
            }else if($location.$$path.indexOf('msaErrorPage') > -1 || $location.$$path.indexOf('remoteLogin.html') > -1 || $location.$$path.indexOf('seamlessQV') > -1 || $location.$$absUrl.indexOf('quickview') > -1){
                $rootScope.loginUserInformation.userAuthenticationStatus = '';
            } else {
                $rootScope.loginUserInformation.userAuthenticationStatus = AUTH_EVENTS.notAuthenticated;
            }
        }
    },true);

    $scope.logoutUser = function(){
        var logoutResource = userResourceResourceFactory.logoutUserResource.get();
        logoutResource.$promise.then(function () {
            $scope.destroyCookie('ObSSOCookie');
            $location.path('/home');
            $window.location.reload(true);
        });
    };

    $scope.authenticateNonSeamlessUser = function(credentials){
        userResourceResourceFactory.userLoginResource.postReq(credentials).$promise.then(function(response){
            var userLoginData = JSON.parse(response.loginResponse)
            if(!(userLoginData.success)){

                if($rootScope.checkHumaneMargins()) {
                    humane.log("Your username or password is incorrect.", {addnCls: "humaneResize"});
                } else {
                    humane.log("Your username or password is incorrect.");
                }
                $scope.credentials.username = '';
                $scope.credentials.password = '';
            }
        });
    };

    $scope.destroyCookie = function(cname) {
        document.cookie = cname + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    };


});

msaiqApp.constant('AUTH_EVENTS', {
    //user auth events
    loginSuccess: 'auth-login-success',
    loginFailed: 'auth-login-failed',
    logoutSuccess: 'auth-logout-success',
    notAuthenticated: 'auth-not-authenticated',

    //url type login
    bondSeamlessQV: 'url-bond-seamless-QV',
    seamlessLogin: 'url-seamless-login',
    ObSSOCookieLogin: 'url-ObSSOCookie-login',
    nonSeamlessLogin: 'non-seamless-login'
});
