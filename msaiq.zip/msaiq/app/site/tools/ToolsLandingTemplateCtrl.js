'use strict';

msaiqApp.controller('ToolsLandingTemplateCtrl', function ($scope,  $log, $routeParams, $location,EntitlementService) {
    $scope.toolsHomeArgs = {activeTab: $routeParams.activeTab};
    $scope.currentTime = new Date();
    $scope.EntitlementService =  EntitlementService;
    $scope.getTemplate = function(tab){
        $location.url('/marketscope/toolsLanding/'+tab);
    };
});