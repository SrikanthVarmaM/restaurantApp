'use strict';

msaiqApp.controller('AdminHomePageCtrl', function ($scope, $log) {

});