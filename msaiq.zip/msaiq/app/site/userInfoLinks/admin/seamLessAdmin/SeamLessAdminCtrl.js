'use strict';

msaiqApp.controller('SeamLessAdminCtrl', function ($scope, $log,userResourceResourceFactory,$filter) {
    $scope.today = Date.parse(new Date());
    var yesOrNoCheckFilter=$filter('yesOrNoWithEmpty');
    var encryptionFilter=$filter('encryptionFilter');
    var reverseEncryptionFilter=$filter('reverseEncryptionFilter');
    $scope.disableSaveButton =  true;
    $scope.disableClearButton =  true;
    $scope.date ;
    $scope.clientNameDropdownLoading = true;
    $scope.partnerCodeDropdownLoading = true;
    $scope.seamLessParameters = {
        action:'' ,
        clientName:'' ,
        partnerCode:'',
        partnerDescription:'',
        password:'',
        algo:'',
        helpDeskPhone: '',
        redirectUrl: '',
        idmMigrationStartDate:'',
        erightsGroup:'',
        idmGroup:'',
        maxusercount:'',
        desKey:'',
        helpdeskEmail: '',
        contactPhone:'',
        addUserFlag:'',
        expirationDays:'',
        idmMigrationFlag:'',
        errMessage:''
    };

    userResourceResourceFactory.getPartnerCodesResource.postReq({action:"getPartners"}, function (response) {
        angular.forEach(response.seamlessPartners,function(item){
            item.idmMigrationFlag = yesOrNoCheckFilter(item.idmMigrationFlag);
            item.addUserFlag = yesOrNoCheckFilter(item.addUserFlag);
            item.algo=reverseEncryptionFilter(item.algo);
        });
        $scope.partnerCodesListsData =  response.seamlessPartners;
        $scope.partnerCodeDropdownLoading = false;
        $scope.clientNameListData = $scope.getClientNameList($scope.partnerCodesListsData)
    });


    $scope.getPartnerCodeData = function(){
        userResourceResourceFactory.getPartnerCodesResource.postReq({action:"getPartners"}, function (response) {
            angular.forEach(response.seamlessPartners,function(item){
                item.idmMigrationFlag = yesOrNoCheckFilter(item.idmMigrationFlag);
                item.addUserFlag = yesOrNoCheckFilter(item.addUserFlag);
                item.algo=reverseEncryptionFilter(item.algo);
                if(item.parnerCode == $scope.seamLessParameters.partnerCode){
                    $scope.autoPopulateDetails(item);
                }
            });
            $scope.partnerCodesListsData =  response.seamlessPartners;
        });


    }

     $scope.autoPopulateDetails = function(partnerCodeData){
        $scope.clientNameAction = partnerCodeData.parnerCode;
        $scope.partnerCodeAction = partnerCodeData.parnerCode;
        $scope.seamLessParameters.clientName = partnerCodeData.clientName;
        $scope.seamLessParameters.partnerCode = partnerCodeData.parnerCode;
        $scope.seamLessParameters.partnerDescription = partnerCodeData.partnerDescription;
        $scope.seamLessParameters.password = partnerCodeData.password;
        $scope.seamLessParameters.erightsGroup = partnerCodeData.erightsGroup;
        $scope.seamLessParameters.idmGroup = partnerCodeData.idmGroup;
        $scope.seamLessParameters.maxusercount = partnerCodeData.maxusercount;
        $scope.seamLessParameters.expirationDays = partnerCodeData.expirationDays;
        $scope.seamLessParameters.contactPhone = partnerCodeData.contactPhone;
        $scope.seamLessParameters.errMessage = partnerCodeData.errMessage;
        $scope.seamLessParameters.desKey = partnerCodeData.desKey;
        $scope.seamLessParameters.helpdeskEmail ='test'// partnerCodeData.helpdeskEmail==''?'tst':partnerCodeData.helpdeskEmail;
        $scope.seamLessParameters.helpDeskPhone = partnerCodeData.helpDeskPhone;
        $scope.seamLessParameters.redirectUrl = partnerCodeData.redirectUrl;
        $scope.seamLessParameters.idmMigrationFlag = partnerCodeData.idmMigrationFlag ;
        $scope.seamLessParameters.addUserFlag = partnerCodeData.addUserFlag ;
        $scope.seamLessParameters.idmMigrationStartDate =  partnerCodeData.idmMigrationStart;
        $scope.seamLessParameters.algo = reverseEncryptionFilter(partnerCodeData.algo);
        $('#inputPartnerCode').val($scope.seamLessParameters.partnerCode);
        $('#inputClientName').val($scope.seamLessParameters.clientName);
    }

    $('#inputPartnerCode').click(function (e) {
        $('#partnerCodeHeader').addClass('open');
        e.stopPropagation();
    })

    $scope.autoPopulateClientDetails = function(partnerCodeData){

        $scope.seamLessParameters.clientName = partnerCodeData.clientName;
        $scope.seamLessParameters.partnerCode = '';
        $scope.seamLessParameters.partnerDescription = '';
        $scope.seamLessParameters.password = '';
        $scope.seamLessParameters.erightsGroup = '';
        $scope.seamLessParameters.idmGroup = '';
        $scope.seamLessParameters.maxusercount = '';
        $scope.seamLessParameters.expirationDays = partnerCodeData.expirationDays;
        $scope.seamLessParameters.contactPhone = '';
        $scope.seamLessParameters.errMessage = '';
        $scope.seamLessParameters.desKey = partnerCodeData.desKey;
        $scope.seamLessParameters.helpdeskEmail = '';
        $scope.seamLessParameters.helpDeskPhone = '';
        $scope.seamLessParameters.redirectUrl = '';
        $scope.seamLessParameters.idmMigrationFlag = partnerCodeData.idmMigrationFlag ;
        $scope.seamLessParameters.addUserFlag = '' ;
        $scope.seamLessParameters.idmMigrationStartDate =  partnerCodeData.idmMigrationStart;
        $scope.seamLessParameters.algo = reverseEncryptionFilter(partnerCodeData.algo);
        $('#inputClientName').val($scope.seamLessParameters.clientName);
    }
    $('#inputClientName').click(function (e) {
        $('#clientNameHeader').addClass('open');
        e.stopPropagation();
    })
    $('#inputClientName').click(function (e) {
        $('#clientNameHeader').addClass('open');
        e.stopPropagation();
    })
    $scope.clearSeamLessParametersObj = function(){
        $scope.clientNameAction = '';
        $scope.partnerCodeAction = '';
        $scope.seamLessParameters.clientName = '';
        $scope.seamLessParameters.partnerCode = '';
        $scope.seamLessParameters.partnerDescription = '';
        $scope.seamLessParameters.password = '';
        $scope.seamLessParameters.erightsGroup = '';
        $scope.seamLessParameters.idmGroup = '';
        $scope.seamLessParameters.maxusercount = '';
        $scope.seamLessParameters.expirationDays = '';
        $scope.seamLessParameters.contactPhone = '';
        $scope.seamLessParameters.errMessage = '';
        $scope.seamLessParameters.desKey = '';
        $scope.seamLessParameters.helpdeskEmail = '';
        $scope.seamLessParameters.helpDeskPhone = '';
        $scope.seamLessParameters.redirectUrl = '';
        $scope.seamLessParameters.idmMigrationFlag = '' ;
        $scope.seamLessParameters.addUserFlag = '' ;
        $scope.seamLessParameters.idmMigrationStartDate ='';
        $scope.seamLessParameters.algo='';
        $scope.c = '';
        $scope.p = '';
        $('#inputPartnerCode').val('');
        $('#inputClientName').val('');
    }
    $scope.saveSeamLessParametersObj = function(value){
        $scope.seamLessParameters.action =  'save';
        $scope.seamLessParameters.addUserFlag =  $scope.convertToBoolean($scope.seamLessParameters.addUserFlag);
        $scope.seamLessParameters.idmMigrationFlag =  $scope.convertToBoolean($scope.seamLessParameters.idmMigrationFlag);
        $scope.seamLessParameters.algo=encryptionFilter($scope.seamLessParameters.algo);
        userResourceResourceFactory.savePartnerCodesResource.postReq($scope.seamLessParameters, function (response) {
            $log.debug('Re loading the  partner Code Details');
            $scope.getPartnerCodeData();

        });
    }
    $scope.convertToBoolean = function(value){
        if(value == 'Yes')
            return 'Y';
        else if(value == 'No')
            return 'N';
        else
            return value;
    }
    $scope.getClientNameList = function(data){
        var clientStore = [];
        var tempData=[];
        angular.forEach(data,function(item){
                var alreadyInTemp=false;
                for(var j=0;j<tempData.length;j++){
                    if(item.clientName == tempData[j].clientName){
                        alreadyInTemp=true;break;
                    }
                }
            if(!alreadyInTemp){
                clientStore.push(item);
                tempData.push(item);
            }
        });
        $scope.clientNameDropdownLoading = false;
        return clientStore;
    }
    $scope.generateKey = function(){
        if(!_.isEmpty($scope.seamLessParameters.partnerCode) || !_.isEmpty($scope.seamLessParameters.algo)){
            $scope.generateKeyLoading = true;
            $scope.seamLessParameters.desKey ='.....Generating.....';
            userResourceResourceFactory.updateEncryptionResource.postReq({ 'action': 'generateKey', 'partnercode': $scope.seamLessParameters.partnerCode, 'encryptionMethod':encryptionFilter($scope.seamLessParameters.algo)}, function (response) {
                $scope.generateKeyLoading = false;
                $scope.seamLessParameters.desKey = response.desKey;
            });
        } else{
            humane.log('please enter partner code and encryption method')
        }

    }
    $scope.$watch('c',function(obj){
        $scope.seamLessParameters.clientName = obj;
    },true);
    $scope.$watch('p',function(obj){
        $scope.seamLessParameters.partnerCode = obj;
    },true);
    $scope.$watch('seamLessParameters',function(obj){
        if(!jQuery.isEmptyObject(obj)){
            //for Save Button
            if(!_.isEmpty(obj.clientName) && !_.isEmpty(obj.partnerCode) && !_.isEmpty(obj.partnerDescription) && !_.isEmpty(obj.password) &&
               !_.isEmpty(obj.erightsGroup) && !_.isEmpty(obj.idmGroup) && (obj.maxusercount) && !_.isEmpty(obj.desKey) &&
               !_.isEmpty(obj.algo) && !_.isEmpty(obj.idmMigrationStartDate) )
                $scope.disableSaveButton =  false;
            else
                $scope.disableSaveButton =  true;
            //for Cancel Button
            if(!_.isEmpty(obj.clientName) || !_.isEmpty(obj.partnerCode) || !_.isEmpty(obj.partnerDescription) || !_.isEmpty(obj.password) ||
                !_.isEmpty(obj.erightsGroup) || !_.isEmpty(obj.idmGroup) || (obj.maxusercount) || !_.isEmpty(obj.desKey) ||
                !_.isEmpty(obj.algo) || !_.isEmpty(obj.idmMigrationStartDate) || !_.isEmpty(obj.addUserFlag) || !_.isEmpty(obj.idmMigrationFlag) ||
                (obj.expirationDays) || !_.isEmpty(obj.contactPhone) || !_.isEmpty(obj.errMessage) || !_.isEmpty(obj.helpdeskEmail) ||
                !_.isEmpty(obj.helpDeskPhone) || !_.isEmpty(obj.redirectUrl) )
                $scope.disableClearButton =  false;
            else
                $scope.disableClearButton =  true;
        }
   },true);

    $('#inputClientName').click(function (e) {
$log.info('cline tname clicked');
        $('#partnerCodeHeader').removeClass('open');

        $('#clientNameHeader').addClass('open');
        e.stopPropagation();
    })
    $('#inputPartnerCode').click(function (e) {
        $log.info('partner tname clicked');
        $('#clientNameHeader').removeClass('open');
        $('#partnerCodeHeader').addClass('open');
        e.stopPropagation();
    })

});
