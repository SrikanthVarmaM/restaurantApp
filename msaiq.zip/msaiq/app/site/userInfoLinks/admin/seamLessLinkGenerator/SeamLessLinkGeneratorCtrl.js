'use strict';

msaiqApp.controller('SeamLessLinkGeneratorCtrl', function ($scope, $log,userResourceResourceFactory,$filter,$rootScope) {
    $scope.today = Date.parse(new Date());
    $scope.partnerCodeDropdownLoading = true;
    $scope.loginIdDropdownLoading = true;

    var decodeHTMLFilter=$filter('decodeHTML');
    var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
    loginUserDetail.$promise.then(function(loginUser){
        if(loginUser.resourceList){
              $scope.isIDMUser = loginUser.resourceList.IS_IDM_USER;
        }
    });

    $scope.generatePartnerCodeDetails = function(){
        userResourceResourceFactory.getPartnerCodesResource.postReq({action:"getPartners"}, function (response) {
            $scope.partnerCodesListsData =  response.seamlessPartners;
            $scope.partnerCodeDropdownLoading = false;
            if($scope.partnerCode){
                angular.forEach(response.seamlessPartners,function(item){
                    if(item.parnerCode == $scope.partnerCode){
                        $scope.autoPopulateLoginListDetails(item);
                    }
                });
            }
        });
    }

    $('#inputPartnerCode').click(function (e) {
        $('#partnerCodeHeader').addClass('open');
        e.stopPropagation();
    })

    $('#inputLoginId').click(function (e) {
        $('#loginIdHeader').addClass('open');
        e.stopPropagation();
    })

    $scope.autoPopulateLoginListDetails = function(data){
        $scope.partnerCode =  data.parnerCode ;
        $('#inputPartnerCode').val($scope.partnerCode);
        $scope.erightsGroup =  data.erightsGroup;
        $scope.idmGroup =   data.idmGroup;
        $scope.loginId =   '';
        $scope.firstName =   '';
        $scope.lastName =   '';
        $scope.userEmailData = '';
        $scope.expirationDate='';
        $scope.seamLessLink= '';
        if($scope.isIDMUser){
            userResourceResourceFactory.getUserListInOimGroupResource.postReq({action:"getLogins",oimGroup:$scope.idmGroup}, function (response) {
                $scope.userListsData =  response.seamlessUsers;
                $scope.loginIdDropdownLoading = false;
            });
        }else{
            userResourceResourceFactory.getUserListInGroupResource.postReq({action:"getLogins",erightsGroup:data.erightsGroup}, function (response) {
                $scope.userListsData =  response.seamlessUsers;
                $scope.loginIdDropdownLoading = false;
            });
        }
    }
    $scope.autoPopulateEmailDetails = function(data){
        $scope.loginId =   data.loginId;
        $('#inputLoginId').val($scope.loginId);
        $scope.firstName =   data.firstName;
        $scope.lastName =   data.lastName;
        $scope.expirationDate='';
        $scope.seamLessLink= '';
        if($scope.isIDMUser){
            userResourceResourceFactory.userEmailResource.postReq({action:"getUserEmail",oimLoginId:$scope.loginId}, function (response) {
                $scope.userEmailData =  response.emailId;
            });
        }else{
            $scope.userEmailData =  data.emailId;
        }
    }

    $scope.cancelSeamLessGenerator = function(data){
        $scope.loginId =   '';
        $scope.firstName =   '';
        $scope.lastName =   '';
        $scope.userEmailData = '';
        $scope.partnerCode =  '' ;
        $scope.erightsGroup =  '';
        $scope.idmGroup =   '';
        $scope.expirationDate='';
        $scope.seamLessLink= '';
    }
    $scope.generateSeamLessLink = function(){
        var seamLessLinkParameters = {action:"generateUrl",partnercode:$scope.partnerCode,loginId:$scope.loginId,firstName:$scope.firstName,expirationDate:$scope.expirationDate,erightsGroup:$scope.erightsGroup,
                                        idmGroup :$scope.idmGroup,emailId:$scope.userEmailData,lastName:$scope.lastName,seamlessLink:$scope.seamLessLink}
        userResourceResourceFactory.updateEncryptionResource.postReq(seamLessLinkParameters, function (response) {
            $scope.seamLessLink =  decodeHTMLFilter(response.data.seamlessLink).replace("/SP/msa", "/dist/#");
        },function(){
            humane.log('Link Generator Failed !!!');
        });
    }
    $scope.openGeneratedLink = function(data){
        window.open(data,'MsaSeamless');
    }

    $scope.generatePartnerCodeDetails();
});
