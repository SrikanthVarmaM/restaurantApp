'use strict';

msaiqApp.controller('EditSeamlessUserCtrl', function ($scope, $log, userResourceResourceFactory,$rootScope) {
    $scope.selectedUser = $scope.modelParam.selectedUser;
    $scope.headerText = "Edit User : "+$scope.selectedUser.login;
    $scope.userEditObj = {id:-1, fetchSeamlessUserDetail:true, groupName:'', partnerCode:'', login:$scope.selectedUser.login, newLogin:$scope.selectedUser.login, firstName:'', lastName:'',
        newGroupName:'',clientName: '', newPartnerCode:''};
    $scope.userEditFormObj = {};
    $scope.viewState = 'LOADING';

    var userEditData = userResourceResourceFactory.getClientUserAdminEditViewResource.postReq({id:-1, partnerCode:$scope.selectedUser.partnerCode,
            idmUser:$scope.selectedUser.idmUser, clientIdmGroup:$scope.selectedUser.groupName, fetchSeamlessUserDetail:false, login:$scope.selectedUser.login});
    userEditData.$promise.then(function(data){
        if(data.success){
            $scope.viewState = 'LOADED';
            angular.forEach(data.clientPartners,function(obj){
               if(obj.partnerCode === $scope.selectedUser.partnerCode){
                   $scope.userEditObj.groupName = obj.erightsGroup+'&';
                   $scope.userEditObj.newGroupName = obj.erightsGroup+'&';
                   $scope.userEditObj.partnerCode = obj.partnerCode;
                   $scope.userEditObj.newPartnerCode = obj.partnerCode;
                   return;
               }
            });
            $scope.userEditObj.clientName = data.user.clientName;
            $scope.userEditObj['lockKey'] = data.user.lockKey;
            $scope.userEditObj.firstName = data.user.firstName;
            $scope.userEditObj.lastName = data.user.lastName;
            $scope.userEditObj['userDetail.attributeValue5'] = data.user.userDetail.attributeValue5;
            $scope.userEditObj['userDetail.attributeValue6'] = data.user.userDetail.attributeValue6;
            $scope.userEditObj['userDetail.attributeValue7'] = data.user.userDetail.attributeValue7;
            $scope.userEditObj['userDetail.attributeValue1'] = data.user.userDetail.attributeValue1;
            $scope.userEditObj['userDetail.attributeValue2'] = data.user.userDetail.attributeValue2;
            $scope.userEditFormObj = data;
        }else {
            $scope.viewState = 'FAILED';
        }
    },function(){$scope.viewState = 'FAILED';});

    $scope.handleSaveButton = function(){
        var userEditData = userResourceResourceFactory.getClientUserAdminSaveEditResource.postReq($scope.userEditObj);
        userEditData.$promise.then(function(data){
            humane.log("Changes to user profile is updated successfully");
            $rootScope.$broadcast('refreshClientUserAdminLandingPage');
            $scope.handleClose();
        },function(){
            humane.log("An error occurred while fetching the user details");
            $scope.handleClose();
        });
    };

});