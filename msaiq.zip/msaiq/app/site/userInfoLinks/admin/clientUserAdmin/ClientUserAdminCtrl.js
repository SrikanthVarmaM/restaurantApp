'use strict';

msaiqApp.controller('ClientUserAdminCtrl', function ($scope, $log,$filter,$routeParams,$rootScope,$location,userResourceResourceFactory,ngTableParams,$,UserInfoLinkServices) {
    $scope.clientUserAdminArgs = {activeTab: $routeParams.activeTab};
    $scope.tableParams = new ngTableParams({ page: 1, count: 25, total: 0, counts : [] });
    $scope.userInfoLinkServices = UserInfoLinkServices;
    $scope.confirmUpdateObj = {source :$scope, action :'deleteUser'};
    $scope.currentUserClientName = '';
    $scope.fetchSeamlessUserDetails = false;



    if($scope.clientUserAdminArgs.activeTab === 'Main'){
        $scope.dropdownLoading = true;
        $scope.clientUserAdminObj = {};
        $scope.headerText= 'CLIENT USER ADMIN';
        $scope.showSearchResultView = false;
        $scope.enableExportToExcelButton = false;
        var userAdminDataResource = userResourceResourceFactory.getUserAdminDataResource.postReq({action:'getPartners'});
        userAdminDataResource.$promise.then(function(obj){
            $scope.userAdminData = obj.seamlessPartners;
            $scope.dropdownLoading = false;
            if($rootScope.loginUserInformation.entitlements.clientAdminLink){
                $scope.currentUserClientName = $rootScope.loginUserInformation.userDetails.PARTNER_CODE;
                $scope.clientUserAdminObj.clientName =  $scope.currentUserClientName;
                $scope.clientUserAdminObj.parnerCode = '';
                $scope.setGroupName($scope.currentUserClientName);
                $scope.fetchSeamlessUserDetails = true;
            }
        });
    } else {
        $scope.reportingObj = {};
        $scope.headerText= 'Genex Report';
        $scope.enableGenexReport = true;
        $scope.$watch('reportingObj',function(obj){
            var reportingObj = { toDate:'', fromDate:''};
            angular.extend(reportingObj, obj);
            if(_.isEmpty(reportingObj.toDate)){
                $scope.todayDateForFrom = ($filter('date')(new Date(), 'MM/dd/yyyy')).toString();
            } if(_.isEmpty(reportingObj.fromDate)){
                $scope.todayDateForTo = ($filter('date')(new Date(), 'MM/dd/yyyy')).toString();
            } if(!_.isEmpty(reportingObj.toDate)){
                $scope.todayDateForFrom = reportingObj.toDate;
            }  if(!_.isEmpty(reportingObj.fromDate) && !_.isEmpty(reportingObj.toDate)){
                $scope.enableGenexReport = false;
            }
        },true);
    }

    $scope.handleReportClearButton = function(){
        $scope.reportingObj = {};
        $scope.enableGenexReport = true;
    };

    $scope.setGroupName = function(cName){
        $scope.clientUserAdminObj.groupName = '';
        if(cName != 'ALL') {
            angular.forEach($scope.userAdminData,function(object){
                if(cName === object.clientName){
                    if(object.erightsGroup && object.erightsGroup.length>0)
                        $scope.clientUserAdminObj.groupName = $scope.clientUserAdminObj.groupName + object.erightsGroup + '&';
                }
            });
        }
    };

    $scope.handleMainClearButton = function(){
        $scope.clientUserAdminObj = {};
        $scope.showSearchResultView = false;
        $scope.enableExportToExcelButton = false;
    };

    $scope.$watch('tableParams', function(params) {
        if(params.total != 0) {
            $scope.searchReportingList =  $scope.searcReportingRawData.slice((params.page - 1) * params.count,params.page * params.count);
            $scope.enableExportToExcelButton = true;
        }
        else $scope.searchReportingList = [];
    }, true);

    $scope.handleMainSearchButton = function(obj){
        $scope.searchListContainerLoading = true;
        $scope.searchReportingList = [];
        $scope.tableParams.total = 0;
        $scope.adminFormObject = {login:obj.login, firstName:obj.firstName, lastName:obj.lastName, groupName:obj.groupName, email:'',
            fetchSeamlessUserDetail: $scope.fetchSeamlessUserDetails, dateCriteria:obj.dateCriteria, fromDate:obj.fromDate, toDate:obj.toDate, clientName:obj.clientName};
        var userAdminDataResource = userResourceResourceFactory.getMsaUserAdminResource.postReq($scope.adminFormObject);
        userAdminDataResource.$promise.then(function(obj){
            $scope.tableParams.total = obj.total_records;
            $scope.searcReportingRawData = obj.seamlessUsers;
            $scope.searchListContainerLoading = false;
            $scope.enableUpdateButton = false;
        },function(){
            $scope.searchListContainerLoading = true;
            $scope.searchReportingList = [];
        });
    };

    $scope.getTemplate = function(tab){
        $location.url('/admin/clientUserAdmin/'+tab);
    };

    $scope.handleCheckBoxChange = function(){
        $scope.deleteLoginID = []
        angular.forEach($scope.searcReportingRawData,function(item){
            if(item.id === true)
                $scope.deleteLoginID.push(item.login);
        });
        $scope.deleteLoginID.length != 0?$scope.enableUpdateButton = true:$scope.enableUpdateButton = false;
    };

    $scope.handleMainCancelButton =  function(){
        angular.forEach($scope.searcReportingRawData,function(item){
            item.id = false;
        });
        $scope.enableUpdateButton = false;
    };

    $scope.handleMainUpdateButton = function(){
        $scope.searchListContainerLoading = true;
        $scope.searchReportingList = [];
        $scope.tableParams.total = 0;
        var clientUserObj = {login:'', firstName:'', lastName:'', groupName:$scope.clientUserAdminObj.groupName, email:'',fetchSeamlessUserDetail: $scope.fetchSeamlessUserDetails, dateCriteria:'', fromDate:'',
            toDate:'', clientName:$scope.clientUserAdminObj.clientName,action:'Delete',deletedUsers:$scope.deleteLoginID.join(',')};
        var userAdminDataResource = userResourceResourceFactory.getMsaUserAdminResource.postReq(clientUserObj);
        userAdminDataResource.$promise.then(function(obj){
            $scope.tableParams.total = obj.total_records;
            $scope.searcReportingRawData = obj.seamlessUsers;
            $scope.searchListContainerLoading = false;
            $scope.enableUpdateButton = false;
        },function(){
            $scope.searchListContainerLoading = true;
            $scope.searchReportingList = [];
        });
    };

    $scope.$on('refreshClientUserAdminLandingPage', function () {
        $scope.searchListContainerLoading = true;
        $scope.searchReportingList = [];
        $scope.tableParams.total = 0;
        var userAdminDataResource = userResourceResourceFactory.getMsaUserAdminResource.postReq($scope.adminFormObject);
        userAdminDataResource.$promise.then(function(obj){
            $scope.tableParams.total = obj.total_records;
            $scope.searcReportingRawData = obj.seamlessUsers;
            $scope.searchListContainerLoading = false;
            $scope.enableUpdateButton = false;
        },function(){
            $scope.searchListContainerLoading = true;
            $scope.searchReportingList = [];
        });
    });



    $('#inputClientName').click(function (e) {
        $('#clientNameHeader').addClass('open');
        e.stopPropagation();
    })
    $('#inputPartnerCode').click(function (e) {
        $('#partnerCodeHeader').addClass('open');
        e.stopPropagation();
    })
});
