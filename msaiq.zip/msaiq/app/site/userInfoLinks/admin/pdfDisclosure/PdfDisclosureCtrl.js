'use strict';

msaiqApp.controller('PdfDisclosureCtrl', function ($scope, $log,userResourceResourceFactory,$rootScope,EntitlementService) {
    $scope.partnerCode = '';
    $scope.fundCheckLink = false;
    $scope.etfCheckLink = false;
    $scope.stockHTMLCheckLink = false;
    $scope.stockPDFCheckLink = false;
    $scope.articleHTMLCheckLink = false;
    $scope.articlePDFCheckLink = false;
    $scope.partnerCodeDropdownLoading = true;
    EntitlementService.loadEnt();

    EntitlementService.deferred.promise.then(function(entResult){
        $scope.isClientAdmin = entResult.admin.clientAdminLink;
        if($scope.isClientAdmin){
            var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
            loginUserDetail.$promise.then(function(loginUser){
                if(loginUser.resourceList){
                    $scope.partnerCode = loginUser.resourceList.PARTNER_CODE;
                    userResourceResourceFactory.getPDFDisclosureResource.postReq({code:"READ",partnerCode:$scope.partnerCode}, function (response) {
                        $scope.disclosureListData =  formatResponse(response.disclosureList);
                        $scope.partnerCodeDropdownLoading = false;
                    });
                }
            });
        }else{
            userResourceResourceFactory.getPartnerCodesResource.postReq({action:"getPartners"}, function (response) {
                $scope.partnerCodesListsData =  response.seamlessPartners;
                $scope.partnerCodeDropdownLoading = false;
            });
        }

    });

    $scope.deleteDisclosureDetails = function(partnerCode,disclosureId){
        userResourceResourceFactory.getPDFDisclosureResource.postReq({code:"DELETE",partnerCode:partnerCode,disclosureId:disclosureId}, function (response) {
            $scope.disclosureListData =  formatResponse(response.disclosureList);
        });
    }
    var formatResponse =  function(disclosureList){
       var tempDisclosureList=[{pageName:'ARTICLES_PDF',disclosureId:-1},{pageName:'ARTICLES_HTML',disclosureId:-1},
            {pageName:'STOCKS_PDF',disclosureId:-1},{pageName:'STOCKS_HTML',disclosureId:-1},
            {pageName:'ETFS',disclosureId:-1},
            {pageName:'FUNDS',disclosureId:-1}];
        angular.forEach(disclosureList,function(item){
            angular.forEach(tempDisclosureList,function(tempItem){
                if(tempItem.pageName ==item.pageName){
                    tempItem.fileName=item.fileName;
                    tempItem.disclosureId=item.disclosureId;
                }
            });
        });
        return tempDisclosureList;
    }
    $scope.autoPopulateDetails = function(partnerCodeData){
        $scope.partnerCode =   partnerCodeData.parnerCode;
        userResourceResourceFactory.getPDFDisclosureResource.postReq({code:"READ",partnerCode:$scope.partnerCode}, function (response) {
            $scope.disclosureListData =  formatResponse(response.disclosureList);
        });
        $('#inputPartnerCode').val($scope.partnerCode);
    }

    $scope.onSuccess = function(response){
        userResourceResourceFactory.getPDFDisclosureResource.postReq({code:"READ",partnerCode: $scope.partnerCode}, function (response) {
            $scope.disclosureListData =  formatResponse(response.disclosureList);
        });
    }
    $scope.onError = function(response){
        humane.log(response);
    }

    $scope.onUpload = function(){
        var pageName = '';
        if($scope.stockPDFCheckLink){
            pageName+='STOCKS_PDF,';
        }
        if($scope.stockHTMLCheckLink){
            pageName+='STOCKS_HTML,';
        }
        if($scope.fundCheckLink){
            pageName+='FUNDS,';
        }
        if($scope.etfCheckLink){
            pageName+='ETFS,';
        }
        if($scope.articlePDFCheckLink){
            pageName+='ARTICLES_PDF,';
        }
        if($scope.articleHTMLCheckLink){
            pageName+='ARTICLES_HTML';
        }
        $scope.formData = {partnerCode:$scope.partnerCode,pageName:pageName};
    }
    $scope.goTo = function(disclosureId,partnerCode){
        if(!$scope.isClientAdmin)
            window.open('/SP/msa/setPDFDisclosure.html?code=DOWNLOAD&disclosureId='+disclosureId+'&partnerCode='+partnerCode);
        else
            window.open('/SP/msa/setPDFDisclosure.html?code=DOWNLOAD&disclosureId='+disclosureId);
    };
    $scope.cancelPDFDisclosure = function(data){
        $scope.articleHTMLCheckLink =   '';
        $scope.articlePDFCheckLink =   '';
        $scope.etfCheckLink =   '';
        $scope.fundCheckLink = '';
        $scope.stockHTMLCheckLink =  '' ;
        $scope.stockPDFCheckLink =  '';
        $scope.partnerCode =   '';
        $scope.disclosureListData = '';
        angular.element(document.getElementById('excel-import-form-id')).val('');
        document.getElementById('phDisclosureForm').reset();
    }
    $('#inputPartnerCode').click(function (e) {
        $('#partnerCodeHeader').addClass('open');
        e.stopPropagation();
    })

});
