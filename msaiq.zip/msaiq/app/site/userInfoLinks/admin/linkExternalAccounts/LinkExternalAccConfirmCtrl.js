'use strict';

msaiqApp.controller('LinkExternalAccConfirmCtrl',function ($scope) {
    $scope.source = $scope.modelParam.source;
    $scope.action = $scope.modelParam.action
    if($scope.action === 'Link'){
        $scope.headerText = 'Link Accounts'
    } else if($scope.action === 'deleteUser'){
        $scope.headerText = 'Confirm Update'
    } else {
        $scope.headerText = 'Unlink Accounts'
    }
});

