'use strict';

msaiqApp.controller('LinkExternalAccountsCtrl', function ($scope, $log,userResourceResourceFactory,UserInfoLinkServices) {
    $scope.statusMsg = '';
    $scope.userExternalLinkObj = { username:'', linkedUserName : ''};
    $scope.isValidUser = 0;
    $scope.userInfoLinkServices = UserInfoLinkServices;
    $scope.confirmLinkObj = {source :$scope,action :'Link'};
    $scope.confirmUnlinkObj = {source :$scope,action :'Unlink'};
    $scope.loading = false;

    $scope.closeErrorMsgBox = function(){
        $scope.statusMsg = '';
    };

    $scope.handleFindButton = function(){
        $scope.inputUsername = $scope.userExternalLinkObj.username;
        $scope.loading = true;
        var linkExternalAccountsRawData =  userResourceResourceFactory.linkExternalAccountsResource.postReq({operationCode:'CHECK_ACCOUNT', userId:$scope.userExternalLinkObj.username});
        linkExternalAccountsRawData.$promise.then(function(data){
            if(data.status === 'NonUser') {
                $scope.statusMsg = $scope.userExternalLinkObj.username+' does not Exist.';
                $scope.isValidUser = 0;
            } else if(data.status === 'Exits' && data.isLinked === 'true'){
                $scope.statusMsg = '';
                $scope.isValidUser = 1;
                $scope.linkExternalAccountsData = data;
            } else {
                $scope.statusMsg = '';
                $scope.linkExternalAccountsData = data;
                $scope.isValidUser = 2;
            }
            $scope.loading = false;
        });
    };

    $scope.handleUnlinkButton = function(){
        $scope.loading = true;
        var linkExternalAccountsRawData =  userResourceResourceFactory.linkExternalAccountsResource.postReq({operationCode:'UNLINK_ACCOUNTS', userId:$scope.linkExternalAccountsData.userId, linkedUserId: $scope.linkExternalAccountsData.linkedUserId});
        linkExternalAccountsRawData.$promise.then(function(data){
            if(data.status === 'UnLinked') {
                $scope.statusMsg = '';
                humane.log($scope.userExternalLinkObj.username+" has been successfully unlinked from "+$scope.linkExternalAccountsData.linkedUserId);
                $scope.isValidUser = 0;
                $scope.linkExternalAccountsData = data;
            } else {
                humane.log("Unable to Unlink.Please try again!");
            }
            $scope.loading = false;
        });
    };

    $scope.handleLinkButton = function(){
        $scope.loading = true;
        var linkExternalAccountsRawData =  userResourceResourceFactory.linkExternalAccountsResource.postReq({operationCode:'LINK_ACCOUNTS', userId:$scope.userExternalLinkObj.username, linkedUserId: $scope.userExternalLinkObj.linkedUserName});
        linkExternalAccountsRawData.$promise.then(function(data){
            if(data.status === 'UserError') {
                $scope.statusMsg = $scope.userExternalLinkObj.linkedUserName+' does not Exist.';
            } else {
                $scope.statusMsg = '';
                $scope.isValidUser = 0;
                humane.log($scope.userExternalLinkObj.username+" has been successfully linked to "+$scope.userExternalLinkObj.linkedUserName);
            }
            $scope.loading = false;
        });
    };

    $scope.handleResetButton = function(){
        $scope.statusMsg = '';
        $scope.isValidUser = 0;
        $scope.userExternalLinkObj = { username:'', linkedUserName : ''};
    };
});
