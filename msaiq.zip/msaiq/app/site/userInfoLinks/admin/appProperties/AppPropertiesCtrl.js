'use strict';

msaiqApp.controller('AppPropertiesCtrl', function ($scope, $log,userResourceResourceFactory,$filter) {
    var decodeHTMLFilter=$filter('decodeHTML');
    $scope.appPropertiesLoading = true;

    $scope.propertiesList = [];
    $scope.isDelete = false;
    userResourceResourceFactory.getAppPropertiesResource.postReq({operationCode:"READ"}, function (response) {
        $scope.propertiesList =  response.appProperties;
        $scope.appPropertiesLoading = false;
    });
    $scope.addProperty = function(){
        var property = {
            instanceName: $scope.instanceName,
            propertyName: $scope.propertyName,
            propertyValue: $scope.propertyValue,
            isDelete : $scope.isDelete
        };

        $scope.propertiesList.push(property);

         $scope.instanceName = '';
         $scope.propertyName = '';
         $scope.propertyValue = '';

    };

    $scope.updateCheckBoxValue = function(instanceName,propertyName){
       angular.forEach( $scope.propertiesList,function(item){
         if(item.instanceName == instanceName && item.propertyName == propertyName)
            item.isDelete = $scope.isDelete;
       });
        //$scope.propertiesList.splice(index, 1);
    };
    $scope.handleSaveButton = function(){
        $scope.appPropertiesLoading = true;
        var appPropertyParams = {};
        for(var j=0;j<$scope.propertiesList.length;j++){
            var property = $scope.propertiesList[j] ;
            if (property.instanceName !== '' && property.propertyName !== '') {
                appPropertyParams['appProperties[' + j + '].instanceName'] = property.instanceName;
                appPropertyParams['appProperties[' + j + '].propertyName'] = property.propertyName;
                appPropertyParams['appProperties[' + j + '].propertyValue'] = decodeHTMLFilter(property.propertyValue);
            }
        }
        appPropertyParams.operationCode = 'UPDATE';
        userResourceResourceFactory.getAppPropertiesResource.postReq(appPropertyParams, function (response) {
            $scope.propertiesList =  response.appProperties;
            $scope.appPropertiesLoading = false;
            humane.log('App properties updated successfully. Restart App to reflect.');
        },function(){
            humane.log('Error saving properties');
        });

}
    $scope.handleDeleteButton = function(){
        $scope.appPropertiesLoading = true;
        var appPropertyParams = {};
        var i = 0;
        for(var j=0;j<$scope.propertiesList.length;j++){
            var property = $scope.propertiesList[j] ;
            if (property.isDelete) {
                appPropertyParams['appProperties[' + i + '].instanceName'] = property.instanceName;
                appPropertyParams['appProperties[' + i + '].propertyName'] = property.propertyName;
                appPropertyParams['appProperties[' + i + '].propertyValue'] = '';
                i++;
            }
        }
        appPropertyParams.operationCode = 'DELETE';
        userResourceResourceFactory.getAppPropertiesResource.postReq(appPropertyParams, function (response) {
            $scope.propertiesList=  response.appProperties;
            $scope.appPropertiesLoading = false;
        });

    }
    $scope.handleRefreshButton = function(){
        userResourceResourceFactory.getAppPropertiesResource.postReq({operationCode:"READ"}, function (response) {
            $scope.propertiesList =  response.appProperties;
        });
    }
});
