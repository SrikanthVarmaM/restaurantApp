'use strict';

msaiqApp.controller('TrialReportingCtrl', function ($scope, $log,userResourceResourceFactory, ngTableParams, $filter,$,$window) {
    $scope.showSearchResultView  = false;
    $scope.enableExportToExcelButton = false;
    $scope.searchListContainerLoading = true;
    //$scope.today = Date.parse(new Date());
    $scope.disableSearchButton = true;
    $scope.tableParams = new ngTableParams({ page: 1,count: 20,total: 0,counts : [] });
    $scope.trialReportingObj = {};
    $scope.searchtrialReportingList = [];
    $scope.searctrialReportingRawData = {};
    $scope.enableSubmitButton = false;


    $scope.searchtrialReportingClientName = userResourceResourceFactory.trialReportingResource.postReq({event:'getClientName'});

    $scope.$watch('trialReportingObj',function(obj){
        if(!jQuery.isEmptyObject(obj)){
            var trialReportingObj = { event:'search', clientName:'',trialStatus:'', trialStartDate: '', trialEndDate:'', lastLoginStart:'', lastLoginEnd:'' };
            angular.extend(trialReportingObj, obj);
            if(!_.isEmpty(trialReportingObj.clientName) || !_.isEmpty(trialReportingObj.trialStatus) || !_.isEmpty(trialReportingObj.trialStartDate) || !_.isEmpty(trialReportingObj.trialEndDate) || !_.isEmpty(trialReportingObj.lastLoginStart) || !_.isEmpty(trialReportingObj.lastLoginEnd))
                $scope.disableSearchButton =  false;
            else
                $scope.disableSearchButton =  true;

        } else {
            $scope.disableSearchButton =  true;
        }
    },true);

    $scope.$watch('tableParams', function(params) {
        if(params.total != 0) {
            $scope.searchtrialReportingList =  $scope.searctrialReportingRawData.slice((params.page - 1) * params.count,params.page * params.count);
            $scope.enableExportToExcelButton = true;
        }
        else $scope.searchtrialReportingList = [];
    }, true);

    $scope.handleSubmitButton = function(obj){
        $scope.searchListContainerLoading = true;
        $scope.tableParams.total = 0;
        var trialReportingObj = { event:'search', clientName:'',trialStatus:'', trialStartDate: '', trialEndDate:'', lastLoginStart:'', lastLoginEnd:'' };
        angular.extend(trialReportingObj, obj);
        var searchtrialReportingData = userResourceResourceFactory.trialReportingResource.postReq(trialReportingObj);
        searchtrialReportingData.$promise.then(function(data){
            $scope.tableParams.total = data.trialReports.length;
            $scope.searctrialReportingRawData = data.trialReports;
            $scope.searchListContainerLoading = false;
        });
    };

    $scope.handleClearButton = function(){
        $scope.trialReportingObj = {};
        $scope.showSearchResultView  = false;
        $scope.searchtrialReportingList = [];
        $scope.enableExportToExcelButton = false
        $scope.tableParams = new ngTableParams({ page: 1,count: 20,total: 0,counts : [] });
    };

    $scope.handleExportToExcelButton = function(){

        $window.document.body.innerHTML += '<form name="dummyForm" action="/SP/msa/admin/trialReportGenerate.html" target=_blank method=post>'
            + '<input type=hidden name=event value="' + "trialReportExcelview" + '">'
            + '<input type=hidden name=clientName   value="' + $scope.trialReportingObj.clientName + '">'
            + '<input type=hidden name=trialStatus   value="' + $scope.trialReportingObj.trialStatus + '">'
            + '<input type=hidden name=trialStartDate   value="' + $scope.trialReportingObj.trialStartDate + '">'
            + '<input type=hidden name=trialEndDate   value="' + $scope.trialReportingObj.trialEndDate + '">'
            + '<input type=hidden name=lastLoginStart   value="' + $scope.trialReportingObj.lastLoginStart + '">'
            + '<input type=hidden name=lastLoginEnd value="' + $scope.trialReportingObj.lastLoginEnd + '">'
            + '</form>';
        $window.document.forms['dummyForm'].submit();
        $window.document.forms['dummyForm'].remove()
    };

});
