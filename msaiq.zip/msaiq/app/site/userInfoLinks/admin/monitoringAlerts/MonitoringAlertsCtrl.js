'use strict';

msaiqApp.controller('MonitoringAlertsCtrl', function ($scope, $log,userResourceResourceFactory,ngTableParams) {
    $scope.tableParams = new ngTableParams({ page: 1,count: 20,total: 0,counts : [] });
    $scope. monitoringAlertList = [];
    $scope.monitorListContainerLoading = true;

    $scope.$watch('tableParams', function(params) {
        if(params.total != 0) $scope.monitoringAlertList =  $scope.monitoringAlertsResourceData.slice((params.page - 1) * params.count,params.page * params.count);
        else $scope.monitoringAlertList = [];
    }, true);

    $scope.handleSaveButton = function(){
        var appPropertyParams = {};
        angular.forEach($scope.monitoringAlertsResourceData,function(item,index){
            appPropertyParams['monitors['+index+'].monitorName'] =  item.monitoName;
            appPropertyParams['monitors['+index+'].suspendStatus'] =  item.checkboxState;
        });
        appPropertyParams['operationCode'] =  'UPDATE';

        $scope.reloadMonitorAlerts(appPropertyParams);
    }

    $scope.handleRefreshButton = function(){
        $scope.reloadMonitorAlerts({operationCode:'READ'});
    }

    $scope.reloadMonitorAlerts = function(formObj){
        $scope.monitorListContainerLoading = true;
        $scope.tableParams.total = 0;
        $scope.monitoringAlertList = [];

        var monitoringAlertsRawData = userResourceResourceFactory.monitoringAlertsResource.postReq(formObj);
        monitoringAlertsRawData.$promise.then(function(data){
            $scope.tableParams.total = data.monitors.length;
            angular.forEach(data.monitors,function(item){
                item['checkboxState'] = item.suspendStatus;
            });
            $scope.monitoringAlertsResourceData = data.monitors;
            $scope.monitorListContainerLoading = false;
            if(formObj.operationCode == 'UPDATE'){
                humane.log('Monitors updated successfully.');
            }
        },function(){
            humane.log('Error saving monitor');
        });

    };
    $scope.reloadMonitorAlerts({operationCode:'READ'});
});
