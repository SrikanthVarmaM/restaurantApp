'use strict';

msaiqApp.controller('ForgetPasswordCtrl', function ($scope, $log, userResourceResourceFactory) {

    $scope.showForgetPanel = true;
    $scope.$watch('showForgetPanel',function(value){
        if(value) {
            $scope.headerText = " Need help ?";
        } else{
            $scope.headerText = " Forgot your password ?";
        }
        $scope.statusMsg = '';
        $scope.forgetPasswordObj = { username : '', email: ''};
    },true);

    $scope.handleForgetPassword = function(){
        var userResetPasswordData = userResourceResourceFactory.userResetPasswordResource.postReq($scope.forgetPasswordObj);
        userResetPasswordData.$promise.then(function(data){
            data = JSON.parse(data.resetPasswordResponse)
            if(data.success){
                $scope.statusMsg = 'An email with your new password has been sent.'
            } else {
                if (data.error==='invalid_email'){
                    $scope.statusMsg = 'Email address does not match. *Email address should match alert email destination.';
                }else if (data.error==='user_not_found'){
                    $scope.statusMsg = 'Username not found';
                }else if (data.error==='group_account'){
                    $scope.statusMsg = 'We are unable to change your password at this time, please contact client support at 1-800-523-4534 (Monday - Friday 8:00 am - 8:00 pm ET).';
                }
            }
        },function(){
            $scope.statusMsg = 'Error';
        })
    };

    $scope.changeViewPanel = function(value){
        value == true ? $scope.showForgetPanel = false : $scope.showForgetPanel = true;
    };

    $scope.closeErrorMsgBox = function(){
        $scope.statusMsg = '';
        $scope.forgetPasswordObj = { username : '', email: ''};
    }

});