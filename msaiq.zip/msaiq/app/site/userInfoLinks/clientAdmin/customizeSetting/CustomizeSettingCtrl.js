'use strict';

msaiqApp.controller('CustomizeSettingCtrl', function ($scope, $log,userResourceResourceFactory,$filter) {
    $scope.customizationObject = {};
   var getSettings = function(){
        var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
        loginUserDetail.$promise.then(function(loginUser){
            if(loginUser.resourceList){
                $scope.partnerCode = loginUser.resourceList.PARTNER_CODE;
                if(loginUser.resourceList.CLIENT_CUSTOMIZATION != null){
                    $scope.customizationObject  = jQuery.parseJSON(loginUser.resourceList.CLIENT_CUSTOMIZATION);
                }
                else{
                    $scope.customizationObject["displayHomeMarketingBanner"] = true ;
                    $scope.customizationObject["displayUnlicensedTabs"] = true ;
                    $scope.customizationObject["displayBondButtons"] = true ;
                    $scope.customizationObject  = jQuery.parseJSON($scope.customizationObject);
                }
            }
        });
    }


    $scope.saveCustomizeSettings = function(){
        var saveParameters = {customizations:JSON.stringify($scope.customizationObject),partnerCode: $scope.partnerCode}
         userResourceResourceFactory.savePartnerCustomizationsResource.postReq(saveParameters, function (response) {
         humane.log('Partner data are saved successfully');
         },function (response) {
         humane.log('Partner data are save failed');
         });
    }
    $scope.cancelCustomizeSettings = function(){
        getSettings();
    }
    getSettings();
});