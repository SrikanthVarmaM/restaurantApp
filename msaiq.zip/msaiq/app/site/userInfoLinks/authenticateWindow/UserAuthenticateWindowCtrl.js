'use strict';

msaiqApp.controller('UserAuthenticateWindowCtrl', function ($scope, $log, $timeout,$cookies,userResourceResourceFactory, UserInfoLinkServices,$location) {
    $scope.userInfoLinkServices = UserInfoLinkServices;
    $scope.headerText = '  Login';
    $scope.statusMsg = '';
    var isSecureAccess = (window.location.toString().indexOf('https://')!=-1)? true : false;
    $scope.credentials = { username: '', password: '' ,requestType:'async',rememberMe:false ,redirectURL:'/dist',currentTime:(new Date()).getTime(), isSecureAccess:isSecureAccess};
    var currentUrl = $location.$$url;
    $location.path('/home');
    $scope.authenticateNonSeamlessUser = function(credentials){
        userResourceResourceFactory.userLoginResource.postReq(credentials).$promise.then(function(response){
            var userLoginData = JSON.parse(response.loginResponse)
            if(userLoginData.success){
                $timeout(function() { $location.path(currentUrl);}, 1000);
            }else {
                $scope.statusMsg = 'Your username or password is incorrect.';
            }
        },function(){
            $scope.statusMsg = 'Your username or password is incorrect.';
        });
    };

    $scope.$on('closeAuthenticateModel', function () {
        $scope.handleClose();
    });

    $scope.closeErrorMsgBox = function(){
        $scope.statusMsg = '';
        $scope.credentials.username = '';
        $scope.credentials.password = '';
        $scope.credentials.rememberMe = false;
    }
});