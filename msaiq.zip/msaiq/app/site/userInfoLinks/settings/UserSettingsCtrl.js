'use strict';

msaiqApp.controller('UserSettingsCtrl', function ($scope, $rootScope, $log, userResourceResourceFactory) {
    $scope.headerText = "Settings";
    $scope.userSettingsObj = { loginId : '', firstName: '', lastName: '', email: '', phone: '', requestType:''};

    var userSettingsData = userResourceResourceFactory.userSettingsResource.postReq({requestType:'READ'});
    userSettingsData.$promise.then(function(data){
        $scope.userSettingsObj = {requestType:'UPDATE', loginId : data.loginId, firstName: data.firstName, lastName: data.lastName, email: data.email, phone: data.phone };
    });

    $scope.handleUserSettings = function(){
        $scope.handleClose();
        var userSettingsDataResponse = userResourceResourceFactory.userSettingsResource.postReq($scope.userSettingsObj);
        userSettingsDataResponse.$promise.then(function(data){
            if(data.success)
                if ($rootScope.checkHumaneMargins()) {
                    humane.log("User information updated Successfully", {addnCls: 'humaneResize'});
                } else {
                    humane.log("User information updated Successfully");
                }
            else
                if ($rootScope.checkHumaneMargins()) {
                    humane.log("User information not updated, please try again.", {addnCls: 'humaneResize'});
                } else {
                    humane.log("User information not updated, please try again.");
                }
        },function(){
            if ($rootScope.checkHumaneMargins()) {
                humane.log("Unable to establish connection", {addnCls: 'humaneResize'});
            } else {
                humane.log("Unable to establish connection");
            }
        });
    };

});