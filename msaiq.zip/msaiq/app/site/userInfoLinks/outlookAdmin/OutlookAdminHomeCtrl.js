'use strict';

msaiqApp.controller('OutlookAdminHomeCtrl', function ($scope, $log,userResourceResourceFactory,ngTableParams, $filter) {
    $scope.outlookAdminObj = {userId:'',email:'',firstName:'',lastName:'',pimsid:''};
    $scope.showOutlookSearchResultView = false;
    $scope.searchListContainerLoading = true;
    $scope.showOutlookUserEditableView = false;
    $scope.today = Date.parse(new Date());
    $scope.outlookMainTitle="Outlook Online Edition Client Support";
    $scope.searchOutlookUserList = [];
    $scope.searchOutlookUserResourceData = []
    $scope.tableParams = new ngTableParams({ page: 1,count: 20,total: 0,counts : [] });

    $scope.$watch('outlookAdminObj',function(obj){
        if(_.isEmpty(obj.userId) && _.isEmpty(obj.email) && _.isEmpty(obj.firstName) && _.isEmpty(obj.lastName) && _.isEmpty(obj.pimsid)) $scope.disableSearchButton =  true;
        else $scope.disableSearchButton =  false;
    },true);

    $scope.$watch('tableParams', function(params) {
        if(params.total != 0) $scope.searchOutlookUserList =  $scope.searchOutlookUserResourceData.slice((params.page - 1) * params.count,params.page * params.count);
        else $scope.searchOutlookUserList = [];
    }, true);

    $scope.clearOutlookAdminObj = function(){
        $scope.outlookAdminObj = {userId:'',email:'',firstName:'',lastName:'',pimsid:''};
    };

    $scope.handleSearchButton = function(outlookAdminObj){
        $scope.searchListContainerLoading = true;
        $scope.tableParams.total = 0;
        var searchOutlookUserData = userResourceResourceFactory.searchOutlookUserResource.postReq(outlookAdminObj);
        searchOutlookUserData.$promise.then(function(searchOutlookData){
            $scope.tableParams.total = searchOutlookData.outlookCustomers.length;
            $scope.searchOutlookUserResourceData = searchOutlookData.outlookCustomers;
            $scope.searchListContainerLoading = false;
        });
    };

    $scope.handleSearchEdit = function(selectedRecord){
        $scope.showOutlookUserEditableView = true;
        $scope.outlookMainTitle="Outlook Online Edition Support";

        var updateOutlookUserResourceData = userResourceResourceFactory.updateOutlookUserResource.postReq({isUpdate:false, custId:selectedRecord.custId});
        updateOutlookUserResourceData.$promise.then(function(data){
            $scope.updateOutlookFormObj = { custId: data.custId,isUpdate:true, email:data.email, userLogin:data.userLogin, password:data.password }
            if(data.expiryDate) $scope.updateOutlookFormObj['expDate'] = data.expiryDate;
            if(data.cancellationDate) $scope.updateOutlookFormObj['cancellationDate'] = data.cancellationDate;
            $scope.updateOutlookUserInfo = data;
        });
    };

    $scope.saveEditableRecord = function(){
        $scope.updateOutlookFormObj.cancellationDate = $filter('date')($scope.updateOutlookFormObj.cancellationDate, 'MM/dd/yyyy');
        $scope.updateOutlookFormObj.expDate = $filter('date')($scope.updateOutlookFormObj.expDate, 'MM/dd/yyyy');
        var updateOutlookUserResourceData = userResourceResourceFactory.updateOutlookUserResource.postReq($scope.updateOutlookFormObj);
        updateOutlookUserResourceData.$promise.then(function(data){
            $scope.updateOutlookFormObj = { custId: data.custId,isUpdate:true, email:data.email, userLogin:data.userLogin, password:data.password };
            if(data.expiryDate) $scope.updateOutlookFormObj['expDate'] = data.expiryDate;
            if(data.cancellationDate) $scope.updateOutlookFormObj['cancellationDate'] = data.cancellationDate;
            $scope.updateOutlookUserInfo = data;
            humane.log("Client Record Saved");
        });
    }

    $scope.hideEditableSection = function(){
        $scope.showOutlookUserEditableView = false;
        $scope.outlookMainTitle="Outlook Online Edition Client Support";
    };

});