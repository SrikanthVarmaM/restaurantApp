'use strict';

msaiqApp.controller('StarStocksCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory ,$, $location   ) {
  
    $scope.loading = true;
    $scope.operation1Value = $routeParams.operation1Value;
    $scope.starStockArgs = {activeTab: 'CUSTOM'};
    $scope.tableParams = { page   : 1,count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc'  }};
    $scope.selectedSppwids =[];
    $scope.showWatchlist = false;

    $scope.clickTab = function (tab){
        $scope.starStockArgs.activeTab = tab;
    };

    $scope.$watch('tableParams', function(params,oldParams) {
        if(oldParams.page === params.page && $scope.tableParams.total !== 0)
        {
            return;
        }
        $scope.starStockResource = articleResourceFactory.starStocksResource.get({start: (params.page-1) * params.count,limit:params.count, operation1Value:$scope.operation1Value});
        $scope.loading = true;
        $scope.starStockResource.$promise.then(function(starStockData){
            $scope.tableParams.total = $scope.totalNumOfRecords = starStockData.total_records;
            for(var i=0; i < starStockData.equities.length; i++){
                starStockData.equities[i].starRankDate = Date.parse(starStockData.equities[i].starRankDate.split('-').join('/'));
            }
            $scope.loading = false;
            $scope.starStockList =  starStockData;
            var printArray = [];
            var countIndex = $scope.totalNumOfRecords/1000;
            for(var index=0;index<countIndex;index++)
            {
                var dataObject = {};
                dataObject.displayLine  = 'Rows '+((index*1000)+1)+'-'+(index+1)*1000;
                dataObject.link  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=starRank&screenerParameters%5B0%5D.propertyLabel=STARS&screenerParameters%5B0%5D.operation1Value='+$scope.operation1Value+'&screenerParameters%5B0%5D.customRenderer=starRankRenderer&start='+((index*1000))+'&limit='+(((index+1)*1000))+'&equityType=STOCKS&sort=securityName&dir=ASC&criteriaMessage='+$scope.operation1Value + ' Star Stocks';
                printArray.push(dataObject);
            }
            $scope.printArray = printArray;
        });
    }, true);

    $scope.goTo = function(path){
        $location.path(path);
    };

    $scope.handleCheckBoxChange=function(event,data,sppwId,securityName){
        if(data.isin){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.starStockList.equities, function(item) {
            if (angular.isDefined(item.isin)) {
                item.isin = checked;
                if(item.isin){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.starStockList.equities,function(item){
                item.isin = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);

});
