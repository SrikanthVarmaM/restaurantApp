'use strict';

msaiqApp.controller('FairValueCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory,$){

    $scope.loading = true;
    $scope.operation1Value = $routeParams.operation1Value;
    $scope.fairValueArgs = {activeTab: 'CUSTOM'};
    $scope.tableParams = { page   : 1,count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' }};
    $scope.selectedSppwids =[];
    $scope.showWatchlist = false;
      $scope.clickTab = function (tab){
        $scope.fairValueArgs.activeTab = tab;
    };

    $scope.$watch('tableParams', function(params,oldParams) {
        if(oldParams.page === params.page && $scope.tableParams.total !== 0)
        {
            return;
        }
        $scope.fairValueResource = articleResourceFactory.fairValueResource.get({start: (params.page-1) * params.count,limit:params.count, operation1Value:$scope.operation1Value});
        $scope.loading = true;
        $scope.fairValueResource.$promise.then(function(fairValueData){
            $scope.tableParams.total = $scope.totalNumOfRecords = fairValueData.total_records;
            for(var i=0; i < fairValueData.equities.length; i++){
                fairValueData.equities[i].starRankDate = Date.parse(fairValueData.equities[i].starRankDate.split('-').join('/'));
            }
            $scope.loading = false;
            $scope.fairValueList =  fairValueData;
            var printArray = [];
            var countIndex = $scope.totalNumOfRecords/1000;
            for(var index=0;index<countIndex;index++)
            {
                var dataObject = {};
                dataObject.displayLine  = 'Rows '+((index*1000)+1)+'-'+(index+1)*1000;
                dataObject.link  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=fairvalueRank&screenerParameters%5B0%5D.operation1Value-displayValue='+$scope.operation1Value+'&screenerParameters%5B0%5D.propertyLabel=S%26P%20Fair%20Value%20Rank&screenerParameters%5B0%5D.operator1Type=%3D&screenerParameters%5B0%5D.operation1Value='+$scope.operation1Value+'&screenerParameters%5B0%5D.operator2Type=%3C%3D&screenerParameters%5B0%5D.conjunctionType=and&screenerParameters%5B0%5D.inferedPropertyName=fairvalueRank&start='+((index*1000))+'&limit='+(((index+1)*1000))+'&equityType=STOCKS&sort=securityName&dir=ASC&criteriaMessage=S%26P+Fair+Value+Rank+%3d '+$scope.operation1Value;
                printArray.push(dataObject);
            }
            $scope.printArray = printArray;
        });
    }, true);

    $scope.handleCheckBoxChange=function(event,data,sppwId,securityName){
        if(data.isin){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };
    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.fairValueList.equities, function(item) {
            if (angular.isDefined(item.isin)) {
                item.isin = checked;
                if(item.isin){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.fairValueList.equities,function(item){
                item.isin = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);
});
