/**
 * Created with IntelliJ IDEA.
 * User: nkakkireni
 * Date: 10/4/13
 * Time: 3:56 PM
 * To change this template use File | Settings | File Templates.
 */
'use strict';

msaiqApp.controller('TechTrendsCtrl', function ($scope, $log, $location, articleResourceFactory, $) {

    $scope.techTrendsResource = articleResourceFactory.articleDataResource.get({articleCode: 'TTWAT',start:0,limit:2});
    $scope.$emit('menuShow','Stocks');

    $scope.goTo = function(articleId,attachmentName){
        window.open('/SP/msa/articleAttachment.pdf?articleId='+articleId+'&attachmentName='+attachmentName);
    };

});
