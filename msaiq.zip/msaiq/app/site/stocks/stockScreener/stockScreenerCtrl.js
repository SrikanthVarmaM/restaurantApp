'use strict';

msaiqApp.controller('StockScreenerCtrl', function ($) {

    $('#msaIframe').on('$destroy',function(){
        $('#stockmenu').css('position', 'inherit');
        $('#stockmenu').css('z-index', '0');
    });

});

var watchForStocks = function () {
    var myTimeout = setInterval(function () {
        if( jQuery('#msaIframe').contents().find('.sectorCode-form').size() > 0  || jQuery('#msaIframe').contents().find('.issuedRegion-form').size() > 0 ){

            jQuery('#msaIframe').contents().find('.security-screener').trigger('click');
            jQuery('#msaIframe').css('visibility','visible');

            jQuery('#stockmenu').css('position', 'absolute');
            jQuery('#stockmenu').css('z-index', '1');
            clearTimeout(myTimeout);
        }


        var iframecss = jQuery('#msaIframe').contents();

        iframecss.find('.screener-form-container').css('overflow', 'visible');
        iframecss.find('.screener-block').css('overflow', 'visible');
        iframecss.find('.lookup-panel-container').css('top', '0px');
        iframecss.find('.x-grid3-col-3').css('width', '240px');
        iframecss.find('.x-grid3-col-report-column').css('width', '90px');
        iframecss.find('.x-grid3-col-1').css('width', '50px');
        iframecss.find('#screener-results-custom-tab').css('width', '76px');
        iframecss.find('#screener-results-basic-tab').css('width', '67px');
        iframecss.find('#screener-results-performance-tab').css('width', '105px');
        iframecss.find('#screener-results-ranking-tab').css('width', '75px');
        iframecss.find('#screener-results-fundamentals-tab').css('width', '112px');
        iframecss.find('#screener-results-dividend-tab').css('width', '75px');



    }, 100);

};