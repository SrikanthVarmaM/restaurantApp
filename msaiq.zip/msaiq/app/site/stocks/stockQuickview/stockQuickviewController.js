'use strict';

msaiqApp.controller('stockQuickViewCtrl',
    function ($scope, $log, $location, $route, assetsResourceFactory, _, AutoSuggestService, $resource, EntitlementService) {
        /*--------------------------------Initialization-----------------------------------*/
        // ranking from 1-5; quality A+ to D; page adjust accordingly if increase ranking
        $scope.fairValueRankingArray = [1, 2, 3, 4, 5];
        $scope.qualityRankingArray = ['D', 'C', 'B-', 'B', 'B+', 'A-', 'A', 'A+'];
        $scope.relStrengthArray = ['LOW', 'MEDIUM', 'HIGH'];
        $scope.riskStrengthArray = ['LOW', 'AVERAGE', 'HIGH'];
        var STAR_RANKS = ['not ranked', 'Strong Sell', 'sell', 'hold', 'buy', 'strong buy'];
        $scope.showWatchlist = false;
        $scope.selectedSppwids = [];

        $scope.states = {LOADING: 0,LOADED: 2,NOT_FOUND: 1 };
        $scope.viewState = $scope.states.LOADING;
        $scope.layoutConstants = { TABBED_LAYOUT: 1, UNTABBED_LAYOUT: 2 };
        $scope.Math = window.Math;
        $scope.Date = window.Date;

        //*****************---utilities---------------------------------//
        $scope.calculateStarRankText = function (starRank) {
            var starRankText = '';

            switch (starRank) {
                case 1:
                    starRankText = STAR_RANKS[1];
                    break;
                case 2:
                    starRankText = STAR_RANKS[2];
                    break;
                case 3:
                    starRankText = STAR_RANKS[3];
                    break;
                case 4:
                    starRankText = STAR_RANKS[4];
                    break;
                case 5:
                    starRankText = STAR_RANKS[5];
                    break;
                default:
                    starRankText = STAR_RANKS[0];
            }

            /* retVal += '<span class="starRankText">'+starRankText+'</span>';

             for(var i = 0; i < starRank; i++){
             retVal += '<img src="app-resources/images/star-blue.gif"/>';
             }        */

            return starRankText;
        };
        $scope.goTo = function (path) {
            // close model and then change route.
            $scope.$modalClose();

            $location.path(path);
            window.location.href = '#' + path;
            $route.reload();

        };
        $scope.getInvestmentStyle = function (marketCap, style) {
            var capitalValues = new Array(3);
            capitalValues['L'] = 'LARGE-CAP';
            capitalValues['M'] = 'MID-CAP';
            capitalValues['S'] = 'SMALL-CAP';
            var marketCapExists = false;
            var styleExists = false;
            if (marketCap === 'L' || marketCap === 'M' || marketCap === 'S') {
                marketCapExists = true;
            }
            if (style && style !== '' && typeof(style) !== 'undefined') {
                styleExists = true;
            }
            if (marketCapExists && styleExists) {
                return '' + capitalValues[marketCap] + ' ' + style;
            } else if (styleExists) {
                return '' + style;
            } else if (marketCapExists) {
                return '' + capitalValues[marketCap];
            } else {
                return '-';

            }
        };
        $scope.getRisk = function (risk, chartSection) {
            if (_.isEmpty(risk)) {
                return false;
            }
            risk = risk.toUpperCase();

            if ((risk === '1' || risk === 'LOW') && chartSection === 'LOW') {
                return true;
            }
            if ((risk === '2' || risk === 'AVERAGE' || risk === 'MEDIUM'  ) && (chartSection === 'AVERAGE' || chartSection === 'MEDIUM')) {
                return true;
            }
            if ((risk === '3' || risk === 'HIGH') && chartSection === 'HIGH') {
                return true;
            }
            return false;
        };
        $scope.getRiskColor = function (risk, chartSection, background) {
            if (!$scope.getRisk(risk, chartSection)) {
                return false;
            }
            if (background === 'g_bcg' && chartSection === 'LOW') {
                return true;
            }
            else if (background === 'y_bcg' && (chartSection === 'MEDIUM' || chartSection === 'AVERAGE')) {
                return true;
            }
            else if (background === 'r_bcg' && chartSection === 'HIGH') {
                return true;
            }
            else {
                return false;
            }
        };
        $scope.getQualRankingColor = function (rank, chartSection, background) {

            if (_.isEmpty(rank)) {
                return false;
            }
            if ((rank === 'A-' || rank === 'A' || rank === 'A+') && background === 'g_bcg' && chartSection === rank) {
                return true;
            }
            else if ((rank === 'B' || rank === 'B-' || rank === 'B+') && background === 'y_bcg' && chartSection === rank) {
                return true;
            }
            else if ((rank === 'D' || rank === 'C') && background === 'r_bcg' && chartSection === rank) {
                return true;
            }
            else {
                return false;
            }
        };
        $scope.getDocument = function (url, windowName) {
            // window.open( url, windowName,'resizable=yes');
            window.open(url, '_blank', 'resizable=yes');  //ie issues fr ticker like usb.c


        };

        /*---------------------------functions to load ----------------------------------*/
        $scope.failedStock = function () {
            $scope.error = 'Stock ' + $scope.ticker + ' is not available';
            $scope.viewState = $scope.states.NOT_FOUND;
        };
        $scope.sucessStock = function () {

        };
        $scope.loadStocks = function () {
            if (!$scope.reportType) {
                $scope.reportType = 'undefined';
            } else {
                if ($scope.reportType.toLowerCase() === 'quantitative' || $scope.reportType.toLowerCase() === 'quant') {
                    $scope.reportType = 'quant';
                } else if ($scope.reportType.toLowerCase() === 'qualitative' || $scope.reportType.toLowerCase() === 'qual') {
                    $scope.reportType = 'qual';
                } else if ($scope.reportType.toLowerCase() === 'none' || $scope.reportType.toLowerCase() === 'n') {
                    $scope.reportType = 'none';
                } else {
                    $scope.reportType = 'undefined';
                }
            }

            $scope.stockData = assetsResourceFactory.stockDetailsESResource.get({sppwid: $scope.sppwId}, $scope.sucessStock, $scope.failedStock);
            // what to reformat resource data as Elastic Search returns back deep level json objects like hits.hits[0]
            $scope.stockData.$promise.then(function (stockData) {
                $log.debug('stock promised return data');

                //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
                if (!stockData.hits || !stockData.hits.hits[0] || !stockData.hits.hits[0]._source) {
                    $scope.failedStock();
                } else if (!EntitlementService.apCon['quickviewLinks']['stock']($scope.stockData.hits.hits[0]._source.issued_region)){
                    // check entitlements of domestic and non domestic stock when getting back stock data - for users that enters stock directly in autosuggest
                    $scope.failedStock();
                }else {

                    $scope.stockData = stockData.hits.hits[0]._source;
                    $scope.showWatchlist = true;
                    $scope.selectedSppwids.push($scope.stockData.sppw_id);
                    $scope.stockData.star_rkng_derived_text = $scope.calculateStarRankText($scope.stockData.star_rkng);
                    $scope.viewState = $scope.states.LOADED;
                    $scope.starRankingExists = !_.isEmpty($scope.stockData.star_rkng) || _.isNumber($scope.stockData.star_rkng);
                    // figure out correct report type
                    if (!$scope.reportType || $scope.reportType === 'undefined') {
                        /// get the report ind from es
                        if ($scope.stockData.qual && $scope.stockData.qual.report_ind) {
                            $scope.reportType = 'qual';
                        } else if ($scope.stockData.quant && $scope.stockData.quant.report_ind) {
                            $scope.reportType = 'quant';
                        } else if ($scope.stockData.none && $scope.stockData.none.report_ind) {
                            $scope.reportType = 'none';
                        } else {
                            // no report_ind found, check on star ranking have star_ranking -> qual , else quant
                            if ($scope.stockData.star_rkng) {
                                $scope.reportType = 'qual';
                            } else {
                                $scope.reportType = 'quant';
                            }
                        }
                    }
                    var reportExists = !_.isEmpty($scope.stockData[$scope.reportType].issue_reports) && !_.isEmpty($scope.stockData[$scope.reportType].issue_reports.report_type);


                    //quant stock if (report exist & reporttype quant) , (if report doesnt exist & star rank doesnt exist)
                    $scope.quantFlag = (reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'QUANT') || (!reportExists && !$scope.starRankingExists);
                    //qual  stock if (report exist & reporttype qual) , (if report doesnt exist & star rank   exists)

                    $scope.qualFlag = (reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'QUAL') || (!reportExists && $scope.starRankingExists);
                    $scope.noReportIndicatorFlag = reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'NONE';

                    $scope.quantButHasStarRankFlag = reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'QUANT' && $scope.starRankingExists;//  read point 4  above

                    $scope.euroAsiaFlag = ($scope.stockData.issued_region === 'EUROPE' || $scope.stockData.issued_region === 'ASIA');

                    if ($scope.stockData.issued_region === 'US') {
                        $scope.layout = $scope.layoutConstants.TABBED_LAYOUT;
                    }
                    else {     //rest
                        $scope.layout = $scope.layoutConstants.UNTABBED_LAYOUT;
                    }


                }

            });

        };

        /*------------------------------- code starts here ----------------------------------------------*/

        $scope.sppwId = $scope.modelParam.sppwId;
        $scope.ticker = $scope.modelParam.ticker;
        $scope.type = $scope.modelParam.type;
        $scope.reportType = $scope.modelParam.report_ind;
        if (_.isEmpty($scope.sppwId) && !_.isNumber($scope.sppwId)) { //beacuse _.isEmpty() returns true for numbers :((

            var url = AutoSuggestService.getSearchList('/es/ac/power_search/_search?pretty=true&q=ticker', $scope.ticker);
            $resource(url).get().$promise.then(function (data) {
                var tickerList = AutoSuggestService.parseResponse(data,false);
                // grab the first matching at index[0]
                $scope.sppwId = tickerList[0].sppw_id || '';
                if (!$scope.reportType) {
                    $scope.reportType = tickerList[0].report_ind || 'none';
                }
                $scope.loadStocks();
            });
        } else {
            $scope.loadStocks();
        }
    }

);
