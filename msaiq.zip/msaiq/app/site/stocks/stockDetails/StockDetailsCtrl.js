'use strict';

msaiqApp.controller('StockDetailsCtrl', function ($scope, $log, $routeParams, assetsResourceFactory, ArticleMessaging,$window, $location, $route,_,$filter, $) {
    $scope.testThis=function(d) {
        return $filter('epsNextDateRenderer')(d,null);
    }
    $scope.$emit('menuShow','Stocks');
    $scope.w=$window;
    $log.debug('Entered StockDetailsCtrl');
    $scope.ticError=$routeParams.ticker;

    if (typeof($routeParams.ticker) === 'string' && $routeParams.ticker.indexOf("*") != -1)  {
        $scope.ticker = $routeParams.ticker; // to be use in html
    }
    $scope.sppwId = $routeParams.sppwId;
    $scope.type = $routeParams.type;
    $scope.pageRequest=$routeParams.pageRequest;
    if (!$routeParams.report_ind){
        $scope.reportType = 'undefined';
    }else{
        if ($routeParams.report_ind.toLowerCase() === 'quantitative' || $routeParams.report_ind.toLowerCase() === 'quant'){
            $scope.reportType =  'quant';
        }else if ($routeParams.report_ind.toLowerCase() === 'qualitative' || $routeParams.report_ind.toLowerCase() === 'qual'){
            $scope.reportType = 'qual';
        }else if ($routeParams.report_ind.toLowerCase() === 'none' || $routeParams.report_ind.toLowerCase() === 'n') {
            $scope.reportType = 'none';
        } else {
            $scope.reportType = 'undefined';
        }
    }

    var STAR_RANKS = ['not ranked', 'Strong Sell', 'sell', 'hold', 'buy', 'strong buy'];

    $scope.states = {
        LOADING: 0,
        LOADED: 2,
        NOT_FOUND: 1
    };
    $scope.layoutConstants = {
        TABBED_LAYOUT: 1,
        UNTABBED_LAYOUT: 2
    };

    $scope.Math = window.Math;
    $scope.Date = window.Date;


    $scope.getDocument = function () {
        var url = '/SP/msa/reports.pdf?reportURL=' + $scope.stockData[$scope.reportType].issue_reports.report_url + '&region=' + $scope.stockData.issued_region;
        window.open(url);
    };

    $scope.viewState = $scope.states.LOADING;

    $scope.failedStock = function(){
        $scope.error = 'Stock ' + $scope.ticker + ' is not available';
        $scope.viewState = $scope.states.NOT_FOUND;
    };

    $scope.sucessStock = function(){

    };
    $scope.stockData = assetsResourceFactory.stockDetailsESResource.get({sppwid: $routeParams.sppwId},  $scope.sucessStock, $scope.failedStock );


    //TODO var stockTicker = ($routeParams.ticker);
    var message = {articleId: null, instruments: [{sppwId:$routeParams.sppwId, tickerSymbol:$routeParams.ticker}]};

    ArticleMessaging.broadcastArticleLoaded($scope, message);

/*
    $scope.stockData1.$promise.then(function (stockData1) {

    });
*/
    // what to reformat resource data as Elastic Search returns back deep level json objects like hits.hits[0]
    $scope.stockData.$promise.then(function (stockData) {
        $log.debug('stock promised return data');

        //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
        if (!stockData.hits || !stockData.hits.hits[0] || !stockData.hits.hits[0]._source) {
            $scope.failedStock();
        } else {
            $scope.stockData = stockData.hits.hits[0]._source;
            $scope.stockData.star_rkng_derived_text = $scope.calculateStarRankText($scope.stockData.star_rkng);

            $scope.viewState = $scope.states.LOADED;

            $scope.starRankingExists = !_.isEmpty($scope.stockData.star_rkng)  || _.isNumber($scope.stockData.star_rkng) ;


            // figure out correct report type
            if (!$scope.reportType || $scope.reportType === 'undefined'){
                 /// get the report ind from es
                if ($scope.stockData.qual && $scope.stockData.qual.report_ind) {
                    $scope.reportType = 'qual';
                } else if ($scope.stockData.quant && $scope.stockData.quant.report_ind ) {
                    $scope.reportType = 'quant';
                } else if ($scope.stockData.none && $scope.stockData.none.report_ind){
                    $scope.reportType = 'none';
                } else{
                    // no report_ind found, check on star ranking have star_ranking -> qual , else quant
                    if ($scope.stockData.star_rkng){
                        $scope.reportType = 'qual';
                    }else{
                        $scope.reportType = 'quant';
                    }
                }
            }

            var reportExists = !(_.isEmpty($scope.stockData[$scope.reportType].issue_reports)) && !(_.isEmpty($scope.stockData[$scope.reportType].issue_reports.report_type));
            //quant stock if (report exist & reporttype quant) , (if report doesnt exist & star rank doesnt exist)
            $scope.quantFlag = (reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'QUANT') || (!reportExists && !$scope.starRankingExists);
            //qual  stock if (report exist & reporttype qual) , (if report doesnt exist & star rank  exists)
            $scope.qualFlag = (reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'QUAL') || (!reportExists && $scope.starRankingExists);
            $scope.noReportIndicatorFlag = reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type  === 'NONE';
            $scope.quantButHasStarRankFlag = reportExists && $scope.stockData[$scope.reportType].issue_reports.report_type === 'QUANT' && $scope.starRankingExists;//  read point 4  above
            $scope.euroAsiaFlag = ($scope.stockData.issued_region === 'EUROPE' || $scope.stockData.issued_region === 'ASIA');

            var message = {articleId: null, instruments: [{sppwId:$routeParams.sppwId, tickerSymbol:$scope.stockData.tik_symbl,isin:$scope.stockData[$scope.reportType].isin}]};
            ArticleMessaging.broadcastArticleLoaded($scope, message);

            if ($scope.stockData.issued_region === 'US') {
                $scope.layout = $scope.layoutConstants.TABBED_LAYOUT;
            }
            else {     //rest
                $scope.layout = $scope.layoutConstants.UNTABBED_LAYOUT;
            }


        }
        // broadcast down for ministock to refresh data
        $scope.$broadcast('reloadMiniStockWithReport', $scope.sppwId, $scope.reportType);
    });

    //*****************---utilities---------------------------------//
    $scope.calculateStarRankText = function (starRank) {
        var starRankText = '';

        switch (starRank) {
            case 1:
                starRankText = STAR_RANKS[1];
                break;
            case 2:
                starRankText = STAR_RANKS[2];
                break;
            case 3:
                starRankText = STAR_RANKS[3];
                break;
            case 4:
                starRankText = STAR_RANKS[4];
                break;
            case 5:
                starRankText = STAR_RANKS[5];
                break;
            default:
                starRankText = STAR_RANKS[0];
        }


        return starRankText;
    };


    $scope.getInvestmentStyle = function (marketCap, style) {
        var capitalValues = new Array(3);
        capitalValues['L'] = 'LARGE-CAP';
        capitalValues['M'] = 'MID-CAP';
        capitalValues['S'] = 'SMALL-CAP';
        var marketCapExists = false;
        var styleExists = false;
        if (marketCap === 'L' || marketCap === 'M' || marketCap === 'S') {
            marketCapExists = true;
        }
        if (style && style !== '' && typeof(style) !== 'undefined') {
            styleExists = true;
        }
        if (marketCapExists && styleExists) {
            return '' + capitalValues[marketCap] + ' ' + style;
        } else if (styleExists) {
            return '' + style;
        } else if (marketCapExists) {
            return '' + capitalValues[marketCap];
        } else {
            return '-';

        }
    };
    $scope.getRisk = function (risk, chartSection) {
        if(_.isEmpty(risk)) {
            return false  ;
        }
        risk = risk.toUpperCase();

        if ((risk === '1' || risk === 'LOW') && chartSection === 'LOW') {
            return true;
        }
        if ((risk === '2' || risk === 'AVERAGE' || risk === 'MEDIUM'  ) && (chartSection === 'AVERAGE' || chartSection === 'MEDIUM')) {
            return true;
        }
        if ((risk === '3' || risk === 'HIGH') && chartSection === 'HIGH') {
            return true;
        }
        return false;
    };
    $scope.getRiskColor = function (risk, chartSection,background) {
        if (!$scope.getRisk(risk, chartSection)){
            return false;
        }
         if(background === 'g_bcg' && chartSection === 'LOW') {
           return true;
         }
        else if (background === 'y_bcg'&& (chartSection === 'MEDIUM' ||  chartSection === 'AVERAGE'))  {
             return true;
         }
        else if (background === 'r_bcg' && chartSection === 'HIGH')  {
             return true;
         }
        else {
             return false;
         }
    };
    $scope.endOfFiscalMonthRenderer= function(val){
        var month='';
        switch(val){
            case 'JA':
                month = 'Jan.31';
                break;
            case 'FB':
                month = 'Feb.28';
                break;
            case 'MR':
                month = 'Mar.31';
                break;
            case 'AP':
                month = 'Apr.30';
                break;
            case 'MY':
                month = 'May.31';
                break;
            case 'JE':
                month = 'Jun.30';
                break;
            case 'JL':
                month = 'Jul.31';
                break;
            case 'AU':
                month = 'Aug.31';
                break;
            case 'SP':
                month = 'Sep.30';
                break;
            case 'OC':
                month = 'Oct.31';
                break;
            case 'NV':
                month = 'Nov.30';
                break;
            case 'DC':
                month = 'Dec.31';
                break;
            default:
                month = '-';
                break;
        }
        return month;
    }

    $scope.getQualRankingColor = function (rank, chartSection,background) {

        if(_.isEmpty(rank)) {
            return false  ;
        }
        if((rank === 'A-' || rank === 'A' || rank === 'A+')  && background === 'g_bcg' && chartSection === rank ) {
            return true;
        }
        else if((rank === 'B' || rank === 'B-' || rank === 'B+') && background === 'y_bcg' && chartSection === rank) {
            return true;
        }
        else if((rank === 'D' || rank === 'C')&& background === 'r_bcg' && chartSection === rank) {
            return true;
        }
        else {
            return false;
        }
    };

    /* close model and then change route. */
    $scope.goTo = function(path){
        $scope.$modalClose();

        $location.path(path);
        $window.location.href =  '#'+path;
        $route.reload();

    };


    $scope.convertFormat = function(dateVal)
    {
        return new Date(dateVal.replace('. ','')+' 2012');
    };

    // ranking from 1-5; quality A+ to D; page adjust accordingly if increase ranking
    $scope.fairValueRankingArray = [1,2,3,4,5];
    $scope.qualityRankingArray = ['D', 'C', 'B-', 'B', 'B+', 'A-', 'A', 'A+'];
    $scope.relStrengthArray = ['LOW', 'MEDIUM', 'HIGH'];
    $scope.riskStrengthArray = ['LOW', 'AVERAGE', 'HIGH'];
});