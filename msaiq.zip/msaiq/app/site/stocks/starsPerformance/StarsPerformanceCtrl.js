'use strict';

msaiqApp.controller('StarsPerformanceCtrl', function ($scope, $log, articleResourceFactory, $) {

    $scope.starPerformanceResource = articleResourceFactory.articleLandingPageResource.get({articleCode:'STRSP'});
    $scope.starPerformanceResource.$promise.then(function(data){
        $scope.tableData = {};  /* Composite Object for refined data */
        $log.info('Data Received StarsPerformanceCtrl');
        $scope.tableData.header = data.star_perf_table.rows[0];
        $scope.tableData.data   = data.star_perf_table.rows.splice(1,data.star_perf_table.rows.length);
        $scope.tableData.title  = (data.Title && data.Title.paragraphs) ?
                        data.Title.paragraphs[0] : '';
    });
});