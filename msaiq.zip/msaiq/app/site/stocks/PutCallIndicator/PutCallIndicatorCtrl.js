'use strict';

msaiqApp.controller('PutCallIndicatorCtrl', function ($scope, $log, articleResourceFactory) {
  $scope.putCallIndicatorData = articleResourceFactory.articleDataResource.get({articleCode:'PCIND',start:'0',limit:'2'});
});