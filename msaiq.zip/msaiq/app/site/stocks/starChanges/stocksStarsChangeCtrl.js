'use strict';

msaiqApp.controller('stocksStarsChangeCtrl', function ($scope, $location,  $log, ngTableParams, articleResourceFactory,$) {
    $scope.starsChangesArgs = {activeTab: 'CUSTOM'};
    $scope.searchStockChangeParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { starRankDate: 'desc' } };
    $scope.selectedSppwids =[];
    $scope.showWatchlist = false;
    $scope.clickTab = function (tab){
        $scope.starsChangesArgs.activeTab = tab;
    };

    $scope.$watch('searchStockChangeParams', function(params,oldParams) {
        if(oldParams.page === params.page && $scope.searchStockChangeParams.total !== 0)
        {
            return;
        }
        $scope.searchStockChangeResource  = articleResourceFactory.stocksStarsChangeResource.get({start: (params.page-1) * params.count,limit:params.count});
        $scope.loading = true;
        $scope.searchStockChangeResource.$promise.then(function(starStockData){
            $scope.searchStockChangeParams.total = $scope.totalNumOfRecords = starStockData.total_records;
            /*for(var i=0; i < starStockData.equities.length; i++){
                starStockData.equities[i].starRankDate = Date.parse(starStockData.equities[i].starRankDate.split('-').join('/'));
            }*/
            $scope.loading = false;
            $scope.starsChangesList =  starStockData;
            var printArray = [];
            var countIndex = $scope.totalNumOfRecords/1000;
            for(var index=0;index<countIndex;index++)
            {
                var dataObject = {};
                dataObject.displayLine  = 'Rows '+((index*1000)+1)+'-'+(index+1)*1000;
                dataObject.link  =  '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=nextStarRank&screenerParameters%5B0%5D.propertyLabel=New%20Ranking&screenerParameters%5B0%5D.operation1Value=%23%23NO_OPERATION%23%23&screenerParameters%5B0%5D.customRenderer=starRankRenderer&screenerParameters%5B1%5D.propertyName=previousStarRank&screenerParameters%5B1%5D.propertyLabel=Old%20Ranking&screenerParameters%5B1%5D.operation1Value=%23%23NO_OPERATION%23%23&screenerParameters%5B1%5D.customRenderer=starRankRenderer&screenerParameters%5B2%5D.propertyName=starRankDate&screenerParameters%5B2%5D.propertyLabel=Date&screenerParameters%5B2%5D.operation1Value=%23%23NOT_NULL%23%23&screenerParameters%5B2%5D.customRenderer=dateRenderer&screenerParameters%5B3%5D.propertyName=starRank&screenerParameters%5B3%5D.propertyLabel=Research%20Notes%20Link&screenerParameters%5B3%5D.operation1Value=90&screenerParameters%5B3%5D.customRenderer=researchNotesLinkRenderer&screenerParameters%5B3%5D.nativeCondition=((issue_typ%20is%20null%20or%20issue_typ!%3D\'Pre\')%20and%20STAR_RKNG_DT%20%3E%20(sysdate%20-%20operation1Value))&start='+((index*1000))+'&limit='+(((index+1)*1000))+'&equityType=STOCKS&addnlSortParameters%5B0%5D.sortProperty=sortableNextStarRank&addnlSortParameters%5B0%5D.sortDirection=DESC&sort=starRankDate&dir=DESC&criteriaMessage='+'STARS Changes';
                printArray.push(dataObject);
            }
            $scope.printArray = printArray;
        });
    }, true);

    $scope.clickTab($scope.starsChangesArgs.activeTab);

    $scope.openDetails = function(data) {
        $scope.researchArticle = articleResourceFactory.stocksStarsChangeResearchResource.get({symbol:data.symbol,starRankDate:data.starRankDate, starRank:data.starRank, sppwId:data.sppwId});

        $scope.researchArticle.$promise.then(function(researchArticle){
            $log.info(researchArticle.articleDetails.articleCode +'  '+ researchArticle.articleDetails.articleId);
            $scope.articleId= researchArticle.articleDetails.articleId;
            $location.path('/marketscope/researchNotesDetails/RNOTS/'+$scope.articleId);
        });
    };

    $scope.handleCheckBoxChange=function(event,data,sppwId,securityName){
        if(data.isin){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.starsChangesList.equities,function(item){
                item.isin = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.starsChangesList.equities, function(item) {
            if (angular.isDefined(item.isin)) {
                item.isin = checked;
                if(item.isin){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };
});