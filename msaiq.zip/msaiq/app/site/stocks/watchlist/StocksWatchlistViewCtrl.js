'use strict';

msaiqApp.controller('StocksWatchlistViewCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory, QuickViewService,$,$rootScope) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.stockWatchListChangesArgs = {activeTab: 'CUSTOM'};
    $scope.title = $rootScope.watchlistTitleForPrerolled;
    $scope.stockWatchListTableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { starRankDate: 'desc' } };
    $scope.sppwIds = $routeParams.sppwIds;
    $scope.selectedSppwids =[];
    $scope.showWatchlist = false;

    $scope.clickTab = function (tab){
        $scope.stockWatchListChangesArgs.activeTab = tab;
    };

    /*$scope.openQV = function(sppwId, ticker, report_ind, type){
     QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
     };*/
    $scope.creatingFormParams = function(params){
        var formData = {};
        formData['start'] =  (params.page-1) * params.count;
        formData['screenerParameters[0].propertyName'] = 'id';
        formData['screenerParameters[0].operation1Value'] = $scope.sppwIds;
        formData['screenerParameters[0].customRenderer']= 'idRenderer';
        formData['limit'] = params.count;
        formData['equityType'] = 'STOCKS';
        formData['sort'] = 'securityName';
        formData['dir'] = 'ASC';
        return formData
    };

    if($scope.sppwIds != "-1"){

        $scope.$watch('stockWatchListTableParams', function(params,oldParams) {
            if(oldParams.page === params.page && $scope.stockWatchListTableParams.total !== 0) { return; }
            $scope.stockWatchListResource  = articleResourceFactory.assetWatchlistResource.postReq($scope.creatingFormParams(params));
            $scope.loading = true;
            $scope.stockWatchListResource.$promise.then(function(stockWatchListData){
                $scope.stockWatchListTableParams.total = $scope.totalNumOfRecords = stockWatchListData.total_records;
                /*for(var i=0; i < stockWatchListData.equities.length; i++){
                 stockWatchListData.equities[i].starRankDate = Date.parse(stockWatchListData.equities[i].starRankDate.split('-').join('/'));
                 }*/
                $scope.loading = false;
                $scope.viewState = $scope.states.LOADED;
                $scope.stockWatchListData =  stockWatchListData;
                var printArray = [];
                var countIndex = $scope.totalNumOfRecords/1000;
                for(var index=0;index<countIndex;index++) {
                    var dataObject = {};
                    dataObject.displayLine  = 'Rows '+((index*1000)+1)+'-'+(index+1)*1000;
                    dataObject.link  =  '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=id&screenerParameters%5B0%5D.operation1Value='+ $scope.sppwIds+'&screenerParameters%5B0%5D.customRenderer=idRenderer&start=0&limit=200&equityType=STOCKS&sort=securityName&dir=ASC&criteriaMessage=Watchlist search: '+$scope.title;
                    printArray.push(dataObject);
                }
                $scope.printArray = printArray;
            });
        }, true);
    } else{
        $scope.stockWatchListData =  [];
        $scope.loading = false;
        $scope.viewState = $scope.states.LOADED;
    }

    $scope.handleCheckBoxChange=function(event,data,sppwId,securityName){
        if(data.isin){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };
    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.stockWatchListData.equities, function(item) {
            if (angular.isDefined(item.isin)) {
                item.isin = checked;
                if(item.isin){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.stockWatchListData.equities,function(item){
                item.isin = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);

    $scope.clickTab($scope.stockWatchListChangesArgs.activeTab);
});
