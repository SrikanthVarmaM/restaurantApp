/**
 * Created by meenakshinagpal on 5/22/14.
 */
'use strict';


msaiqApp.controller('IndicesCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.viewState = $scope.states.LOADING;

    $scope.currentTime=new Date().getTime();
    $scope.indicesRawData = articleResourceFactory.indicesDetailsDataResource.get({requestType:'indexhome'});
    $scope.indicesRawData.$promise.then(function(indicesData){

        $scope.indicesData=$scope.indicesRawData;
        $scope.viewState = $scope.states.LOADED;

    });


});