'use strict';


msaiqApp.controller('IndicesDetailsCtrl', function ($scope,  $log, $routeParams, ngTableParams ,articleResourceFactory,  QuickViewService, $location,$) {

    $scope.indicesActive= 'VITALSTATISTICS';

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.viewState = $scope.states.LOADING;

    $scope.currentTime=new Date().getTime();

    $scope.indicesDetailsRawData = articleResourceFactory.indicesDataResource.get({requestType:'indexDetail',sppwId:$routeParams.sppwid});
    $scope.indicesDetailsRawData.$promise.then(function(indicesDetailsData){

        $scope.indicesDetailsData=$scope.indicesDetailsRawData;
        $scope.imageUrl='/SP/msa/servlet/prophetCharts.html?symbol='+$scope.indicesDetailsData.chartLink+'&isSecure=false&chartStyle=1&clearCache=0&currentTime='+ $scope.currentTime;
        $scope.viewState = $scope.states.LOADED;

    });
    $scope.tableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' } };

    $scope.$watch('tableParams', function(params) {

        $scope.indicesStockRaw = articleResourceFactory.indicesStockDataResource.get({start: (params.page-1) * params.count , operationValue:$routeParams.sppwid});
        $scope.indicesStockRaw.$promise.then(function(indicesStock){
            $scope.tableParams.total = $scope.indicesStockRaw.total_records;
            $scope.indicesStock= $scope.indicesStockRaw.equities;

        });
    }, true);

    $scope.showTemplate = function (tab) {
        $scope.indicesActive = tab;
        if (tab === 'CONSTITUENTS') {
            $scope.indicesStockRaw = articleResourceFactory.indicesStockDataResource.get({start:'0' , operationValue:$routeParams.sppwid});
            $scope.indicesStockRaw.$promise.then(function(indicesStock){
                $scope.tableParams.total = $scope.indicesStockRaw.total_records;
                $scope.indicesStock= $scope.indicesStockRaw.equities;

            });
        }
    };

    $scope.openQV = function(sppwId, ticker, report_ind, type){
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'Fund').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
    };
    $scope.goTo = function(path){
        // close model and then change route.
        $location.path(path);

    };
});