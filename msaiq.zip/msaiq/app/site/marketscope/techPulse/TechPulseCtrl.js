'use strict';


msaiqApp.controller('TechPulseCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {

    $scope.techPulsesResource = articleResourceFactory.articleDataResource.get({articleCode:'ETECP', start: 0, limit: 3});

});