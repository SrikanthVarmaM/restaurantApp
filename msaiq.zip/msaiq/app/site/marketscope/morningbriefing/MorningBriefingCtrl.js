'use strict';

msaiqApp.controller('MorningBriefingCtrl', function ($scope,  $log, $routeParams, articleResourceFactory, QuickViewService,$rootScope){

    $scope.morningBriefingHomeArgs = {articleCode:'MBRIF', activeTab: 'US'};
    $scope.showWatchlist = false;
    $scope.selectedSppwIdsObj ={
        selectedSppwIds : []
    };
    $scope.QuickViewService = QuickViewService;

    $scope.getData = function (tab){
        $scope.morningBriefingHomeArgs.activeTab = tab;
        if (tab === 'US'){
            $scope.morningBriefingHomeArgs.articleCode = 'MBRIF';
            $scope.morningBriefingData = articleResourceFactory.morningBriefingPageResource.get({articleCode:$scope.morningBriefingHomeArgs.articleCode,isSpotLightPage:false});
            $scope.morningBriefingData.$promise.then(function(data){
                angular.forEach(data.symbolsMentioned,function(item){
                     item['checkLink'] = false;
                });
                $scope.morningBriefingData = data;
            });
        }
    };
    $scope.getData($scope.morningBriefingHomeArgs.activeTab);

    $scope.goTo = function(articleId,attachmentName){
        var url='/SP/msa/articleAttachment.pdf?articleId='+articleId+'&attachmentName='+attachmentName;
       window.open(url);
        // Google anaytics code to track PDF downloaded
        ga('send', 'pageview', {
            'page': url,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        // Google Analytics Code ENDs
      //$location.path('/SP/msa/articleAttachment.pdf?articleId='+articleId+'&attachmentName='+attachmentName);
    };

    $scope.handleCheckBoxChange = function(checkLink, sppwid){
        if(checkLink){
            $scope.selectedSppwIdsObj.selectedSppwIds.push(sppwid);
        }else{
            $scope.selectedSppwIdsObj.selectedSppwIds.splice( $scope.selectedSppwIdsObj.selectedSppwIds.indexOf(sppwid), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwIdsObj.selectedSppwIds.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwIdsObj.selectedSppwIds',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.morningBriefingData.symbolsMentioned,function(item){
                item.checkLink = false;
            });
            $scope.showWatchlist  = false;
        }
    },true);

}) ;