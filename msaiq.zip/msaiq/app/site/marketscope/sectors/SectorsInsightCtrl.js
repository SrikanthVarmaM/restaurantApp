'use strict';

msaiqApp.controller('SectorsInsightCtrl', function (ngTableParams, $scope,  $log, articleResourceFactory) {
    $scope.tableParams = {
        page: 1,        // show first page
        count: 20,      // records for page
        total:0,        // count per page
        counts : []     // hide page counts control
    };
    $scope.loading = true;
    $scope.$watch('tableParams', function(params) {
        $scope.sectorInsightRawData = articleResourceFactory.articleIdDataResource.get({articleCode: 'ESECI',articleId:$scope.articleId,start: (params.page-1) * params.count,limit:params.count});
        $scope.sectorInsightRawData.$promise.then(function(sectorInsightRawData){
            $scope.tableParams.total = sectorInsightRawData.total_records;
            $scope.sectorInsightData =  sectorInsightRawData.articles;
            $scope.loading = false;
        });
    }, true);
});
