'use strict';

msaiqApp.controller('SectorsSurveysCtrl', function (ngTableParams,$scope,  $log, $routeParams, articleResourceFactory) {
    $scope.surveyType =  $routeParams.surveyType;
    if($scope.surveyType === 'GLOBAL SURVEYS') {
        $scope.region = 'ASIA,EUROPE,CANADA,LATAM';
        $scope.entitlementKey = 'downloadReportsLink.globalIndSurv';
    } else{
        $scope.region = 'US';
        $scope.entitlementKey = 'downloadReportsLink.usIndSurv';
    }
    $scope.tableParams = {
        page: 1,        // show first page
        count: 20,      // records for page
        total:0,        // count per page
        counts : [],     // hide page counts control
        sorting: {
            surveyName: 'asc' // for sort icon
        }
    };
    $scope.loading = true;
    $scope.$watch('tableParams', function(params) {
        $scope.sectorSurveyRawList = articleResourceFactory.sectorFullIndustryReports.get({region:$scope.region,start: (params.page-1) * params.count,limit:params.count});
        $scope.sectorSurveyRawList.$promise.then(function(sectorSurveyRawList){
            $scope.tableParams.total = sectorSurveyRawList.total_records;
            $scope.sectorSurveyList =  sectorSurveyRawList.industryReports;
            $scope.loading = false;
        });
    }, true);
});