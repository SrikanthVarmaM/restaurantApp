'use strict';

msaiqApp.controller('SectorsArticleDetailsCtrl', function ($scope,  $log, articleResourceFactory,$routeParams) {
    $scope.articleId = $routeParams.articleId;
    $scope.sectorArticleData = articleResourceFactory.articleIdDataResource.get({articleCode: 'STOVL',articleId:$scope.articleId,start: 0,limit:1});
});