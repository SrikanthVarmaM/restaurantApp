'use strict';

msaiqApp.controller('SubSectorArticleDetailsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {
    $scope.gicCd = $routeParams.gicCd;
    $scope.sectorName =  $routeParams.sectorName;
    $scope.sectorDetail = $routeParams.sectorDetail;
    $scope.sectorEvaluation = [];
    $scope.loading = true;
    $scope.sectorArticleDetails = articleResourceFactory.sectorDetailsResource.get({gicCd:$scope.gicCd,sectorName:$scope.sectorName,sectorDetail:$scope.sectorDetail});
    $scope.sectorArticleDetails.$promise.then(function(sectorArticleDetails){
        var i =0;
        for(var key in sectorArticleDetails.sectorEvaluationSummary) {
            $scope.sectorEvaluation[i] = sectorArticleDetails.sectorEvaluationSummary[key];i++;
        }
        $scope.sectorArticleDetails = sectorArticleDetails;
        $scope.loading = false;
    });
});