'use strict';

msaiqApp.controller('SectorsSTOVLArticleDetailsCtrl', function ($scope,  $log, articleResourceFactory,$routeParams) {
    $scope.articleId = $routeParams.articleId;
    $scope.loading = true;
    $scope.sectorArticleDetailsData = articleResourceFactory.articlesDetailsResource.get({articleCode: 'STOVL',articleId:$scope.articleId});
});
