'use strict';

msaiqApp.controller('SectorDetailsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {
    $scope.gicCd =  $routeParams.gicCd;
    $scope.sectorName =  $routeParams.sectorName;
    $scope.sourceGicCd = $routeParams.sourceGicCd;
    $scope.inudstryDesc = $routeParams.inudstryDesc;
    $scope.sectorCode = $scope.gicCd.substring(0,2);
    //$scope.formDataParam = 'DESC&equityType=STOCKS&screenerParameters[0].conjunctionType=and&screenerParameters[0].inferedPropertyName=starRank&screenerParameters[0].operation1Value=4&screenerParameters[0].operator1Type=>=&screenerParameters[0].operator2Type=<=&screenerParameters[0].propertyName=starRank&screenerParameters[1].inferedPropertyName=sectorName&screenerParameters[1].propertyName=sectorCode&screenerParameters[2].inferedPropertyName=subIndustryName&screenerParameters[2].propertyName=subIndustryCode&screenerParameters[3].propertyName=issuedRegion&screenerParameters[3].inferedPropertyName=issuedRegion&screenerParameters[3].operation1Value=US,&addnlSortParameters[0].sortProperty=securityName&addnlSortParameters[0].sortDirection=ASC&sort=starRank';
    $scope.formDataParam = 'DESC&equityType=STOCKS&screenerParameters[0].conjunctionType=and&screenerParameters[0].inferedPropertyName=starRank&screenerParameters[0].operation1Value=4&screenerParameters[0].operator1Type=>=&screenerParameters[0].operator2Type=<=&screenerParameters[0].propertyName=starRank&screenerParameters[1].inferedPropertyName=sectorName&screenerParameters[1].propertyName=sectorCode&screenerParameters[2].inferedPropertyName=subIndustryName&screenerParameters[2].propertyName=subIndustryCode&screenerParameters[3].propertyName=issuedRegion&screenerParameters[3].inferedPropertyName=issuedRegion&screenerParameters[3].operation1Value=US,&addnlSortParameters[0].sortProperty=securityName&addnlSortParameters[0].sortDirection=ASC&sort=starRank';
    $scope.noResultMsgLower = 'S&P Capital IQ does not maintain a four or five STARS recommendation on any of the companies within this sub-industry at the present time.';
    $scope.noStockResultMsgLower='You are not currently entitled to see detailed information on this page. Please call one of our MarketScope Advisor Product Specialists at 1-877-219-1247 for more information or to learn more about additional subscription packages';
    $scope.sectorDetailsByGICData = articleResourceFactory.sectorScreenResults.get({gicCd:$scope.gicCd,sectorCode:$scope.sectorCode,formDataParam:$scope.formDataParam});
 });