'use strict';

msaiqApp.controller('SectorsDetailsCtrl', function ($scope,  $log, articleResourceFactory,$rootScope,ga) {
    $scope.loading = true;
    //Industry reports for EUROPE region survey data
    $scope.sectorIndustryReportEUROPE = articleResourceFactory.sectorIndustryReports.get({region: 'ASIA,EUROPE,CANADA,LATAM',start:0,limit:5});
    //Industry reports for US region  survey data
    $scope.sectorIndustryReportUS = articleResourceFactory.sectorIndustryReports.get({region: 'US',start:0,limit:5});
    //Article details for STOVL article
    $scope.sectorArticleDataSTOVL = articleResourceFactory.articleDataResource.get({articleCode: 'STOVL',start:0,limit:1});
    $scope.sectorArticleDataSTOVL.$promise.then(function(sectorArticleDataSTOVL){

        var date = new Date(Date.parse(sectorArticleDataSTOVL.lastPublishDate.replace(/\-/ig, '/').split('.')[0]));
        $scope.STOVLdate = date;
        $scope.sectorArticleDataSTOVL = sectorArticleDataSTOVL;
        $scope.loading = false;
    });
    //pdf report
    $scope.sectorTAndIPDFReport = articleResourceFactory.sectorTrendsAndIdeasPDFReport.get({region: 'US'});

    $scope.sendGa=function(url){

        $log.info('cookie my favourite'+url);

        ga('send', 'pageview', {
            'page': url,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        window.open(url, '_blank', 'resizable=yes');
    };


});