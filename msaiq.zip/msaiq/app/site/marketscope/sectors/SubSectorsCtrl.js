'use strict';

msaiqApp.controller('SubSectorsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {
    $scope.gicCd =  $routeParams.gicCd;
    var length = 750;
    $scope.sectorName =  $routeParams.sectorName;
    $scope.sectorDetail = 'sectorDetail';
    $scope.sectorEvaluation = [];
    $scope.loading = true;
    $scope.scorecards =  [];
    //for showing another pop up for download reports
        $scope.showUSServey = 0;
        $scope.showEUROPEServey = 0;

    $scope.sectorDetailsRawData = articleResourceFactory.sectorDetailsResource.get({gicCd:$scope.gicCd,sectorName:$scope.sectorName,sectorDetail:$scope.sectorDetail});
    $scope.sectorDetailsRawData.$promise.then(function(sectorDetailsRawData){
        $scope.sectorText = sectorDetailsRawData.overview.text.substring(0,length-1);
        // for getting sector evaluation value (json data map key name contained with spaces like..."TECHNICAL OUTLOOK" )
            var i =0;
            for(var key in sectorDetailsRawData.sectorEvaluationSummary) {
                $scope.sectorEvaluation[i] = sectorDetailsRawData.sectorEvaluationSummary[key];i++;
            }
        $scope.scorecards = $scope.removeDuplicate(sectorDetailsRawData.scorecards);
        $scope.sectorDetailsRawData = sectorDetailsRawData;
        $scope.loading = false;
    });

    $scope.removeDuplicate = function(rawData){
        var result = [];
        var uniqueResult = [];
        angular.forEach(rawData, function(item){
            angular.forEach(item.report, function(data){
                if(result.indexOf(data.reportURL) < 0) {
                    result.push(data.reportURL);
                    uniqueResult.push(data);
                    if(data.region === 'US'){ $scope.showUSServey++; }
                    if(data.region === 'EUROPE' || data.region === 'ASIA'){ $scope.showEUROPEServey++; }
                }
            });
        });
        return uniqueResult;
    };
});