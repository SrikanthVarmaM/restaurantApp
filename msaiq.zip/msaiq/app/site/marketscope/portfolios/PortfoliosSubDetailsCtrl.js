'use strict';

msaiqApp.controller('PortfoliosSubDetailsCtrl', function ($scope, $log, $routeParams, articleResourceFactory, $filter,$location){


    $scope.portfolioCode = $routeParams.portfolioCode;
    $scope.subPortfolioTitle = $routeParams.subPortfolioTitle.split('~').join('/');
    $scope.innerTableFormation = false;
    $scope.currentLoading = false;
    $scope.deletedLoading = false;
    $scope.loading =true;
    var entityTypeMap = $filter('findEntityType');

    if($routeParams.activeTab === 'COMPONENTS'){
        $scope.portfoliosHomeArgs = {activeTab: 'PERFORMANCE'};
    } else if($routeParams.activeTab === 'DELETES'){
        $scope.portfoliosHomeArgs = {activeTab: 'DELETED'};
    } else {
        $scope.portfoliosHomeArgs = {activeTab: 'CURRENT'};
    }

    $scope.portfolioDetailResource = articleResourceFactory.msaPortfolioInfoResource.get({key: 'ALL_PORTFOLIOS',available:$scope.portfolioCode});
    $scope.portfolioDetailResource.$promise.then(function(data){
        $scope.articleId = data.availablePortfolios[0].articleId;
        $scope.portfolioArticleDetails = articleResourceFactory.portfolioArticleDetailsResource.get({portfolioCode:$scope.portfolioCode, articleId:$scope.articleId,key:'ARTICLE_DETAIL'});
        $scope.portfolioArticleDetails.$promise.then(function(){
            $scope.loading =false;
        });
        $scope.excelURL = '/SP/msa/portfolio/portfolioExcelReport.html?key=PORTFOLIO_GRID&portfolioCode=' + $scope.portfolioCode + '&articleId=' + $scope.articleId;
    });

    $scope.clickTab = function (tab){
        $scope.portfoliosHomeArgs.activeTab = tab;
        if (tab === 'CURRENT'){
            $scope.portfolioTabCurrentData = {};
            $scope.tableParamsCurrent = {
                page: 1,        // show first page
                count: 20,      // records for page
                total:0,        // count per page
                counts : []     // hide page counts control
            };
            $scope.currentLoading = false;
            $scope.$watch('tableParamsCurrent', function(params) {
                $scope.portfolioTabDataRaw = articleResourceFactory.portfolioSubTabResource.postReq($scope.createFormParamObject($scope.formParametersForCurrent,params));
                $scope.portfolioTabDataRaw.$promise.then(function(portfolioTabDataRaw){
                    $scope.tableParamsCurrent.total = portfolioTabDataRaw.total_records;
                    $scope.portfolioTabCurrentData =  $scope.handleRoutingParams(portfolioTabDataRaw.portfolios);
                    $scope.currentLoading = true;
                });
            }, true);
        } else if(tab === 'DELETED'){
            $scope.portfolioTabDeletedData = {};
                $scope.tableParamsDeleted = {
                page: 1,        // show first page
                count: 20,      // records for page
                total:0,        // count per page
                counts : []     // hide page counts control
            };
            $scope.deletedLoading = false;
            $scope.$watch('tableParamsDeleted', function(params) {
                $scope.portfolioTabDataRaw = articleResourceFactory.portfolioSubTabResource.postReq($scope.createFormParamObject($scope.formParametersForDeleted,params));
                $scope.portfolioTabDataRaw.$promise.then(function(portfolioTabDataRaw){
                    $scope.tableParamsDeleted.total = portfolioTabDataRaw.total_records;
                    $scope.portfolioTabDeletedData = $scope.handleRoutingParams(portfolioTabDataRaw.portfolios);
                    $scope.deletedLoading = true;
                });
            }, true);
        }else if(tab === 'PERFORMANCE'){
            $scope.formatPerformenceData();
        }
    };

    $scope.handleRoutingParams = function(data){
        data.forEach(function(items){
            items.issueTypeId = (entityTypeMap(items.issueTypeId)).toLowerCase();
        })
        return data;
    };

    $scope.goTo = function(path){
        $location.path(path);
    };
    $scope.createFormParamObject = function(data,params){
        data[0].start = (params.page-1) * params.count;
        data[0].limit=params.count;
        return data[0];
    };
    $scope.getColumnHeader = function(portfolioCode){
        $scope.currentPortfolioConfig = articleResourceFactory.portfolioConfigResource.get();
        $scope.currentPortfolioConfig.$promise.then(function(currentPortfolioConfig){
            $scope.currentPortfolioConfig = $scope.getConfig(portfolioCode,currentPortfolioConfig);
            $scope.clickTab($scope.portfoliosHomeArgs.activeTab);
            $scope.innerTableFormation = true;
        });


    };

    $scope.formatDataIndexForCurrent = function(indexObj,currentColumnObj){
        angular.forEach(currentColumnObj.columns,function(item){
            if(indexObj.hasOwnProperty(item.dataIndex)){
                indexObj[item.dataIndex] = item.dataIndex;
            }
        });
        return indexObj;
    };
    $scope.formatDataIndexForDeleted = function(indexObj,rawObj){
        if(!rawObj.hideDeleted) {
            angular.forEach(rawObj.deletedConfig.columns,function(item){
                if(indexObj.hasOwnProperty(item.dataIndex)){
                    indexObj[item.dataIndex] = item.dataIndex;
                }
            });
        }
        return indexObj;
    };

    $scope.formatPerformenceData = function(){
        $scope.portfolioPerformenceData = [];
        var data = $scope.portfolioArticleDetails.FiveYearPerformance.rows;
        for(var i=0; i<data[0].length; i++){
            var tempArray  =[];
            //for pushing each ith data to temp array
            for(var j=0; j<data.length; j++){
                tempArray.push(data[j][i]);
            }
            $scope.portfolioPerformenceData.push(tempArray);
        }
    };

    $scope.getConfig =  function(portfolioId,pConfigData){
        var returnData = {};
        angular.forEach(pConfigData.portfolioConfig, function(item){
            if(portfolioId === item.portfolioId) {
                returnData =  item;
                $scope.dataIndexsForCurrent = $scope.formatDataIndexForCurrent(pConfigData.dataIndex,returnData.currentConfig);
                $scope.dataIndexsForDeleted = $scope.formatDataIndexForDeleted(pConfigData.dataIndex,returnData);
                $scope.formParametersForCurrent =  returnData.currentConfig.formParams;
                if(!returnData.hideDeleted) {
                $scope.formParametersForDeleted =  returnData.deletedConfig.formParams;
                }
            }
        });
        return returnData;
    };

    $scope.getColumnHeader($scope.portfolioCode);

});