'use strict';

msaiqApp.controller('AnalyzePortfoliosCtrl', function ($scope, $log, assetsResourceFactory,$routeParams) {

    $scope.ticker = $routeParams.ticker;
    $log.info(" sdf sdfsdf"+$scope.ticker)
    if ($scope.ticker && typeof($scope.ticker)=="string" && $scope.ticker.indexOf("*") > -1) {// for tickers having a back slash , angular routing fails, decoding backslash   eg  rr /ln
        $scope.ticker =  $scope.ticker.replace("*","/");
    }
    $scope.analyzePortfolioLoading = true;
    var hypoToolRawData = assetsResourceFactory.hypoToolResource.doPostReq();
    hypoToolRawData.$promise.then(function (portfolioData) {
        if($scope.ticker){
            $scope.analyzePortfolioIFrameURL = portfolioData.hypoURL+'&ticker='+$scope.ticker;
        }
        else
        {
            $scope.analyzePortfolioIFrameURL = portfolioData.hypoURL;
        }
        $scope.analyzePortfolioLoading = false;
    });
});