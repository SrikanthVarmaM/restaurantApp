'use strict';

msaiqApp.controller('PortfoliosHomeCtrl', function ($scope,  $log, articleResourceFactory) {
    var allPortfolios = [];
    $scope.loading = true;
	$scope.portfolioConfig = articleResourceFactory.portfolioConfigResource.get();
    $scope.portfolioConfig.$promise.then(function(portfolioConfig){
        allPortfolios = portfolioConfig.availablePortfoliosOnlandingPage.concat(','+portfolioConfig.ETF_PORTFOLIOS.concat(','+portfolioConfig.TOP_SCREENS)).toString();
        $scope.portfolioDetailResource = articleResourceFactory.msaPortfolioInfoResource.get({key: 'ALL_PORTFOLIOS',available:allPortfolios});
        $scope.portfolioDetailResource.$promise.then(function(){
            $scope.loading = false;
        });
    });

    $scope.encodeURl = function(data){
        return data.split('/').join('~');
    };
});
