'use strict';


msaiqApp.controller('TraderTacticsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {

    $scope.traderTacticsResource = articleResourceFactory.articleDataResource.get({articleCode:'TTACS', start: 0, limit: 1});
    $scope.traderTacticsResource.$promise.then(function(traderTacticsResource){

        $scope.getTimeOfDay(traderTacticsResource);

    });

    $scope.getTimeOfDay = function(article){

        if(article.endOfDayComments){
            $scope.traderTacticsData = article.endOfDayComments;
        }
        if(article.intraDayComments){
            $scope.traderTacticsData = article.intraDayComments;
        }
        if(article.preOpeningComments){
            $scope.traderTacticsData = article.preOpeningComments;
        }

        $log.info($scope.traderTacticsData);
    };

});