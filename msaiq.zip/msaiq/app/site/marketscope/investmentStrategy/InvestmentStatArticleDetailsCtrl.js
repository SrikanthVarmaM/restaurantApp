'use strict';

msaiqApp.controller('InvestmentStatArticleDetailsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {
    $scope.articleId =  $routeParams.articleId;
    $scope.articleCode = $routeParams.articleCode;
    $scope.author = $routeParams.author;
    $scope.articleDetailsRawData = articleResourceFactory.articlesDetailsResource.get({articleId:$scope.articleId,articleCode:$scope.articleCode});
});