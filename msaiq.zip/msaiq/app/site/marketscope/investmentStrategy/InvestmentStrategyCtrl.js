'use strict';

msaiqApp.controller('InvestmentStrategyCtrl', function ($scope,  $log, $routeParams, articleResourceFactory,$location) {
    $scope.investmentStatHomeArgs = {articleCode:'ASALOM', activeTab: $routeParams.activeTab};
    $scope.investmentStrategyASALOMData = {};
    $scope.investmentStrategyGLLOKData = {};
    $scope.investmentStrategyEUIPCData = {};
    if ($scope.investmentStatHomeArgs.activeTab === 'US'){
        $scope.investmentStrategyASALOMData = articleResourceFactory.articleDataResource.get({articleCode: 'ASALOM',start:0,limit:1});
    }else if ($scope.investmentStatHomeArgs.activeTab === 'INTERNATIONAL'){
        $scope.investmentStrategyGLLOKData = articleResourceFactory.seeFullArticleDetailsGLOOK.get({start:0,limit:5});
        $scope.investmentStrategyEUIPCData = articleResourceFactory.articleDataResource.get({articleCode: 'EUIPC',start:0,limit:1});
    }
    $scope.getData = function(tab){
        $location.url('/marketscope/investmentStrategy/'+tab);
    };
});