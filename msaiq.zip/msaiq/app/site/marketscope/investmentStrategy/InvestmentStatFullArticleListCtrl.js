'use strict';

msaiqApp.controller('InvestmentStatFullArticleListCtrl', function (ngTableParams,$scope,  $log, articleResourceFactory) {
    var  fullArticleDetailsData = [];
    $scope.tableParams = {
        page: 1,       // show first page
        total: 0,      // length of data
        count: 10,     // count per page
        counts : [],    // hide page counts control
        sorting: {
            lastPublishDate: 'desc' // for sort icon
        }
    };
    $scope.loading = true;

    $scope.fullArticleDetailsRawData = articleResourceFactory.seeFullArticleDetailsGLOOK.get({start:0,limit:200});
    $scope.fullArticleDetailsRawData.$promise.then(function(fullArticleDetailsRawData){
        $scope.tableParams.total = fullArticleDetailsRawData.total_records;
        fullArticleDetailsData = fullArticleDetailsRawData.articles;
        $scope.loading = false;
    });

    // watch for changes of parameters
    $scope.$watch('tableParams', function(params) {
        $scope.articleList = fullArticleDetailsData.slice((params.page - 1) * params.count,params.page * params.count);
    }, true);

});