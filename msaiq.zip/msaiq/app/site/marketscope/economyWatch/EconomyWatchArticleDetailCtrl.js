'use strict';

msaiqApp.controller('EconomyWatchArticleDetailCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {
    $log.debug('Article Details EconomyWatchArticleDetailCtrl');
    $scope.loading = true;
    $scope.articleShowPDF = false;
    $scope.articleId =  $routeParams.articleId;
    $scope.articleCode = $routeParams.articleCode;
    $scope.path = $routeParams.source || '' ;
    $log.info('article id: ' + $scope.articleId + ', article code: ' +  $scope.articleCode +' article path: '+ $scope.path);

    if('ECOCL' === $scope.articleCode )
    {
        $scope.result = articleResourceFactory.articlesDetailsResource.get({articleCode:$scope.articleCode, articleId:$scope.articleId});
    } else
    {
        $scope.result = articleResourceFactory.economyWatchDetailResource.get({articleCode:$scope.articleCode, articleId:$scope.articleId});
    }

    $scope.result.$promise.then(
        function( jsonResponse ){
            var data = {}; /* Composite data object after refining */
            if('ECOCL' === $scope.articleCode )
            {
                data.articleId = jsonResponse.articleDetails.articleId;
                data.headline = jsonResponse.articleDetails.headline;
                data.publishedDate = jsonResponse.articleDetails.publishedDate;
                data.commentary = jsonResponse.articleDetails.commentary;
            }else
            {
                data.articleId = jsonResponse.articles[0].articleId;
                data.headline = jsonResponse.articles[0].headline;
                data.publishedDate = jsonResponse.articles[0].publishedDate;
                data.commentary = jsonResponse.articles[0].content;
            }
            $scope.article = data;
            $scope.loading = false;
            $log.debug('Article Details EconomyWatchArticleDetailCtrl Done');
        });

    $scope.pdfCheckAvailability = articleResourceFactory.marketscopePdfCheckAvailability.get({articleId: $scope.articleId});
    $scope.pdfCheckAvailability.$promise.then(function (PDFCheck) {

        if(PDFCheck.status.exists === true)
        {$scope.articleShowPDF = true;}

    }, function(error){
        $scope.articleShowPDF = false;
    });


});
