'use strict';
/*jshint newcap: false */

msaiqApp.controller('EconomyWatchAllCtrl', function ($scope,  $log, articleResourceFactory, ngTableParams, $location) {
    $log.debug('Getting Details for EconomyWatchAllCtrl');
    $scope.route = 'marketscope/economyWatchArticle';
    $scope.source = 'navPage';
    $scope.loading = true;
    $scope.tableParams = new ngTableParams({
        page   : 1,
        count  : 20,
        total  : 0,
        counts : [],
        sorting: {
            publishedDate: 'desc' // for sort icon
        }
    });
    $scope.openArticleDetailsPage = function(url){
        $location.path(url);
    };
    $scope.economyAllData = articleResourceFactory.economyWatchArticleResource.get({articleCode:'ECONOMYWATCHALLDATA'});
    $scope.economyAllData.$promise.then(function(economyAllData){
        $scope.tableParams.total = $scope.totalNumOfRecords = economyAllData.mktIntArticles.length;
        $scope.$watch('tableParams', function(params) {
            $scope.economyAllList =  economyAllData.mktIntArticles.slice((params.page - 1) * params.count,params.page * params.count);
        }, true);
        $scope.loading = false;
    });

});
