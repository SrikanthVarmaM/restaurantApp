'use strict';
/*jshint newcap: false */

msaiqApp.controller('EconomyWatchCtrl', function ($scope,  $log, articleResourceFactory, ngTableParams) {
    $log.debug('Getting Details for EconomyWatchCtrl');
    $scope.route = 'marketscope/economyWatchArticle';
    $scope.source = 'mainPage';
    $scope.loading = true;
    $scope.articleLoading = true;
    $scope.nodata=false;
    $scope.economyArticleData = articleResourceFactory.economyWatchArticleResource.get({articleCode:'ECONOMYWATCHHOME'});
    $scope.economyArticleData.$promise.then( function(){ $scope.articleLoading = false;},
                                             function(){ $scope.articleLoading = false; $scope.nodata=true;}
                                           );
    $scope.tableParams = new ngTableParams({
        page   : 1,
        count  : 20,
        total  : 0,
        counts : [],
        sorting: {
            eventdate: 'asc' // for sort icon
        }
    });
    $scope.$watch('tableParams', function(params,oldParams) {
        if(oldParams.page === params.page && $scope.tableParams.total !== 0) {
            return;
        }
        $scope.economyData = articleResourceFactory.economyWatchResource.get({start: (params.page-1) * params.count,limit:params.count});
        $scope.loading = true;
        $scope.economyData.$promise.then(function(economyData){
            $scope.tableParams.total = economyData.total_records;
            for(var i=0; i < economyData.events.length; i++){
                var temp = economyData.events[i].id.time;
                economyData.events[i].id.time = temp.substring(0,temp.indexOf('US'));
                economyData.events[i].id.eventdate = Date.parse(economyData.events[i].id.eventdate.split('-').join('/'));
            }
            $scope.economyDataList =  economyData;
            $scope.loading = false;
        });
    }, true);
});
