'use strict';

msaiqApp.controller('MarketIntelligenceDetailCtrl', function ($scope, $http, $routeParams, $route, $log, articleResourceFactory) {
    $scope.mkTabLoading = false;
    $scope.articleId = $routeParams.articleId;
    $scope.articleCode = $routeParams.articleCode;
    $scope.intTabLoading = false;
    $scope.showPDF = false;
    $scope.marketIntData = articleResourceFactory.marketIntelligenceDetailResource.get({articleCode:$scope.articleCode, articleId:$scope.articleId});

    $scope.pdfCheckAvailability = articleResourceFactory.marketscopePdfCheckAvailability.get({articleId: $scope.articleId});
    $scope.pdfCheckAvailability.$promise.then(function (PDFCheck) {

        if(PDFCheck.status.exists==true)
             $scope.showPDF = true;

    },function(error){
        $scope.showPDF = false;
    });

});