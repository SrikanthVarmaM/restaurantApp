'use strict';


msaiqApp.controller('MarketIntelligenceCtrl', function ($scope, $http, $routeParams, $route, $log, articleResourceFactory) {

    $scope.marketIntData = articleResourceFactory.marketIntelligenceResource.get({articleCode:'MRKINTHOME'});
    $scope.marketIntData.$promise.then(function(marketIntData){
        $log.info(marketIntData.mktIntArticles);
        $scope.marketIntData =  marketIntData.mktIntArticles;
    });
});