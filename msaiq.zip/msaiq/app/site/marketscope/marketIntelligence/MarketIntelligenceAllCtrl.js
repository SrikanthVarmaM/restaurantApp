'use strict';


/*
 review: justin.  After you make the other changes, let me use this to add the new ng-table stuff.
 */
msaiqApp.controller('MarketIntelligenceAllCtrl', function ($scope, $http, $routeParams, $route, $log, articleResourceFactory, $location, $filter, ngTableParams) {

    $scope.sortOrder = false;

    $scope.loadingState = true;

    $scope.tableParams = new ngTableParams({
        page: 1,            // show first page
        total: 0,           // length of data
        count: 20,          // count per page
        counts: [],
        sorting: {
            publishedDate: 'desc'     // initial sorting
        }
    });


    $scope.goTo = function(url) {
        $log.info(url);
        $location.path('/marketscope/marketIntelligenceDetail/' + url.articleCode + '/' + url.articleId);
    };

    $scope.sortDate = function() {
        var orderedData = $filter('orderBy')($scope.data.mktIntArticles, 'publishedDate', $scope.sortOrder);

        $scope.articles = orderedData.slice(
            ($scope.tableParams.page - 1) * $scope.tableParams.count,
            $scope.tableParams.page * $scope.tableParams.count);

        $scope.sortOrder = !$scope.sortOrder;

    };


    $scope.$watch('tableParams', function(params) {

        if($scope.data !== undefined) {

            $log.info('hello world');

            $scope.tableParams.total = $scope.data.mktIntArticles.length;

            var orderedData = $filter('orderBy')($scope.data.mktIntArticles, params.orderBy());

            $scope.articles = orderedData.slice(
                (params.page - 1) * params.count,
                params.page * params.count);

        }  else {

            articleResourceFactory.marketIntelligenceResource.get({articleCode:'MKTINTALLDATA'}, function(data) {

                $scope.loadingState = false;
                $scope.data = data;

                $scope.tableParams.total = $scope.data.mktIntArticles.length;

                var orderedData = $filter('orderBy')($scope.data.mktIntArticles, params.orderBy());

                $scope.articles = orderedData.slice(
                    (params.page - 1) * params.count,
                    params.page * params.count);

            });
        }

    }, true);



/*    $scope.decrementPage = function() {
        $log.info($scope.currentPage);
        if ($scope.currentPage > 1) {
            $scope.currentPage = $scope.currentPage - 1;
            $scope.temp = $scope.marketIntData;
            $scope.pagedData =  $scope.orderedData.slice(($scope.currentPage - 1) * 20, ($scope.currentPage * 20));
        }

    };
    $scope.incrementPage = function() {
        if ($scope.currentPage < $scope.totalArticles){
            $scope.currentPage = $scope.currentPage + 1;
            $scope.temp = $scope.marketIntData;
            $scope.pagedData =  $scope.orderedData.slice(($scope.currentPage - 1) * 20, ($scope.currentPage * 20));
        }
    };

    $scope.sortBy = function(param) {

        if (param === 'headline') {
            $scope.temp = $scope.marketIntData;
            $scope.sortHeadline = !$scope.sortHeadline;
            $scope.orderedData = $filter('orderBy')($scope.temp.mktIntArticles, param, $scope.sortHeadline);
            $scope.pagedData =  $scope.orderedData.slice(($scope.currentPage - 1) * 20, ($scope.currentPage * 20));
        } else if (param === 'publishedDate') {
            $scope.temp = $scope.marketIntData;
            $scope.sortDate = !$scope.sortDate;
            $scope.orderedData = $filter('orderBy')($scope.temp.mktIntArticles, param, $scope.sortDate);
            $scope.pagedData =  $scope.orderedData.slice(($scope.currentPage - 1) * 20, ($scope.currentPage * 20));
        }
    };
    */
});