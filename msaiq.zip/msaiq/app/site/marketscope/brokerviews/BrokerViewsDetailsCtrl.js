'use strict';

msaiqApp.controller('BrokerViewsDetailsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory, ArticleMessaging, _, $) {

    $log.debug('BrokerViews Details Controller article id: ' + $routeParams.articleId+ ', article code ' + $routeParams.articleCode);

    $scope.article = articleResourceFactory.articlesDetailsResource.get({articleCode:$routeParams.articleCode, articleId:$routeParams.articleId});
    $scope.article.$promise.then(function(article){
        // send event message that article has loaded to all subdirectives
        $log.debug('send message that article has changed');

        /* reformat message to be {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
        var param = {}; var index=0;
        _.forEach(article.articleDetails.articleInstruments, function(instrument) {
            // only pass the main ticker
            if (instrument.articleRelationship === 'main'){
                param[index] = {sppwId: instrument.sppwId, tickerSymbol: instrument.tickerSymbol};
                index++;
            }
        });
        // flatten this, need to use jquery as IE _flatten doesn't work
        var symbolsTickers = $.map(param, function(n){ return n; });
        var message = {articleId: article.articleDetails.articleId, instruments: symbolsTickers};

        ArticleMessaging.broadcastArticleLoaded($scope, message);

        // go through each title and parse it out by ticker
        $scope.article.articleDetails.headlineUpdate = $scope.redoArticleTitle(article.articleDetails.headline, article.articleDetails.articleInstruments);

        $scope.article = article;

    });  // end promise


    $scope.redoArticleTitle = function(headline, instruments){
        // return back from 'headline'
        // headlineParsed : {headlineStart: '', link: '', headlineEnd: ''}';
        // get article symbol  main
        var mainSymbol = '';  var sppwId = '';
        angular.forEach(instruments, function(instrument){
            if( instrument.articleRelationship === 'main'){
                mainSymbol = instrument.tickerSymbol;
                sppwId = instrument.sppwId;
            }
        });

        if (mainSymbol){
            var indexSearch = headline.indexOf('('+mainSymbol+')');
            if (indexSearch > 0){
                return ({headlineStart: headline.substring(0, indexSearch-1).trim(), 'link': mainSymbol, headlineEnd: headline.substring(indexSearch+mainSymbol.length+2, headline.length), sppwId: sppwId});
            }else{
                return {headlineStart: headline, 'link': mainSymbol, sppwId: sppwId };
            }
        }else{
            return null;
        }
    };


});