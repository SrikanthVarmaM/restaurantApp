'use strict';

msaiqApp.controller('TrendsAndIdeasTopicsCtrl', function ($scope, $http, $routeParams, $route, $log, articleResourceFactory, $location, $filter, ngTableParams, _) {
    $scope.topic = $routeParams.topic.split(':')[0];
    $scope.type = $routeParams.topic.split(':')[1];
    $scope.sortOrder = false;
    $scope.loadingState = true;

    $scope.tableParams = new ngTableParams({
        page: 1,            // show first page
        total: 0,           // length of data
        count: 20,          // count per page
        counts: [],
        sorting: {
            lastPublishDate: 'desc'     // initial sorting
        }
    });

    $scope.goTo = function (articleId) {
        $log.info('TrendsAndIdeasTopics goTo: ' + articleId);
        $location.path('/marketscope/trendsAndIdeas/details/' + articleId);
    };

    $scope.sortDate = function () {
        var orderedData = $filter('orderBy')($scope.data.articles, 'lastPublishDate', $scope.sortOrder);
        var uniqueData = _.unique(orderedData, function (article) {return article.articleId; });
        $scope.tableParams.total = uniqueData.length;

        $scope.articles = uniqueData.slice(($scope.tableParams.page - 1) * $scope.tableParams.count, $scope.tableParams.page * $scope.tableParams.count);

        $scope.sortOrder = !$scope.sortOrder;
    };

    $scope.$watch('tableParams', function (params) {
        if ($scope.data !== undefined) {
            $log.info('TrendsAndIdeasTopics watch');

            var orderedData = $filter('orderBy')($scope.data.articles, params.orderBy());
            var uniqueData = _.unique(orderedData, function (article) {return article.articleId; });
            $scope.tableParams.total = uniqueData.length;

            $scope.articles = uniqueData.slice((params.page - 1) * params.count, params.page * params.count);
        } else {
            var type = '';
            if ($scope.type === 'STOCKS') {
                type = 'S';
            } else if ($scope.type === 'ETFs') {
                type = 'ETF';
            } else if ($scope.type === 'FUNDS') {
                type = 'M';
            } else {
                type = 'S,ETF,M';
            }

            articleResourceFactory.articleTopicResource.get({articleCode: 'TREND', requestType: 'TOPIC', equityType: type, topic: $scope.topic}, function (data) {

                $scope.loadingState = false;
                $scope.data = data;

                var orderedData = $filter('orderBy')($scope.data.articles, params.orderBy());
                var uniqueData = _.unique(orderedData, function (article) {return article.articleId; });
                $scope.tableParams.total = uniqueData.length;

                $scope.articles = uniqueData.slice((params.page - 1) * params.count, params.page * params.count);
            });
        }

    }, true);

});
