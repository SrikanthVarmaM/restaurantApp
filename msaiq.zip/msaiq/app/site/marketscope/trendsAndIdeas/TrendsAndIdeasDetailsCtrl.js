'use strict';

msaiqApp.controller('TrendsAndIdeasDetailsCtrl', function ($scope, $log, articleResourceFactory, $routeParams, ArticleMessaging, _, $) {
    $scope.articleId = $routeParams.articleId;
    $scope.trendsAndIdeasDetailsResource = articleResourceFactory.articlesDetailsResource.get({articleCode: 'TREND', articleId: $scope.articleId});

    $scope.trendsAndIdeasDetailsResource.$promise.then(function (trendsAndIdeasDetailsResource) {
        // send event message that article has loaded to all subdirectives
        $log.debug('send message that article has changed');
        /* reformat message to be {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
        var param = {};
        var index = 0;
        _.forEach(trendsAndIdeasDetailsResource.articleDetails.articleInstruments, function (instrument) {
            if (instrument.articleRelationship === 'opportunity') {
                param[index] = {sppwId: instrument.sppwId, tickerSymbol: instrument.tickerSymbol};
                index++;
            }
        });
        // flatten this, need to use jquery as IE _flatten doesn't work
        var symbolsTickers = $.map(param, function (n) {
            return n;
        });
        var message = {articleId: trendsAndIdeasDetailsResource.articleDetails.articleId, instruments: symbolsTickers};

        ArticleMessaging.broadcastArticleLoaded($scope, message);
    });
});