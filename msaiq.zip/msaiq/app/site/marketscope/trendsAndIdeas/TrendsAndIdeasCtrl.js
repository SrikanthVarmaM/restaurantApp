'use strict';

msaiqApp.controller('TrendsAndIdeasCtrl', function ($scope,  $log, $location,$routeParams, articleResourceFactory, $filter, ngTableParams, _, $, msaMessageController, WatchlistDataService) {
    $log.info('TrendsAndIdeasCtrl');
    $scope.tabs = {activeTab: $routeParams.activeTab};
    var decodeHTML = $filter('decodeHTML');

    $scope.sortOrder = false;
    $scope.searchCompleted = false;
    $scope.filterToggled = false;

    $scope.defaultCompanies = 'COMPANIES MENTIONED TODAY';
    $scope.defaultWatchlists = '';
    $scope.defaultSectors = 'GICS SECTORS';
    $scope.defaultIndustries = 'GICS SUB INDUSTRIES';
    $scope.defaultAuthors = 'AUTHORS';

    $scope.placeholderCompanies = $scope.defaultCompanies;
    $scope.placeholderWatchlists = $scope.defaultWatchlists;
    $scope.placeholderSectors = $scope.defaultSectors;
    $scope.placeholderIndustries = $scope.defaultIndustries;
    $scope.placeholderAuthors = $scope.defaultAuthors;

    $('#watchlists-dd').click(function (e) {
        $('#tai-watchlist-drop-down-header2').addClass('open');
        e.stopPropagation();
    });

    $scope.tableParams = new ngTableParams({
        page: 1,            // show first page
        total: 0,           // length of data
        count: 20,          // count per page
        counts: [],
        sorting: {
            lastPublishDate: 'desc'     // initial sorting
        }
    });

    $scope.clearSearch = function () {
        $scope.limit = 200;
        $scope.sppwIds = '';
        $scope.requestType = '';
        $scope.symbol = '';
        $scope.gicsCode = '';
        $scope.author = '';
    };
    $scope.clearSearch();

    $scope.goTo = function (articleId) {
        $log.info('TrendsAndIdeasTopics goTo: ' + articleId);
        $location.path('/marketscope/trendsAndIdeas/details/' + articleId);
    };

    $scope.sortDate = function () {
        var orderedData = $filter('orderBy')($scope.data.articles, 'lastPublishDate', $scope.sortOrder);

        $scope.articles = orderedData.slice(
            ($scope.tableParams.page - 1) * $scope.tableParams.count,
            $scope.tableParams.page * $scope.tableParams.count
        );

        $scope.sortOrder = !$scope.sortOrder;
    };

    $scope.getFilters = function () {
        $scope.articlesFilterResource = articleResourceFactory.articlesFilterResource.get();
        $scope.articlesFilterResource.$promise.then(function () {
            // _.flatten doesn't work in IE8, have to use jquery's flatten
            $scope.companies =  $.map(_.pluck($scope.articlesFilterResource.articles, 'articleInstruments'), function (n) { return n; });
            $scope.sectors = $scope.articlesFilterResource.sectors;
            $scope.industriesRef = $scope.articlesFilterResource.subIndustries;
            if (!$scope.industries) {
                $scope.industries = [];
            }
            $scope.authors = $scope.articlesFilterResource.authorsList;
        });
    };
    $scope.getFilters();

    $scope.getWatchLists = function () {
        WatchlistDataService.watchlistData.$promise.then(function(watchlistData){
            $scope.watchlists = watchlistData.watchLists;
        });
    };
    $scope.getWatchLists();

    $scope.getSearchData = function (params) {
        articleResourceFactory.filterArticlesResource.get(
            {
                limit: $scope.limit,
                articleCode: 'GLBTREND',
                sppwIds: $scope.sppwIds,
                requestType: $scope.requestType,
                symbol: $scope.symbol,
                gicsCode: $scope.gicsCode,
                author: $scope.author
            },

            function (data) {
                $scope.loadingState = false;

                $scope.data = data;
                $scope.tableParams.total = $scope.data.articles.length;

                if (data.total_records === 1) {
                    $scope.goTo(data.articles[0].articleId);
                }

                var orderedData = $filter('orderBy')($scope.data.articles, params.orderBy());

                $scope.articles = orderedData.slice(
                    (params.page - 1) * params.count,
                    params.page * params.count);
            });

        // update filter data
        $scope.getFilters();
        $scope.getWatchLists();
        $scope.searchCompleted = true;
    };

    $scope.$watch('tableParams', function (params) {
        if ($scope.data !== undefined) {
            $log.info('TrendsAndIdeasSearch watch');

            $scope.tableParams.total = $scope.data.articles.length;

            var orderedData = $filter('orderBy')($scope.data.articles, params.orderBy());

            $scope.articles = orderedData.slice(
                (params.page - 1) * params.count,
                params.page * params.count);

        }
    }, true);

    $scope.filterIndustry = function(sector) {
        var tmpIndustry = [];

        for (var i = 0; i < $scope.industriesRef.length; i++) {
            var industry = $scope.industriesRef[i][0].substring(0,2);
            if (sector === industry) {
                tmpIndustry.push($scope.industriesRef[i]);
            }
        }
        $scope.industries = tmpIndustry.slice(0);
    };

    $scope.clearTickers = function() {
        var messageWarpper = {
            messageType: 'CLEAR_SEARCH'
        };
        msaMessageController.prepForBroadcast(messageWarpper);
    };

    $scope.submitSearch = function() {
        $scope.loadingState = true;
        $scope.getSearchData($scope.tableParams);
    };


    $scope.setClass = function (length) {
        if (length > 0) {
            return 'form-control enabled';
        } else {
            return 'form-control disabled';
        }
    };

    $scope.select = function(id) {
        var el;
        var fields = ['companies-dd','watchlists-dd','sectors-dd','industries-dd','authors-dd'];

        // set font to selected
        for (var i=0; i < fields.length; i++) {
            el = document.getElementById(fields[i]);
            el = $('#' + fields[i]);
            if (fields[i] === id) {
                el.removeClass('unselected');
                el.addClass('selected');
            }
            else {
                el.removeClass('selected');
                el.addClass('unselected');
            }
        }
    };
    $scope.select('');

    $scope.selectTicker = function(sppwId){
        // set input box value - reset others
        $scope.placeholderCompanies = $scope.defaultCompanies;
        $scope.placeholderWatchlists = $scope.defaultWatchlists;
        $scope.placeholderSectors = $scope.defaultSectors;
        $scope.placeholderIndustries = $scope.defaultIndustries;
        $scope.placeholderAuthors = $scope.defaultAuthors;

        $scope.select('');
        $scope.clearSearch();
        $scope.requestType = 'autosuggest';
        $scope.sppwIds = sppwId;

        $scope.filterIndustry('');
        $scope.getFilters();
    };

    $scope.selectCompany = function(company){
        // set input box value - reset others
        $scope.clearTickers();
        $scope.placeholderCompanies = company.tickerSymbol + '-' +  company.companyName;
        $scope.placeholderWatchlists = $scope.defaultWatchlists;
        $scope.placeholderSectors = $scope.defaultSectors;
        $scope.placeholderIndustries = $scope.defaultIndustries;
        $scope.placeholderAuthors = $scope.defaultAuthors;

        $scope.select('companies-dd');
        $scope.clearSearch();
        $scope.requestType = 'todaysSymbols';
        $scope.sppwIds = company.sppwId;

        $scope.filterIndustry('');
    };

    $scope.getWatchlistSppwIds = function(data,typeAction) {
        var identifierArray = [];
        if(typeAction === 'one'){
            angular.forEach(data.items,function(watchlistItem){
                identifierArray.push( watchlistItem.sppwId );
            });
        } else {
            angular.forEach($scope.watchlists,function(watchlist){
                angular.forEach(watchlist.items,function(watchlistItem){
                    identifierArray.push( watchlistItem.sppwId );
                });
            });
        }
        if(identifierArray.length > 0)
            return identifierArray.join(',');
        else
            return -1;
    };
    $scope.$watch('placeholderWatchlists',function(){
        $('#watchlists-dd').val($scope.placeholderWatchlists);
    });

    $scope.selectWatchlist = function(watchlist,typeAction){
        // set input box value - reset others
        if(typeAction === 'one'){
            $scope.placeholderWatchlists = decodeHTML(watchlist.name);
        } else {
            $scope.placeholderWatchlists = 'All';
        }
        $scope.clearTickers();
        $scope.placeholderCompanies = $scope.defaultCompanies;
        $scope.placeholderSectors = $scope.defaultSectors;
        $scope.placeholderIndustries = $scope.defaultIndustries;
        $scope.placeholderAuthors = $scope.defaultAuthors;

        $scope.select('watchlists-dd');
        $scope.clearSearch();
        $scope.requestType = 'watchlist';
        $scope.sppwIds = $scope.getWatchlistSppwIds(watchlist,typeAction);

        $scope.filterIndustry('');
    };

    $scope.selectSector = function(sector){
        // set input box value - reset others
        $scope.clearTickers();
        $scope.placeholderCompanies = $scope.defaultCompanies;
        $scope.placeholderWatchlists = $scope.defaultWatchlists;
        $scope.placeholderSectors = sector[1];
        $scope.placeholderIndustries = $scope.defaultIndustries;
        $scope.placeholderAuthors = $scope.defaultAuthors;

        $scope.select('sectors-dd');
        $scope.clearSearch();
        $scope.requestType = 'sectors';
        $scope.gicsCode = sector[0];

        $scope.filterIndustry(sector[0]);
    };

    $scope.selectIndustry = function(industry){
        // set input box value - reset others
        $scope.clearTickers();
        $scope.placeholderCompanies = $scope.defaultCompanies;
        $scope.placeholderWatchlists = $scope.defaultWatchlists;
        $scope.placeholderSectors = $scope.placeholderSectors;
        $scope.placeholderIndustries = industry[1];
        $scope.placeholderAuthors = $scope.defaultAuthors;

        $scope.select('industries-dd');
        $scope.clearSearch();
        $scope.requestType = 'subindustries';
        $scope.gicsCode = industry[0];
    };

    $scope.selectAuthor = function(author){
        // set input box value - reset others
        $scope.clearTickers();
        $scope.placeholderCompanies = $scope.defaultCompanies;
        $scope.placeholderWatchlists = $scope.defaultWatchlists;
        $scope.placeholderSectors = $scope.defaultSectors;
        $scope.placeholderIndustries = $scope.defaultIndustries;
        $scope.placeholderAuthors = author[1];

        $scope.select('authors-dd');
        $scope.clearSearch();
        $scope.requestType = 'authors';
        $scope.author = author[0];

        $scope.filterIndustry('');
    };

    $scope.frontPage = function() {
        $scope.filterToggled = false;
        $scope.searchCompleted = false;
        $scope.clearSearch();
        $scope.data = {};

        $scope.select('');
        $scope.clearTickers();
        $scope.placeholderTickers = $scope.defaultTickers;
        $scope.placeholderCompanies = $scope.defaultCompanies;
        $scope.placeholderWatchlists = $scope.defaultWatchlists;
        $scope.placeholderSectors = $scope.defaultSectors;
        $scope.placeholderIndustries = $scope.defaultIndustries;
        $scope.placeholderAuthors = $scope.defaultAuthors;
    };

    $scope.filterToggle = function () {
        $scope.filterToggled = !$scope.filterToggled;
    };

    $scope.$on('handleBroadcast', function () {
        if (msaMessageController.message.messageType === 'SECURITY_INFO') {
            $scope.selectTicker(msaMessageController.message.messageBody.sppw_id);
        }
    });

    // ------------------------------------------------------------------------------------------------------------------------------
    // Begin tab functionality
    // ------------------------------------------------------------------------------------------------------------------------------

    $scope.getData = function (tab) {
        // set tab active value
        $scope.tabs.activeTab = tab;
        $location.path('/marketscope/trendsAndIdeas/' + tab);

        $scope.topics = [];

        if (tab === 'ALL') {
            $log.debug('ALL tab');

            $scope.trendsAndIdeasAllResource = articleResourceFactory.trendsAndIdeasResource.get({articleCode:'GLBTREND',equityType:'S,ETF,M'});
            $scope.articleCountResource = articleResourceFactory.articleCountResource.get({articleCode:'TREND',equityType:'S,ETF,M'});

        } else if (tab === 'STOCKS') {
            $log.debug('STOCKS tab');

            $scope.trendsAndIdeasStocksResource = articleResourceFactory.trendsAndIdeasEquityResource.get({articleCode:'GLBTREND',equityType:'S',topic:''});
            $scope.articleCountResource = articleResourceFactory.articleCountResource.get({articleCode:'TREND',equityType:'S'});

        } else if (tab === 'FUNDS') {
            $log.debug('FUNDS tab');

            $scope.trendsAndIdeasFundsResource = articleResourceFactory.trendsAndIdeasEquityResource.get({articleCode:'GLBTREND',equityType:'M',topic:'mutual funds'});
            $scope.articleCountResource = articleResourceFactory.articleCountResource.get({articleCode:'TREND',equityType:'M'});

        } else if (tab === 'ETFs') {
            $log.debug('ETFs tab');

            $scope.trendsAndIdeasEtfsResource = articleResourceFactory.trendsAndIdeasEquityResource.get({articleCode:'GLBTREND',equityType:'ETF',topic:'etfs'});
            $scope.articleCountResource = articleResourceFactory.articleCountResource.get({articleCode:'TREND',equityType:'ETF'});

        } else if (tab === 'FIXED INCOME') {
            $log.debug('FIXED INCOME tab');

            $scope.trendsAndIdeasFixedResource = articleResourceFactory.trendsAndIdeasFixedResource.get({articleCode:'GLBTREND',requestType:'TOPIC',issueType:'S, M, ETF',topic:'fixed income'});
            $scope.articleCountResource = articleResourceFactory.articleCountResource.get({articleCode:'TREND',equityType:''});

        }

        $scope.articleCountResource.$promise.then(function () {
              $scope.topics = $scope.articleCountResource.topics;
        });
    };

    $scope.getData($scope.tabs.activeTab);

});
