'use strict';


msaiqApp.controller('TechAnalysisCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {

    $scope.traderTacticsResource = articleResourceFactory.articleDataResource.get({articleCode:'TTACS', start: 0, limit: 1});
    $scope.techTrendsResource = articleResourceFactory.articleDataResource.get({articleCode:'TTWAT', start: 0, limit: 1});
    $scope.traderTacticsResource.$promise.then(function(traderTacticsResource){
        $scope.getTimeOfDay(traderTacticsResource);

    });

    $scope.techTrendsResource.$promise.then(function(a) {
        var date = new Date(Date.parse(a.technicalTrends[0].lastPublishDate.replace(/\-/ig, '/').split('.')[0]));
        $scope.techTrendsDate = date;

    });

    $scope.getTimeOfDay = function(article){

        if(article.endOfDayComments){
            $scope.traderTacticsData = article.endOfDayComments;
        }
        if(article.intraDayComments){
            $scope.traderTacticsData = article.intraDayComments;
        }
        if(article.preOpeningComments){
            $scope.traderTacticsData = article.preOpeningComments;
        }


        $scope.findWordEnd($scope.traderTacticsData.comments[0].segments[0].paragraphs[0]);

    };

    $scope.findWordEnd = function(paragraph) {

        var firstPart = paragraph.substring(0, 1600);
        var tag =   paragraph.substring(1600).indexOf('<');

        var secondPart = paragraph.substring(1600, 1600 + tag);
        $log.info(paragraph);

        $scope.traderTacticsParagraph = firstPart + secondPart + '...</div>';

    };


});



