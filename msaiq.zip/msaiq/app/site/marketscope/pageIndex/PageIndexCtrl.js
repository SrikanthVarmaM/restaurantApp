'use strict';

msaiqApp.controller('PageIndexCtrl', function ($scope, $log, $location, articleResourceFactory) {
    $log.info('at Page Index');
    $scope.pageIndexes = articleResourceFactory.pageIndexResourceTest.get();

    $scope.goTo = function(pageIndex){
        var url =  '/' +(pageIndex._source.link || 'home');
        $log.info('pageindex:goTo '+url );
        $location.path(url);
    };
});