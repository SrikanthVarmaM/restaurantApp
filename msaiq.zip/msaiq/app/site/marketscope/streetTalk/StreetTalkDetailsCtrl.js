'use strict';

msaiqApp.controller('StreetTalkDetailsCtrl', function ($scope, $log, $routeParams, articleResourceFactory) {
    $log.info('StreetTalkDetails Controller article id: ' + $routeParams.articleId + ', article code ' + $routeParams.articleCode);
    $scope.article = articleResourceFactory.articlesDetailsResource.get({articleCode:$routeParams.articleCode, articleId:$routeParams.articleId});
    $scope.printArticleURL = '/SP/msa/articleDetails.html?printToPdf=printToPdf&articleId=' + $routeParams.articleId + '&articleCode=' + $routeParams.articleCode;
});