/**
 * Created with IntelliJ IDEA.
 * User: nkakkireni
 * Date: 10/21/13
 * Time: 10:29 AM
 * To change this template use File | Settings | File Templates.
 */
'use strict';

msaiqApp.controller('PreviousStockOfWeekCtrl', function ($scope,  $log, $resource,articleResourceFactory) {
    $scope.previousStocksOfWeekData = articleResourceFactory.articleDataResource.get({articleCode: 'FSOWLIST',start:1,limit:6});
    $scope.openFocusStockOfWeekDetailsPage = function(url){
        window.location = url;
    };
   /* $scope.openQV = function(sppwId, ticker, report_ind, type){
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''),region:region, report_ind: (report_ind || 'undefined')});
    };*/
});


