'use strict';

msaiqApp.controller('FocusStockCtrl', function ($scope,  $log, $resource,$routeParams,articleResourceFactory,ArticleMessaging, _, $) {
    $log.debug('In Focus Stock Of WeekCtrl Controller'+$routeParams.articleId);
    $scope.loading = true;
    $scope.focusStockOfWeekData = articleResourceFactory.articleIdDataResource.get({articleCode: 'FSOW',start:0,limit:1,articleId:$routeParams.articleId});
    $scope.focusStockOfWeekData.$promise.then(function(focusStockOfWeekData){
        $scope.loading=false;
        $log.debug('send message that article has changed'+focusStockOfWeekData.sppwId+focusStockOfWeekData.tickerSymbol);

        /* reformat message to be {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
        var param = {};
        param[0] = {sppwId: focusStockOfWeekData.sppwId, tickerSymbol: focusStockOfWeekData.tickerSymbol};

        // flatten this, need to use jquery as IE _flatten doesn't work
        var symbolsTickers = $.map(param, function(n){ return n; });
        var message = {articleId: focusStockOfWeekData.articleId, instruments: symbolsTickers};

        ArticleMessaging.broadcastArticleLoaded($scope, message);

        // broadcast down for ministock to refresh data
        var stockMsg= {sppwid :$scope.focusStockOfWeekData.sppwId , report: $scope.focusStockOfWeekData.reportType }
        $scope.$broadcast('reloadMiniStock', stockMsg);
    });
});
