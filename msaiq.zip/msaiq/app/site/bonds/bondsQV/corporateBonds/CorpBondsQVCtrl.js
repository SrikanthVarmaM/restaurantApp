'use strict';

msaiqApp.controller('CorpBondsQVCtrl', function ($scope, $log, bondsResourceFactory, _, QuickViewService, $resource, $location, $filter, ngTableParams, $, ThomsonService,ga, $cookies,$rootScope) {

    //------------------------------------------variable declaration & intitialization---------------------------------

    $scope.orgId = '';
    $scope.QuickViewService = QuickViewService;
    $scope.ThomsonService = ThomsonService;
    $scope.cusip = $scope.modelParam.cusip;
    $scope.haveBondDocument = false;
    $scope.isDetailsPage = false;
    var emptyCheckFilter = $filter('emptyCheckFilter');
    var orderFilter = $filter('orderObjectBy');
    var outlookFilter = $filter('getOutlookIssuer');
    var spRatingFilter = $filter('getSPRatingIssuer');
    var creditWatchFilter = $filter('getCreditWatchIssuer');
    $scope.currentTime = Date();
    $scope.isActiveBond = $scope.modelParam.active;

    $scope.candyBarColors = ['color-1-red', 'color-2-yellow', 'color-3-cyan', 'color-4-green'];
    $scope.candyMarketBarColors = ['color-1-red', 'color-1-orange', 'color-2-yellow', 'color-3-cyan', 'color-4-green'];

    $scope.marketVal = [5, 4, 3, 2, 1];
    //---------------------------------------------code starts here----------------------------------------------

    //-----------------------           check if this  bond has pdf report available or not

    var checkBondDocument = bondsResourceFactory.checkReportExistsResource.get({cusip: $scope.cusip});
    checkBondDocument.$promise.then(function (checkBondDocument) {
        $scope.haveBondDocument = checkBondDocument.status;
    });
    //--------------------                get Orgid which will be needed for latter calls

    $scope.getOrgIDByIdentifierResource = bondsResourceFactory.getOrgIDByIdentifierResource.get({cusip: $scope.cusip});
    $scope.getOrgIDByIdentifierResource.$promise.then(function (issuerDetailsData) {
        $scope.issuerRawDetails = issuerDetailsData;
        if (!_.isEmpty($scope.issuerRawDetails)) {
            $scope.orgId = $scope.issuerRawDetails.issuer_orgid.orgId;
            if ($scope.relatedNewsClicked) {
                $scope.getRelatedNews($scope.orgId);
            }
            if ($scope.relatedIssuesClicked) {
                $scope.getRelatedIssues($scope.orgId);
            }
        }
    });
    //--------------            get data from gds
    $scope.gdsRawDataResource = bondsResourceFactory.gdsDataResource.get({cusip: $scope.cusip});
    $scope.gdsRawDataResource.$promise.then(function (gdsData) {
            $scope.gdsData = gdsData.basic_data;
            $scope.gdsIssuerData=gdsData.issuer_data;
            if (_.isEmpty($scope.gdsData)) {
                $scope.gdsRawDataResource.error = true;
                return;
            }
            if (emptyCheckFilter($scope.gdsData.security_to_issuer_number, '-') === '-') {
                $scope.gdsRawDataResource.error = true;
                return;
            }
            $scope.issuerSummary = bondsResourceFactory.issuerSummaryResource.getArrayReq({issuerNumber: $scope.gdsData.security_to_issuer_number});
            $scope.showTemplate('overview');


        }, function (error) {
            $scope.gdsRawDataResource.error = true;
        }
    )
    ;

    $scope.showRelatedNewsTab = function (tabValue, isFirst) {
        $scope.activeTab = tabValue;
        var rData = [];
        if (!isFirst) {
            $scope.unbindWatch();
        }
        $scope.relatedNewsTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
        if ($scope.activeTab === 'ALL') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.ratingsAction.length + $scope.relatedNewsRawData.summaryAnalysis.length +
                $scope.relatedNewsRawData.commentaries.length + $scope.relatedNewsRawData.bulletins.length;
            rData = $scope.rNewsDataFormat($scope.relatedNewsRawData, rData);
        }
        else if ($scope.activeTab === 'RATING_ACTION') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.ratingsAction.length;
            rData = $scope.relatedNewsRawData.ratingsAction;
        }
        else if ($scope.activeTab === 'ANALYSIS') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.summaryAnalysis.length;
            rData = $scope.relatedNewsRawData.summaryAnalysis;
        }
        else if ($scope.activeTab === 'COMMENTS') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.commentaries.length;
            rData = $scope.relatedNewsRawData.commentaries;
        }
        else if ($scope.activeTab === 'BULLETIN') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.bulletins.length;
            rData = $scope.relatedNewsRawData.bulletins;
        }
        $scope.unbindWatch = $scope.$watch('relatedNewsTableParams', function (params) {
            $scope.relatedNewsData = rData.slice((params.page - 1) * params.count, params.page * params.count);
        }, true);
    };

    $scope.rNewsDataFormat = function (source, dist) {
        angular.forEach(source.summaryAnalysis, function (element) {
            dist.push(element);
        });
        angular.forEach(source.ratingsAction, function (element) {
            dist.push(element);
        });
        angular.forEach(source.commentaries, function (element) {
            dist.push(element);
        });
        angular.forEach(source.bulletins, function (element) {
            dist.push(element);
        });
        return dist;
    };

    $scope.openBondsQuickView = function (data) {
        $scope.$modalClose();
        QuickViewService.openBondsQuickView({ cusip: data,partner :$scope.modelParam.partner});
    };



    $scope.goToDetailsPage = function () {
        $scope.$modalClose();
        if($location.$$path.indexOf('seamlessQV') > -1|| $location.$$absUrl.indexOf('quickview') > -1){
            window.location.href = $location.$$protocol + '://' + $location.$$host+':'+$location.$$port+'/dist/#/bonds/bondDetails/corp/' + $scope.gdsData.cusip9+'/'+($scope.modelParam.active||'');
        }else{
            $location.path('/bonds/bondDetails/corp/' + $scope.gdsData.cusip9+'/'+($scope.modelParam.active||''));
        }

    };
    $scope.loadIssuerTabData = function () {
        $scope.loadChartURL();
        $scope.getIssueCiqResource = bondsResourceFactory.getIssueCiqResource.get({cusip: $scope.cusip, isin: $scope.gdsData.isin, gvkey: $scope.gdsData.gvkey});
        $scope.getIssueCiqResource.$promise.then(function (ciqIssuerInfo) {
            $scope.ciqIssuerInfo = ciqIssuerInfo;
        }, function () {
            $scope.getIssueCiqResource.error = true;
        });
    };
    $scope.loadPeerAnalysisData = function () {
        $scope.peerAnalysisBondsDataResource = bondsResourceFactory.getPeerAnalysisResource.get({issuerNumber: $scope.gdsData.security_to_issuer_number});
        $scope.peerAnalysisBondsDataResource.$promise.then(function (peerAnalysisBondsData) {
            $scope.peerAnalysisTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
            $scope.peerAnalysisformattedData = $scope.formattedPeerAnalysisData(peerAnalysisBondsData.peers_analysis, $scope.gdsData.security_to_issuer_number);
            $scope.peerAnalysisTableParams.total = $scope.peerAnalysisformattedData.length;
            $scope.$watch('peerAnalysisTableParams', function (params) {
                $scope.peerAnalysisSlicedList = $scope.peerAnalysisformattedData.slice((params.page - 1) * params.count, params.page * params.count);
            }, true);
            if ($scope.peerAnalysisformattedData.length <= 0) {
                $scope.peerAnalysisBondsDataResource.error = true;
            }

        }, function () {
            $scope.peerAnalysisBondsDataResource.error = true;
        });
    };

    $scope.loadRelatedIssue = function () {
        if (emptyCheckFilter($scope.orgId, '-') != '-') {  //not empty orgid
            $scope.getRelatedIssues($scope.orgId);
            return;
        }
        if ($scope.getOrgIDByIdentifierResource.$resolved) { // orgid not found from issiuerdetails call
            $scope.relatedIssuesDataResource = {$resolved: true, error: true};
            return;
        }
        $scope.relatedIssuesClicked = true;   //getOrgIDByIdentifierResource call is pending
    };
    $scope.loadOverviewTabData = function () {
        $scope.quartileDataResource = bondsResourceFactory.quartileDataResource.get({cusip: $scope.cusip});
        $scope.quartileDataResource.$promise.then(function (quartileRawData) {
                $scope.quartileData = quartileRawData;
                $scope.yieldUniverseVal = 0;
                $scope.yieldPeerVal = 0;
                $scope.volatilityUniverseVal = 0;
                $scope.volatilityPeerVal = 0;
                $scope.creditUniverseVal = 0;
                $scope.creditPeerVal = 0;
                if ($scope.quartileData.quartileMeanYieldUniverse) {
                    $scope.yieldUniverseVal = $scope.quartileData.quartileMeanYieldUniverse;
                }
                if ($scope.quartileData.quartileMeanYieldPeergroup) {
                    $scope.yieldPeerVal = $scope.quartileData.quartileMeanYieldPeergroup;
                }
                if ($scope.quartileData.quartileVolatilityUniverse) {
                    $scope.volatilityUniverseVal = parseInt($scope.quartileData.quartileVolatilityUniverse);
                }
                if ($scope.quartileData.quartileVolatilityPeergroup) {
                    $scope.volatilityPeerVal = parseInt($scope.quartileData.quartileVolatilityPeergroup);
                }
                if ($scope.quartileData.quartileCreditRiskUniverse) {
                    $scope.creditUniverseVal = parseInt($scope.quartileData.quartileCreditRiskUniverse);
                }
                if ($scope.quartileData.quartileCreditRiskPeergroup) {
                    $scope.creditPeerVal = parseInt($scope.quartileData.quartileCreditRiskPeergroup);
                }
            },
            function (error) {
                $scope.quartileDataResource.error = true;
            });
        var issueRawInfo = bondsResourceFactory.issueInfoResource.get({cusip: $scope.cusip});
        issueRawInfo.$promise.then(function (issueRawInfo) {
            $scope.issueInfo = issueRawInfo;
            $scope.marketUniverseVal = 0;
            if ($scope.issueInfo.marketActivitySore) {
                $scope.marketUniverseVal = $scope.issueInfo.marketActivitySore;
            }
        });
    };
    $scope.loadRelatedNews = function () {
        if (emptyCheckFilter($scope.orgId, '-') != '-') {  //not empty orgid
            $scope.getRelatedNews($scope.orgId);
            return;
        }
        if ($scope.getOrgIDByIdentifierResource.$resolved) { // orgid not found from issiuerdetails call
            $scope.relatedNewsDataResource = {$resolved: true, error: true};
            return;
        }
        $scope.relatedNewsClicked = true;   //getOrgIDByIdentifierResource call is pending
    };
    $scope.showTemplate = function (tab) {
        $scope.bondsQVActiveTab = tab;
        if (tab === 'issuer') {
            $scope.loadIssuerTabData();
        } else if (tab === 'peer-analysis') {
            $scope.loadPeerAnalysisData();
        } else if (tab === 'related-issues') {
            $scope.loadRelatedIssue();
        } else if (tab === 'overview') {
            $scope.loadOverviewTabData();
        }
        else if (tab === 'related-news') {
            $scope.loadRelatedNews();
        } else if (tab === 'bond-details') {
            $scope.tradeActivityURL = '/SP/msa/service/bonds/issue/ida/image/' + $scope.cusip + '?item=tradeActivityChartSvg';
            $scope.yieldCurveURL = '/SP/msa/service/bonds/issue/ida/image/' + $scope.cusip + '?item=yieldVsMaturityChartSvg';
        }
    };


    $scope.getRelatedIssues = function (orgId) {
        $scope.relIssuesTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
            $scope.relatedIssuesDataResource = bondsResourceFactory.relatedIssuesDataFromAssetServicesResource.get({cusip: $scope.cusip, orgId: $scope.orgId, pageNum: 1, pageSize: 20});
            $scope.relatedIssuesDataResource.$promise.then(function (relatedIssuesRawData) {
                if (relatedIssuesRawData.related_issues.length != 0) {
                    $scope.relIssuesTableParams.total = relatedIssuesRawData.related_issues_size >= 20 ? 20 : relatedIssuesRawData.related_issues_size ;
                    $scope.$watch('relIssuesTableParams', function(params) {
                        $scope.relatedIssuesData =  relatedIssuesRawData.related_issues.slice((params.page - 1) * params.count,params.page * params.count);
                    }, true);
                 } else {
                    $scope.relatedIssuesDataResource.error = true;
                }
            }, function () {
                $scope.relatedIssuesDataResource.error = true;
            });
    };
    $scope.getRelatedNews = function (orgId) {
        $scope.relatedNewsDataResource = bondsResourceFactory.relatedNewsDataFromAssetServicesResource.get({orgId: orgId, creditResearchType: 'ALL', summaryAnalysisTot: '25',cusip:$scope.cusip});
        $scope.relatedNewsDataResource.$promise.then(function (data) {
            $scope.relatedNewsRawData = data.related_news;
            $scope.showRelatedNewsTab('ALL', true);
        }, function () {
            $scope.relatedNewsDataResource.error = true;
        });
    };

    $scope.openDoc=function(){
        $log.info("testing bonds pdf");

        $log.info('cookie my favourite'+$cookies.msa_fe);
        var urlDoc = '/assets-service/bonds/reports/'+$scope.gdsData.cusip9 +'.pdf';
        ga('send', 'pageview', {
            'page': urlDoc,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        window.open(urlDoc, '_blank', 'resizable=yes');
    };
    $scope.loadChartURL = function () {
        $scope.ratingHistoryGraphURL = '/SP/msa/service/bonds/issuer/ida/image/' + $scope.gdsData.security_to_issuer_number + '?item=longTermRatingChartSvg';
        $scope.weaknessData = bondsResourceFactory.weaknessDataResource.getArrayReq({issuerNumber: $scope.gdsData.security_to_issuer_number});
        $scope.strengthData = bondsResourceFactory.strengthDataResource.getArrayReq({issuerNumber: $scope.gdsData.security_to_issuer_number});
        $scope.creditSwapGraphURL = '/SP/msa/service/bonds/issue/ida/image/' + $scope.cusip + '?item=creditDefaultSwapChartSvg';
    }
    $scope.formattedPeerAnalysisData = function (input, issuerNumber) {
        var peerAnalysisBondsData = [];
        var temp = {};
        for (var i = 0; i < input.length; i++) {
            var tempObject = {};
            tempObject.peerGroupCompanyName = input[i].PEER_GROUP_COMPANY_NAME;
            tempObject.peergdsData = input[i].GDSDATA;
            tempObject.creditRating = spRatingFilter(input[i].GDSDATA);
            tempObject.outlook = outlookFilter(input[i].GDSDATA);
            tempObject.creditWatch = creditWatchFilter(input[i].GDSDATA);
            tempObject.peerStarValue = input[i].PEER_STARS_VALUE;
            if (issuerNumber === input[i].ISSUER_NUMBER) {
                temp = tempObject;
            } else {
                peerAnalysisBondsData.push(tempObject);
            }
        }
        peerAnalysisBondsData = orderFilter(peerAnalysisBondsData);
        if (temp.peerGroupCompanyName) {
            peerAnalysisBondsData.unshift(temp);  //Adding at Top
        }
        return peerAnalysisBondsData;
    };

});
