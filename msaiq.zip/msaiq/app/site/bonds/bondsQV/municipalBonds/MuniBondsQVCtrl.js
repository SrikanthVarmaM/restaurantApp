'use strict';

msaiqApp.controller('MuniBondsQVCtrl', function ($scope, $log, bondsResourceFactory, QuickViewService, $resource, $location, $filter, ngTableParams, $, ThomsonService, $cookies,$rootScope,ga) {

    //------------------------------------------variable declaration & intitialization---------------------------------

    $scope.QuickViewService = QuickViewService;
    $scope.ThomsonService = ThomsonService;
    $scope.cusip = $scope.modelParam.cusip;
    $scope.isDetailsPage = false;
    var emptyCheckFilter = $filter('emptyCheckFilter');
    $scope.currentTime = Date();
    $scope.isActiveBond = $scope.modelParam.active;
    $scope.tradeActivityURL = '/assets-service/bonds/charts/' + $scope.cusip + '-TRADE_ACTIVITY_CHART.png';
    $scope.yieldCurveURL = '/assets-service/bonds/charts/' + $scope.cusip + '-YIELD_VS_MATURITY_CHART_30YR.png';
    $scope.candyBarColors = ['color-1-red', 'color-2-yellow', 'color-3-cyan', 'color-4-green'];
    $scope.universeValue = 0;    $scope.comparableValue = 0;
    $scope.priceToDate = {price_todate: ''};
    $scope.haveBondDocument = false;
    $scope.orgId = '';
    //---------------------------------------------code starts here----------------------------------------------

    $scope.invalidCusip = _.isEmpty($scope.cusip);   //--------- return on invalid cusip -------------------
    if ($scope.invalidCusip) {
        return;
    }
    //--------------------                get Orgid which will be needed for relatedissues & relatednews call

    $scope.getOrgIDByIdentifierResource = bondsResourceFactory.getOrgIDByIdentifierResource.get({cusip: $scope.cusip});
    $scope.getOrgIDByIdentifierResource.$promise.then(function (issuerRawDetails) {
        if (emptyCheckFilter(issuerRawDetails, '-') !== '-') {
            $scope.orgId = issuerRawDetails.issuer_orgid.orgId;
            if ($scope.relatedNewsClicked) {
                $scope.getRelatedNews($scope.orgId);
            }
            if ($scope.relatedIssuesClicked) {
                $scope.getRelatedIssues($scope.orgId);
            }
        }
    });     //-----------------------           check if this muni bond has pdf report available or not

    var checkBondDocument = bondsResourceFactory.checkReportExistsResource.get({cusip: $scope.cusip});
    checkBondDocument.$promise.then(function (checkBondDocument) {
        if (checkBondDocument.status === 'true') {
            $scope.haveBondDocument = true;
        }
    });    //
        //calling the below function here cz this data will only be available for a grm covered bond
    if ($scope.isActiveBond) {
        $scope.priceToDate = bondsResourceFactory.grmPriceToDateResource.get({cusip: $scope.cusip}); //need on bond details tab

    }     //-------------------                now get gds data

    $scope.gdsResource = bondsResourceFactory.gdsDataResource.get({cusip: $scope.cusip});
    $scope.gdsResource.$promise.then(function (gdsData) {
            $scope.gdsData = gdsData.basic_data;
            $scope.gdsIssuerData=gdsData.issuer_data;
            if (emptyCheckFilter($scope.gdsData, '-') === '-') {
                $scope.gdsResource.error = true;
                return;
            }
            if (emptyCheckFilter($scope.gdsData.security_to_issuer_number, '-') === '-') {
                $scope.gdsResource.error = true;
                return;
            }
            $scope.showTemplate('overview');
        },
        function (error) {
            $scope.gdsResource.error = true;
        });
    //------------------------------------------------- function definitions ------------------------------------

    $scope.openBondsQuickView = function (data) {
        // close model and then change route.
        $scope.$modalClose();
        QuickViewService.openBondsQuickView({cusip: data,partner :$scope.modelParam.partner});
    };

    $scope.goToDetailsPage = function () {
        $scope.$modalClose();
        if($location.$$path.indexOf('seamlessQV') > -1|| $location.$$absUrl.indexOf('quickview') > -1){
            window.location.href = $location.$$protocol + '://' + $location.$$host+':'+$location.$$port+'/dist/#/bonds/bondDetails/muni/' + $scope.gdsData.cusip9+'/'+($scope.modelParam.active||'');
        }
        else{
            $location.path('/bonds/bondDetails/muni/' + $scope.gdsData.cusip9+'/'+($scope.modelParam.active||''));
        }
    };

    $scope.showTemplate = function (tab) {
        $scope.bondsQVActiveTab = tab;
        if (tab === 'overview') {
            $scope.loadGrmBasicInfo();
        }
        else if (tab === 'participants') {
            $scope.loadParticipants();
        }
        else if (tab === 'comparable') {
            $scope.loadComparables();
        }
        else if (tab === 'related-issues') {
            $scope.loadRelatedIssue();
        }
        else if (tab === 'related-news') {
            $scope.loadRelatedNews();
        }
    };
    $scope.loadComparables = function () {
        if (!$scope.isActiveBond) {
            $scope.comparableBondsDataResource = {error: true, $resolved: true}
        }
        $scope.comparableBondsDataResource = bondsResourceFactory.grmComparableBondsResource.get({cusip: $scope.cusip, pageSize: 10, pageNum: 0});
        $scope.comparableBondsDataResource.$promise.then(function (comparableBondsRawData) {
            $scope.comparableData = comparableBondsRawData;
            if ($scope.comparableData.comparative_performance.length <= 0) {
                $scope.comparableBondsDataResource.error = true;
            }
        }, function (error) {
            $scope.comparableBondsDataResource.error = true;
        });

    };
    $scope.loadRelatedNews = function () {
        if (emptyCheckFilter($scope.orgId, '-') != '-') {  //not empty orgid
            $scope.getRelatedNews($scope.orgId);
            return;
        }
        if ($scope.getOrgIDByIdentifierResource.$resolved){ // orgid not found from issiuerdetails call
            $scope.relatedNewsDataResource ={$resolved :true,error:true} ;
            return;
        }
        $scope.relatedNewsClicked =true;   //getOrgIDByIdentifierResource call is pending

    };


    $scope.loadRelatedIssue = function () {
        if (emptyCheckFilter($scope.orgId, '-') != '-') {  //not empty orgid
            $scope.getRelatedIssues($scope.orgId);
            return;
        }
        if ($scope.getOrgIDByIdentifierResource.$resolved){ // orgid not found from issiuerdetails call
            $scope.relatedNewsDataResource ={$resolved :true,error:true} ;
            return;
        }
        $scope.relatedIssuesClicked =true;   //getOrgIDByIdentifierResource call is pending
    };
    $scope.getRelatedNews = function (orgId) {
        $scope.relatedNewsDataResource = bondsResourceFactory.relatedNewsDataFromAssetServicesResource.get({orgId: orgId, creditResearchType: 'ALL', summaryAnalysisTot: '25',cusip:$scope.cusip});
        $scope.relatedNewsDataResource.$promise.then(function (data) {
            $scope.relatedNewsRawData = data.related_news;
            $scope.showRelatedNewsTab('ALL', true);
        }, function () {
            $scope.relatedNewsDataResource.error = true;
        });
    };
    $scope.getRelatedIssues = function (orgId) {
        $scope.relIssuesTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
            $scope.relatedIssuesDataResource =  bondsResourceFactory.relatedIssuesDataFromAssetServicesResource.get({cusip:$scope.cusip,orgId:$scope.orgId, pageNum:1, pageSize:20});
            $scope.relatedIssuesDataResource.$promise.then(function(relatedIssuesRawData){
                if(relatedIssuesRawData.related_issues.length != 0){
                    $scope.relIssuesTableParams.total =  relatedIssuesRawData.related_issues_size >= 20 ? 20 : relatedIssuesRawData.related_issues_size;;
                    $scope.$watch('relIssuesTableParams', function(params) {
                        $scope.relatedIssuesData =  relatedIssuesRawData.related_issues.slice((params.page - 1) * params.count,params.page * params.count);
                    }, true);
                } else {
                    $scope.relatedIssuesDataResource.error = true;
                }
            },function() {
                $scope.relatedIssuesDataResource.error = true;
            });

    };

    $scope.openDoc=function(){
        $log.info("testing bonds pdf");

        $log.info('cookie my favourite'+$cookies.msa_fe);
        var urlDoc = '/assets-service/bonds/reports/'+$scope.gdsData.cusip9 +'.pdf';
        ga('send', 'pageview', {
            'page': urlDoc,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        window.open(urlDoc, '_blank', 'resizable=yes');
    };

        $scope.loadGrmBasicInfo = function () {
        if (!$scope.isActiveBond) {
            $scope.grmBondsBasicInfoResource = {error: true, $resolved: true};
            return;
        }
        $scope.grmBondsBasicInfoResource = bondsResourceFactory.grmBondsBasicInfoResource.get({cusip: $scope.cusip});
        $scope.grmBondsBasicInfoResource.$promise.then(function (grmBondBasicRawData) {
            $scope.grmBondsBasicInfo = grmBondBasicRawData;

            if ($scope.grmBondsBasicInfo.grm_basic_info.currentPeer) {
                $scope.comparableValue = $scope.grmBondsBasicInfo.grm_basic_info.currentPeer.quartileBidYieldComparable;
            }
            if ($scope.grmBondsBasicInfo.grm_basic_info.issue.derivedAttribute) {
                $scope.universeValue = $scope.grmBondsBasicInfo.grm_basic_info.issue.derivedAttribute.quartileBidYieldUniverse;
            }
        }, function () {
            $scope.grmBondsBasicInfoResource.error = true;
        });
    };
    $scope.loadParticipants = function () {
        $scope.grmParticipantsInfoResource = bondsResourceFactory.grmParticipantsInfoResource.get({cusip: $scope.cusip, pageSize: 10, pageNum: 0});
        $scope.grmParticipantsInfoResource.$promise.then(function (participantsRawInfo) {
            $scope.participantsData = participantsRawInfo.participant_info;
            if (!$scope.participantsData) {
                $scope.grmParticipantsInfoResource.error = true;
            }

        }, function () {
            $scope.grmParticipantsInfoResource.error = true;
        });
    };



    $scope.showRelatedNewsTab = function (tabValue, isFirst) {
        $scope.activeTab = tabValue;
        var rData = [];
        if (!isFirst) {
            $scope.unbindWatch();
        }
        $scope.relatedNewsTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
        if ($scope.activeTab === 'ALL') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.ratingsAction.length + $scope.relatedNewsRawData.summaryAnalysis.length +
                $scope.relatedNewsRawData.commentaries.length + $scope.relatedNewsRawData.bulletins.length;
            rData = $scope.rNewsDataFormat($scope.relatedNewsRawData, rData);
        }
        else if ($scope.activeTab === 'RATING_ACTION') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.ratingsAction.length;
            rData = $scope.relatedNewsRawData.ratingsAction;
        }
        else if ($scope.activeTab === 'ANALYSIS') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.summaryAnalysis.length;
            rData = $scope.relatedNewsRawData.summaryAnalysis;
        }
        else if ($scope.activeTab === 'COMMENTS') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.commentaries.length;
            rData = $scope.relatedNewsRawData.commentaries;
        }
        else if ($scope.activeTab === 'BULLETIN') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.bulletins.length;
            rData = $scope.relatedNewsRawData.bulletins;
        }
        $scope.unbindWatch = $scope.$watch('relatedNewsTableParams', function (params) {
            $scope.relatedNewsData = rData.slice((params.page - 1) * params.count, params.page * params.count);
        }, true);
    };

    $scope.rNewsDataFormat = function (source, dist) {
        angular.forEach(source.summaryAnalysis, function (element) {
            dist.push(element);
        });
        angular.forEach(source.ratingsAction, function (element) {
            dist.push(element);
        });
        angular.forEach(source.commentaries, function (element) {
            dist.push(element);
        });
        angular.forEach(source.bulletins, function (element) {
            dist.push(element);
        });
        return dist;
    };

})
;
