'use strict';

msaiqApp.controller('BondsLandingCtrl', function ($scope, $log, articleResourceFactory, QuickViewService) {

    $scope.QuickViewService = QuickViewService;

});