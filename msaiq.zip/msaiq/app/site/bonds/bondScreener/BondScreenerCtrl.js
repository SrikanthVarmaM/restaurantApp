'use strict';

msaiqApp.controller('BondScreenerCtrl', function ($scope, $log, $http, $filter, $location, $window, QuickViewService,ga,$rootScope) {
    {
        $log.info('Begin BondScreenerCtrl');

        $scope.criteriaSet = {
            'security type': {},
            'min yield': 'ANY',
            'max yield': 'ANY',
            'tax status': {},
            'min coupon': 'ANY',
            'max coupon': 'ANY',
            'coupon type': {},
            'state': {},
            'rating type': {},
            'min maturity': 'ANY',
            'max maturity': 'ANY',
            'rating': {},
            'currency': {},
            's&p fixed income research': {}
        };

        $scope.aggj =
        {
            'size': 0,
            'aggs': {
                'filter_agg': {
                    'filter': {
                        'and': [
                            { 'match_all': { } }
                        ]
                    },
                    'aggs': {
                        'bond_type_agg': { 'terms': { 'field': 'identifier_source_c' } },
                        'taxable_agg': { 'terms': { 'field': 'taxable_ind_calc' } },
                        'state_agg': { 'terms': { 'field': 'state_code_c', 'size': 100 } },
                        'credit_rating_type_agg': { 'terms': { 'field': 'credit_rating_type.raw', 'size': 15 } },
                        'credit_rating_agg': { 'terms': { 'field': 'credit_rating_primary_calc.raw', 'size': 200, 'order': { '_term': 'asc' } } },
                        'credit_rating_rt_agg': { 'terms': { 'field': 'credit_rating_calc.raw', 'size': 200, 'order': { '_term': 'asc' } } },
                        'yield_agg': { 'histogram': { 'field': 'yield_calc', 'interval': 10 } },
                        'coupon_agg': { 'histogram': { 'field': 'coupon_rate_calc', 'interval': 10 } },
                        'coupon_type_agg': { 'terms': { 'field': 'coupon_rate_ind_calc', 'size': 15 } },
                        'maturity_agg': { 'date_histogram': { 'field': 'maturity_d', 'interval': 'year' } },
                        'currency_agg': { 'terms': { 'field': 'currency_code_c' } },
                        'report_agg': { 'terms': { 'field': 'grm_haveDoc' } }
                    }
                }
            }
        };

        $scope.queryj =
        {
            'from': 0,
            'size': 20,
            'sort': [
                { 'yield_calc': {'order': 'desc'}}
            ],
            '_source': [
                'identifier_c',
                'identifier_source_c',
                'org_publ_name_calc',
                'yield_calc',
                'coupon_rate_calc',
                'maturity_d',
                'credit_rating_type',
                'credit_rating',
                'credit_rating_date'
            ],
            'query': {
                'filtered': {
                    'query': { 'match_all': {} },
                    'filter': {
                        'and': [
                            { 'match_all': { } },
                            { 'not': {'missing': {'field': 'identifier_c', 'existence': true, 'null_value': true}}},
                            { 'not': {'missing': {'field': 'include_cusip', 'existence': true, 'null_value': true}}}
                        ]
                    }
                }
            }
        };

        $scope.filter =
        {
            'typeFilter': { 'terms': { 'identifier_source_c': [] } },
            'taxableFilter': { 'terms': { 'taxable_ind_calc': [] } },
            'stateFilter': { 'terms': { 'state_code_c': [] } },
            'ratingTypeFilter': { 'terms': { 'credit_rating_type.raw': [] } },
            'ratingFilter': { 'terms': { 'credit_rating_primary_calc.raw': [] } },
            'couponTypeFilter': { 'terms': { 'coupon_rate_ind_calc': [] } },
            'yieldFilter': { 'range': { 'yield_calc': { 'gte': 'ANY', 'lte': 'ANY' } } },
            'couponFilter': { 'range': { 'coupon_rate_calc': { 'gte': 'ANY', 'lte': 'ANY' } } },
            'maturityFilter': { 'range': { 'maturity_d': { 'gte': 'ANY', 'lte': 'ANY' } } },
            'maturityMinFilter': { 'range': { 'maturity_d': { 'gte': 'ANY' } } },
            'maturityAllFilter': {'or': [
                {'missing': {'field': 'maturity_d', 'existence': true, 'null_value': true}}
            ]},
            'currencyFilter': { 'terms': { 'currency_code_c': [] } },
            'reportFilter': { 'terms': { 'grm_haveDoc': [] } }
        };


        $scope.results = {'aloaded': false, 'qloaded': false, 'loading': true, 'error': false, 'breadcrumb': ''};
        $scope.amaster = null;
        $scope.qresults = {};

        $scope.selectAny = {key: 'ANY', doc_count: 0};
        $scope.yield = {};
        $scope.yield.yieldMin = $scope.yield.yieldMax = $scope.selectAny;
        $scope.coupon = {};
        $scope.coupon.couponMin = $scope.coupon.couponMax = $scope.selectAny;
        $scope.maturity = {};
        $scope.maturity.maturityMin = $scope.maturity.maturityMax = $scope.selectAny;

        $scope.ratingTypeMap =
        {
            'FCL': 'Foreign Currency Long-Term',
            'FCS': 'Foreign Currency Short-Term',
            'LCL': 'Local Currency Long-Term',
            'LCS': 'Local Currency Short-Term'
        };

        $scope.criteria = {'open': true};
        $scope.pageWatch = false;
        $scope.ratingMap = {};

        $scope.sort =
        {
            'dir': {
                'sortAsc': { 'order': 'asc', 'missing': '_last' },
                'sortDesc': { 'order': 'desc', 'missing': '_first' }
            },
            'sortFields': {
                'security': 'identifier_c',
                'issuer': 'org_publ_name_calc.raw',
                'type': 'identifier_source_c',
                'rating_type': 'credit_rating_type.raw',
                'rating': 'credit_rating_secondary_calc.raw',
                'rating_date': 'credit_rating_date',
                'yield': 'yield_calc',
                'coupon': 'coupon_rate_calc',
                'maturity_date': 'maturity_d'
            }
        };

        if (!Object.keys) {
            Object.keys = function (obj) {
                var keys = [];

                for (var i in obj) {
                    if (obj.hasOwnProperty(i)) {
                        keys.push(i);
                    }
                }

                return keys;
            };
        }

        $scope.sort.key = $scope.sort.keySecondary = Object.keys($scope.sort.sortFields)[1];
        $scope.sort.dirDefault = $scope.sort.dir.sortAsc;
        $scope.sort.fieldDefault = $scope.sort.fieldSecondary = $scope.sort.sortFields[$scope.sort.key];

        $scope.fmtBreadcrumb = function (bc, label, field) {
            var i, parsedField = [];
            if (label === 'S&P Rating') {
                for (i = 0; i < field.length; i++) {
                    if (field[i].indexOf('(sf)') === -1) {
                        if (field[i].indexOf('0023:D') === -1) {
                            var rating = field[i].split(':')[1].toUpperCase();
                            if (parsedField.indexOf(rating) === -1) {
                                // make sure we don't have duplicates
                                parsedField.push(rating);
                            }
                        }
                    }
                }
            } else if (label === 'Yield' || label === 'Coupon') {
                if (typeof field.gte !== 'undefined') {
                    parsedField.push('>=' + (field.gte / 10).toString());
                }
                if (typeof field.lte !== 'undefined') {
                    parsedField.push('<=' + (field.lte / 10).toString());
                }
            } else if (label === 'Maturity') {
                if (typeof field.gte !== 'undefined') {
                    parsedField.push('>=' + $scope.filterDate(field.gte, 'yyyy'));
                }
                if (typeof field.lte !== 'undefined') {
                    parsedField.push('<=' + $scope.filterDate(field.lte, 'yyyy'));
                }
            } else if (label === 'Security Type') {
                for (i = 0; i < field.length; i++) {
                    var type = field[i].replace('nsf', 'CORP/GOVT/AGENCY').replace('sf', 'STRUCTURED FINANCE').replace('muni', 'MUNICIPAL');
                    if (parsedField.indexOf(type) === -1) {
                        // make sure we don't have duplicates
                        parsedField.push(type);
                    }
                }
            } else {
                for (i = 0; i < field.length; i++) {
                    var value = field[i].toUpperCase();
                    if (parsedField.indexOf(value) === -1) {
                        // make sure we don't have duplicates
                        parsedField.push(value);
                    }
                }
            }
            bc += ((bc === '') ? ' ' : ' + ') + label + ' = ' + JSON.stringify(parsedField).replace('[', '').replace(']', '');
            return bc;
        };

        $scope.addSort = function (query) {
            var dir = {}, sort = {}, sortSecondary = {};
            dir = $scope.sort.dirDefault;
            sort[$scope.sort.fieldDefault] = dir;
            sortSecondary[$scope.sort.fieldSecondary] = dir;

            //query.sort.pop();
            query.sort.length = 0;
            query.sort.push(sort);

            if (JSON.stringify($scope.sort.fieldDefault) !== JSON.stringify($scope.sort.fieldSecondary)) {
                query.sort.push(sortSecondary);
            }
        };

        $scope.addAggFilters = function (json) {
            var new_json = JSON.parse(JSON.stringify(json));
            if ($scope.filter.typeFilter.terms['identifier_source_c'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.typeFilter);
            }
            if ($scope.filter.taxableFilter.terms['taxable_ind_calc'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.taxableFilter);
            }
            if ($scope.filter.stateFilter.terms['state_code_c'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.stateFilter);
            }
            if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.ratingTypeFilter);
            }
            if ($scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.ratingFilter);
            }
            if ($scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.couponTypeFilter);
            }

            if ($scope.filter.yieldFilter.range['yield_calc'].gte !== 'ANY' ||
                $scope.filter.yieldFilter.range['yield_calc'].lte !== 'ANY') {
                if ($scope.filter.yieldFilter.range['yield_calc'].gte === 'ANY') {
                    delete $scope.filter.yieldFilter.range['yield_calc'].gte;
                }
                if ($scope.filter.yieldFilter.range['yield_calc'].lte === 'ANY') {
                    delete $scope.filter.yieldFilter.range['yield_calc'].lte;
                }
                new_json.aggs.filter_agg.filter.and.push($scope.filter.yieldFilter);
            }

            if ($scope.filter.couponFilter.range['coupon_rate_calc'].gte !== 'ANY' ||
                $scope.filter.couponFilter.range['coupon_rate_calc'].lte !== 'ANY') {
                if ($scope.filter.couponFilter.range['coupon_rate_calc'].gte === 'ANY') {
                    delete $scope.filter.couponFilter.range['coupon_rate_calc'].gte;
                }
                if ($scope.filter.couponFilter.range['coupon_rate_calc'].lte === 'ANY') {
                    delete $scope.filter.couponFilter.range['coupon_rate_calc'].lte;
                }
                new_json.aggs.filter_agg.filter.and.push($scope.filter.couponFilter);
            }

            if ($scope.filter.maturityFilter.range['maturity_d'].gte !== 'ANY' ||
                $scope.filter.maturityFilter.range['maturity_d'].lte !== 'ANY') {
                // if maturity min = ANY or maturity min <= today, set to today
                if ($scope.filter.maturityFilter.range['maturity_d'].gte === 'ANY' ||
                    $scope.filter.maturityFilter.range['maturity_d'].gte <=
                    $scope.filter.maturityMinFilter.range['maturity_d'].gte) {
                    $scope.filter.maturityFilter.range['maturity_d'].gte =
                        $scope.filter.maturityMinFilter.range['maturity_d'].gte;
                }
                if ($scope.filter.maturityFilter.range['maturity_d'].lte === 'ANY') {
                    delete $scope.filter.maturityFilter.range['maturity_d'].lte;
                }
                new_json.aggs.filter_agg.filter.and.push($scope.filter.maturityFilter);
            } else {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.maturityMinFilter);
            }

            if ($scope.filter.currencyFilter.terms['currency_code_c'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.currencyFilter);
            }

            if ($scope.filter.reportFilter.terms['grm_haveDoc'].length > 0) {
                new_json.aggs.filter_agg.filter.and.push($scope.filter.reportFilter);
            }

            return new_json;
        };

        $scope.addQueryFilters = function (json) {
            var new_json = JSON.parse(JSON.stringify(json));
            var breadcrumb = '';
            if ($scope.filter.typeFilter.terms['identifier_source_c'].length > 0) {
                new_json.query.filtered.filter.and.push($scope.filter.typeFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Security Type', $scope.filter.typeFilter.terms['identifier_source_c']);
            }

            if ($scope.filter.taxableFilter.terms['taxable_ind_calc'].length > 0) {
                if ($scope.filter.typeFilter.terms['identifier_source_c'].indexOf('nsf') > -1 &&
                    $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('muni') === -1) {
                    // do not add taxable filter if only nsf is checked
                } else {
                    new_json.query.filtered.filter.and.push($scope.filter.taxableFilter);
                    breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Tax Status', $scope.filter.taxableFilter.terms['taxable_ind_calc']);
                }
            }

            if ($scope.filter.stateFilter.terms['state_code_c'].length > 0) {
                if ($scope.filter.typeFilter.terms['identifier_source_c'].indexOf('nsf') > -1 &&
                    $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('muni') === -1) {
                    // do not add state filter if only nsf is checked
                } else {
                    new_json.query.filtered.filter.and.push($scope.filter.stateFilter);
                    breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'State', $scope.filter.stateFilter.terms['state_code_c']);
                }
            }

            if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].length > 0) {
                new_json.query.filtered.filter.and.push($scope.filter.ratingTypeFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'S&P Rating Type', $scope.filter.ratingTypeFilter.terms['credit_rating_type.raw']);
            }

            if ($scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].length > 0) {
                if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].length > 0) {
                    // if any of the rating types are checked, strip out ratings that are invalid
                    var strippedRatingFilter = $scope.stripRatings();
                    if (strippedRatingFilter.terms['credit_rating_primary_calc.raw'].length > 0) {
                        new_json.query.filtered.filter.and.push(strippedRatingFilter);
                        breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'S&P Rating', strippedRatingFilter.terms['credit_rating_primary_calc.raw']);
                    }
                } else {
                    new_json.query.filtered.filter.and.push($scope.filter.ratingFilter);
                    breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'S&P Rating', $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw']);
                }
            }

            if ($scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].length > 0) {
                new_json.query.filtered.filter.and.push($scope.filter.couponTypeFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Coupon Type', $scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc']);
            }

            if ($scope.filter.yieldFilter.range['yield_calc'].gte !== 'ANY' ||
                $scope.filter.yieldFilter.range['yield_calc'].lte !== 'ANY') {
                if ($scope.filter.yieldFilter.range['yield_calc'].gte === 'ANY') {
                    delete $scope.filter.yieldFilter.range['yield_calc'].gte;
                }
                if ($scope.filter.yieldFilter.range['yield_calc'].lte === 'ANY') {
                    delete $scope.filter.yieldFilter.range['yield_calc'].lte;
                }
                new_json.query.filtered.filter.and.push($scope.filter.yieldFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Yield', $scope.filter.yieldFilter.range['yield_calc']);
            }

            if ($scope.filter.couponFilter.range['coupon_rate_calc'].gte !== 'ANY' ||
                $scope.filter.couponFilter.range['coupon_rate_calc'].lte !== 'ANY') {
                // if maturity min = ANY or maturity min < today, set to today
                if ($scope.filter.couponFilter.range['coupon_rate_calc'].gte === 'ANY') {
                    delete $scope.filter.couponFilter.range['coupon_rate_calc'].gte;
                }
                if ($scope.filter.couponFilter.range['coupon_rate_calc'].lte === 'ANY') {
                    delete $scope.filter.couponFilter.range['coupon_rate_calc'].lte;
                }
                new_json.query.filtered.filter.and.push($scope.filter.couponFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Coupon', $scope.filter.couponFilter.range['coupon_rate_calc']);
            }

            if ($scope.filter.maturityFilter.range['maturity_d'].gte !== 'ANY' ||
                $scope.filter.maturityFilter.range['maturity_d'].lte !== 'ANY') {
                // if maturity min = ANY or maturity min <= today, set to today
                if ($scope.filter.maturityFilter.range['maturity_d'].gte === 'ANY' ||
                    $scope.filter.maturityFilter.range['maturity_d'].gte <=
                    $scope.filter.maturityMinFilter.range['maturity_d'].gte) {
                    $scope.filter.maturityFilter.range['maturity_d'].gte =
                        $scope.filter.maturityMinFilter.range['maturity_d'].gte;
                }
                if ($scope.filter.maturityFilter.range['maturity_d'].lte === 'ANY') {
                    delete $scope.filter.maturityFilter.range['maturity_d'].lte;
                }
                new_json.query.filtered.filter.and.push($scope.filter.maturityFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Maturity', $scope.filter.maturityFilter.range['maturity_d']);
            } else {
                var new_maturityAllFilter = JSON.parse(JSON.stringify($scope.filter.maturityAllFilter));
                new_json.query.filtered.filter.and.push(new_maturityAllFilter);
                var position = new_json.query.filtered.filter.and.length;
                new_json.query.filtered.filter.and[position - 1].or.push($scope.filter.maturityMinFilter);
                //new_json.query.filtered.filter.and.push($scope.filter.maturityMinFilter);
            }

            if ($scope.filter.currencyFilter.terms['currency_code_c'].length > 0) {
                new_json.query.filtered.filter.and.push($scope.filter.currencyFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'Currency', $scope.filter.currencyFilter.terms['currency_code_c']);
            }

            if ($scope.filter.reportFilter.terms['grm_haveDoc'].length > 0) {
                new_json.query.filtered.filter.and.push($scope.filter.reportFilter);
                breadcrumb = $scope.fmtBreadcrumb(breadcrumb, 'S&P Fixed Income Research', $scope.filter.reportFilter.terms['grm_haveDoc']);
            }

            $scope.results.breadcrumb = breadcrumb;
            return new_json;
        };

        $scope.getKeyAgg = function (buckets, key) {
            var results = jQuery.grep(buckets,
                function (e) {
                    return e.key === key;
                });
            return results[0];
        };

        $scope.getAgg = function () {
            var aggj = $scope.addAggFilters($scope.aggj);
            var aggs = JSON.stringify(aggj);
            $http({
                url: '/es/bondscreener/bonds/_search?preference=bonds',
                dataType: 'json',
                method: 'post',
                data: aggs,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                }
            }).success(function (results) {
                $scope.results.atotal = results.aggregations.filter_agg.doc_count;
                if ($scope.amaster === null) {
                    $scope.amaster = JSON.parse(JSON.stringify(results));
                    $scope.aresults = results;
                    $scope.aresults.aggregations.filter_agg.yield_agg.buckets.unshift($scope.selectAny);
                    $scope.aresults.aggregations.filter_agg.coupon_agg.buckets.unshift($scope.selectAny);
                    $scope.aresults.aggregations.filter_agg.maturity_agg.buckets.unshift($scope.selectAny);
                }

                $scope.yield.yieldMin = $scope.getKeyAgg($scope.aresults.aggregations.filter_agg.yield_agg.buckets, $scope.yield.yieldMin.key);
                $scope.yield.yieldMax = $scope.getKeyAgg($scope.aresults.aggregations.filter_agg.yield_agg.buckets, $scope.yield.yieldMax.key);

                $scope.coupon.couponMin = $scope.getKeyAgg($scope.aresults.aggregations.filter_agg.coupon_agg.buckets, $scope.coupon.couponMin.key);
                $scope.coupon.couponMax = $scope.getKeyAgg($scope.aresults.aggregations.filter_agg.coupon_agg.buckets, $scope.coupon.couponMax.key);

                $scope.maturity.maturityMin = $scope.getKeyAgg($scope.aresults.aggregations.filter_agg.maturity_agg.buckets, $scope.maturity.maturityMin.key);
                $scope.maturity.maturityMax = $scope.getKeyAgg($scope.aresults.aggregations.filter_agg.maturity_agg.buckets, $scope.maturity.maturityMax.key);
                $scope.results.aloaded = true;
            }).error(function (error) {
                $log.error('Bond screener agg error: ' + error.status);
                $scope.results.atotal = 0;
                //$scope.aresults = {};
                $scope.results.aloaded = true;
                $scope.results.error = true;
            });
        };

        $scope.getQuery = function () {
            var queryj = $scope.addQueryFilters($scope.queryj);
            $scope.addSort(queryj);
            queryj.from = $scope.qfrom;
            var querys = JSON.stringify(queryj);
            var qdate = new Date().valueOf();
            $http({
                url: '/es/bondscreener/bonds/_search?preference=bonds',
                dataType: 'json',
                method: 'post',
                data: querys,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                }
            }).success(function (results) {
                $scope.results.qtotal = results.hits.total;
                //$scope.results.qdate = qdate;
                $scope.qpages = Math.ceil($scope.results.qtotal / $scope.qsize);
                $scope.qresults = results;
                $scope.results.qloaded = true;
                $scope.results.loading = false;
                $scope.sendToGA();
            }).error(function (error) {
                $log.error('Bond screener query error: ' + error.status);
                $scope.results.qtotal = 0;
                $scope.results.qdate = qdate;
                $scope.qpages = 0;
                $scope.qresults = {};
                $scope.results.qloaded = true;
                $scope.results.error = true;
                $scope.results.loading = false;
            });
        };

        $scope.getLoadDate = function () {
            $http({
                url: '/es/bondscreener/bonds/loadDate',
                method: 'get'
            }).success(function (results) {
                $scope.results.qdate = results._source.load_date;
            }).error(function (error) {
                $log.error('Bond screener load date error: ' + error.status);
            });
        };

        $scope.submitSearch = function (doAgg) {
            $scope.qsize = 20;
            $scope.qfrom = 0;
            $scope.qpage = 1;
            if (doAgg === true) {
                $scope.getAgg();
            }
            $scope.getQuery();
            $scope.sendToGAFlag = true;
            $scope.getLoadDate();
        };

        $scope.submitMasterSearch = function () {
            $log.info('submitMasterSearch');
            if ($scope.amaster === null) {
                // master aggregation not loaded yet
                setTimeout(function () {
                    $scope.submitMasterSearch();
                }, 100);
            } else {
                // master aggregation is loaded - set default criteria and submit search
                $scope.setRating('0001:AAA');
                $scope.submitSearch(false);
            }
        };

        $scope.resetSearch = function () {
            $scope.filter.typeFilter.terms['identifier_source_c'].length = 0;
            $scope.filter.taxableFilter.terms['taxable_ind_calc'].length = 0;
            $scope.filter.stateFilter.terms['state_code_c'].length = 0;
            $scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].length = 0;
            $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].length = 0;
            $scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].length = 0;

            $scope.filter.yieldFilter.range['yield_calc'].gte = 'ANY';
            $scope.filter.yieldFilter.range['yield_calc'].lte = 'ANY';
            $scope.yield.yieldMin = $scope.yield.yieldMax = $scope.selectAny;

            $scope.filter.couponFilter.range['coupon_rate_calc'].gte = 'ANY';
            $scope.filter.couponFilter.range['coupon_rate_calc'].lte = 'ANY';
            $scope.coupon.couponMin = $scope.coupon.couponMax = $scope.selectAny;

            $scope.filter.maturityFilter.range['maturity_d'].gte = 'ANY';
            $scope.filter.maturityFilter.range['maturity_d'].lte = 'ANY';
            $scope.maturity.maturityMin = $scope.maturity.maturityMax = $scope.selectAny;

            $scope.filter.currencyFilter.terms['currency_code_c'].length = 0;
            $scope.filter.reportFilter.terms['grm_haveDoc'].length = 0;

            $scope.resetSort();
            $scope.openHeader('headerType');
            $scope.openHeader('headerTaxable');
            $scope.openHeader('headerState');
            $scope.openHeader('headerRatingType');
            $scope.openHeader('headerRating');
            $scope.openHeader('headerYield');
            $scope.openHeader('headerCoupon');
            $scope.openHeader('headerCouponType');
            $scope.openHeader('headerMaturity');
            $scope.openHeader('headerCurrency');
            $scope.openHeader('headerReport');
            $scope.scrollState(true);
            $scope.results.error = false;
            //$scope.amaster = null;
            $scope.qresults = {};

            $scope.results.loading = true;
            // get master aggregation
            //$scope.getAgg();
            // wait for master
            $scope.submitMasterSearch();
        };

        $scope.checkType = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.typeFilter.terms['identifier_source_c'].indexOf(bucket.key) === -1) {
                    $scope.filter.typeFilter.terms['identifier_source_c'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.typeFilter.terms['identifier_source_c'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.typeFilter.terms['identifier_source_c'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
            // if nsf or sf is checked and muni is not checked, don't show
            if (($scope.filter.typeFilter.terms['identifier_source_c'].indexOf('nsf') > -1 ||
                $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('sf') > -1) &&
                $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('muni') === -1) {
                $scope.closeHeader('headerTaxable');
            } else {
                $scope.openHeader('headerTaxable');
            }
            // if nsf or sf is checked and muni is not checked, don't show
            if (($scope.filter.typeFilter.terms['identifier_source_c'].indexOf('nsf') > -1 ||
                $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('sf') > -1) &&
                $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('muni') === -1) {
                $scope.closeHeader('headerState');
                $scope.scrollState(false);
            } else {
                $scope.openHeader('headerState');
                $scope.scrollState(true);
            }
        };
        $scope.isCheckedType = function (bucket) {
            var index = $scope.filter.typeFilter.terms['identifier_source_c'].indexOf(bucket.key);
            $scope.setCriteriaForGA('security type', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.sortType = function (bucket) {
            var typeReturn = bucket.key.replace('nsf', 'CORP/GOVT/AGENCY');
            return typeReturn;
        };

        $scope.checkTaxable = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.taxableFilter.terms['taxable_ind_calc'].indexOf(bucket.key) === -1) {
                    $scope.filter.taxableFilter.terms['taxable_ind_calc'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.taxableFilter.terms['taxable_ind_calc'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.taxableFilter.terms['taxable_ind_calc'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedTaxable = function (bucket) {
            var index = $scope.filter.taxableFilter.terms['taxable_ind_calc'].indexOf(bucket.key);
            $scope.setCriteriaForGA('tax status', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.showTaxable = function (bucket) {
            // if nsf is checked and muni is not checked, don't show
            if ($scope.filter.typeFilter.terms['identifier_source_c'].indexOf('nsf') > -1 &&
                $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('muni') === -1) {
                return false;
            } else {
                return true;
            }
        };

        $scope.checkState = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.stateFilter.terms['state_code_c'].indexOf(bucket.key) === -1) {
                    $scope.filter.stateFilter.terms['state_code_c'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.stateFilter.terms['state_code_c'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.stateFilter.terms['state_code_c'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedState = function (bucket) {
            var index = $scope.filter.stateFilter.terms['state_code_c'].indexOf(bucket.key);
            $scope.setCriteriaForGA('state', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.showState = function (bucket) {
            // state = 'n' is not valid (seen on nsf only)
            // if nsf is checked and muni is not checked, don't show
            if (bucket.key === 'n') {
                return false;
            } else if ($scope.filter.typeFilter.terms['identifier_source_c'].indexOf('nsf') > -1 &&
                $scope.filter.typeFilter.terms['identifier_source_c'].indexOf('muni') === -1) {
                return false;
            } else {
                return true;
            }
        };
        $scope.scrollState = function (flag) {
            if (flag === true) {
                if (!jQuery('div[id=' + 'resultsState' + ']').hasClass('scroll')) {
                    jQuery('div[id=' + 'resultsState' + ']').addClass('scroll');
                }
            } else {
                if (jQuery('div[id=' + 'resultsState' + ']').hasClass('scroll')) {
                    jQuery('div[id=' + 'resultsState' + ']').removeClass('scroll');
                }
            }
        };

        $scope.checkRatingType = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].indexOf(bucket.key) === -1) {
                    $scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedRatingType = function (bucket) {
            var index = $scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].indexOf(bucket.key);
            $scope.setCriteriaForGA('rating type', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.showRatingType = function (bucket) {
            if (bucket.key === '') {
                return false;
            } else {
                return true;
            }
        };

        $scope.checkRating = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].indexOf(bucket.key) === -1) {
                    $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].push(bucket.key);
                    $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].push(bucket.key + ' (sf)');
                    if (bucket.key.indexOf('0024:D') > -1) {
                        var altD = bucket.key.replace('24', '23');
                        $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].push(altD);
                        $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].push(altD + ' (sf)');
                    }
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].splice(index, 1);
                }
                index = $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].indexOf(bucket.key + ' (sf)');
                if (index > -1) {
                    $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedRating = function (bucket) {
            var index = $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].indexOf(bucket.key);
            $scope.setCriteriaForGA('rating', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.setRating = function (key) {
            $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].push(key);
            $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].push(key + ' (sf)');
            $scope.setCriteriaForGA('rating', key, true);

        };
        $scope.getRatingTypes = function (key) {
            var results1 = $scope.ratingMap[key];
            if (results1 !== undefined) {
                return results1;
            } else {
                var results2 = [];
                if ($scope.amaster !== null) {
                    var matches = jQuery.grep($scope.amaster.aggregations.filter_agg.credit_rating_rt_agg.buckets,
                        function (e) {
                            return (e.key.indexOf(key) > -1);
                        });
                    for (var i = 0; i < matches.length; i++) {
                        var ratingType = matches[i].key.slice(matches[i].key.lastIndexOf(':') + 1);
                        if (results2.indexOf(ratingType) === -1) {
                            results2.push(ratingType);
                        }
                    }
                    // save results for quicker lookup later since this function gets called a lot
                    $scope.ratingMap[key] = results2;
                }
                return results2;
            }
        };
        $scope.stripRatings = function () {
            // create new empty filter from active filter
            var ratingFilter = JSON.parse(JSON.stringify($scope.filter.ratingFilter));
            ratingFilter.terms['credit_rating_primary_calc.raw'].length = 0;

            for (var h = 0; h < $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'].length; h++) {
                var rating = $scope.filter.ratingFilter.terms['credit_rating_primary_calc.raw'][h];
                var ratingTypes = $scope.getRatingTypes(rating);
                for (var i = 0; i < ratingTypes.length; i++) {
                    // get the long value of the rating type abbreviation
                    var longValue = $scope.ratingTypeMap[ratingTypes[i]];
                    // if rating type of rating is one of the checked rating types - save it to new filter
                    if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].indexOf(longValue) > -1) {
                        ratingFilter.terms['credit_rating_primary_calc.raw'].push(rating);
                        // already added for this rating, so break out of inner for loop
                        break;
                    }
                }
            }
            return ratingFilter;
        };
        $scope.showRating = function (bucket) {
            if (bucket.key === '') {
                return false;
            } else if (bucket.key.indexOf('(sf)') > -1) {
                return false;
            } else if (bucket.key.indexOf('0023:D') > -1) {
                return false;
            } else if (bucket.key.indexOf(':SP') > -1) {
                return false;
            } else if (bucket.key.indexOf('0000:0:0') > -1) {
                return false;
            } else if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].length > 0) {
                // if any credit rating type is checked
                // get rating types for this rating
                var ratingTypes = $scope.getRatingTypes(bucket.key);
                for (var i = 0; i < ratingTypes.length; i++) {
                    // get the long value of the rating type abbreviation
                    var longValue = $scope.ratingTypeMap[ratingTypes[i]];
                    // if rating type of rating is one of the checked rating types
                    if ($scope.filter.ratingTypeFilter.terms['credit_rating_type.raw'].indexOf(longValue) > -1) {
                        return true;
                    }
                }
                return false;
            } else {
                return true;
            }
        };
        $scope.sortRatings = function (bucket) {
            var ratingTypes = $scope.getRatingTypes(bucket.key);
            var ratingReturn = bucket.key.replace(':', ':' + ratingTypes[0] + ':');
            return ratingReturn;
        };

        $scope.checkCouponType = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].indexOf(bucket.key) === -1) {
                    $scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedCouponType = function (bucket) {
            var index = $scope.filter.couponTypeFilter.terms['coupon_rate_ind_calc'].indexOf(bucket.key);
            $scope.setCriteriaForGA('coupon type', bucket.key, index > -1);
            return (index > -1);
        };

        $scope.selectYieldMin = function (bucket) {
            $log.info('yield min: ' + bucket.key + ' ' + bucket.doc_count);
            $scope.setCriteriaForGA('min yield', bucket.key, null);
            $scope.resetSort();
            if (bucket.key === 'ANY') {
                $scope.yield.yieldMin = $scope.selectAny;
                $scope.filter.yieldFilter.range['yield_calc'].gte = 'ANY';
                if (!$scope.filter.yieldFilter.range['yield_calc'].lte) {
                    $scope.yield.yieldMax = $scope.selectAny;
                    $scope.filter.yieldFilter.range['yield_calc'].lte = 'ANY';
                }
                $scope.submitSearch(false);
            } else if (bucket.key >= $scope.yield.yieldMax.key) {
                $scope.yield.yieldMax = bucket;
                $scope.filter.yieldFilter.range['yield_calc'].gte = $scope.yield.yieldMin.key;
                $scope.filter.yieldFilter.range['yield_calc'].lte = $scope.yield.yieldMax.key;
                $scope.submitSearch(false);
            } else {
                $scope.filter.yieldFilter.range['yield_calc'].gte = $scope.yield.yieldMin.key;
                $scope.submitSearch(false);
            }
        };
        $scope.selectYieldMax = function (bucket) {
            $log.info('yield max: ' + bucket.key + ' ' + bucket.doc_count);
            $scope.setCriteriaForGA('max yield', bucket.key, null);
            $scope.resetSort();
            if (bucket.key === 'ANY') {
                $scope.yield.yieldMax = $scope.selectAny;
                $scope.filter.yieldFilter.range['yield_calc'].lte = 'ANY';
                if (!$scope.filter.yieldFilter.range['yield_calc'].gte) {
                    $scope.yield.yieldMin = $scope.selectAny;
                    $scope.filter.yieldFilter.range['yield_calc'].gte = 'ANY';
                }
                $scope.submitSearch(false);
            } else if (bucket.key <= $scope.yield.yieldMin.key) {
                $scope.yield.yieldMin = bucket;
                $scope.filter.yieldFilter.range['yield_calc'].gte = $scope.yield.yieldMin.key;
                $scope.filter.yieldFilter.range['yield_calc'].lte = $scope.yield.yieldMax.key;
                $scope.submitSearch(false);
            } else {
                $scope.filter.yieldFilter.range['yield_calc'].lte = $scope.yield.yieldMax.key;
                $scope.submitSearch(false);
            }
        };
        $scope.showYield = function (bucket) {
            if (bucket.key === 'ANY') {
                return true;
            } else if (bucket.key >= 0 && bucket.key < 160) {
                return true;
            } else {
                return false;
            }
        };

        $scope.selectCouponMin = function (bucket) {
            $log.info('coupon min: ' + bucket.key + ' ' + bucket.doc_count);
            $scope.setCriteriaForGA('min coupon', bucket.key, null);
            $scope.resetSort();
            if (bucket.key === 'ANY') {
                $scope.coupon.couponMin = $scope.selectAny;
                $scope.filter.couponFilter.range['coupon_rate_calc'].gte = 'ANY';
                if (!$scope.filter.yieldFilter.range['yield_calc'].lte) {
                    $scope.coupon.couponMax = $scope.selectAny;
                    $scope.filter.couponFilter.range['coupon_rate_calc'].lte = 'ANY';
                }
                $scope.submitSearch(false);
            } else if (bucket.key >= $scope.coupon.couponMax.key) {
                $scope.coupon.couponMax = bucket;
                $scope.filter.couponFilter.range['coupon_rate_calc'].gte = $scope.coupon.couponMin.key;
                $scope.filter.couponFilter.range['coupon_rate_calc'].lte = $scope.coupon.couponMax.key;
                $scope.submitSearch(false);
            } else {
                $scope.filter.couponFilter.range['coupon_rate_calc'].gte = $scope.coupon.couponMin.key;
                $scope.submitSearch(false);
            }
        };
        $scope.selectCouponMax = function (bucket) {
            $log.info('coupon max: ' + bucket.key + ' ' + bucket.doc_count);
            $scope.setCriteriaForGA('max coupon', bucket.key, null);
            $scope.resetSort();
            if (bucket.key === 'ANY') {
                $scope.coupon.couponMax = $scope.selectAny;
                $scope.filter.couponFilter.range['coupon_rate_calc'].lte = 'ANY';
                if (!$scope.filter.couponFilter.range['coupon_rate_calc'].gte) {
                    $scope.coupon.couponMax = $scope.selectAny;
                    $scope.filter.couponFilter.range['coupon_rate_calc'].gte = 'ANY';
                }
                $scope.submitSearch(false);
            } else if (bucket.key <= $scope.coupon.couponMin.key) {
                $scope.coupon.couponMin = bucket;
                $scope.filter.couponFilter.range['coupon_rate_calc'].gte = $scope.coupon.couponMin.key;
                $scope.filter.couponFilter.range['coupon_rate_calc'].lte = $scope.coupon.couponMax.key;
                $scope.submitSearch(false);
            } else {
                $scope.filter.couponFilter.range['coupon_rate_calc'].lte = $scope.coupon.couponMax.key;
                $scope.submitSearch(false);
            }
        };
        $scope.showCoupon = function (bucket) {
            if (bucket.key === 'ANY') {
                return true;
            } else if (bucket.key >= 0 && bucket.key < 160) {
                return true;
            } else {
                return false;
            }
        };

        $scope.selectMaturityMin = function (bucket) {
            $log.info('maturity min: ' + bucket.key + ' ' + bucket.doc_count);
            $scope.resetSort();
            if (bucket.key === 'ANY') {
                $scope.maturity.maturityMin = $scope.selectAny;
                $scope.filter.maturityFilter.range['maturity_d'].gte = 'ANY';
                if (!$scope.filter.maturityFilter.range['maturity_d'].lte) {
                    $scope.maturity.maturityMax = $scope.selectAny;
                    $scope.filter.maturityFilter.range['maturity_d'].lte = 'ANY';
                }
                $scope.submitSearch(false);
            } else if (bucket.key >= $scope.maturity.maturityMax.key) {
                $scope.maturity.maturityMax = bucket;
                $scope.filter.maturityFilter.range['maturity_d'].gte = $scope.maturity.maturityMin.key;
                $scope.filter.maturityFilter.range['maturity_d'].lte = $scope.getMaturityMax($scope.maturity.maturityMax.key);
                $scope.submitSearch(false);
            } else {
                $scope.filter.maturityFilter.range['maturity_d'].gte = $scope.maturity.maturityMin.key;
                $scope.submitSearch(false);
            }
        };
        $scope.selectMaturityMax = function (bucket) {
            $log.info('maturity max: ' + bucket.key + ' ' + bucket.doc_count);
            $scope.resetSort();
            if (bucket.key === 'ANY') {
                $scope.maturity.maturityMax = $scope.selectAny;
                $scope.filter.maturityFilter.range['maturity_d'].lte = 'ANY';
                if (!$scope.filter.maturityFilter.range['maturity_d'].gte) {
                    $scope.maturity.maturityMax = $scope.selectAny;
                    $scope.filter.maturityFilter.range['maturity_d'].gte = 'ANY';
                }
                $scope.submitSearch(false);
            } else if (bucket.key <= $scope.maturity.maturityMin.key) {
                $scope.maturity.maturityMin = bucket;
                $scope.filter.maturityFilter.range['maturity_d'].gte = $scope.maturity.maturityMin.key;
                $scope.filter.maturityFilter.range['maturity_d'].lte = $scope.getMaturityMax($scope.maturity.maturityMax.key);
                $scope.submitSearch(false);
            } else {
                $scope.filter.maturityFilter.range['maturity_d'].lte = $scope.getMaturityMax($scope.maturity.maturityMax.key);
                $scope.submitSearch(false);
            }
        };
        $scope.showMaturity = function (bucket) {
            if (bucket.key === 'ANY') {
                return true;
            } else {
                var thisYear = new Date().getFullYear();
                var bucketYear = parseInt($scope.filterDate(bucket.key, 'yyyy'), 10);

                if ((bucketYear >= thisYear && bucketYear <= thisYear + 11) || bucketYear === thisYear + 21 || bucketYear === thisYear + 31) {
                    return true;
                } else {
                    return false;
                }
            }
        };
        $scope.getMaturityMax = function (data) {
            var date = new Date(data);
            date.setFullYear(date.getFullYear() + 1);
            var dateVal = date.valueOf() - 60000;
            return dateVal;
        };

        $scope.checkCurrency = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.currencyFilter.terms['currency_code_c'].indexOf(bucket.key) === -1) {
                    $scope.filter.currencyFilter.terms['currency_code_c'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.currencyFilter.terms['currency_code_c'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.currencyFilter.terms['currency_code_c'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedCurrency = function (bucket) {
            var index = $scope.filter.currencyFilter.terms['currency_code_c'].indexOf(bucket.key);
            $scope.setCriteriaForGA('currency', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.showCurrency = function (bucket) {
            if (bucket.key.indexOf('usd') > -1) {
                return true;
            } else {
                return false;
            }
        };

        $scope.checkReport = function (bucket, $event) {
            $scope.resetSort();
            if ($event.target.checked) {
                if ($scope.filter.reportFilter.terms['grm_haveDoc'].indexOf(bucket.key) === -1) {
                    $scope.filter.reportFilter.terms['grm_haveDoc'].push(bucket.key);
                    $scope.submitSearch(false);
                }
            } else {
                var index = $scope.filter.reportFilter.terms['grm_haveDoc'].indexOf(bucket.key);
                if (index > -1) {
                    $scope.filter.reportFilter.terms['grm_haveDoc'].splice(index, 1);
                }
                $scope.submitSearch(false);
            }
        };
        $scope.isCheckedReport = function (bucket) {
            var index = $scope.filter.reportFilter.terms['grm_haveDoc'].indexOf(bucket.key);
            $scope.setCriteriaForGA('s&p fixed income research', bucket.key, index > -1);
            return (index > -1);
        };
        $scope.showReport = function (bucket) {
            if (bucket.key.indexOf('y') > -1) {
                return true;
            } else {
                return false;
            }
        };

        $scope.nextPage = function () {
            $log.info('BondScreener nextPage: ' + $scope.qpage);
            if ($scope.qpage !== '' && $scope.qpage < $scope.qpages) {
                //$scope.qpage += 1;
                $scope.qpage = parseInt($scope.qpage, 10) + 1;
                $scope.qfrom = (($scope.qpage - 1) * $scope.qsize);
                $scope.getQuery();
            }
        };
        $scope.prevPage = function () {
            $log.info('BondScreener prevPage: ' + $scope.qpage);
            if ($scope.qpage !== '' && $scope.qpage > 1) {
                //$scope.qpage -= 1;
                $scope.qpage = parseInt($scope.qpage, 10) - 1;
                $scope.qfrom = (($scope.qpage - 1) * $scope.qsize);
                $scope.getQuery();
            }
        };
        $scope.nextPageClass = function (qpage, qpages) {
            // {'page-next':qpage<qpages,'page-next-disabled':qpage==qpages}
            if (qpage === '') {
                return 'page-next-disabled';
            } else if (qpage < qpages) {
                return 'page-next';
            } else if (qpage === qpages) {
                return 'page-next-disabled';
            } else {
                return 'page-next-disabled';
            }
        };
        $scope.prevPageClass = function (qpage, qpages) {
            // {'page-prev':qpage>1,'page-prev-disabled':qpage==1}
            if (qpage === '') {
                return 'page-prev-disabled';
            } else if (qpage > 1) {
                return 'page-prev';
            } else if (qpage === 1) {
                return 'page-prev-disabled';
            } else {
                return 'page-prev-disabled';
            }
        };
        $scope.goToPage = function () {
            $log.info('BondScreener goToPage: ' + $scope.qpage);
            if (isNaN($scope.qpage)) {
                $scope.qpage = 1;
                $scope.qfrom = (($scope.qpage - 1) * $scope.qsize);
                $scope.getQuery();
            } else if ($scope.qpage === '') {
                $log.info('BondScreener goToPage: no value wait for watch timeout');
                $scope.pageWatch = true;
            } else {
                // tricky since value comes as string from input field - convert back to int
                $scope.qpage = parseInt($scope.qpage, 10);
                if ($scope.qpage < 1) {
                    $scope.qpage = 1;
                    $scope.qfrom = (($scope.qpage - 1) * $scope.qsize);
                    $scope.getQuery();
                }
                if ($scope.qpage > $scope.qpages) {
                    $scope.qpage = $scope.qpages;
                    $scope.qfrom = (($scope.qpage - 1) * $scope.qsize);
                    $scope.getQuery();
                } else {
                    $log.info('BondScreener goToPage: value wait for watch timeout');
                    $scope.pageWatch = true;
                }
            }
        };
        $scope.$watch('qpage', function (qpagetmp) {
            $log.info('BondScreener page watch: ' + qpagetmp + ' ' + $scope.pageWatch);
            if (!qpagetmp || qpagetmp.length === 0 || !$scope.pageWatch) {
                $log.info('BondScreener page watch: do nothing');
                return 0;
            }
            setTimeout(function () {
                // if qpage is still the same... go ahead and submit query
                if (qpagetmp === $scope.qpage) {
                    $log.info('BondScreener page watch: waiting done');
                    $scope.pageWatch = false;
                    $scope.qfrom = (($scope.qpage - 1) * $scope.qsize);
                    $scope.getQuery();
                }
            }, 500);
        });

        $scope.openHeader = function (header) {
            var results = header.replace('header', 'results');
            if (jQuery('a[id=' + header + ']').hasClass('expand-close')) {
                jQuery('a[id=' + header + ']').removeClass('expand-close').addClass('expand-open');
                jQuery('div[id=' + results + ']').slideDown(10);
            }
        };
        $scope.closeHeader = function (header) {
            var results = header.replace('header', 'results');
            if (jQuery('a[id=' + header + ']').hasClass('expand-open')) {
                jQuery('a[id=' + header + ']').removeClass('expand-open').addClass('expand-close');
                jQuery('div[id=' + results + ']').slideUp(10);
            }
        };
        $scope.toggleHeader = function ($event) {
            var header = $event.target.id;
            var results = header.replace('header', 'results');
            jQuery('a[id=' + header + ']').toggleClass('expand-open expand-close');
            jQuery('div[id=' + results + ']').slideToggle(10);

        };

        $scope.formatDate = function (data, format) {
            var dateFilter = $filter('date');
            return dateFilter(data, format);
        };

        $scope.filterDate = function (data, format) {
            var emptyCheckFilter = $filter('emptyCheckFilter');
            var dateFilter = $filter('date');

            if (emptyCheckFilter(data, '-') === '-' || data === 'null') {
                return '--';
            } else if (!isNaN(data)) {
                var localDate = new Date();
                var localOffset = localDate.getTimezoneOffset() * 60000;
                var dataOffset = new Date(data + localOffset + 3600000);
                return dateFilter(dataOffset, format);
            } else {
                var parsedDate = data.split('-').join('/');
                var strippedDate = parsedDate.replace(/\.0/, '');
                return dateFilter(Date.parse(strippedDate), format);
            }
        };
        $scope.filterNumber = function (data) {
            var emptyCheckFilter = $filter('emptyCheckFilter');
            var numberFilter = $filter('number');

            if (emptyCheckFilter(data, '-') === '-' || data === 'null') {
                return '--';
            } else {
                var num = parseFloat(data) / 10;
                var num2 = Math.round(num * 1000) / 1000;
                var num3 = Math.round(num2 * 100) / 100;
                return numberFilter(num3, 2);
            }
        };

        $scope.filterNumBucket = function (bucket) {
            if (isNaN(bucket.key)) {
                return bucket.key;
            } else {
                return bucket.key / 10;
            }
        };

        $scope.filterDateBucket = function (bucket) {
            if (isNaN(bucket.key)) {
                return bucket.key;
            } else {
                return $scope.filterDate(bucket.key, 'yyyy');
            }
        };

        $scope.filterSecurity = function (data) {
            var emptyCheckFilter = $filter('emptyCheckFilter');

            if (emptyCheckFilter(data, '-') === '-' || data === 'null') {
                return '--';
            } else if (data.indexOf('NSF') !== -1) {
                return 'Corp/Govt/Agency';
            } else if (data.indexOf('MUNI') !== -1) {
                return 'Municipal';
            } else if (data.indexOf('SF') !== -1) {
                return 'Structured Finance';
            } else {
                return data;
            }
        };

        $scope.resetSort = function () {
            $scope.sort.key = Object.keys($scope.sort.sortFields)[1];
            $scope.sort.dirDefault = $scope.sort.dir.sortAsc;
            $scope.sort.fieldDefault = $scope.sort.sortFields[$scope.sort.key];
        };

        $scope.getSort = function (column) {
            if (column === $scope.sort.key) {
                return $scope.sort.dirDefault === $scope.sort.dir.sortAsc ? 'sort-asc' : 'sort-desc';
            } else {
                return 'sort-none';
            }
        };

        $scope.doSort = function (column) {
            if (column === $scope.sort.key) {
                $scope.sort.dirDefault = ($scope.sort.dirDefault === $scope.sort.dir.sortAsc ? $scope.sort.dir.sortDesc : $scope.sort.dir.sortAsc);
            } else {
                $scope.sort.dirDefault = $scope.sort.dir.sortAsc;
                $scope.sort.key = column;
                $scope.sort.fieldDefault = $scope.sort.sortFields[$scope.sort.key];
            }
            $scope.submitSearch(false);
        };

        $scope.goTo = function (cusip) {
            $log.info('BondScreener goTo: ' + cusip);
            if (cusip !== undefined) {
                if (typeof Ext !== 'undefined') {
                    // we assume if Ext is defined, then we use bondSnapshotVM
                    $window.scrollTo(0, 0);
                    require(['logger', '/SP/msa/js/site/bond/snapshot/bondSnapshotVM.js'], function (log, bondSnapshotVM) {
                        bondSnapshotVM.initBindAndReturn(cusip);
                    });
                } else {
                    var encU=encodeURIComponent($rootScope.currentUser);
                    var encP=encodeURIComponent($rootScope.partnerIdm);
                    var encC=encodeURIComponent($rootScope.company);

                    QuickViewService.openBondsQuickView({ cusip: cusip, partner: '/seamlessQV/BondDesk',source :'bondScreener',user:encU,partnerIdm:encP,company:encC});
                }
            }
        };

        $scope.toggleCriteria = function () {
            $scope.criteria.open = !$scope.criteria.open;
            $scope.resizeMsaContainer();
        };

        $scope.setMinDate = function () {
            var minDate = new Date();
            minDate.setUTCHours(0);
            minDate.setUTCMinutes(0);
            minDate.setUTCSeconds(0);
            $scope.filter.maturityMinFilter.range['maturity_d'].gte = minDate.valueOf();
        };

        $scope.resizeMsaContainer = function () {
            setTimeout(function () {
                // hack to resize extjs window for footer
                if (typeof Ext !== 'undefined') {
                    this.containerDiv = Ext.fly('main-container');

                    if (this.containerDiv) {
                        var elTemp = Ext.get('bond-screener-container');
                        if (elTemp.isVisible()) {
                            var height = elTemp.getHeight();
                            this.containerDiv.setHeight(height);
                        }
                    }
                }
            }, 10);
        };
        $scope.checkLast = function (last) {
            if (last) {
                $scope.results.loading = false;
                $scope.resizeMsaContainer();
            }
            return '';
        };
        $scope.setCriteriaForGA = function (controlType, value, flag) {
            if (flag == null) {
                $scope.criteriaSet[controlType] = value;
            } else {
                $scope.criteriaSet[controlType][value] = flag;
            }
        }
        $scope.sendToGA = function () {
            if (typeof Ext !== 'undefined') {
                return;
            }
            if (!$scope.sendToGAFlag) {
                return;
            }
            $log.info("in send to ga");

            var stringForGA = '';//prepare the string to send to google analytics
            for (var property in $scope.criteriaSet) {
                if ($scope.criteriaSet.hasOwnProperty(property)) {
                    if (typeof($scope.criteriaSet[property]) == 'object') { // for checkboxes
                        var concatString = '';
                        for (var prop in $scope.criteriaSet[property]) {
                            if ($scope.criteriaSet[property][prop] === true) {
                                if (property === 'rating') {
                                    concatString += prop.substring(prop.indexOf(":") + 1) + ',';
                                } else {
                                    concatString += prop + ',';
                                }
                            }
                        }
                        if (concatString !== '') {
                            //$log.info("adding obj  prop to sendtoga");
                            stringForGA += property + " : " + concatString + " ; "
                        }

                    } else if ($scope.criteriaSet[property] != 'ANY') { // when the criteria is a string (for select drop downs)
                        // $log.info("adding string   prop to sendtoga");
                        stringForGA += property + " : " + $scope.criteriaSet[property] + " ; "
                    }
                }
            }
            $log.info(stringForGA);
            ga('send', 'pageview', {
                'page': $location.path(),
                'title': stringForGA,
                'dimension1': $rootScope.currentUser,
                'dimension2': $rootScope.partnerIdm,
                'dimension3': $rootScope.company
            });

            $scope.sendToGAFlag = false;
        };

        // display full results on entry with maturity date >= today
        $scope.setMinDate();
        // get master aggregation
        $scope.getAgg();
        // wait for master
        $scope.submitMasterSearch();

    }
});
