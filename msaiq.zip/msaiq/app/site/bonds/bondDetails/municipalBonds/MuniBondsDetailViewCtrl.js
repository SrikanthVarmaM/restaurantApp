'use strict';

msaiqApp.controller('MuniBondsDetailViewCtrl', function ($scope, $log, _, $routeParams, bondsResourceFactory, $location, QuickViewService, ThomsonService, ngTableParams, $filter, $cookies,$rootScope,ga ) {
    //-------------------------------------------------
    // needed to show the homepage when user clicks on bonddetails from seamless quickview , we had to hide the homepage by default for quickview background
    //todo  Need to think of a better way of doing it :I HATE JQUERY
    $('#main-wrapper').removeClass('initial-hide');
    $('#main-header').removeClass('initial-hide');
    //------------------------------------------------

    $scope.QuickViewService = QuickViewService;
    $scope.ThomsonService = ThomsonService;

    $scope.orgId = '';
    $scope.isDetailsPage = true;
    var emptyCheckFilter = $filter('emptyCheckFilter');

    $scope.cusip = $routeParams.cusip;
    $scope.tradeActivityURL = '/assets-service/bonds/charts/' + $scope.cusip + '-TRADE_ACTIVITY_CHART.png';
    $scope.yieldCurveURL = '/assets-service/bonds/charts/' + $scope.cusip + '-YIELD_VS_MATURITY_CHART_30YR.png';
    $scope.currentTime = Date();
    $scope.priceToDate = {price_todate: ''};
    $scope.candyBarColors = ['color-1-red', 'color-2-yellow', 'color-3-cyan', 'color-4-green'];
    $scope.haveBondDocument = false;
    $scope.isActiveBond = $routeParams.active;

    //initialization
    $scope.universeValue = 0;
    $scope.comparableValue = 0;


        $scope.openDoc=function(){
        $log.info("testing bonds pdf");

        $log.info('cookie my favourite'+$cookies.msa_fe);
        var urlDoc = '/assets-service/bonds/reports/'+$scope.gdsData.cusip9 +'.pdf';
        ga('send', 'pageview', {
            'page': urlDoc,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        window.open(urlDoc, '_blank', 'resizable=yes');
    };

    $scope.loadGDSData = function () {
        $scope.gdsDataResource = bondsResourceFactory.gdsDataResource.get({cusip: $scope.cusip});
        $scope.gdsDataResource.$promise.then(function (gdsData) {
                $scope.gdsData = gdsData.basic_data;
                $scope.gdsIssuerData=gdsData.issuer_data;
                if (_.isEmpty($scope.gdsData)) {
                    $scope.gdsDataResource.error = true;
                    $scope.errorMsg = 'MSA does not have enough information to display Bond Details for this identifier - ' + $scope.cusip;
                    return;
                }
                if (emptyCheckFilter($scope.gdsData.security_to_issuer_number, '-') === '-') {
                    $scope.gdsDataResource.error = true;
                    $scope.errorMsg = 'Search produced no results  for this identifier';
                    return;
                }
                $scope.issuerSummary = bondsResourceFactory.issuerSummaryResource.get({issuerNumber: $scope.gdsData.security_to_issuer_number});


            }
            ,
            function () {
                $scope.gdsDataResource.error = true;
                $scope.errorMsg = 'MSA does not have enough information to display Bond Details for this identifier - ' + $scope.cusip;
            }
        )
        ;
    };
    $scope.getAllGrmData = function () {
        $scope.priceToDate = bondsResourceFactory.grmPriceToDateResource.get({cusip: $scope.cusip});
        $scope.grmBondsBasicInfoResource = bondsResourceFactory.grmBondsBasicInfoResource.get({cusip: $scope.cusip});
        $scope.grmBondsBasicInfoResource.$promise.then(function (grmBondBasicRawData) {

            $scope.grmBondsBasicInfo = grmBondBasicRawData;
            if ($scope.grmBondsBasicInfo.grm_basic_info.currentPeer) {
                $scope.comparableValue = $scope.grmBondsBasicInfo.grm_basic_info.currentPeer.quartileBidYieldComparable;
            }
            if ($scope.grmBondsBasicInfo.grm_basic_info.issue.derivedAttribute) {
                $scope.universeValue = $scope.grmBondsBasicInfo.grm_basic_info.issue.derivedAttribute.quartileBidYieldUniverse;
            }
        }, function () {

            $scope.grmBondsBasicInfoResource.error = true;
        });
        //(comparableBondsData.length === 0 ) && (grmBondsBasicInfo.currentPeer != null)
        $scope.comparableTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
        $scope.$watch('comparableTableParams', function (params) {
            $scope.grmComparableBondsResource = bondsResourceFactory.grmComparableBondsResource.get({cusip: $scope.cusip, pageSize: params.count, pageNum: (params.page - 1)});
            $scope.grmComparableBondsResource.$promise.then(function (comparableBondsData) {
                $scope.comparableTableParams.total = comparableBondsData.comparative_performance_size;
                $scope.comparableBondsData = comparableBondsData.comparative_performance;
                if ($scope.comparableBondsData.length <= 0) {
                    $scope.grmComparableBondsResource.error = true;
                }
            }, function () {
                $scope.grmComparableBondsResource.error = true;
            });
        }, true);
    };
    $scope.loadIssuerRawDetails = function () {
        $scope.getOrgIDByIdentifierResource = bondsResourceFactory.getOrgIDByIdentifierResource.get({cusip: $scope.cusip});
        $scope.getOrgIDByIdentifierResource.$promise.then(function (issuerRawDetails) {
            if (_.isEmpty(issuerRawDetails)) {
                $scope.orgId = '';
                $scope.relatedNewsDataResource = {$resolved: true, error: true};
                $scope.relatedIssuesDataResource = {$resolved: true, error: true};
                return;
            }
            $scope.orgId = issuerRawDetails.issuer_orgid.orgId;
            $scope.relatedNewsDataResource = bondsResourceFactory.relatedNewsDataFromAssetServicesResource.get({orgId: $scope.orgId, creditResearchType: 'ALL', summaryAnalysisTot: '25', cusip: $scope.cusip});
            $scope.relatedNewsDataResource.$promise.then(function (data) {
                $scope.relatedNewsRawData = data.related_news;
                $scope.showRelatedNewsTab('ALL', true);
            }, function () {
                $scope.relatedNewsDataResource.error = true;
            });

            $scope.relatedIssuesTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
                $scope.relatedIssuesDataResource = bondsResourceFactory.relatedIssuesDataFromAssetServicesResource.get({cusip: $scope.cusip, orgId: $scope.orgId, pageNum: 1, pageSize: 20});
                $scope.relatedIssuesDataResource.$promise.then(function (relatedIssuesRawData) {
                    if (relatedIssuesRawData.related_issues.length != 0) {
                        $scope.relatedIssuesTableParams.total = relatedIssuesRawData.related_issues_size >= 20 ? 20 : relatedIssuesRawData.related_issues_size;
                        $scope.$watch('relatedIssuesTableParams', function(params) {
                            $scope.relatedIssuesData =  relatedIssuesRawData.related_issues.slice((params.page - 1) * params.count,params.page * params.count);
                        }, true);
                    } else {
                        $scope.relatedIssuesDataResource.error = true;
                    }
                }, function () {
                    $scope.relatedIssuesDataResource.error = true;
                });
            });

    };
    $scope.loadParticipantsInfo = function () {
        $scope.participantsTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
        $scope.$watch('participantsTableParams', function (params) {
            $scope.grmParticipantsInfoResource = bondsResourceFactory.grmParticipantsInfoResource.get({cusip: $scope.cusip, pageSize: params.count, pageNum: (params.page - 1)});
            $scope.grmParticipantsInfoResource.$promise.then(function (participantsInfo) {
                $scope.participantsTableParams.total = participantsInfo.participant_info_size;
                $scope.participantsInfo = participantsInfo.participant_info;
                if (!$scope.participantsInfo) {
                    $scope.grmParticipantsInfoResource.error = true;
                }

            }, function () {
                $scope.grmParticipantsInfoResource.error = true;
            });
        }, true);
    }
    $scope.showRelatedNewsTab = function (tabValue, isFirst) {
        $scope.activeTab = tabValue;
        var rData = [];
        if (!isFirst) {
            $scope.unbindWatch();
        }
        $scope.relatedNewsTableParams = new ngTableParams({ page: 1, count: 10, total: 0, counts: []});
        if ($scope.activeTab === 'ALL') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.ratingsAction.length + $scope.relatedNewsRawData.summaryAnalysis.length +
                $scope.relatedNewsRawData.commentaries.length + $scope.relatedNewsRawData.bulletins.length;
            rData = $scope.rNewsDataFormat($scope.relatedNewsRawData, rData);
        }
        else if ($scope.activeTab === 'RATING_ACTION') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.ratingsAction.length;
            rData = $scope.relatedNewsRawData.ratingsAction;
        }
        else if ($scope.activeTab === 'ANALYSIS') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.summaryAnalysis.length;
            rData = $scope.relatedNewsRawData.summaryAnalysis;
        }
        else if ($scope.activeTab === 'COMMENTS') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.commentaries.length;
            rData = $scope.relatedNewsRawData.commentaries;
        }
        else if ($scope.activeTab === 'BULLETIN') {
            $scope.relatedNewsTableParams.total = $scope.relatedNewsRawData.bulletins.length;
            rData = $scope.relatedNewsRawData.bulletins;
        }
        $scope.unbindWatch = $scope.$watch('relatedNewsTableParams', function (params) {
            $scope.relatedNewsData = rData.slice((params.page - 1) * params.count, params.page * params.count);
        }, true);
    };

    $scope.rNewsDataFormat = function (source, dist) {
        angular.forEach(source.summaryAnalysis, function (element) {
            dist.push(element);
        });
        angular.forEach(source.ratingsAction, function (element) {
            dist.push(element);
        });
        angular.forEach(source.commentaries, function (element) {
            dist.push(element);
        });
        angular.forEach(source.bulletins, function (element) {
            dist.push(element);
        });
        return dist;
    };
    //---------------------------------------code starts here------------------------------------------------------

    //-----------------------           check if this muni bond has pdf report available or not

    var checkBondDocument = bondsResourceFactory.checkReportExistsResource.get({cusip: $scope.cusip});
    checkBondDocument.$promise.then(function (checkBondDocument) {
        if (checkBondDocument.status === 'true') {
            $scope.haveBondDocument = true;
        }
    });    //


    $scope.loadGDSData();
    $scope.loadIssuerRawDetails();//this call   can go parallelly
    if ($scope.isActiveBond) {
        $scope.getAllGrmData();
    }
    $scope.loadParticipantsInfo();


})
;