'use strict';

msaiqApp.controller('BondDetailsCtrl', function ($scope,$routeParams, bondsResourceFactory, $location) {
    $scope.cusip = $routeParams.cusip;
    $scope.getBondTypeResource = bondsResourceFactory.checkReportExistsResource.get({cusip:$scope.cusip});
    $scope.getBondTypeResource.$promise.then(function(response){
        if (response.type === "CORP")  {
            $location.path('/bonds/bondDetails/corp/'+$scope.cusip+'/'+(response.active||''));
        } else if (response.type === "MUNI"){
            $location.path('/bonds/bondDetails/muni/'+$scope.cusip+'/'+(response.active||''));
        }
        else {
                $scope.getBondTypeResource.error=true;
            }
    },  function(error) {
            $scope.getBondTypeResource.error=true;
        }
    );




   /* var gdsRawData = bondsResourceFactory.gdsDataResource.get({cusip:$scope.cusip});
    gdsRawData.$promise.then(function(gdsData){
        $scope.gdsData= gdsData.basic_data;
        if(emptyCheckFilter(gdsData, '-') === '-') {
            $scope.viewState = $scope.states.LOADED;
            $scope.errorMsg = 'MSA does not have enough information to display Bond Details for this identifier - '+ $scope.cusip;
        } else {
            if(emptyCheckFilter(gdsData.security_to_issuer_number, '-') === '-') {
                $scope.viewState = $scope.states.LOADED;
                $scope.errorMsg = 'Search produced no results  for this identifier';
            }else {
                if(gdsData && gdsData.offr_institution_type === 'MUNI') {
                    $location.path('/bonds/bondDetails/muni/'+gdsData.cusip9);
                } else if(gdsData && gdsData.offr_institution_type === 'CORP') {
                    $location.path('/bonds/bondDetails/corp/'+gdsData.cusip9);
                } else {
                    $scope.viewState = $scope.states.LOADED;
                    $scope.errorMsg = 'Search produced no results  for this identifier';
                }
            }
        }
    }); */
});