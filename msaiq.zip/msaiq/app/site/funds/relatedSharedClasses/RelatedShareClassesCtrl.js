'use strict';

msaiqApp.controller('RelatedShareClassesCtrl', function ($scope, QuickViewService, articleResourceFactory, assetsResourceFactory, ngTableParams, $log, $routeParams, $) {

    $scope.sppwId = $routeParams.sppwid;
    $scope.ticker = $routeParams.ticker;
    $scope.artickeId = $routeParams.articleId;
    $scope.QuickViewService = QuickViewService;
    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.viewState = $scope.states.LOADING;

    $scope.fundrelatedshare = {activeTab: 'CUSTOM'};
    $scope.tableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' } };
    $scope.showExportToExcel = $scope.states.LOADING;

    $scope.$watch('tableParams', function(params) {
        $scope.fundsRelatedshareResource = articleResourceFactory.fundsRelatedShareClass.get({start: (params.page-1) * params.count,limit:params.count, sppwId:$scope.sppwId});
      //  $scope.starFundResource = articleResourceFactory.starFundsResource.get({start: (params.page-1) * params.count,limit:params.count, operation1Value:$scope.operation1Value});
        $scope.fundsRelatedshareResource.$promise.then(function(fundsRelatedShareClassesData){
            $scope.fundsRelatedShareClassesData = fundsRelatedShareClassesData;
            $scope.tableParams.total = $scope.totalNumOfRecords = fundsRelatedShareClassesData.total_records;
            for (var i=0; i < fundsRelatedShareClassesData.equities.length; i++){
                fundsRelatedShareClassesData.equities[i].inceptionDate = fundsRelatedShareClassesData.equities[i].inceptionDate.split('-').join('/');
            }
            if($scope.tableParams.page === 1){
                if($scope.tableParams.total <= 200 && $scope.tableParams.total > 0){
                    $scope.printArrayLink  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=RELATED_SHARED_CLASSES&screenerParameters%5B0%5D.operation1Value='+$scope.sppwId+'&start=0&limit=200&equityType=FUNDS&sort=securityName&dir=ASC';
                    $scope.showExportToExcel = $scope.states.LOADED;
                } else {
                    $scope.showExportToExcel = $scope.states.NOT_FOUND;
                }
            }

            $scope.viewState = $scope.states.LOADED;
            $scope.loading = false;
        },function(error){
            $scope.viewState = $scope.states.NOT_FOUND;
        });
    }, true);

        $scope.fundsDataPromise = assetsResourceFactory.fundsDetailsESResource.get({ticker: $routeParams.ticker});
        $scope.fundsDataPromise.$promise.then(function (fundsData) {
            if (!fundsData.hits || !fundsData.hits.hits[0] || !fundsData.hits.hits[0]._source) {
                $scope.error = 'FUNDS ' + $scope.ticker + ' is not available';
            } else {
                $scope.fundsData = fundsData.hits.hits[0]._source;
                $scope.articleHeadline = $scope.fundsData.fund_nm_full;
                $scope.articleHeadline=$scope.articleHeadline.length > 40 ? $scope.articleHeadline.substring(0,40) + '...  ' : $scope.articleHeadline;

            }
         },function(error){
            $scope.viewState = $scope.states.NOT_FOUND;
        });

    $scope.clickTab = function (tab) {
        $scope.fundrelatedshare.activeTab = tab;
    };

    $scope.openQV = function(sppwId, ticker, report_ind, type) {
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'Fund').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
    };
});