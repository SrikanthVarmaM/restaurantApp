'use strict';

msaiqApp.controller('FundWatchlistViewCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory, QuickViewService,$,$rootScope) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.loading = true;
    $scope.showExportToExcel = $scope.states.LOADING;

    $scope.sppwIds = $routeParams.sppwIds;
    $scope.title = $rootScope.watchlistTitleForPrerolled
    $scope.fundWatchlistArgs = {activeTab: 'CUSTOM'};
    $scope.tableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' } };
    $scope.showWatchlist = false;
    $scope.selectedSppwids =[];

    $scope.openQV = function(sppwId, ticker, report_ind, type){
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'Fund').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
    };

    $scope.clickTab = function (tab){
        $scope.fundWatchlistArgs.activeTab = tab;
    };

    $scope.handleCheckBoxChange=function(event,data,sppwId,securityName){
        if(data.commonStocksPct){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.fundWatchlistData.equities, function(item) {
            if (angular.isDefined(item.commonStocksPct)) {
                item.commonStocksPct = checked;
                if(item.commonStocksPct){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.fundWatchlistData.equities,function(item){
                item.commonStocksPct = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);

    $scope.creatingFormParams = function(params){
        var formData = {};
        formData['start'] =  (params.page-1) * params.count;
        formData['screenerParameters[0].propertyName'] = 'id';
        formData['screenerParameters[0].operation1Value'] = $scope.sppwIds;
        formData['screenerParameters[0].customRenderer']= 'idRenderer';
        formData['limit'] = params.count;
        formData['equityType'] = 'FUNDS';
        formData['sort'] = 'securityName';
        formData['dir'] = 'ASC';
        return formData
    };

    if($scope.sppwIds != "-1"){
        $scope.$watch('tableParams', function(params) {
            var fundWatchlistResource = articleResourceFactory.assetWatchlistResource.postReq($scope.creatingFormParams(params));
            fundWatchlistResource.$promise.then(function(fundWatchlistData){
                $scope.tableParams.total = $scope.totalNumOfRecords = fundWatchlistData.total_records;
                for(var i=0; i < fundWatchlistData.equities.length; i++){
                    fundWatchlistData.equities[i].inceptionDate = fundWatchlistData.equities[i].inceptionDate.split('-').join('/');
                }
                if($scope.tableParams.page === 1){
                    if($scope.tableParams.total <= 200 && $scope.tableParams.total > 0){
                        $scope.printArrayLink  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=id&screenerParameters%5B0%5D.operation1Value='+ $scope.sppwIds+'&screenerParameters%5B0%5D.customRenderer=idRenderer&start=0&limit=200&equityType=FUNDS&sort=securityName&dir=ASC&criteriaMessage=Watchlist search: '+$scope.title;
                        $scope.showExportToExcel = $scope.states.LOADED;
                    } else {
                        $scope.showExportToExcel = $scope.states.NOT_FOUND;
                    }
                }
                $scope.fundWatchlistData =  fundWatchlistData;
                $scope.viewState = $scope.states.LOADED;
                $scope.loading = false;
            },function(){
                $scope.viewState = $scope.states.NOT_FOUND;
            });
        }, true);
    } else {
        $scope.fundWatchlistData =  [];
        $scope.showExportToExcel = $scope.states.LOADING;
        $scope.viewState = $scope.states.LOADED;
        $scope.loading = false;
    };
});
