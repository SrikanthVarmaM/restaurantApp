'use strict';

msaiqApp.controller('PrevFocusFundOfTheMonthCtrl', function ($scope, $log, articleResourceFactory, QuickViewService, $,$rootScope) {

    $scope.previousFocusOfTheMonthResource = articleResourceFactory.articleDataResource.get({articleCode: 'FFOMLIST', start: 1, limit: 6});
    $scope.QuickViewService = QuickViewService;

    $scope.previousFocusOfTheMonthResource.$promise.then(function () {
        $log.info('Data received FocusOfTheMonthCtrl length: ' + $scope.previousFocusOfTheMonthResource.previousFocusFunds.length);
    });

    /*refactor-someday: justin. we do these funtions alot..we would put this on root scope..or think of another way.  idk*/
    $scope.goTo = function (url, windowName) {

        // Google anaytics code to track PDF downloaded
        $log.info('tracking GA');
        ga('send', 'pageview', {
            'page': url,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        // Google Analytics Code ENDs
        window.open(url, windowName, 'resizable=yes');
    };

});