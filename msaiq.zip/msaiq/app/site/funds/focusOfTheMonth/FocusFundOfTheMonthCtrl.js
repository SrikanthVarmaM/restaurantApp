'use strict';

msaiqApp.controller('FocusFundOfTheMonthCtrl', function ($scope, $log, $routeParams, articleResourceFactory, QuickViewService, ArticleMessaging, $,$rootScope) {

    $scope.articleId = $routeParams.articleId;
    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.qvService = QuickViewService;  // to be use in the html
    $scope.showWatchlist = false;
    $scope.selectedSppwids =[];
    $scope.loadingState = $scope.states.LOADING;
    $scope.focusOfTheMonthResource = articleResourceFactory.articleIdDataResource.get({articleCode: 'FFOM', articleId: $scope.articleId, limit: 1, start: 0});

    $scope.focusOfTheMonthResource.$promise.then(function () {

        var message = {articleId: $scope.focusOfTheMonthResource.articleId, instruments: [{ sppwId: $scope.focusOfTheMonthResource.sppwId, tickerSymbol:$scope.focusOfTheMonthResource.symbol}]};
        $scope.sppwid = $scope.focusOfTheMonthResource.sppwId;
        $scope.ticker = $scope.focusOfTheMonthResource.symbol;
        $scope.selectedSppwids.push($scope.focusOfTheMonthResource.sppwId);
        $scope.showWatchlist = true;
        ArticleMessaging.broadcastFundsArticleLoaded($scope, message);
        ArticleMessaging.broadcastArticleLoaded($scope, message);
        $scope.loadingState = $scope.states.LOADED;

    },function(){
        $scope.loadingState = $scope.states.NOT_FOUND;
    });

    $scope.goTo = function (url, windowName) {
        window.open(url, windowName, 'resizable=yes');


        // Google anaytics code to track PDF downloaded
        ga('send', 'pageview', {
            'page': url,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        // Google Analytics Code ENDs
    };
});