'use strict';

msaiqApp.controller('StarFundsCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory, QuickViewService, $) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.operation1Value = $routeParams.operation1Value;
    $scope.starFundArgs = {activeTab: 'CUSTOM'};
    $scope.loading = true;
    $scope.showExportToExcel = $scope.states.LOADING;
    $scope.tableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' } };
    $scope.showWatchlist = false;
    $scope.selectedSppwids =[];
    $scope.$watch('tableParams', function(params) {
        $scope.starFundResource = articleResourceFactory.starFundsResource.get({start: (params.page-1) * params.count,limit:params.count, operation1Value:$scope.operation1Value});
        $scope.starFundResource.$promise.then(function(starFundData){
            $scope.tableParams.total = $scope.totalNumOfRecords = starFundData.total_records;
            for(var i=0; i < starFundData.equities.length; i++){
                starFundData.equities[i].inceptionDate = starFundData.equities[i].inceptionDate.split('-').join('/');
            }
            if($scope.tableParams.page === 1){
                if($scope.tableParams.total <= 200 && $scope.tableParams.total > 0){
                    $scope.printArrayLink  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=starsRank3Yr&screenerParameters%5B0%5D.propertyLabel=Star&screenerParameters%5B0%5D.operation1Value='+$scope.operation1Value+'&screenerParameters%5B0%5D.customRenderer=starRankRenderer&start=0&limit=200&equityType=FUNDS&sort=securityName&dir=ASC';
                    $scope.showExportToExcel = $scope.states.LOADED;
                } else {
                    $scope.showExportToExcel = $scope.states.NOT_FOUND;
                }
            }
            $scope.starFundList =  starFundData;
            $scope.viewState = $scope.states.LOADED;
            $scope.loading = false;
        },function(){
            $scope.viewState = $scope.states.NOT_FOUND;
        });
    }, true);

    $scope.openQV = function(sppwId, ticker, report_ind, type){
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'Fund').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
    };

    $scope.clickTab = function (tab){
        $scope.starFundArgs.activeTab = tab;
        $scope.viewState = $scope.states.LOADING;
    };
    $scope.handleCheckBoxChange=function(event,data,sppwId){
        if(data.commonStocksPct){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){

        angular.forEach($scope.starFundList.equities, function(item) {
            if (angular.isDefined(item.commonStocksPct)) {
                item.commonStocksPct = checked;
                if(item.commonStocksPct){
                    $scope.selectedSppwids.push(item.sppwId);
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.starFundList.equities,function(item){
                item.commonStocksPct = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);
});
