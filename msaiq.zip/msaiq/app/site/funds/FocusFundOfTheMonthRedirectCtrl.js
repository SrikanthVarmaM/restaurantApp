'use strict';

msaiqApp.controller('FocusFundOfTheMonthRedirectCtrl', function ($scope, $log, $routeParams, $location, $) {

    $location.path('/fund/focusOfTheMonth/:'+$routeParams.articleId) ;

});