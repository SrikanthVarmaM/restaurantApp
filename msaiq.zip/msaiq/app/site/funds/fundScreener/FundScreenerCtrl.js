'use strict';

msaiqApp.controller('FundScreenerCtrl', function ($) {
    $('#msaIframe').on('$destroy',function(){
        $('#fundmenu').css('position', 'inherit');
        $('#fundmenu').css('z-index', '0');
    });

});
var watchForFunds = function () {
    var myTimeout = setInterval(function () {
        if (jQuery('#msaIframe').contents().find('.screener-form-container').size() > 0) {
            jQuery('#msaIframe').contents().find('.security-screener').trigger('click');
            jQuery('#msaIframe').css('visibility', 'visible');

            jQuery('#fundmenu').css('position', 'absolute');
            jQuery('#fundmenu').css('z-index', '1');
            clearTimeout(myTimeout);
        }
    }, 100);
};
