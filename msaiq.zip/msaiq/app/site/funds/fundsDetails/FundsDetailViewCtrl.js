'use strict';

msaiqApp.controller('FundsDetailViewCtrl', function ($scope,AutoSuggestService, $log, $routeParams, assetsResourceFactory, ArticleMessaging, QuickViewService, $) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.viewState = $scope.states.LOADING;
    $scope.totalRtnArgs = { activeTab : 'dailyRtn' };
    $scope.rankingTypes = ['Positive', 'Neutral', 'Negative'];
    $scope.au= AutoSuggestService;
    $scope.showWatchlist = false;
    $scope.showWatchlistForTop10 = false;
    $scope.selectedSppwids = [];
    $scope.selectedTickersObj = {
        selectedTickers: [],
        selectAllSecurity : false
    };

    $scope.openQV =function(data){
        QuickViewService.openQV(data);
    }  ;

    $scope.showTotalReturn = function (tab) { $scope.totalRtnArgs.activeTab = tab; };
    $scope.fundsDataPromise = assetsResourceFactory.fundsDetailsESResource.get({ticker: $routeParams.ticker});

        $scope.fundsDataPromise = assetsResourceFactory.fundsDetailsESResource.get({ticker: $routeParams.ticker});

    $scope.fundsDataPromise.$promise.then(function (fundsData) {
        //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
        if (!fundsData.hits || !fundsData.hits.hits[0] || !fundsData.hits.hits[0]._source) {
            $scope.failedFunds();
        } else {
            var fundsDataRawData = fundsData.hits.hits[0]._source;
            $scope.top10HoldingSppwIdArray = true;
            angular.forEach(fundsDataRawData.Content.TopHoldings.holdings,function(item){
                item['checkLink'] = false;
                if(item.AssetIdentifier != '' && item.AssetIdentifier != 'CUSIP' && item.AssetIdentifier != 'Ticker' && item.AssetIdentifier != 'Unknown'){
                    $scope.top10HoldingSppwIdArray = false;
                }
            });
            $scope.fundsData = fundsDataRawData
            $scope.showWatchlist = true;
            $scope.selectedSppwids.push($scope.fundsData.sppw_id);
            $scope.hideRanking =  function()
            {
                if($scope.fundsData.Content.Main.MutualFund !== 'MoneyMarket' && $scope.fundsData.Content.Main.MutualFund !=='SpecialtyOther')
                {
                    return true;
                }else
                {
                    return false;
                }
            };
            $scope.hideStyle =  function()
            {
                if($scope.fundsData.style_index_symbol === null)
                {
                    return true;
                }else
                {
                    return false;
                }
            };
            if($scope.fundsData.Content.Commentary != null && $scope.fundsData.Content.Commentary.MFCommentary != null){
                $scope.spRankingComm =   $scope.fundsData.Content.Commentary.MFCommentary.main.replace('<p>', '');
            }
            if($scope.fundsData.Content.Contact != null && $scope.fundsData.Content.Contact.Manager != null){
                $scope.contactManager =   $scope.fundsData.Content.Contact.Manager.substring($scope.fundsData.Content.Contact.Manager.indexOf('(')+7,$scope.fundsData.Content.Contact.Manager.indexOf(')'));
            }

            $scope.viewState = $scope.states.LOADED;
            var message = {articleId: null, instruments: [{sppwId:$scope.fundsData.sppw_id, tickerSymbol:$scope.fundsData.tik_symbl}]};
            ArticleMessaging.broadcastFundsArticleLoaded($scope, message);
            if($scope.fundsData.Content.Contact.AddressLine.length === 0 && $scope.fundsData.Content.Contact.City.length === 0 &&
                $scope.fundsData.Content.Contact.State.length === 0 && $scope.fundsData.Content.Contact.PostalCode.length === 0) {
                return true;
            }else{
                return false;
            }
        }
    });

    $scope.failedFunds = function () {
        $scope.error = 'Funds ' + $scope.ticker + ' is not available';
        $scope.viewState = $scope.states.NOT_FOUND;
    };

    $scope.QuickViewService = QuickViewService;

    $scope.openQV = function(sppwId, ticker, report_ind, type){
        QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
    };

    $scope.fundDetailTitle='funds_Detail_Section_Tile';

    $scope.searchFinancialData = function(data){
        if (data && data.FinancialData){
            return true;
        }
        return false;
    };

    $scope.handleCheckBoxChange = function(checkLink, ticker){
        if(checkLink){
            $scope.selectedTickersObj.selectedTickers.push(ticker);
         }else{
            $scope.selectedTickersObj.selectedTickers.splice( $scope.selectedTickersObj.selectedTickers.indexOf(ticker), 1);
         }
         $scope.showWatchlistForTop10 = $scope.selectedTickersObj.selectedTickers.length>0 ? true:false;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.fundsData.Content.TopHoldings.holdings, function(item) {
            if (angular.isDefined(item.checkLink)) {
                if(item.AssetIdentifier != '' && item.AssetIdentifier != 'CUSIP' && item.AssetIdentifier != 'Ticker' && item.AssetIdentifier != 'Unknown'){
                    item.checkLink = checked;
                    if(item.checkLink){
                        if($scope.selectedTickersObj.selectedTickers.indexOf(item.AssetIdentifier) < 0){
                            $scope.selectedTickersObj.selectedTickers.push(item.AssetIdentifier);
                        }
                    }else{
                        $scope.selectedTickersObj.selectedTickers.splice( $scope.selectedTickersObj.selectedTickers.indexOf(item.AssetIdentifier), 1);
                    }
                }
            }
        });
        $scope.showWatchlistForTop10 = $scope.selectedTickersObj.selectedTickers.length>0 ? true:false;
    };

    $scope.$watch('selectedTickersObj.selectedTickers',function(value){
        if(value.length == 0 && $scope.showWatchlistForTop10){
            angular.forEach($scope.fundsData.Content.TopHoldings.holdings,function(item){
                item.checkLink = false;
            });
            $scope.showWatchlistForTop10  = false;
            $scope.selectedTickersObj.selectAllSecurity = false;
        }
    },true);
});