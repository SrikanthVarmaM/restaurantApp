'use strict';


msaiqApp.controller('fundsQuickViewCtrl',
    function ($scope, $log, $resource, assetsResourceFactory,$location) {

        $scope.ticker = $scope.modelParam.ticker;
        $scope.sppwId = $scope.modelParam.sppwId;
        $scope.states = {
            LOADING: 0,
            LOADED: 2,
            NOT_FOUND: 1
        };
        $scope.viewState = $scope.states.LOADING;
        $scope.showWatchlist = false;
        $scope.selectedSppwids = [];

        $scope.failedFunds = function () {
            $scope.error = 'Funds ' + $scope.ticker + ' is not available';
            $scope.viewState = $scope.states.NOT_FOUND;
        };

        $scope.fundsDataPromise = assetsResourceFactory.fundsDetailsESResource.get({ticker: $scope.ticker});

        $scope.fundsDataPromise.$promise.then(function (fundsData) {

            if (!fundsData.hits || !fundsData.hits.hits[0] || !fundsData.hits.hits[0]._source) {
                $scope.failedFunds();
            } else {
                $scope.fundsData = fundsData.hits.hits[0]._source;
                if($scope.fundsData.Content.Commentary != null && $scope.fundsData.Content.Commentary.MFCommentary != null){
                    $scope.spRankingComm = $scope.fundsData.Content.Commentary.MFCommentary.main.replace('<p>', '').substring(0, 200) + '...  ';
                }
                $scope.showWatchlist = true;
                $scope.selectedSppwids.push($scope.fundsData.sppw_id);
                $scope.viewState = $scope.states.LOADED;
            }

        },function(error){
                $scope.viewState = $scope.states.NOT_FOUND;
            });
               // type of ranking
        $scope.rankingTypes = ['Positive', 'Neutral', 'Negative'];
        $scope.fundDetailTitle='quickview-section-title';

        $scope.goTo = function(path){
            // close model and then change route.
            $scope.$modalClose();
            $location.path(path);

        };
});

