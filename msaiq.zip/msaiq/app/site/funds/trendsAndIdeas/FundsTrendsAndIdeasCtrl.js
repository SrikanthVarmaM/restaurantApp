'use strict';

msaiqApp.controller('FundsTrendsAndIdeasCtrl', function ($scope,  $log, $location, articleResourceFactory, $) {

    $scope.trendsAndIdeasFundsResource = articleResourceFactory.trendsAndIdeasEquityResource.get({articleCode:'TREND',equityType:'M',topic:'mutual funds'});

    $scope.articleCountResource = articleResourceFactory.articleCountResource.get({articleCode:'TREND',equityType:'M'});
    $scope.articleCountResource.$promise.then(function () {
        $scope.topics = $scope.articleCountResource.topics;
    });
});