'use strict';

msaiqApp.controller('FundLandingCtrl', function ($scope, $log, articleResourceFactory, QuickViewService, $, $window) {

    $scope.QuickViewService = QuickViewService;
    $scope.test = "TEST";
    $scope.fundLandingData = articleResourceFactory.articleLandingPageTakeAwayResource.get({articleCode: 'FUNDSHOME', noOfTakeAways: 1});
    $scope.Math = $window.Math;

    $scope.goTo = function (url, windowName) {
        window.open(url, windowName);
    };
});