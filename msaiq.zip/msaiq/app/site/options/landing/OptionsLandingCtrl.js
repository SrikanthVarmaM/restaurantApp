'use strict';

msaiqApp.controller('OptionsLandingCtrl', function ($scope, $log, $routeParams,assetsResourceFactory, $location) {

    $scope.optionsLoading = true;
    $location.url('/options/optionsLanding/iFrame');
    var OptionsRawData = assetsResourceFactory.OptionsDataResource.doPostReq();
    OptionsRawData.$promise.then(function(OptionsData){
        $scope.optionsIFrameURL = OptionsData.optionsURL;
        $scope.optionsLoading = false;
    });

});