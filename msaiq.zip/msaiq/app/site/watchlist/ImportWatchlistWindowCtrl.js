'use strict';

msaiqApp.controller('ImportWatchlistWindowCtrl', function ($scope,$rootScope , $log, $routeParams,WatchlistDataService,AutoSuggestService, QuickViewService) {
    $scope.headerText = "Create Watchlist from Spreadsheet";

    $scope.AutoSuggestService= AutoSuggestService;
    $scope.states = {LOADING: 0,LOADED: 2,NOT_FOUND: 1 };
    $scope.importView = $scope.states.LOADED;
    $scope.tableView = $scope.states.NOT_FOUND;
    $scope.errorMsg, $scope.emptyFileMsg = false;
    $scope.errorMsgOnInvalid = '';
    $scope.WatchlistDataService = WatchlistDataService

    $scope.openQV =function(data){ QuickViewService.openQV(data); };

    $scope.onSuccess = function(response){
        $scope.responseData = response.data;
        if($scope.responseData.errorFiles.length > 0){
            $scope.tableView = $scope.states.NOT_FOUND;
            $scope.importView = $scope.states.LOADED;
            $scope.errorMsg = true;
            $scope.emptyFileMsg = false;
        } else if($scope.responseData.watchLists.length > 0){
            $scope.watchlistRawData = $scope.emptySppwIdCheck($scope.responseData.watchLists);
            $scope.importView = $scope.states.NOT_FOUND;
            $scope.tableView = $scope.states.LOADED;
        } else {
            $scope.importView = $scope.states.LOADED;
            $scope.tableView = $scope.states.NOT_FOUND;
            $scope.emptyFileMsg = true;
            $scope.errorMsg = false;
        }
    };


    $scope.handleSaveWatchlist = function(parentIndex, title){
        var selectedItem = $scope.watchlistRawData[parentIndex];
        $scope.WatchlistDataService.watchlistCrudOperations($scope.creatingFormParams(title,selectedItem.items)).$promise.then(function(watchlistData){
            $scope.watchlistRawData.splice(parentIndex,1);
            $rootScope.$broadcast('refreshWatchLandingPage');
            if ($rootScope.checkHumaneMargins()) {
                humane.log("You have successfully added assets to your "+title+ " watchlist", {addnCls: 'humaneResize'});
            } else {
                humane.log("You have successfully added assets to your "+title+ " watchlist");
            }
            if($scope.watchlistRawData.length == 0){
                $scope.importView = $scope.states.LOADED;
                $scope.tableView = $scope.states.NOT_FOUND;
                $scope.emptyFileMsg = false;
                $scope.errorMsg = false;
            }
        });
    };
    $scope.handleDeleteWatchlist = function(parentIndex){
        $scope.watchlistRawData.splice(parentIndex,1);
        if($scope.watchlistRawData.length == 0){
            $scope.importView = $scope.states.LOADED;
            $scope.tableView = $scope.states.NOT_FOUND;
            $scope.emptyFileMsg = false;
            $scope.errorMsg = false;
        }
    };
    $scope.deleteWatchlistItemsConfirm =function(parentIndex, childIndex,securityName){
        $scope.WatchlistDataService.openWatchlistConfirmWindow({source :$scope, action :'deleteImportWItem', securityName:securityName, watchlistItemId:childIndex, watchlistId: parentIndex});
    };

    $scope.deleteWatchlistItems = function(parentIndex, childIndex){
        $scope.watchlistRawData[parentIndex].items.splice(childIndex,1);
    };
    $scope.onUpload = function(files){
        $scope.errorMsgOnInvalid = '';
        $scope.importView = $scope.states.NOT_FOUND;
        $scope.tableView = $scope.states.LOADING;
    };

    $scope.onError = function(response){
        if(response){
            var tempArry = response.split('\\');
            $scope.errorMsgOnInvalid = tempArry[tempArry.length-1];
        }
        $scope.tableView = $scope.states.NOT_FOUND;
        $scope.importView = $scope.states.LOADED;
        $scope.errorMsg = true;
        $scope.emptyFileMsg = false;
    };

    $scope.creatingFormParams = function(wTitle,items){
        var formData = {};
        var sppwIdArray = [];
        formData['operationCode'] =  'IMPORT';
        formData['watchlist.name'] = wTitle;
        formData['watchlist.sequenceNumber'] = '';
        angular.forEach(items, function(item){
            if(item.sppwId) { sppwIdArray.push(item.sppwId);  }
        });
        formData['tickers'] =  '';
        formData['sppwIds'] =  sppwIdArray;
        formData['securityIds']  = sppwIdArray;
        return formData
    };
    $scope.emptySppwIdCheck = function(watchlists){
        angular.forEach(watchlists , function(watchlist){
           angular.forEach(watchlist.items,function(item, index){
               if(!item.sppwId && (!item.instrumentId || !item.finEntId)){
                   watchlist.items.splice(index,1);
               }
           });
        });
        return watchlists;
    };

});