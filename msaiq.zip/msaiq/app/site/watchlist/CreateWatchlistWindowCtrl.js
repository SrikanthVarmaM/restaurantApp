'use strict';

msaiqApp.controller('CreateWatchlistWindowCtrl', function ($scope,$rootScope , $log, $routeParams,WatchlistDataService) {
    $scope.headerText = "Create Watchlist";
    $scope.WatchlistDataService = WatchlistDataService;

    $scope.handleCreateWatchlist = function(value){
        $scope.handleClose();
        $scope.WatchlistDataService.watchlistCrudOperations($scope.createWatchlistFormParams(value)).$promise.then(function(watchlistData){
            $rootScope.$broadcast('refreshWatchLandingPage');
        });
    };
    $scope.createWatchlistFormParams = function(value){
        var formData = {};
        formData['operationCode'] =  'CREATE';
        formData['watchlist.name'] = value;
        formData['watchlist.sequenceNumber'] = '';
        return formData;
    };

});
