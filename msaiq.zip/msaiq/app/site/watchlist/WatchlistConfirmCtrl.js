'use strict';

msaiqApp.controller('WatchlistConfirmCtrl', function ($scope) {
    $scope.source = $scope.modelParam.source;
    $scope.action = $scope.modelParam.action;
    $scope.securityName = $scope.modelParam.securityName;
});

