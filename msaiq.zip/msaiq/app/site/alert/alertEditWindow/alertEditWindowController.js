'use strict';


msaiqApp.controller('alertEditWindowController',
	function ($scope, $log, $resource, userResourceResourceFactory, msaMessageController, $, $window, AlertDataService,QuickViewService,$rootScope) {
		//------------------------function definition------------------------------------------

		$scope.clearAll = function () {
			if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO") {
				$scope.alertItemsPortfolio[0].checked = false;
				$scope.alertItemsPortfolio[1].checked = false;
				return;
			}
			$scope.alertItems[0].checked = false;
			$scope.clearNewsAlert();
			$scope.alertItems[2].checked = false;
			$scope.clearPrice();
			$scope.clearTargetPrice();
			$scope.clearAvgEst();
			$scope.alertItems[6].criteria1 = '';
			$scope.alertItems[6].checked = false;
			$scope.alertItems[7].name = '';
			$scope.alertItems[7].criteria1 = '';
			$scope.alertItems[7].checked = false;
			$scope.alertItems[8].criteria1 = '';
			$scope.alertItems[8].checked = false;
			$scope.alertItems[9].criteria1 = '';
			$scope.alertItems[9].checked = false;
			$scope.alertItems[10].criteria1 ='';
			$scope.alertItems[10].criteria2 = '';
			$scope.alertItems[10].checked = false;
		};
		$scope.clearPrice = function () {
			$scope.alertItems[3].checked = false;
			$scope.alertItems[3].criteria1 = null;
			$scope.alertItems[3].criteria2 = null;
		};
		$scope.clearTargetPrice = function () {
			$scope.alertItems[4].checked = false;
			$scope.alertItems[4].criteria1 = null;
			$scope.alertItems[4].criteria2 = null;
		};
		$scope.handleIndexPercent = function () {
			$scope.alertItems[10].checked = ($scope.alertItems[10].criteria1 !== null && $scope.alertItems[10].criteria1 !== ''
				&& $scope.alertItems[10].criteria2 !== null && $scope.alertItems[10].criteria2 !== '')//intentional != to avoid strong type casting
		}
		$scope.handlePrevCloseChange = function () {
			$scope.alertItems[9].checked = ($scope.alertItems[9].criteria1 !== null && $scope.alertItems[9].criteria1 !== '' )//intentional != to avoid strong type casting
		};
		$scope.handle52WeekSelectionChange = function () {
			$scope.alertItems[7].criteria1= $scope.alertItems[7].name;
			$scope.alertItems[7].checked = ($scope.alertItems[7].name !== null && $scope.alertItems[7].name !== '' )//intentional != to avoid strong type casting
		};
		$scope.handleTradingVolumeSelectionChange = function () {
			$scope.alertItems[6].checked = ($scope.alertItems[6].criteria1 !== null && $scope.alertItems[6].criteria1 !== '' )//intentional != to avoid strong type casting
		};
		$scope.handleMovingAverageChange = function () {
			$scope.alertItems[8].checked = ($scope.alertItems[8].criteria1 !== null && $scope.alertItems[8].criteria1 !== '' )//intentional != to avoid strong type casting
		};
		$scope.handleAVGEstChange = function () {
			if (!($scope.alertItems[5].criteria3 || $scope.alertItems[5].criteria4 )) {
				$scope.alertItems[5].criteria3 = true;

			}


			$scope.alertItems[5].checked = ($scope.alertItems[5].criteria3 || $scope.alertItems[5].criteria4) && ($scope.alertItems[5].criteria1 !== null || $scope.alertItems[5].criteria2 !== null);
		};
		$scope.handleAVGEstChangeYear = function () {

			$scope.alertItems[5].checked = ($scope.alertItems[5].criteria3 || $scope.alertItems[5].criteria4) && ($scope.alertItems[5].criteria1 !== null || $scope.alertItems[5].criteria2 !== null);
		};
		$scope.handleMOTargetChange = function () {

			$scope.alertItems[4].checked = ($scope.alertItems[4].criteria1 !== null || $scope.alertItems[4].criteria2 !== null);
		};
		$scope.handlePriceChange = function () {
			$log.info($scope.alertItems[3].criteria1);
			$scope.alertItems[3].checked = ($scope.alertItems[3].criteria1 !== null || $scope.alertItems[3].criteria2 !== null);
		};
		$scope.clearAvgEst = function () {
			$scope.alertItems[5].checked = false;
			$scope.alertItems[5].criteria3 = false;
			$scope.alertItems[5].criteria4 = false;
			$scope.alertItems[5].criteria1 = null;
			$scope.alertItems[5].criteria2 = null;
		};
		$scope.deleteAlert = function () {
			$scope.getThisAlert();
			AlertDataService.deleteAlert($scope.thisAlert);
			$scope.$modalClose();

		};
		$scope.ifClearAllDisabled = function () {
			if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO") {
				return !($scope.alertItemsPortfolio[0].checked || $scope.alertItemsPortfolio[1].checked );
			} else {
				return  !($scope.alertItems[0].checked || $scope.alertItems[12].checked || $scope.alertItems[13].checked || $scope.alertItems[1].checked || $scope.alertItems[2].checked
					|| $scope.alertItems[3].checked || $scope.alertItems[4].checked || $scope.alertItems[5].checked || $scope.alertItems[6].checked || $scope.alertItems[7].checked || $scope.alertItems[8].checked ||
					$scope.alertItems[9].checked || $scope.alertItems[10].checked );
			}

		};
		$scope.clearNewsAlert = function () {
			$scope.alertItems[1].checked = false;
			$scope.alertItems[12].checked = false;
			$scope.alertItems[13].checked = false;
		};
		$scope.ifDeletable = function () {
			return  !$scope.deletable;
		};
		$scope.createOrEditAlert = function (actionType, alert) {

			if (actionType === "CREATE") {
				/*  var alertTemp = AlertDataService.getExistingAlertForThisInstrument($scope.selectedInstrument.instrumentId);
				 if (!_.isEmpty(alertTemp)) {
				 alert = alertTemp;
				 actionType = "UPDATE";
				 }  */

			}

			$scope.headerText = (actionType === "CREATE" ? "CREATE " : "EDIT ") + "ALERT FOR ";
			$scope.model.email = AlertDataService.getEmail();
			$scope.uncheckAllAlerts();
			if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO" && actionType === "CREATE") {
				$scope.alertItemsPortfolio[0].checked = true;
				var shallowCopy = {};
				angular.extend(shallowCopy,$scope.alertItemsPortfolio[0]);
				$scope.existingAlertsPortfolio.push(shallowCopy) ;
			}
			if (alert) {
				$scope.thisAlert = alert;
				$scope.deletable = true;
				$scope.selectedInstrument = {};
				$scope.selectedInstrument.alertId = alert.alertId;
				$scope.selectedInstrument.instrumentId = alert.instrumentId;
				$scope.selectedInstrument.instrumentName = alert.instrumentName;
				$scope.selectedInstrument.instrumentType = alert.instrumentType;
				$scope.selectedInstrument.instrumentLongName = alert.instrumentLongName;
				$scope.selectedInstrument.securityType = alert.securityType;
				$log.info($scope.selectedInstrument.instrumentLongName);
				$scope.model.jointType= alert.alertItems[0].jointType;
				$scope.existingJointType= $scope.model.jointType;
				if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO") {

					for (var i = 0; i < alert.alertItems.length; i += 1) {
						for (var j = 0; j < $scope.alertItemsPortfolio.length; j += 1) {
							if (alert.alertItems[i].name === $scope.alertItemsPortfolio[j].name) {
								$scope.alertItemsPortfolio[j] = alert.alertItems[i];
								$scope.alertItemsPortfolio[j].checked = true;
								var shallowCopy = {};
								angular.extend(shallowCopy,$scope.alertItemsPortfolio[j]);
								$scope.existingAlertsPortfolio.push(shallowCopy) ;
							}
						}
					}

				} else {
					for (var i = 0; i < alert.alertItems.length; i += 1) {
						for (var j = 0; j < $scope.alertItems.length; j += 1) {
							if (alert.alertItems[i].name === $scope.alertItems[j].name) {
								var cr1Flag=false;var cr2Flag = false;
								if($scope.alertItems[j].criteria1 === '' & alert.alertItems[i] === null ){

									cr1Flag=true;
								}
								if($scope.alertItems[j].criteria2 === '' & alert.alertItems[i] === null ){

									cr2Flag=true;
								}
								$scope.alertItems[j] = alert.alertItems[i];
								if (cr1Flag){
									$scope.alertItems[j].criteria1='' ;
								}
								if (cr2Flag){
									$scope.alertItems[j].criteria2='' ;
								}
								$scope.alertItems[j].checked = true;
								var shallowCopy ={};
								angular.extend(shallowCopy,$scope.alertItems[j]);
								$scope.existingAlertsIndividual.push(shallowCopy) ;

							}
							var nameArr=['HIGH_52WEEKS','LOW_52WEEKS','HIGH_LOW_52WEEKS'] ;
							var found =_.find(nameArr, function(name) {
								return name === alert.alertItems[i].name;
							});
							if ( j === 7 &&( $scope.alertItems[j].name === null || $scope.alertItems[j].name == "" )&&! _.isEmpty(found) ) {
								$scope.alertItems[j] = alert.alertItems[i];
								$scope.alertItems[j].checked = true;
								var shallowCopy ={};
								angular.extend(shallowCopy,$scope.alertItems[j]);
								$scope.existingAlertsIndividual.push(shallowCopy) ;
							}
						}
					}
				}

			}
			var param = "operationCode=GET_DETAIL&sppwId=" + $scope.selectedInstrument.instrumentId;
			$scope.actionType = actionType;
			if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO") {
				return;
			}
			userResourceResourceFactory.securityResource.postReq(param, function (securityDetailsResult) {

				$scope.getAdditionalInfoFromSecurityDetails(securityDetailsResult);

			});


		};

		$scope.getName = function () {
			if ($scope.selectedInstrument.instrumentType === 'SPPORTFOLIO') {
				$log.info($scope.selectedInstrument.instrumentLongName + "port");
				return $scope.selectedInstrument.instrumentLongName;

			} else {
				$log.info($scope.selectedInstrument.instrumentName);
				return "[" + $scope.selectedInstrument.instrumentName + "]";
			}
		};
		$scope.getThisAlert = function () {
			if ($scope.thisAlert) {
				return;
			}
			$scope.thisAlert.alertId = $scope.selectedInstrument.alertId;
			$scope.thisAlert.instrumentId = $scope.selectedInstrument.instrumentId;
			$scope.thisAlert.instrumentName = $scope.selectedInstrument.instrumentName;
			//TODO add instrument type here

			$scope.thisAlert.alertItems = $scope.alertItems;
		};
		$scope.isValidNumericInputs = function (item) {

			var criteria1Valid = _.isEmpty(item.criteria1) || _.isFinite(item.criteria1) && !item.criteria1.startsWith('-');
			var criteria2Valid = _.isEmpty(item.criteria2) || _.isFinite(item.criteria2) && !item.criteria2.startsWith('-');
			return criteria1Valid && criteria2Valid;

		};
		$scope.isSaveDisabled = function () {

		};
		$scope.validateAndSave=function(){
			var selectedAlerts=[];
			var existingAlerts =[];
            var portfolioFirstTime=false;
			if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO") {
				selectedAlerts = _.filter($scope.alertItemsPortfolio, function(item) { return item.checked === true; });
				existingAlerts= $scope.existingAlertsPortfolio;
                if ($scope.actionType === 'CREATE' &&   selectedAlerts.length  ===  existingAlerts.length && selectedAlerts.length ===1 && _.isEqual(selectedAlerts[0], existingAlerts[0]))  {
                    portfolioFirstTime=true;;
                }

			}else {
				selectedAlerts=_.filter($scope.alertItems, function(item) { return item.checked === true; });
				existingAlerts= $scope.existingAlertsIndividual;
			}

			var alertsUnChanged =true;
            var diff=[];
			if (  selectedAlerts.length  ===  existingAlerts.length )  {


                for (var i =0; i < selectedAlerts.length;i++){
                   var idx= _.findIndex(existingAlerts, function(item) {
                        return _.isEqual(item,selectedAlerts[i]);
                    });

					alertsUnChanged= alertsUnChanged &&  (idx !== -1);

				}
			}  else {
				alertsUnChanged=false;
			}
            if (portfolioFirstTime) {
                alertsUnChanged=false;
            }
			var isEmailUnchanged = AlertDataService.getEmail() === $scope.model.email;
			var isJointTypeUnchanged= $scope.existingJointType ===  $scope.model.jointType;
			if (alertsUnChanged && isEmailUnchanged && isJointTypeUnchanged){
                if ($rootScope.checkHumaneMargins()) {
				    humane.log("You have not made any change to this alert yet", {addnCls: 'humaneResize'});
                } else {
                    humane.log("You have not made any change to this alert yet");
                }
				return;
			}
			if ($scope.selectedInstrument.instrumentType !== "SPPORTFOLIO") {
				var valid3=$scope.isValidNumericInputs($scope.alertItems[3]);
				var valid4= $scope.isValidNumericInputs($scope.alertItems[4]);
				var valid5=$scope.isValidNumericInputs($scope.alertItems[5])

				if (!valid3 ||!valid4 || !valid5 ) {
					var errorMessage="";
					if (!valid3){
						errorMessage = "Please enter valid numeric values for above and below Price.";
					}
					if (!valid4) {
						errorMessage += "\n"+ "Please enter valid numeric values for above and below 12 Mo. Target Price. ";
					}

					if (!valid5) {
						errorMessage += "\n"+ "Please enter valid numeric values for above and below Avg. Estimate."
					}

                    if ($rootScope.checkHumaneMargins()) {
					    humane.log(errorMessage, {addnCls: 'humaneResize'});
                    } else {
                        humane.log(errorMessage);
                    }
					return;
				}
			}
			var validEmail =$scope.isValidEmail($scope.model.email) ;

			if (!validEmail)  {
				var errorMessage="Please enter valid email adress.";
                if ($rootScope.checkHumaneMargins()) {
				    humane.log(errorMessage, {addnCls: 'humaneResize'});
                } else {
                    humane.log(errorMessage);
                }
				return;
			}
			QuickViewService.openAlertConfirmWindow({source :$scope,action :'save'});

		};
		$scope.deleteAlertC=function(){

			QuickViewService.openAlertConfirmWindow({source :$scope,action :'delete'});

		};
		$scope.isValidEmail=function(x) {
			var atpos=x.indexOf("@");
			var dotpos=x.lastIndexOf(".");
			if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
			{

				return false;
			}
			return true;

		} ;
		$scope.saveAlert = function () {

			if ($scope.selectedInstrument.instrumentType === "SPPORTFOLIO") {
				AlertDataService.saveThisAlert($scope.actionType, $scope.alertItemsPortfolio, $scope.model.email, $scope.selectedInstrument,$scope.model.jointType);

			} else {


				AlertDataService.saveThisAlert($scope.actionType, $scope.alertItems, $scope.model.email, $scope.selectedInstrument,$scope.model.jointType);

			}
			$scope.deletable = true;
			$scope.$modalClose();

		};
		$scope.getAdditionalInfoFromSecurityDetails = function (securityDetailsResult) {
			if (securityDetailsResult.errorCode) {
				return;
			}
			$scope.selectedInstrument.instrumentName = securityDetailsResult.symbol;
			$scope.selectedInstrument.instrumentLongName = securityDetailsResult.securityName;
			$scope.selectedInstrument.securityType = securityDetailsResult.equityType;
			$scope.selectedInstrument.currencyCode = securityDetailsResult.currencyCode;
			$scope.selectedInstrument.lastPrice = securityDetailsResult.delayedPrice;
			$scope.selectedInstrument.priceChange = securityDetailsResult.priceChange;
			$scope.selectedInstrument.percentChange = securityDetailsResult.pctChange;
			$scope.selectedInstrument.avgDailyVolume = securityDetailsResult.avgVol;
			$scope.selectedInstrument.week52High = securityDetailsResult.high52week;
			$scope.selectedInstrument.week52Low = securityDetailsResult.low52week;
			$scope.selectedInstrument.prevClose = securityDetailsResult.lastClosed;
			$scope.selectedInstrument.targetPrice12Month = securityDetailsResult.targetPrice12Month;
			$scope.selectedInstrument.prevTargetPrice12Month = securityDetailsResult.prevTargetPrice12Month;


			if (securityDetailsResult.earningsConsensus && securityDetailsResult.earningsConsensus.exists) {
				$scope.selectedInstrument.avgEstCurrentYr = securityDetailsResult.earningsConsensus.currentYear.average;
				$scope.selectedInstrument.prevAvgEstCurrentYr = securityDetailsResult.earningsConsensus.currentYear.prior;
				$scope.selectedInstrument.avgEstCurrentYrPlusOne = securityDetailsResult.earningsConsensus.nextYear.average;
				$scope.selectedInstrument.prevAvgEstCurrentYrPlusOne = securityDetailsResult.earningsConsensus.nextYear.prior;
			}
		};
		$scope.uncheckAllAlerts = function () {
			for (var j = 0; j < $scope.alertItems.length; j += 1) {
				$scope.alertItems[j].checked = false;
			}
			for (var j = 0; j < $scope.alertItemsPortfolio.length; j += 1) {
				$scope.alertItemsPortfolio[j].checked = false;
			}
		};

		//--------------------------------------- initialization--------------------------------------------------
		$.placeholder.shim();
		$scope.model = {};
		$scope.model.jointType = "ANY";
		$scope.deletable = false;
		$scope.headerText = "";
		$scope.alertItems = [
			{checked: false, name: 'STARS_RANK'},   //0
			{checked: false, name: 'SECURITIES_IN_RESEARCH_NOTES' },//1
			{checked: false, name: 'SECURITIES_IN_TRENDS'},                       //2 trendsandidea
			{checked: false, name: 'PRICE_TARGET', criteria1: null, criteria2: null } ,    //3
			{checked: false, name: 'TARGET_PRICE_12M', criteria1: null, criteria2: null}  ,   //4 twlveMonthpriceAlert :
			{checked: false, name: 'AVG_EST', criteria1: null, criteria2: null, criteria3: null, criteria4: null},    //5   avgEstAlert :
			{name: 'TRADE_VOLUME', checked: false, criteria1: ''}   ,  //6    tradingVolumeAlert :
			{name: '', criteria1 :'', checked: false}, //7  Low52WeekAlert :
			{ name: 'MOVING_AVG', checked: false, criteria1: ''},    //8  movingAvgAlert :
			{name: 'PRICE_CHANGE', checked: false, criteria1: ''},   //9   previousCloseAlert :
			{name: 'PRICE_INDEX_CHANGE', checked: false, criteria1: '', criteria2: ''},  //10   previousCloseIndexAlert :
			{checked: false} ,   //11  fmrChangedRatingAlert :
			{checked: false, name: 'SECURITIES_IN_MARKET_MOVERS' },//12
			{checked: false, name: 'SECURITIES_IN_BROKER_VIEWSNEWS' }//13 ,
		];
		$scope.existingAlertsIndividual=[];
		$scope.existingAlertsPortfolio=[];
		$scope.existingJointType='ANY';
		$scope.alertItemsPortfolio = [
			{      checked: false, name: 'PORTFOLIO_SEC_ADD'  },
			{   checked: false, name: 'PORTFOLIO_SEC_DELETE'          }
		];
		$scope.instrumentInfos = [
			{}
		];
		$scope.selectedInstrument = {};
		$scope.selectedInstrument.instrumentId = $scope.modelParam.selectedInstrument ? $scope.modelParam.selectedInstrument.instrumentId : $scope.modelParam.sppw_id;
		$scope.selectedInstrument.instrumentType = $scope.modelParam.selectedInstrument ? $scope.modelParam.selectedInstrument.instrumentType : 'INDIVIDUAL';
		$scope.selectedInstrument.instrumentName = $scope.modelParam.selectedInstrument ? $scope.modelParam.selectedInstrument.instrumentName : $scope.modelParam.ticker;
		$scope.selectedInstrument.securityType = $scope.modelParam.selectedInstrument ? $scope.modelParam.selectedInstrument.securityType : ($scope.modelParam.alert?$scope.modelParam.alert.securityType: $scope.modelParam.security_type);

		$scope.selectedInstrument.instrumentLongName = $scope.modelParam.selectedInstrument ? $scope.modelParam.selectedInstrument.instrumentLongName : null;
		$scope.createOrEditAlert($scope.modelParam.actionType, $scope.modelParam.alert);
		//-----------------
	}


);
msaiqApp.filter('priceTextRenderer', function ($filter) {  // from an array of alerts of all types , filters out particular type of alerts & returns
	var emptyCheckFilter=$filter('emptyCheckFilter')  ;
	return function (price, currencySymbol) {
		if (emptyCheckFilter(price))  {
			return "-";
		}
		if (emptyCheckFilter(currencySymbol))  {
			return '$' + price;
		}
		return    currencySymbol + price;
	};
	//$(".tooltip1").tooltip();
});
