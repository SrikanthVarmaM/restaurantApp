'use strict';


msaiqApp.controller('alertConfirmController',
    function ($scope) {
        //------------------------function definition------------------------------------------
        $scope.source= $scope.modelParam.source;
         $scope.action=$scope.modelParam.action

        //-----------------
    }


);

