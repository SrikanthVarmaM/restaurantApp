'use strict';


msaiqApp.directive('msaAlertButton', function () {
    return{
        restrict: 'A',
        transclude: true,
        templateUrl: 'site/alert/alertButtonTemplate.html',
        replace: true,
        link: function (scope, attrs) {

        },
        scope: {
        },
        controller: function ($scope, $log, $resource, userResourceResourceFactory, _, msaMessageController,AlertDataService,QuickViewService ) {
           $scope.AlertDataService=AlertDataService;

            $scope.openAlert=function(alert){

                var message = {
                    actionType: 'UPDATE',
                    alert: alert
                };
                QuickViewService.openAlertWindow(message);

            } ;


        }
    };


});


