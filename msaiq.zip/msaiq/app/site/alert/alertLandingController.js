'use strict';

msaiqApp.directive('msaAlertLandingPage', function () {
    return{
        restrict: 'A',
        transclude: true,
        templateUrl: 'site/alert/alertLandingTemplate.html',
        replace: true,
        controller: function ($scope, _,$, $routeParams,$log, $resource, userResourceResourceFactory, msaMessageController,AlertDataService,ngTableParams,QuickViewService,AutoSuggestService) {
            $scope.createAlertDisabled=true;
            $scope.w=window;
            $scope.AlertDataService=AlertDataService;
            $scope.au= AutoSuggestService;

            $scope.openQV =function(data){
                QuickViewService.openQV(data);
            }  ;



            AlertDataService.alertData.$promise.then(function(alertData){

                var alertCount=0;
                for (var i=0;i <alertData.alerts.length;i++)  {
                  //  alertData.alerts[i].isDeleted=false;
                    if (alertData.alerts[i] && alertData.alerts[i].instrumentType === "SPPORTFOLIO"){
                        alertCount+=1;
                    }
                }

            });


            $scope.clearSearch=function(){

                var messageWrapper = {
                    messageType: 'CLEAR_SEARCH'

                };
                msaMessageController.prepForBroadcast(messageWrapper);
            };

            $scope.selectedAlertArray =[];
            $scope.handleCheckBoxChange=function(event,alert){
                if(alert.checkBoxSelected)  {
                    $scope.selectedAlertArray.push(alert);
                }   else {


                    $scope.selectedAlertArray= _.filter($scope.selectedAlertArray,function(item){
                        return item  !== alert;
                    });

                }

            };
            $scope.ifDeletable=function(selectedAlertArray) {
                return (_.isEmpty($scope.selectedAlertArray)  );
            }    ;
            $scope.deleteAlertC=function(){
                QuickViewService.openAlertConfirmWindow({source :$scope,action :'delete'});

            } ;
            $scope.deleteAlert=function(){
                for (var item in $scope.selectedAlertArray ) {
                   // $scope.selectedAlertArray[item].isDeleted=true;

                    AlertDataService.deleteAlert($scope.selectedAlertArray[item]);
                    //item.checkBoxSelected=false;
                }
                $scope.selectedAlertArray=[];
            } ;

            $scope.$on('handleBroadcast', function () {
                if (msaMessageController.message.messageType === 'SECURITY_INFO') {
                   msaMessageController.message.messageBody.actionType="CREATE" ;
                    $scope.messageToCreateAlert= msaMessageController.message.messageBody;

                }


            });
            $scope.handleAlertButtonState=function(value){
                $scope.createAlertDisabled=value;
                $scope.$digest();  //  since angular does not throw view refresh on scope value change until it is bound to some input element through ng-model"
            } ;
            $scope.createOrEditAlert = function (actionType, alert) {
                var data=null;
                if (actionType === "CREATE") {
                    $scope.clearSearch();
                    data=$scope.messageToCreateAlert;
                }  else {
                    data = {
                        actionType: actionType,
                        alert: alert
                    };
                }


                    QuickViewService.openAlertWindow(data);
                $scope.createAlertDisabled=true;



            };

            var requestParam = 'operationCode=GET_ALL';
            //var requestParamW = 'operationCode=READ';  // THIS is the weirdest way of passing angular post params instead of using json object notation, took me 4 days to figure out

            $log.info("alerts initialized");
            /*
             $scope.watchlistData = userResourceResourceFactory.watchlistResource.postReq(requestParamW, function (data) {
             $scope.watchlistData = data;
             $log.info("watchlist  loaded")
             });
             */
        }
    }
});




msaiqApp.filter('getWatchlistNames', function () {  // from an array of alerts of all types , filters out particular type of alerts & returns
    return function (alertArray, watchlistArray) {

        for (var item1 in alertArray) {
            if (alertArray[item1].instrumentId){
                for (var item in watchlistArray) {
                    if (watchlistArray[item].id == alertArray[item1].instrumentId) { // "=="  intentional to avoid strong type casting in this particular scenario
                        alertArray[item1].watchlistName = watchlistArray[item].name;
                    }
                }
            }
        }
        return alertArray;
    };
});
msaiqApp.filter('currentPrevPriceTextRenderer', function ($filter) {  // from an array of alerts of all types , filters out particular type of alerts & returns
    var roundFilter=$filter('roundToNDecimalFilter')  ;
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function (curr, prev, currencySymbol) {
        if ( emptyCheckFilter(curr) && emptyCheckFilter(prev))  {
            return "---(-%)"  ;
        }
        if ( emptyCheckFilter(currencySymbol) ) {
            currencySymbol='$'  ;
        }
        var v1, v2, diff, pct;
        var format;
        v1 = currencySymbol + curr;
        v2 = currencySymbol + prev;
        if (v1 !== '-' && v2 !== '-') {
            diff = curr - prev;
            pct = diff / curr;

            diff = currencySymbol + roundFilter(diff,2);
            format = v1 + ' - ' + diff + ' (' + roundFilter(pct,2) + '%)';
        }
        else if (v1 === '-') {
            format = '- --(%)';
        }

        else if (v2 === '-') {
            format = v1 + ' --(%)';
        }

        else {
            format = '-';
        }


        return format;
    };
    //$(".tooltip1").tooltip();
});