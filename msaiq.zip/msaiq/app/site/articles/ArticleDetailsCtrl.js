'use strict';

msaiqApp.controller('ArticleDetailsCtrl', function ($scope,  $log, $routeParams, articleResourceFactory) {
    $log.info('Article Details Controller');
    $scope.articleId =  $routeParams.articleId;
    $scope.articleCode = $routeParams.articleCode;
    $scope.path = $routeParams.source || '' ;
    $log.info('article id: ' + $scope.articleId + ', article code: ' +  $scope.articleCode +' article path: '+ $scope.path);

    $scope.article = articleResourceFactory.articlesDetailsResource.get({articleCode:$scope.articleCode, articleId:$scope.articleId});

    $scope.article.$promise.then(
        function(){
            if( $scope.article.articleDetails.articleAttachments && $scope.article.articleDetails.articleAttachments.length >= 1)
            {
                $scope.attachmentName = encodeURI($scope.article.articleDetails.articleAttachments[0].attachmentName);
                $scope.showPdf = true;
            } else
            {
                $scope.showPdf = false;
            }

        });

    $scope.goTo = function(url, windowName){
        url = 'http://12.26.55.67/data/EQ/pdf/sr/9/92035510.pdf?tracking=WebSolutions';
        window.open( url, windowName);
    };
});
