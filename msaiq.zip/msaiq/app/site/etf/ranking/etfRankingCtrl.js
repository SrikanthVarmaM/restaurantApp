'use strict';

msaiqApp.controller('etfRankingCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory,$, $location) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.loading = true;
    $scope.showExportToExcel = $scope.states.LOADING;
    $scope.operation1Value = $routeParams.operation1Value
    $scope.showWatchlist = false;
    $scope.selectedSppwids =[];

    if($scope.operation1Value === '4'){
        $scope.selectedItem='OVERWEIGHT';
    }else if($scope.operation1Value === '3'){
        $scope.selectedItem='MARKETWEIGHT';
    }
    else if($scope.operation1Value === '2'){
        $scope.selectedItem='UNDERWEIGHT';
    }

    $scope.etfRankingArgs = {activeTab: 'CUSTOM'};
    $scope.rankingTableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' } };

    $scope.clickTab = function (tab){
        $scope.etfRankingArgs.activeTab = tab;
    };

    $scope.$watch('rankingTableParams', function(params,oldParams) {
        if(oldParams.page === params.page && $scope.rankingTableParams.total !== 0)
        {
            return;
        }
        $scope.etfRankingResource = articleResourceFactory.etfRankingResource.get({start: (params.page-1) * params.count,limit:params.count, operation1Value:$scope.operation1Value});
        $scope.loading = true;
        $scope.etfRankingResource.$promise.then(function(rankingData){
            $scope.rankingTableParams.total = $scope.totalNumOfRecords = rankingData.total_records;
            $scope.loading = false;
            $scope.rakingList =  rankingData;
            if($scope.rankingTableParams.page === 1){
                if($scope.rankingTableParams.total <= 200 && $scope.rankingTableParams.total > 0){
                    $scope.printArrayLink  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=overallIndVal&screenerParameters%5B0%5D.propertyLabel=Overall S&P Ranking&screenerParameters%5B0%5D.operation1Value='+ $scope.operation1Value+'&screenerParameters%5B0%5D.customRenderer=weightRenderer&start=0&limit=200&equityType=ETFS&sort=securityName&dir=ASC&criteriaMessage='+$scope.selectedItem+' ETFs';
                    $scope.showExportToExcel = $scope.states.LOADED;
                } else {
                    $scope.showExportToExcel = $scope.states.NOT_FOUND;
                }
            }
        },function(){
            $scope.showExportToExcel = $scope.states.LOADING;
            $scope.loading = false;
        });
    }, true);

    $scope.handleCheckBoxChange=function(event,data,sppwId){
        if(data.speculativeGrade){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.rakingList.equities, function(item) {
            if (angular.isDefined(item.speculativeGrade)) {
                item.speculativeGrade = checked;
                if(item.speculativeGrade){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.rakingList.equities,function(item){
                item.speculativeGrade = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);

    $scope.goTo = function(path){
        $location.path(path);
    };
});
