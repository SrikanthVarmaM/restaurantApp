'use strict';

msaiqApp.controller('EtfQuickViewCtrl',  ['$scope', '$log', '$location', '$route', 'assetsResourceFactory',
    function ($scope,  $log, $location, $route, assetsResourceFactory) {
        $log.debug('ETF QuickView Controller');
        $scope.sppwId = $scope.modelParam.sppwId;
        $scope.ticker = $scope.modelParam.ticker;
        $scope.type = $scope.modelParam.type;
        $scope.showWatchlist = false;
        $scope.selectedSppwids = [];

        $log.debug('ETF QuickView sppwid: ' + $scope.sppwId + ', ticker: ' +  $scope.ticker);

        var etfResource = assetsResourceFactory.etfDetailsResource.get({ticker: ($scope.ticker||'null'), sppwid: ($scope.sppwId || 'null') });

        // what to reformat resource data as Elastic Search returns back deep level json objects like hits.hits[0]
        etfResource.$promise.then(function(etfData){

            $log.debug('etf  promised return data');
            //   window.alert('etf  promised return data');
            //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
            if (!etfData.hits || !etfData.hits.hits[0] || !etfData.hits.hits[0]._source){
                $scope.error = 'ETF ' + $scope.ticker + ' is not available';
            }else{
                $scope.etfDetails = etfData.hits.hits[0]._source;
                $scope.setGeneralFlags();
                $scope.showWatchlist = true;
                $scope.selectedSppwids.push($scope.sppwId);
            }

        });

        // type of ranking
        $scope.rankingTypes = ['OVERWEIGHT', 'MARKETWEIGHT', 'UNDERWEIGHT'];
        $scope.Math = window.Math;

        $scope.setGeneralFlags = function(){
            $scope.isFixedIncome = ($scope.etfDetails.holding_asset_class === 'Taxable Fixed Income' || $scope.etfDetails.holding_asset_class === 'Tax-Free Fixed Income');
            $scope.isEquity = ($scope.etfDetails.holding_asset_class === 'Equity');
        };


        $scope.openNewWindow = function(url, windowName){
            window.open( url, windowName, 'resizable=yes');
        };

        $scope.goTo = function(path){
            // close model and then change route.
            $scope.$modalClose();

            $location.path(path);
            window.location.href =  '#'+path;
            $route.reload();

        };
    }

]);
