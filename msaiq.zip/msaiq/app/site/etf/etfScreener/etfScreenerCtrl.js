'use strict';

msaiqApp.controller('EtfScreenerCtrl', function ($) {
    $('#msaIframe').on('$destroy',function(){
        $('#etfmenu').css('position', 'inherit');
        $('#etfmenu').css('z-index', '0');
    });

});

var watchForEtfs = function () {
    var myTimeout = setInterval(function () {
        if (jQuery('#msaIframe').contents().find('.holdingAssetClass-form').size() > 0) {
            jQuery('#msaIframe').contents().find('.security-screener').trigger('click');
            jQuery('#msaIframe').css('visibility', 'visible');

            jQuery('#etfmenu').css('position', 'absolute');
            jQuery('#etfmenu').css('z-index', '1');
            clearTimeout(myTimeout);
        }
    }, 100);
};
