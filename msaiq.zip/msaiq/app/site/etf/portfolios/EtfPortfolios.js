'use strict';

msaiqApp.controller('EtfPortfoliosCtrl', function ($scope, $log, articleResourceFactory) {
    $scope.etfPortfoliosResource = articleResourceFactory.portfolioConfigResource.get();
});