'use strict';

msaiqApp.controller('EtfLandingCtrl', function ($scope, $log, articleResourceFactory, $) {
    $scope.etfLandingResource = articleResourceFactory.articleLandingPageTakeAwayResource.get({articleCode: 'ETFSHOME', noOfTakeAways: 1});

    $scope.goTo = function (url, windowName) {
        window.open(url, windowName);
    };
});