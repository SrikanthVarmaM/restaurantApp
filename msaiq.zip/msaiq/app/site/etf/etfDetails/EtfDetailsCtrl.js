'use strict';

msaiqApp.controller('EtfDetailsCtrl', function ($scope, $log, $routeParams, assetsResourceFactory, ArticleMessaging,$,AutoSuggestService,QuickViewService) {
  //  window.alert('At ETF Controller');
    $log.debug('ETF Details Controller');
    $scope.sppwId =  $routeParams.sppwId;
    $scope.ticker = $routeParams.ticker;
    $scope.showWatchlist = false;
    $scope.selectedSppwids = [];
    $scope.showWatchlistForTop10 = false;
    $scope.selectedTickersForTop10 = [];
    $scope.AutoSuggestService = AutoSuggestService;
    $scope.top10HoldingSppwIdArray = true;
    //$scope.loading = false;

    // set up the asset menu to highlight
    $scope.$emit('menuShow','Etf');

    var etfResource = assetsResourceFactory.etfDetailsResource.get({ticker: ($scope.ticker||'null'), sppwid: ($scope.sppwId || 'null') });

    // what to reformat resource data as Elastic Search returns back deep level json objects like hits.hits[0]
    etfResource.$promise.then(function(etfData){

        $log.debug('etf  promised return data');
      //   window.alert('etf  promised return data');
        //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
        if (!etfData.hits || !etfData.hits.hits[0] || !etfData.hits.hits[0]._source){
            $scope.error = 'ETF  ' + $scope.ticker + ' is not available';
        }else{

            var etfDetailsRawData = etfData.hits.hits[0]._source;
            angular.forEach(etfDetailsRawData.topholdings,function(item){
               item['checkLink'] = false;
                if(item.TradingInformation_Ticker){
                    AutoSuggestService.getTickerInformation(item.TradingInformation_Ticker,function(data){
                            if(data.sppwId != 'blank') {
                                item['sppwId'] = data.sppwId;
                                $scope.top10HoldingSppwIdArray = false;
                            } else{
                                item['sppwId'] = '';
                            }
                        }
                    );
                }else{
                    item['sppwId'] = '';
                }
            });
            $scope.etfDetails =  etfDetailsRawData;
            $scope.showWatchlist = true;
            $scope.selectedSppwids.push($scope.sppwId);
        }

        $scope.setGeneralFlags();
        $scope.setCreditRating();
        $scope.setTopHoldingSum();

        //search for all overweight unless there's no overall rank
        var relatedParam = {
            overallInd: ($scope.isFixedIncome || $scope.isEquity)?'Overweight':'',
            etfType: ($scope.etfDetails.holdings_region === 'U.S. Domestic'||(!$scope.isFixedIncome && !$scope.isEquity) )?$scope.etfDetails.etf_type:'',
            holdingsAssetClass: (!$scope.isFixedIncome && !$scope.isEquity)?$scope.etfDetails.holding_asset_class: '',
            holdingsRegion: ($scope.isFixedIncome || $scope.isEquity)?$scope.etfDetails.holdings_region:''
        };
        var message = {sppwId: $scope.etfDetails.sppw_id, ticker: $scope.etfDetails.ticker, articleid: null, relatedParam: relatedParam};

        try{
            ArticleMessaging.broadcastEtfArticleLoaded($scope, message);

        }catch(err){
            //window.alert('Article Message broadcast error ' + err.message);
            $log.error('Article Message broadcast error ' + err.message);
        }
       // $scope.loading = true;
    });

    $scope.setGeneralFlags = function(){
        $scope.isFixedIncome = ($scope.etfDetails.holding_asset_class === 'Taxable Fixed Income' || $scope.etfDetails.holding_asset_class === 'Tax-Free Fixed Income');
        $scope.isEquity = ($scope.etfDetails.holding_asset_class === 'Equity');
        $scope.econDiv = 4;     // customer bar
        $scope.econSectorArray = new Array(100/$scope.econDiv);
        $scope.checkedTop10Holdings = []; // checked top holdings;

    };

     // create a nice rating array for graph chart
    $scope.setCreditRating = function(){
        $scope.max_credit_rating = [];
        $scope.header_rating = [];
        var array = [$scope.etfDetails.etfcreditqualitybreakdown.aaarating,  $scope.etfDetails.etfcreditqualitybreakdown.aarating,
            $scope.etfDetails.etfcreditqualitybreakdown.arating, $scope.etfDetails.etfcreditqualitybreakdown.bbbrating,
            $scope.etfDetails.etfcreditqualitybreakdown.brating, $scope.etfDetails.etfcreditqualitybreakdown.belowbrating,
            $scope.etfDetails.etfcreditqualitybreakdown.nonratedrating
        ];
        var highest_rating =0;
        for(var i=0; i<array.length; i++){
            if (highest_rating< array[i]){
                highest_rating = array[i];
            }
        }
        // create credit_rating
        for (var j=0; j < highest_rating;j++){
            $scope.max_credit_rating.push(j);
        }
        $scope.header_rating= $scope.max_credit_rating.slice(0, ($scope.max_credit_rating.length/5)+2);
    };

    $scope.setTopHoldingSum = function(){

        $scope.holdings_sum = 0;
        for (var i=0; i < $scope.etfDetails.topholdings.length; i++)
        {
            $scope.holdings_sum = $scope.holdings_sum + $scope.etfDetails.topholdings[i].percentofetfassets;
        }

    };

    $scope.Math = window.Math;

    // type of ranking
    $scope.rankingTypes = ['OVERWEIGHT', 'MARKETWEIGHT', 'UNDERWEIGHT'];

    $scope.openNewWindow = function(url, windowName){
        window.open( url, windowName, 'resizable=yes');
    };

    $scope.openQV =function(data){
        QuickViewService.openQV(data);
    };

    $scope.handleCheckBoxChange = function(data){
        if(data.checkLink){
            $scope.selectedTickersForTop10.push(data.sppwId);
        }else{
            $scope.selectedTickersForTop10.splice( $scope.selectedTickersForTop10.indexOf(data.sppwId), 1);
        }
        $scope.showWatchlistForTop10 = $scope.selectedTickersForTop10.length>0 ? true:false;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.etfDetails.topholdings, function(item) {
            if (angular.isDefined(item.checkLink)) {
                if(item.sppwId)
                    item.checkLink = checked;
                if(item.checkLink){
                    if($scope.selectedTickersForTop10.indexOf(item.sppwId) < 0){
                        $scope.selectedTickersForTop10.push(item.sppwId);
                    }
                }else{
                    $scope.selectedTickersForTop10.splice( $scope.selectedTickersForTop10.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlistForTop10 = $scope.selectedTickersForTop10.length>0 ? true:false;
    };

    $scope.$watch('selectedTickersForTop10',function(value){
        if(value.length == 0 && $scope.showWatchlistForTop10){
            angular.forEach($scope.etfDetails.topholdings,function(item){
                item.checkLink = false;
            });
            $scope.showWatchlistForTop10  = false;
            $scope.selectAllSecurity = false;
        }
    },true);
});
