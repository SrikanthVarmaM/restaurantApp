'use strict';

msaiqApp.controller('EtfWatchlistViewCtrl', function ($scope,  $log, $routeParams, ngTableParams, articleResourceFactory, QuickViewService,$,$rootScope) {

    $scope.states = { LOADING: 0, NOT_FOUND: 1, LOADED: 2 };
    $scope.loading = true;
    $scope.showExportToExcel = $scope.states.LOADING;

    $scope.sppwIds = $routeParams.sppwIds;
    $scope.title = $rootScope.watchlistTitleForPrerolled;
    $scope.etfWatchListArgs = {activeTab: 'CUSTOM'};
    $scope.showWatchlist = false;
    $scope.selectedSppwids =[];
    $scope.watchListTableParams = { page   : 1, count  : 20, total  : 0, counts : [], sorting: { securityName: 'asc' } };

    $scope.clickTab = function (tab){
        $scope.etfWatchListArgs.activeTab = tab;
    };

    $scope.handleSelectAllCheckBoxChange = function(checked){
        angular.forEach($scope.etfWatchlistData.equities, function(item) {
            if (angular.isDefined(item.speculativeGrade)) {
                item.speculativeGrade = checked;
                if(item.speculativeGrade){
                    if($scope.selectedSppwids.indexOf(item.sppwId) < 0){
                        $scope.selectedSppwids.push(item.sppwId);
                    }
                }else{
                    $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(item.sppwId), 1);
                }
            }
        });
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.handleCheckBoxChange=function(event,data,sppwId,securityName){
        if(data.speculativeGrade){
            $scope.selectedSppwids.push(sppwId);
        }else{
            $scope.selectedSppwids.splice( $scope.selectedSppwids.indexOf(sppwId), 1);
        }
        $scope.showWatchlist = $scope.selectedSppwids.length>0 ? true:false;
    };

    $scope.$watch('selectedSppwids',function(value){
        if(value.length == 0 && $scope.showWatchlist){
            angular.forEach($scope.etfWatchlistData.equities,function(item){
                item.speculativeGrade = false;
            });
            $scope.showWatchlist  = false;
            $scope.selectAllSecurity = false;
        }
    },true);

    $scope.creatingFormParams = function(params){
        var formData = {};
        formData['start'] =  (params.page-1) * params.count;
        formData['screenerParameters[0].propertyName'] = 'id';
        formData['screenerParameters[0].operation1Value'] = $scope.sppwIds;
        formData['screenerParameters[0].customRenderer']= 'idRenderer';
        formData['limit'] = params.count;
        formData['equityType'] = 'ETFS';
        formData['sort'] = 'securityName';
        formData['dir'] = 'ASC';
        return formData
    };

    if($scope.sppwIds != "-1"){
        $scope.$watch('watchListTableParams', function(params) {
            var etfWatchlistResource = articleResourceFactory.assetWatchlistResource.postReq($scope.creatingFormParams(params));
            etfWatchlistResource.$promise.then(function(etfWatchlistData){
                $scope.watchListTableParams.total = $scope.totalNumOfRecords = etfWatchlistData.total_records;
                for(var i=0; i < etfWatchlistData.equities.length; i++){
                    etfWatchlistData.equities[i].inceptionDate = etfWatchlistData.equities[i].inceptionDate.split('-').join('/');
                }
                if($scope.watchListTableParams.page === 1){
                    if($scope.watchListTableParams.total <= 200 && $scope.watchListTableParams.total > 0){
                        $scope.printArrayLink  = '/SP/msa/excelScreenerResults.html?screenerParameters%5B0%5D.propertyName=id&screenerParameters%5B0%5D.operation1Value='+ $scope.sppwIds+'&screenerParameters%5B0%5D.customRenderer=idRenderer&start=0&limit=200&equityType=ETFS&sort=securityName&dir=ASC&criteriaMessage=Watchlist search: '+$scope.title;
                        $scope.showExportToExcel = $scope.states.LOADED;
                    } else {
                        $scope.showExportToExcel = $scope.states.NOT_FOUND;
                    }
                }
                $scope.etfWatchlistData =  etfWatchlistData;
                $scope.viewState = $scope.states.LOADED;
                $scope.loading = false;
            },function(){
                $scope.viewState = $scope.states.NOT_FOUND;
            });
        }, true);
    } else {
        $scope.etfWatchlistData =  [];
        $scope.showExportToExcel = $scope.states.LOADING;
        $scope.viewState = $scope.states.LOADED;
        $scope.loading = false;
    };



});