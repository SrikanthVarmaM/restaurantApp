'use strict';

msaiqApp.controller('FocusOfTheMonthCtrl', function ($scope, $log, $routeParams) {
    $scope.articleId = $routeParams.articleId;
});