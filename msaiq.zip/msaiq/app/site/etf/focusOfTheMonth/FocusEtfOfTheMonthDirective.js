'use strict';

msaiqApp.directive('msaFocusEtfOfMonth', function () {
    return{
        restrict: 'A',
        transclude: true,
        templateUrl: 'site/etf/focusOfTheMonth/FocusEtfOfTheMonthTemplate.html',
        replace: true,
        scope: {
            articleid:'@'
        },
        controller: function ($scope, $log, articleResourceFactory, QuickViewService, ArticleMessaging) {
            $scope.showWatchlist = false;
            $scope.articleId=$scope.articleid;
            $scope.selectedSppwids = [];
            $scope.loadingState = true;

            $scope.QuickViewService = QuickViewService;  // to be use in the html

            $scope.focusOfTheMonthResource = articleResourceFactory.articleIdDataResource.get({articleCode: 'FEOM', articleId: $scope.articleId, limit: 1, start: 0});

            $scope.focusOfTheMonthResource.$promise.then(function () {
                $log.debug('Data received FocusOfTheMonthCtrl: ' + $scope.focusOfTheMonthResource.securityName);
                $scope.showWatchlist = true;
                $scope.loadingState = false;
                var relatedParam = {
                    overallInd: ($scope.focusOfTheMonthResource.overallInd)?'Overweight':$scope.focusOfTheMonthResource.overallInd, etfType: $scope.focusOfTheMonthResource.etfType, holdingsRegion:$scope.focusOfTheMonthResource.holdingsRegion
                };
                $scope.selectedSppwids.push($scope.focusOfTheMonthResource.sppwId);

                var message = {sppwId: $scope.focusOfTheMonthResource.sppwId, ticker: $scope.focusOfTheMonthResource.symbol, articleid: $scope.focusOfTheMonthResource.articleId,
                    relatedParam: relatedParam};

                ArticleMessaging.broadcastEtfArticleLoaded($scope, message);

            });

            $scope.goTo = function (url, windowName) {
                window.open(url, windowName, 'resizable=yes');
            };
        }
    }
});