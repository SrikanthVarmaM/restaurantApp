'use strict';

msaiqApp.controller('PreviousFocusOfTheMonthCtrl', function ($scope, $log, articleResourceFactory) {
    $log.info('Entered PreviousFocusOfTheMonthCtrl');
    $scope.previousFocusOfTheMonthResource = articleResourceFactory.articleDataResource.get({articleCode: 'FEOMLIST', start: 1, limit: 6});

    $scope.previousFocusOfTheMonthResource.$promise.then(function () {
        $log.info('Data received FocusOfTheMonthCtrl length: ' + $scope.previousFocusOfTheMonthResource.etfList.length);
    });

    /*refactor-someday: justin. we do these funtions alot..we would put this on root scope..or think of another way.  idk*/
    $scope.goTo = function (url, windowName) {
        window.open(url, windowName, 'resizable=yes');
    };

});