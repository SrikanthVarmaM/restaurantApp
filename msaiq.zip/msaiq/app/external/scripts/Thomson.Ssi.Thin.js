// Copyright (c)2012 Thomson Financial.  All rights reserved.

Thomson.Ssi.DataListener = function () {
}
function Thomson$Ssi$DataListener$onResponse(id, data) {
}
function Thomson$Ssi$DataListener$onUpdate(id, data) {
}
function Thomson$Ssi$DataListener$onError(id, data) {
}
Thomson.Ssi.DataListener.prototype = {onResponse: Thomson$Ssi$DataListener$onResponse, onUpdate: Thomson$Ssi$DataListener$onUpdate, onError: Thomson$Ssi$DataListener$onError}
Thomson.Ssi.DataListener.registerClass('Thomson.Ssi.DataListener');
Thomson.Ssi.DataServices = function () {
    this._subscriptionsIds = [];
    this._ssi = null;
}
function Thomson$Ssi$DataServices$subscribe(source, topics, fields, options, listener) {
    var e = Function._validateParams(arguments, [
        {name: "source", type: String, mayBeNull: false, optional: false},
        {name: "topics", type: Array, mayBeNull: true, optional: false},
        {name: "fields", type: Array, mayBeNull: false, optional: false},
        {name: "options", type: Object, mayBeNull: true, optional: false},
        {name: "listener", type: Object, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    var requests = new Array();
    if (topics == null) {
        var req = new Thomson.Ssi.DataRequest();
        req.set_source(source);
        req.set_fields(fields);
        req.set_listener(listener);
        req.set_options(options);
        requests.push(req);
    }
    else {
        for (var i = 0; i < topics.length; i++) {
            var req = new Thomson.Ssi.DataRequest();
            req.set_source(source);
            req.set_topic(topics[i]);
            req.set_fields(fields);
            req.set_listener(listener);
            req.set_options(options);
            requests.push(req);
        }
    }
    return this.multiSubscribe(requests);
}
function Thomson$Ssi$DataServices$unsubscribe(subscriptions) {
    var e = Function._validateParams(arguments, [
        {name: "subscriptions", type: Array, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    if (subscriptions.length > 0) {
        this._getImplementation().subscriptionManager.unsubscribe(subscriptions);
        for (var i = 0; i < subscriptions.length; i++) {
            Array.remove(this._subscriptionsIds, subscriptions[i]);
        }
    }
}
function Thomson$Ssi$DataServices$multiSubscribe(requests) {
    var e = Function._validateParams(arguments, [
        {name: "requests", type: Array, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    if (requests.length == 0) {
        return[];
    }
    var subscriptionIds = this._getImplementation().subscriptionManager.subscribe(requests);
    for (var i = 0; i < subscriptionIds.length; i++) {
        this._subscriptionsIds.push(subscriptionIds[i]);
    }
    return subscriptionIds;
}
function Thomson$Ssi$DataServices$unsubscribeAll() {
    this._ensureNotSubscribed();
}
function Thomson$Ssi$DataServices$_getImplementation() {
    if (!this._ssi) {
        var topFrame = this._getTopWindow(window);
        this._ssi = topFrame.ssiImplementation;
    }
    return this._ssi;
}
function Thomson$Ssi$DataServices$_ensureNotSubscribed() {
    if (this._subscriptionsIds && this._subscriptionsIds.length > 0) {
        this._getImplementation().subscriptionManager.unsubscribe(this._subscriptionsIds);
        this._subscriptionsIds = [];
    }
}
function Thomson$Ssi$DataServices$_getTopWindow(win) {
    try {
        var topFrame = window.top.frames["t1HiddenFrame"];
        if (topFrame != null)
            return topFrame;
    } catch (e) {
    }
    if (win.parent == null || win == win.parent) {
        return win;
    }
    else {
        var openerHref = "";
        try {
            openerHref = top.opener.top.location.href;
        } catch (e) {
            openerHref = "";
        }
        if (top.opener && openerHref.toLowerCase().indexOf(document.domain + '/workspace/main.aspx') != -1) {
            return this._getTopWindow(top.opener);
        }
        else {
            return this._getTopWindow(win.parent);
        }
    }
}
function Thomson$Ssi$DataServices$dispose() {
    this._ensureNotSubscribed();
    this._ssi = null;
}
Thomson.Ssi.DataServices.prototype = {subscribe: Thomson$Ssi$DataServices$subscribe, unsubscribe: Thomson$Ssi$DataServices$unsubscribe, multiSubscribe: Thomson$Ssi$DataServices$multiSubscribe, unsubscribeAll: Thomson$Ssi$DataServices$unsubscribeAll, dispose: Thomson$Ssi$DataServices$dispose, _getImplementation: Thomson$Ssi$DataServices$_getImplementation, _getTopWindow: Thomson$Ssi$DataServices$_getTopWindow, _ensureNotSubscribed: Thomson$Ssi$DataServices$_ensureNotSubscribed}
Thomson.Ssi.DataServices.registerClass('Thomson.Ssi.DataServices');
Thomson.Ssi.DataRequest = function () {
    this._fields = new Array();
    this._listener = null;
    this._options = null;
    this._source = null;
    this._topic = null;
    this._token = null;
    this._requestBuilder = null;
}
function Thomson$Ssi$DataRequest$set_fields(fields) {
    this._fields = fields;
}
function Thomson$Ssi$DataRequest$set_listener(listener) {
    this._listener = listener;
}
function Thomson$Ssi$DataRequest$get_listener(listener) {
    return this._listener;
}
function Thomson$Ssi$DataRequest$set_options(options) {
    this._options = options;
}
function Thomson$Ssi$DataRequest$set_source(source) {
    this._source = source;
}
function Thomson$Ssi$DataRequest$set_topic(topic) {
    this._topic = topic;
}
function Thomson$Ssi$DataRequest$set_token(token) {
    this._token = token;
}
function Thomson$Ssi$DataRequest$get_token(token) {
    return this._token;
}
Thomson.Ssi.DataRequest.prototype = {set_fields: Thomson$Ssi$DataRequest$set_fields, set_listener: Thomson$Ssi$DataRequest$set_listener, get_listener: Thomson$Ssi$DataRequest$get_listener, set_options: Thomson$Ssi$DataRequest$set_options, set_source: Thomson$Ssi$DataRequest$set_source, set_topic: Thomson$Ssi$DataRequest$set_topic, set_token: Thomson$Ssi$DataRequest$set_token, get_token: Thomson$Ssi$DataRequest$get_token}
Thomson.Ssi.DataRequest.registerClass('Thomson.Ssi.DataRequest');
Thomson.Ssi.ElementsManager = function () {
    Thomson.Ssi.ElementsManager.initializeBase(this);
    this._streamingManager = this._getImplementation().GetStreamingManagerFromFrame(window);
    this._streamingManager.RemoveAllStreamingElements();
}
function Thomson$Ssi$ElementsManager$addStreamingElements(element) {
    var e = Function._validateParams(arguments, [
        {name: "element", type: Object, domElement: true, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.AddStreamingElement(element);
}
function Thomson$Ssi$ElementsManager$scanForStreamingElements(element) {
    this._streamingManager.RemoveAllStreamingElements();
    this._streamingManager.ScanForStreamingElements(element);
}
function Thomson$Ssi$ElementsManager$setDefaultUpColor(color) {
    var e = Function._validateParams(arguments, [
        {name: "color", type: String, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.SetDefaultUpColor(color);
}
function Thomson$Ssi$ElementsManager$setDefaultDownColor(color) {
    var e = Function._validateParams(arguments, [
        {name: "color", type: String, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.SetDefaultDownColor(color);
}
function Thomson$Ssi$ElementsManager$addColorChangeField(fieldName) {
    var e = Function._validateParams(arguments, [
        {name: "fieldName", type: String, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.AddColorChangeField(fieldName);
}
function Thomson$Ssi$ElementsManager$removeColorChangeField(fieldName) {
    var e = Function._validateParams(arguments, [
        {name: "fieldName", type: String, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.RemoveColorChangeField(fieldName);
}
function Thomson$Ssi$ElementsManager$setBlinkColors(colorForeground, colorBackground) {
    var e = Function._validateParams(arguments, [
        {name: "colorForeground", type: String, mayBeNull: false, optional: false},
        {name: "colorBackground", type: String, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.SetBlinkColors(colorBackground, colorForeground);
}
function Thomson$Ssi$ElementsManager$setCustomVariantColors(colorBackground, colorForeground) {
    var e = Function._validateParams(arguments, [
        {name: "colorForeground", type: String, mayBeNull: false, optional: false},
        {name: "colorBackground", type: String, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._streamingManager.SetCustomVariantColors(colorBackground, colorForeground);
}
function Thomson$Ssi$ElementsManager$subscribe() {
    this.unsubscribe()
    this._streamingManager.Subscribe();
}
function Thomson$Ssi$ElementsManager$unsubscribe() {
    this._streamingManager.unsubscribe();
}
function Thomson$Ssi$ElementsManager$dispose() {
    this.unsubscribe();
}
Thomson.Ssi.ElementsManager.prototype = {addStreamingElements: Thomson$Ssi$ElementsManager$addStreamingElements, scanForStreamingElements: Thomson$Ssi$ElementsManager$scanForStreamingElements, setDefaultUpColor: Thomson$Ssi$ElementsManager$setDefaultUpColor, setDefaultDownColor: Thomson$Ssi$ElementsManager$setDefaultDownColor, addColorChangeField: Thomson$Ssi$ElementsManager$addColorChangeField, removeColorChangeField: Thomson$Ssi$ElementsManager$removeColorChangeField, setBlinkColors: Thomson$Ssi$ElementsManager$setBlinkColors, setCustomVariantColors: Thomson$Ssi$ElementsManager$setCustomVariantColors, subscribe: Thomson$Ssi$ElementsManager$subscribe, unsubscribe: Thomson$Ssi$ElementsManager$unsubscribe, dispose: Thomson$Ssi$ElementsManager$dispose}
Thomson.Ssi.ElementsManager.registerClass('Thomson.Ssi.ElementsManager', Thomson.Ssi.DataServices, Thomson.Ssi.IElementsManager, Sys.IDisposable);
Thomson.Ssi.ConnectionManager = function () {
    Thomson.Ssi.ConnectionManager.initializeBase(this);
    this._observersArray = [];
}
function Thomson$Ssi$ConnectionManager$initializeConnection() {
    try {
        this._getImplementation().connectionManager.ensureConnected();
    }
    catch (e) {
    }
}
function Thomson$Ssi$ConnectionManager$registerObserver(observer) {
    try {
        this._getImplementation().connectionManager.registerConnectionObserver(observer);
        this._observersArray.push(observer);
    }
    catch (e) {
    }
}
function Thomson$Ssi$ConnectionManager$unregisterObserver(observer) {
    try {
        this._getImplementation().connectionManager.unregisterConnectionObserver(observer);
        Array.remove(this._observersArray, observer);
    }
    catch (e) {
    }
}
function Thomson$Ssi$ConnectionManager$dispose() {
    if (this._observersArray) {
        for (var i = 0; i < this._observersArray.length; i++) {
            this._getImplementation().connectionManager.unregisterConnectionObserver(this._observersArray[i]);
        }
    }
    this._observersArray = [];
    Thomson.Ssi.ConnectionManager.callBaseMethod(this, 'dispose');
}
Thomson.Ssi.ConnectionManager.prototype = {initializeConnection: Thomson$Ssi$ConnectionManager$initializeConnection, registerObserver: Thomson$Ssi$ConnectionManager$registerObserver, unregisterObserver: Thomson$Ssi$ConnectionManager$unregisterObserver, dispose: Thomson$Ssi$ConnectionManager$dispose}
Thomson.Ssi.ConnectionManager.registerClass('Thomson.Ssi.ConnectionManager', Thomson.Ssi.DataServices, Sys.IDisposable);
Thomson.Ssi._Alert = function (rawAlert) {
    this._msxml = null;
    this._message = null;
    this._symbol = null;
    this._raw = rawAlert;
}
function Thomson$Ssi$Alert$get_xml() {
    return this._raw[2];
}
function Thomson$Ssi$Alert$_convertMessageId() {
    var guid = "";
    guid = this._dec2hex(parseInt(this._raw[3])) + "-";
    var temp = this._dec2hex(parseInt(this._raw[4]));
    guid += temp.substr(0, 4) + "-" + temp.substr(4, 4) + "-";
    temp = this._dec2hex(parseInt(this._raw[5]));
    guid += temp.substr(0, 4) + "-" + temp.substr(4, 4)
    guid += this._dec2hex(parseInt(this._raw[6]));
    return guid;
}
function Thomson$Ssi$Alert$_dec2hex(n) {
    var padding = 8;
    if (n < 0) {
        n = 0x100000000 + n;
    }
    var hex = n.toString(16)
    while (hex.length < padding) {
        hex = "0" + hex;
    }
    return hex;
}
function Thomson$Ssi$Alert$get_messageId() {
    return this._convertMessageId();
}
function Thomson$Ssi$Alert$get_timestamp() {
    return this._raw[0];
}
function Thomson$Ssi$Alert$get_expireTime() {
    return this._raw[1];
}
function Thomson$Ssi$Alert$get_type() {
    return this.getAttribute("CN");
}
function Thomson$Ssi$Alert$get_group() {
    return this.getAttribute("Name");
}
function Thomson$Ssi$Alert$get_url() {
    return this.getAttribute("URL");
}
function Thomson$Ssi$Alert$get_text() {
    var text = this._getValue("/PD");
    text = text.replace('<Data>', '');
    text = text.replace('</Data>', '');
    return text;
}
function Thomson$Ssi$Alert$get_value() {
    return this.getAttribute("AN");
}
function Thomson$Ssi$Alert$get_account() {
    return this.getAttribute("AC");
}
function Thomson$Ssi$Alert$get_profileId() {
    return this.getAttribute("ProfileId");
}
function Thomson$Ssi$Alert$get_windowBitMask() {
    return this.getAttribute("WindowBitMask");
}
function Thomson$Ssi$Alert$_getMSXML() {
    if (this._msxml) {
        return this._msxml;
    }
    else {
        var progIDs = ['Msxml2.DOMDocument.6.0', 'Msxml2.DOMDocument.3.0'];
        for (var i = 0; i < progIDs.length; i++) {
            try {
                var xmlDOM = new ActiveXObject(progIDs[i]);
                xmlDOM.async = false;
                xmlDOM.loadXML(this._raw[2]);
                return xmlDOM;
            }
            catch (ex) {
            }
        }
        return null;
    }
}
function Thomson$Ssi$Alert$getAttribute(attributeName) {
    return this._getValue("/PD/@" + attributeName);
}
function Thomson$Ssi$Alert$_getValue(xpath) {
    this._msxml = this._getMSXML();
    if (this._msxml) {
        var node = this._msxml.selectSingleNode(xpath);
        if (node) {
            return node.text;
        }
    }
    return"";
}
Thomson.Ssi._Alert.prototype = {_convertMessageId: Thomson$Ssi$Alert$_convertMessageId, _dec2hex: Thomson$Ssi$Alert$_dec2hex, _getMSXML: Thomson$Ssi$Alert$_getMSXML, _getValue: Thomson$Ssi$Alert$_getValue, get_xml: Thomson$Ssi$Alert$get_xml, get_messageId: Thomson$Ssi$Alert$get_messageId, get_timestamp: Thomson$Ssi$Alert$get_timestamp, get_expireTime: Thomson$Ssi$Alert$get_expireTime, get_type: Thomson$Ssi$Alert$get_type, get_group: Thomson$Ssi$Alert$get_group, get_url: Thomson$Ssi$Alert$get_url, get_text: Thomson$Ssi$Alert$get_text, get_value: Thomson$Ssi$Alert$get_value, get_account: Thomson$Ssi$Alert$get_account, get_profileId: Thomson$Ssi$Alert$get_profileId, get_windowBitMask: Thomson$Ssi$Alert$get_windowBitMask, getAttribute: Thomson$Ssi$Alert$getAttribute}
Thomson.Ssi._Alert.registerClass('Thomson.Ssi._Alert', null, Thomson.Ssi.IAlert);
Thomson.Ssi.Alerts = function () {
    Thomson.Ssi.Alerts.initializeBase(this);
    this._callback = null;
    this._fields = ["timestamp", "expireTime", "text", "msgId1", "msgId2", "msgId3", "msgId4"];
    this._source = this._getImplementation().ALERT_SOURCE;
}
function Thomson$Ssi$Alerts$subscribe(callback) {
    var e = Function._validateParams(arguments, [
        {name: "callback", type: Function, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._ensureNotSubscribed();
    this._callback = callback;
    return Thomson.Ssi.Alerts.callBaseMethod(this, 'subscribe', [this._source, null, this._fields, null, this]);
}
function Thomson$Ssi$Alerts$unsubscribe() {
    this._callback = null;
    this._ensureNotSubscribed();
}
function Thomson$Ssi$Alerts$_onAlert(id, rawAlert) {
    if (this._callback != null && rawAlert != null && rawAlert != undefined) {
        var alert = new Thomson.Ssi._Alert(rawAlert);
        this._callback(alert);
    }
}
function Thomson$Ssi$Alerts$onResponse(id, data) {
}
function Thomson$Ssi$Alerts$onUpdate(id, data) {
    this._onAlert(id, data);
}
function Thomson$Ssi$Alerts$onError(id, data) {
}
function Thomson$Ssi$Alerts$dispose() {
    this._callback = null;
    Thomson.Ssi.Alerts.callBaseMethod(this, 'dispose');
}
Thomson.Ssi.Alerts.prototype = {subscribe: Thomson$Ssi$Alerts$subscribe, unsubscribe: Thomson$Ssi$Alerts$unsubscribe, _onAlert: Thomson$Ssi$Alerts$_onAlert, onResponse: Thomson$Ssi$Alerts$onResponse, onUpdate: Thomson$Ssi$Alerts$onUpdate, onError: Thomson$Ssi$Alerts$onError, dispose: Thomson$Ssi$Alerts$dispose}
Thomson.Ssi.Alerts.registerClass('Thomson.Ssi.Alerts', Thomson.Ssi.DataServices, Thomson.Ssi.IAlerts);
Thomson.Ssi.NewsHeadlines = function () {
    Thomson.Ssi.NewsHeadlines.initializeBase(this);
    this._callback = null;
    this._source = this._getImplementation().NEWS_SOURCE;
    this._fields = ["srcKey", "storyNo", "timestamp", "msgTxt", "urlQuery", "flags1", "srcSymbol"];
}
function Thomson$Ssi$NewsHeadlines$_onHeadline(subscriptionId, rawHeadline) {
    if (this._callback != null && rawHeadline != null && rawHeadline != undefined) {
        var newsHeadline = new Thomson.Ssi._NewsHeadline(rawHeadline);
        this._callback(newsHeadline);
    }
}
function Thomson$Ssi$NewsHeadlines$subscribe(newsSource, filter, pkeys, callback) {
    var e = Function._validateParams(arguments, [
        {name: "newsSource", type: String, mayBeNull: false, optional: false},
        {name: "filter", type: String, mayBeNull: false, optional: false},
        {name: "pkeys", type: String, mayBeNull: true, optional: false},
        {name: "callback", type: Function, mayBeNull: false, optional: false}
    ]);
    if (e)throw e;
    this._ensureNotSubscribed();
    this._callback = callback;
    var options = null;
    if (filter != "") {
        options = {};
        options["filterCriteria"] = filter;
    }
    return Thomson.Ssi.NewsHeadlines.callBaseMethod(this, 'subscribe', [this._source, newsSource.split(","), this._fields, options, this]);
}
function Thomson$Ssi$NewsHeadlines$unsubscribe() {
    this._callback = null;
    this._ensureNotSubscribed();
}
function Thomson$Ssi$NewsHeadlines$onResponse(id, data) {
}
function Thomson$Ssi$NewsHeadlines$onUpdate(id, data) {
    if (this._callback != null) {
        var newsHeadline = new Thomson.Ssi._NewsHeadline(data);
        this._callback(newsHeadline);
    }
}
function Thomson$Ssi$NewsHeadlines$onError(id, data) {
}
function Thomson$Ssi$NewsHeadlines$dispose() {
    this._callback = null;
    Thomson.Ssi.NewsHeadlines.callBaseMethod(this, 'dispose');
}
Thomson.Ssi.NewsHeadlines.prototype = {subscribe: Thomson$Ssi$NewsHeadlines$subscribe, unsubscribe: Thomson$Ssi$NewsHeadlines$unsubscribe, _onHeadline: Thomson$Ssi$NewsHeadlines$_onHeadline, onResponse: Thomson$Ssi$NewsHeadlines$onResponse, onUpdate: Thomson$Ssi$NewsHeadlines$onUpdate, onError: Thomson$Ssi$NewsHeadlines$onError, dispose: Thomson$Ssi$NewsHeadlines$dispose}
Thomson.Ssi.NewsHeadlines.registerClass('Thomson.Ssi.NewsHeadlines', Thomson.Ssi.DataServices);
Thomson.Ssi._NewsHeadline = function (newsHeadlineRaw) {
    this._raw = newsHeadlineRaw;
}
function Thomson$Ssi$_NewsHeadline$get_newsSource() {
    return this._raw[6];
}
function Thomson$Ssi$_NewsHeadline$get_newsSourceKey() {
    return this._raw[0];
}
function Thomson$Ssi$_NewsHeadline$get_storyNumber() {
    return this._raw[1];
}
function Thomson$Ssi$_NewsHeadline$get_timeStamp() {
    return this._raw[2];
}
function Thomson$Ssi$_NewsHeadline$get_text() {
    return this._raw[3];
}
function Thomson$Ssi$_NewsHeadline$get_codes() {
    return"";
}
function Thomson$Ssi$_NewsHeadline$get_url() {
    return this._raw[4];
}
function Thomson$Ssi$_NewsHeadline$get_flags() {
    return this._raw[5];
}
function Thomson$Ssi$_NewsHeadline$get_raw() {
    return this._raw;
}
Thomson.Ssi._NewsHeadline.prototype = {get_newsSource: Thomson$Ssi$_NewsHeadline$get_newsSource, get_newsSourceKey: Thomson$Ssi$_NewsHeadline$get_newsSourceKey, get_storyNumber: Thomson$Ssi$_NewsHeadline$get_storyNumber, get_timeStamp: Thomson$Ssi$_NewsHeadline$get_timeStamp, get_text: Thomson$Ssi$_NewsHeadline$get_text, get_codes: Thomson$Ssi$_NewsHeadline$get_codes, get_url: Thomson$Ssi$_NewsHeadline$get_url, get_flags: Thomson$Ssi$_NewsHeadline$get_flags, get_raw: Thomson$Ssi$_NewsHeadline$get_raw}
Thomson.Ssi._NewsHeadline.registerClass('Thomson.Ssi._NewsHeadline', null, Thomson.Ssi.INewsHeadline);
Thomson.Ssi.DataTableCellIdentifiers = function () {
    this._symbolsMapping = {};
    this._fieldsMapping = {};
    this._subscriptionIdSymbol = {};
    this._fieldIdName = {};
    this._initialized = false;
    this._hack = false;
}
function Thomson$Ssi$DataTableCellIdentifiers$_init(symbols, fields, subscriptionIds, tableId) {
    this._clearMappings();
    for (var i = 0; i < symbols.length; i++) {
        this._symbolsMapping[symbols[i]] = subscriptionIds[i];
        if (this._hack) {
            this._subscriptionIdSymbol[subscriptionIds[i]] = symbols[i];
            for (var j = 0; j < fields.length; j++) {
                this._mappings[symbols[i] + "-" + fields[j]] = this._makeFieldId(tableId, i, j);
            }
        }
    }
    for (var i = 0; i < fields.length; i++) {
        this._fieldsMapping[fields[i]] = i;
        if (this._hack) {
            this._fieldIdName[i] = fields[i];
        }
    }
    this._initialized = true;
}
function Thomson$Ssi$DataTableCellIdentifiers$_clearMappings() {
    this._symbolsMapping = {};
    this._fieldsMapping = {};
    this._initialized = false;
}
function Thomson$Ssi$DataTableCellIdentifiers$getCellId(symbol, field) {
    if (this._hack) {
        return this._mappings[symbol + "-" + field];
    }
    else {
        if (undefined != this._symbolsMapping[symbol] && undefined != this._fieldsMapping[field]) {
            return this._generateCellId(this._symbolsMapping[symbol], this._fieldsMapping[field]);
        }
        return null;
    }
}
function Thomson$Ssi$DataTableCellIdentifiers$_generateCellId(symbolId, fieldId) {
    if (this._hack) {
        return this.getCellId(this._subscriptionIdSymbol[symbolId], this._fieldIdName[fieldId]);
    }
    else {
        return'dt' + symbolId + "-" + fieldId;
    }
}
function Thomson$Ssi$DataTableCellIdentifiers$_makePaddedNumberString(n) {
    if (n > 15) {
        if (n > 255) {
            if (n > 4095) {
                return n.toString(16);
            }
            else {
                return"0" + n.toString(16);
            }
        }
        else {
            return"00" + n.toString(16);
        }
    }
    else {
        return"000" + n.toString(16);
    }
}
function Thomson$Ssi$DataTableCellIdentifiers$_makeFieldId(idTable, idRow, idColumn) {
    return idTable.toString(16) + this._makePaddedNumberString(idRow) + this._makePaddedNumberString(idColumn);
}
Thomson.Ssi.DataTableCellIdentifiers.prototype = {_init: Thomson$Ssi$DataTableCellIdentifiers$_init, _clearMappings: Thomson$Ssi$DataTableCellIdentifiers$_clearMappings, _generateCellId: Thomson$Ssi$DataTableCellIdentifiers$_generateCellId, getCellId: Thomson$Ssi$DataTableCellIdentifiers$getCellId, _makePaddedNumberString: Thomson$Ssi$DataTableCellIdentifiers$_makePaddedNumberString, _makeFieldId: Thomson$Ssi$DataTableCellIdentifiers$_makeFieldId}
Thomson.Ssi.DataTableCellIdentifiers.registerClass('Thomson.Ssi.DataTableCellIdentifiers');
Thomson.Ssi.DataTable = function () {
    Thomson.Ssi.DataTable.initializeBase(this);
    this._callback = null;
    this._dataTableCellIdentifier = new Thomson.Ssi.DataTableCellIdentifiers();
    this._tempSymbols = null;
    this._source = this._getImplementation().QUOTES_SOURCE;
    ;
}
function Thomson$Ssi$DataTable$subscribe(tableType, symbols, fields, options, callback, streamingId) {
    var e = Function._validateParams(arguments, [
        {name: "tableType", type: Number, mayBeNull: false, optional: false},
        {name: "symbols", type: Array, mayBeNull: false, optional: false},
        {name: "fields", type: Array, mayBeNull: false, optional: false},
        {name: "options", type: Array, mayBeNull: false, optional: false},
        {name: "callback", type: Function, mayBeNull: false, optional: false},
        {name: "streamingId", type: String, mayBeNull: true, optional: true}
    ]);
    if (e)throw e;
    try {
        options = null;
        symbols = this._removeDuplicateSymbols(symbols);
        this._ensureNotSubscribed();
        this._callback = callback;
        this._subscriptionsIds = Thomson.Ssi.DataTable.callBaseMethod(this, 'subscribe', [this._source, symbols, fields, options, this]);
        this._dataTableCellIdentifier._init(symbols, fields, this._subscriptionsIds, streamingId);
        return this._dataTableCellIdentifier;
    }
    catch (e) {
        return null;
    }
}
function Thomson$Ssi$DataTable$unsubscribe() {
    this._ensureNotSubscribed();
}
function Thomson$Ssi$DataTable$_removeDuplicateSymbols(symbols) {
    this._tempSymbols = new Array();
    for (var i = 0; i < symbols.length; i++) {
        if (!Array.contains(this._tempSymbols, symbols[i])) {
            this._tempSymbols.push(symbols[i]);
        }
    }
    return this._tempSymbols;
}
function Thomson$Ssi$DataTable$_ensureNotSubscribed() {
    Thomson.Ssi.DataTable.callBaseMethod(this, '_ensureNotSubscribed');
    this._dataTableCellIdentifier._clearMappings();
    this._tempSymbols = null;
}
function Thomson$Ssi$DataTable$dispose() {
    this._callback = null;
    Thomson.Ssi.DataTable.callBaseMethod(this, 'dispose');
}
function Thomson$Ssi$DataTable$onResponse(id, data) {
    this._onData(id, data);
}
function Thomson$Ssi$DataTable$onUpdate(id, data) {
    this._onData(id, data);
}
function Thomson$Ssi$DataTable$_onData(id, data) {
    if (data == null || data == undefined)return;
    if (this._dataTableCellIdentifier._initialized) {
        for (var field in data) {
            var cellId = this._dataTableCellIdentifier._generateCellId(id, field);
            this._callback(cellId, data[field], 0);
        }
    }
}
function Thomson$Ssi$DataTable$onError(id, data) {
}
Thomson.Ssi.DataTable.prototype = {subscribe: Thomson$Ssi$DataTable$subscribe, unsubscribe: Thomson$Ssi$DataTable$unsubscribe, _removeDuplicateSymbols: Thomson$Ssi$DataTable$_removeDuplicateSymbols, _ensureNotSubscribed: Thomson$Ssi$DataTable$_ensureNotSubscribed, onResponse: Thomson$Ssi$DataTable$onResponse, onUpdate: Thomson$Ssi$DataTable$onUpdate, onError: Thomson$Ssi$DataTable$onError, _onData: Thomson$Ssi$DataTable$_onData, dispose: Thomson$Ssi$DataTable$dispose}
Thomson.Ssi.DataTable.registerClass('Thomson.Ssi.DataTable', Thomson.Ssi.DataServices, Sys.IDisposable);
Thomson.Ssi.ServiceFactory = function () {
}
window._ssiServiceFactory = Thomson.Ssi.ServiceFactory;
Thomson.Ssi._activatedServices = [];
Thomson.Ssi.ServiceFactory.getService = function (serviceName) {
    if (serviceName == "IElementsManager") {
        if (!Thomson.Ssi._streamingElementManagerObj) {
            Thomson.Ssi._streamingElementManagerObj = new Thomson.Ssi.ElementsManager();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._streamingElementManagerObj);
        }
        return Thomson.Ssi._streamingElementManagerObj;
    }
    else if (serviceName == "INewsHeadlines") {
        if (!Thomson.Ssi._newsHeadlinesObj) {
            Thomson.Ssi._newsHeadlinesObj = new Thomson.Ssi.NewsHeadlines();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._newsHeadlinesObj);
        }
        return Thomson.Ssi._newsHeadlinesObj;
    }
    else if (serviceName == "IAlerts") {
        if (!Thomson.Ssi._alertsObj) {
            Thomson.Ssi._alertsObj = new Thomson.Ssi.Alerts();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._alertsObj);
        }
        return Thomson.Ssi._alertsObj;
    }
    else if (serviceName == "IAlertsOld") {
        if (!Thomson.Ssi._alertsOldObj) {
            Thomson.Ssi._alertsOldObj = new Thomson.Ssi.AlertsOld();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._alertsOldObj);
        }
        return Thomson.Ssi._alertsOldObj;
    }
    else if (serviceName == "IConnectionManager") {
        if (!Thomson.Ssi._streamingConnectionManagerObj) {
            Thomson.Ssi._streamingConnectionManagerObj = new Thomson.Ssi.ConnectionManager();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._streamingConnectionManagerObj);
        }
        return Thomson.Ssi._streamingConnectionManagerObj;
    }
    else if (serviceName == "IDataTable") {
        if (!Thomson.Ssi._streamingDataTableObj) {
            Thomson.Ssi._streamingDataTableObj = new Thomson.Ssi.DataTable();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._streamingDataTableObj);
        }
        return Thomson.Ssi._streamingDataTableObj;
    }
    else if (serviceName == "IDataServices") {
        if (!Thomson.Ssi._dataServicesObj) {
            Thomson.Ssi._dataServicesObj = new Thomson.Ssi.DataServices();
            Thomson.Ssi._activatedServices.push(Thomson.Ssi._dataServicesObj);
        }
        return Thomson.Ssi._dataServicesObj;
    }
    else {
        return null;
    }
}
Thomson.Ssi.ServiceFactory.disposeServices = function () {
    var svcs = Thomson.Ssi._activatedServices;
    for (var i = 0; i < svcs.length; i++) {
        var svc = svcs[i];
        if (svc.dispose) {
            try {
                svc.dispose();
            }
            catch (e) {
            }
        }
    }
}
Thomson.Ssi.ServiceFactory.registerClass('Thomson.Ssi.ServiceFactory');
Thomson.Ssi.DisconnectReasonEnum = function () {
}
Thomson.Ssi.DisconnectReasonEnum.CONNECTION_RECYCLE = 1;
Thomson.Ssi.DisconnectReasonEnum.CONNECTION_BROKEN = 2;
Thomson.Ssi.DisconnectReasonEnum.CONNECTION_LINGERTIMEOUT = 3;
Thomson.Ssi.DisconnectReasonEnum.SERVER_ERROR = 4;
Thomson.Ssi.DisconnectReasonEnum.MLP_LOGOFF = 5;
Thomson.Ssi.DisconnectReasonEnum.registerClass("Thomson.Ssi.DisconnectReasonEnum");