// Copyright (c)2012 Thomson Financial.  All rights reserved.

Tfsi.Context._CallbackManager = function (we) {
    this._we = we;
    this._ctxCallback = null;
    this._prefCallback = null;
    this._registered = false;
    this._callbackDelegate = Function.createDelegate(this, this._ContextChangedCallback);
}
Tfsi.Context._CallbackManager.prototype = {_registerCtxCallback: function (needCallback) {
    this._needCtxCallback = needCallback;
    this._handleRegistration();
}, _registerPrefCallback: function (needCallback) {
    this._needPrefCallback = needCallback;
    this._handleRegistration();
}, _handleRegistration: function () {
    if ((this._needCtxCallback || this._needPrefCallback) && !this._registered) {
        this._we.context.register(this._callbackDelegate);
        this._registered = true;
    }
    else if (!this._needCtxCallback && !this._needPrefCallback && this._registered) {
        this._we.context.unregister();
        this._registered = false;
    }
}, _handleContext: function (weContext) {
    for (var key in weContext) {
        if (key != 'Preference' && key != 'WebProperty') {
            return true;
        }
    }
    return false;
}, _handlePreferences: function (weContext) {
    for (var key in weContext) {
        if (key == 'Preference') {
            return true;
        }
    }
    return false;
}, _ContextChangedCallback: function (newContext) {
    var contextSvc;
    if (this._handleContext(newContext)) {
        contextSvc = Tfsi.ServiceFactory.getService("IContext");
    }
    var preferenceSvc;
    if (this._handlePreferences(newContext)) {
        preferenceSvc = Tfsi.ServiceFactory.getService("IPreference");
    }
    var needCtxRefresh = false;
    var needPrefRefresh = false;
    if (preferenceSvc) {
        needPrefRefresh = preferenceSvc._PreferenceChangedCallback(newContext);
    }
    if (contextSvc && !needPrefRefresh) {
        needCtxRefresh = contextSvc._ContextChangedCallback(newContext);
    }
    if (needCtxRefresh || needPrefRefresh) {
        return false;
    }
    return true;
}}
Tfsi.Context._CallbackManager.registerClass('Tfsi.Context._CallbackManager', null);
Tfsi.Context._getCallbackManager = function () {
    if (!Tfsi.Context._CallbackManagerObj) {
        Tfsi.Context._CallbackManagerObj = new Tfsi.Context._CallbackManager(Tfsi._wePriv);
    }
    return Tfsi.Context._CallbackManagerObj;
}
if (!Tfsi._CookieAccess) {
    Tfsi._CookieAccess = function (name) {
        var e = Function._validateParams(arguments, [
            {name: "name", type: String}
        ]);
        if (e)throw e;
        this._name = name;
    }
    Tfsi._CookieAccess.prototype = {get_Value: function () {
        var m = document.cookie.match(new RegExp("(" + this._name + "=[^;]*)(;|$)"));
        return m ? m[1] : null;
    }, get_SubValue: function (key) {
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e)throw e;
        var ck = this.get_Value();
        if (ck) {
            var cookieName = key + "=";
            var p1 = ck.indexOf(cookieName);
            if (p1 > 0) {
                var p2 = ck.indexOf("&", p1);
                if (p2 > p1 + cookieName.length) {
                    return ck.substring(p1 + cookieName.length, p2);
                }
                else {
                    return ck.substring(p1 + cookieName.length);
                }
            }
        }
    }}
    Tfsi._CookieAccess.registerClass('Tfsi._CookieAccess', null);
}
Tfsi.Context._Context = function (we) {
    Tfsi.Context._Context.initializeBase(this);
    this._we = we;
    this._contextChangedHandler = null;
}
Tfsi.Context._Context.prototype = {setContexts: function (contextDict, updateOnly) {
    Tfsi.Context._Context.callBaseMethod(this, 'setContexts', [contextDict, updateOnly]);
    var contextXml = Tfsi.Context._dictionaryToString(contextDict, updateOnly);
    if (contextXml && contextXml != "") {
        this._we.contextChange(contextXml);
    }
}, setContext: function (name, value, updateOnly) {
    Tfsi.Context._Context.callBaseMethod(this, 'setContext', [name, value, updateOnly]);
    if (!this.isContextSupported(name)) {
        throw new Error.fsiContextAccessDeniedException();
    }
    var ctxDict = new Tfsi.KeyedItemDictionary();
    ctxDict.add(name, value);
    this.setContexts(ctxDict, updateOnly);
}, getContexts: function () {
    var weContext = this._we.context.contextUpdate;
    if (!weContext) {
        weContext = this._we.context.initialContext;
    }
    return this._convertContextObject(weContext);
}, getContext: function (key) {
    Tfsi.Context._Context.callBaseMethod(this, 'getContext', [key]);
    var weContext = this._we.context.contextUpdate;
    if (!weContext) {
        weContext = this._we.context.initialContext;
    }
    if (weContext[key]) {
        return this._convertContextItem(key, weContext[key]);
    }
}, setContextHandler: function (handler) {
    Tfsi.Context._Context.callBaseMethod(this, 'setContextHandler', [handler]);
    var cbMgr = Tfsi.Context._getCallbackManager();
    this._contextChangedHandler = handler;
    if (handler) {
        cbMgr._registerCtxCallback(true);
    }
    else {
        cbMgr._registerCtxCallback(false);
    }
}, _ContextChangedCallback: function (newContext) {
    var weContext = this._we.lastwecontext;
    if (!weContext) {
        weContext = this._we.context.initialContext;
    }
    this._we.lastwecontext = newContext;
    var updatedContext = this._diffWeContextObject(newContext, weContext);
    var hasKey = false;
    for (var k in updatedContext) {
        hasKey = true;
    }
    var ctxtHandler = this._contextChangedHandler;
    if (ctxtHandler == null) {
        return true;
    }
    var changedcontext = new Object();
    var commandargs = new String();
    var subfunction = new String();
    for (var value in updatedContext) {
        if (value != "CommandArgs") {
            changedcontext[value] = updatedContext[value];
        }
        else {
            var argsParts = updatedContext[value][0].value.split('#$');
            if (argsParts[0]) {
                if ((argsParts.length > 2) && (argsParts[0] == "SelectedSubFunction")) {
                    subfunction = argsParts[1];
                }
                else {
                    commandargs = decodeURIComponent(argsParts[0]);
                }
            }
        }
    }
    var ctxArray = this._convertContextObject(changedcontext);
    var args = new Tfsi.Context.ContextChangedEventArgs(ctxArray, subfunction, commandargs);
    if (!ctxtHandler(this, args)) {
        return false;
    }
    return true;
}, isContextSupported: function (key) {
    Tfsi.Context._Context.callBaseMethod(this, 'isContextSupported', [key]);
    if (key == 'WebProperty' || key == 'Preference') {
        return false;
    }
    var weContext = this._we.context.contextUpdate;
    if (!weContext) {
        weContext = this._we.context.initialContext;
    }
    var isArray = (typeof weContext == 'array');
    for (var key1 in weContext) {
        if (isArray && typeof Array.prototype[key1] != 'undefined') {
            continue;
        }
        if (key1 == key) {
            return true;
        }
    }
    return true;
}, transform: function (ctxValue, ctxInFormat, ctxOutFormat) {
}, _convertContextItem: function (key, weContextItem) {
    var e = Function._validateParams(arguments, [
        {name: "key", type: String},
        {name: "weContextItem"}
    ]);
    if (e)throw e;
    var contextItem;
    if (weContextItem[0] && !weContextItem[1] && !weContextItem[0].attribute) {
        var value = weContextItem[0].value;
        if (typeof value == "string") {
            contextItem = new Tfsi.Context.ContextItem(key, value);
        }
        return contextItem;
    }
    var contextValue = new Tfsi.Context.ContextValue(key);
    for (var i in weContextItem) {
        var attrs = weContextItem[i].attribute;
        var contextAttributes;
        if (attrs) {
            contextAttributes = new Tfsi.StringDictionary();
            for (var name in attrs) {
                contextAttributes.add(name, attrs[name]);
            }
        }
        contextValue.set_Value(contextAttributes, weContextItem[i].value);
    }
    return new Tfsi.Context.ContextItem(key, contextValue);
}, _convertContextObject: function (weContext) {
    var isArray = (typeof weContext == 'array');
    var context = new Tfsi.Context.ContextDictionary();
    for (var key in weContext) {
        if (key == 'WebProperty' || key == 'Preference') {
            continue;
        }
        if (isArray && typeof Array.prototype[key] != 'undefined') {
            continue;
        }
        var contextItem = this._convertContextItem(key, weContext[key]);
        if (contextItem) {
            context._add(key, contextItem);
        }
    }
    return context;
}, _diffWeContextObject: function (weContext1, weContext2) {
    var isArray = (typeof weContext1 == 'array');
    var newCtx = new Object();
    for (var key in weContext1) {
        if (key == 'WebProperty' || key == 'Preference') {
            continue;
        }
        if (isArray && typeof Array.prototype[key] != 'undefined') {
            continue;
        }
        if (!this._isWeContextItemEqual(weContext1[key], weContext2[key])) {
            newCtx[key] = weContext1[key];
        }
    }
    return newCtx;
}, _isWeContextItemEqual: function (weContextItem1, weContextItem2) {
    if (!weContextItem1) {
        return false;
    }
    for (var i in weContextItem1) {
        if (!weContextItem1[i] || !weContextItem2 || !weContextItem2[i]) {
            return false;
        }
        if (weContextItem1[i].value != weContextItem2[i].value) {
            return false;
        }
    }
    return true;
}}
Tfsi.Context._Context.registerClass('Tfsi.Context._Context', Tfsi.Context._ContextBase, Tfsi.Context.IContextBroker);
Tfsi.Context._dictionaryToString = function (contextDict, updateOnly) {
    var e = Function._validateParams(arguments, [
        {name: "contextDict", type: Tfsi.Context.KeyItemedDictionary},
        {name: "updateOnly", type: Boolean, mayBeNull: true, optional: true}
    ]);
    if (e)throw e;
    var sb = new Sys.StringBuilder();
    if (updateOnly) {
        sb.append("<Context we:updateOnly='true'>");
    }
    else {
        sb.append("<Context>");
    }
    var items = contextDict._get_Items();
    for (var name in items) {
        var itemValue = items[name];
        if (typeof itemValue == "string") {
            sb.append('<' + name + '>' + itemValue + '</' + name + '>');
        }
        else if (Tfsi.Context.ContextValue.isInstanceOfType(itemValue)) {
            sb.append(items[name]._serialize());
        }
    }
    sb.append("</Context>");
    return sb.toString();
}
Tfsi.Context._dictionaryToWeContext = function (contextDict) {
    var e = Function._validateParams(arguments, [
        {name: "contextDict", type: Tfsi.Context.KeyItemedDictionary}
    ]);
    if (e)throw e;
    var weContext = new Object();
    var items = contextDict._get_Items();
    for (var name in items) {
        var attrs = new Array();
        var attr = new Object();
        attr.attribute = new Object();
        attr.value = items[name];
        Array.add(attrs, attr);
        weContext[name] = attrs;
    }
    return weContext;
}
Tfsi._commandArgsToString = function (commandArgs, resetThomlet) {
    var e = Function._validateParams(arguments, [
        {name: "commandArgs", type: String},
        {name: "resetThomlet", type: Boolean}
    ]);
    if (e)throw e;
    if (resetThomlet) {
        return'DrillDownResetTrue' + ':CommandArgs=' + encodeURIComponent(commandArgs);
    }
    else {
        return'DrillDownResetFalse' + ':CommandArgs=' + encodeURIComponent(commandArgs);
    }
}
Tfsi.Navigation._Drilldown = function (we) {
    Tfsi.Navigation._Drilldown.initializeBase(this);
    this._we = we;
    this._func = null;
    this._callbackDelegate = Function.createDelegate(this, this._DrilldownChangedCallback);
}
Tfsi.Navigation._Drilldown.prototype = {register: function (drilldownList, handler) {
    Tfsi.Navigation._Drilldown.callBaseMethod(this, 'register', [drilldownList, handler]);
    var ids = [];
    this._we.drillDown.drillDownChangedCallback = this._callbackDelegate;
    var action = function (ddItem) {
        Array.add(ids, ddItem.get_Id());
        this._we.drillDown.displayDrilldowns = ids;
        var defaultTarget = "";
        var readOnly = false;
        var ddTarget = ddItem.get_DefaultTarget();
        if (ddTarget) {
            defaultTarget = ddTarget.get_ThomletId();
            readOnly = ddTarget.get_ReadOnly();
        }
        this._we.drillDown.registerDrillDown(ddItem.get_Id(), ddItem.get_Name(), ddItem.get_Description(), defaultTarget, readOnly);
    }
    Tfsi.Navigation.DrilldownItemList.forEach(drilldownList, action, this);
    this._func = handler;
    this._we.drillDown.ValidateDrilldowns();
}, clear: function () {
    this._we.drillDown.clearDrillDowns();
    this._func = null;
}, invoke: function (id, contextDict, commandArgs, resetTarget, windowFeature) {
    Tfsi.Navigation._Drilldown.callBaseMethod(this, 'invoke', [id, contextDict, commandArgs, resetTarget, windowFeature]);
    var contextXml = "";
    if (contextDict) {
        contextXml = Tfsi.Context._dictionaryToString(contextDict);
    }
    var resetThomlet = false;
    if (resetTarget) {
        resetThomlet = resetTarget;
    }
    var commandString = "";
    if (commandArgs) {
        commandString = Tfsi._commandArgsToString(commandArgs, resetThomlet);
    }
    this._we.drillDown.drillDown(id, "dd", contextXml, "", commandString, windowFeature);
}, openThomletInFrame: function (frame, thomletId, contextDict, commandArgs, sessionPersistent, lockWindow) {
    Tfsi.Navigation._Drilldown.callBaseMethod(this, 'openThomletInFrame', [frame, thomletId, contextDict, commandArgs, sessionPersistent, lockWindow]);
    var context;
    if (contextDict) {
        context = Tfsi.Context._dictionaryToString(contextDict);
    }
    var commandText;
    if (commandArgs) {
        commandText = Tfsi._commandArgsToString(commandArgs, false);
    }
    this._we.openThomletInFrame(frame, thomletId, "", "", context, commandText, sessionPersistent, lockWindow);
}, _DrilldownChangedCallback: function (info) {
    var e = Function._validateParams(arguments, [
        {name: "info", type: Object}
    ]);
    if (e)throw e;
    if (this._func) {
        var args = new Tfsi.Navigation.DrilldownChangedEventArgs(parseInt(info.id), info.tooltip, info.enabled);
        this._func(this, args);
    }
}}
Tfsi.Navigation._Drilldown.registerClass('Tfsi.Navigation._Drilldown', Tfsi.Navigation._DrilldownBase, Tfsi.Navigation.IDrilldown);
Tfsi.Navigation._Navigation = function (we) {
    Tfsi.Navigation._Navigation.initializeBase(this);
    this._we = we;
}
Tfsi.Navigation._Navigation.prototype = {goHome: function () {
    this._we.resetDefinition();
}, navigateTo: function (relativeUrl, ctxDict) {
    var ctxArray = null;
    if (ctxDict) {
        ctxArray = ctxDict.toArray();
    }
    this._we.BrowserNavigationTo(relativeUrl, ctxArray);
}}
Tfsi.Navigation._Navigation.registerClass('Tfsi.Navigation._Navigation', Tfsi.Navigation._NavigationBase, Tfsi.Navigation.INavigation);
Tfsi.Shell.MenuSeparator.prototype._toStringHelper = function (sb) {
    var e = Function._validateParams(arguments, [
        {name: "sb", type: Sys.StringBuilder}
    ]);
    if (e)throw e;
    sb.append('<menuitem id="' + this._id + '"/>');
}
Tfsi.Shell.MenuItem.prototype._toStringHelper = function (sb) {
    var e = Function._validateParams(arguments, [
        {name: "sb", type: Sys.StringBuilder}
    ]);
    if (e)throw e;
    var children = this.get_Children();
    if (!this._parent) {
        sb.append('<custommenu>');
        for (var i = 0; i < children.length; i++) {
            sb.append(children[i]._toStringHelper(sb));
        }
        sb.append('</custommenu>');
        return;
    }
    sb.append('<menuitem id="' + this._id + '" name="' + this._name + '" enabled="' + this._enabled + '" checked="' + this._checked + '"');
    if (children.length == 0) {
        sb.append('/>');
    }
    else {
        sb.append('>');
        for (var i = 0; i < children.length; i++) {
            sb.append(children[i]._toStringHelper(sb));
        }
        sb.append('</menuitem>');
    }
}
Tfsi.Shell._ContextMenu = function (we) {
    Tfsi.Shell._ContextMenu.initializeBase(this);
    this._we = we;
    this._rootMenuItem = null;
    we.setCustomMenuHandler(Function.createDelegate(this, this._HandleCustomMenuClick));
}
Tfsi.Shell._ContextMenu.prototype = {add: function (rootMenuItem) {
    Tfsi.Shell._ContextMenu.callBaseMethod(this, 'add', [rootMenuItem]);
    this._rootMenuItem = rootMenuItem;
    var menuXml = rootMenuItem._toString();
    this._we.loadCustomRightMouseMenu(menuXml);
}, clear: function () {
    Tfsi.Shell._ContextMenu._currentMenuItem = null;
    this._we.clearCustomRightMouseMenu();
}, contextMenu: function (xPos, yPos, srcElement, contextMenuSections) {
    Tfsi.Shell._ContextMenu.callBaseMethod(this, 'contextMenu', [xPos, yPos, srcElement, contextMenuSections]);
    var weObj = this._we;
    var contextXml = '';
    if (this._contextDict) {
        contextXml = Tfsi.Context._dictionaryToWeContext(this._contextDict);
    }
    if (!srcElement) {
        srcElement = document.body;
    }
    xPos = xPos + document.documentElement.scrollLeft;
    yPos = yPos + document.documentElement.scrollTop;
    weObj.contextMenu(weObj, xPos, yPos, srcElement, weObj.name, contextXml, contextMenuSections);
}, setMenuContextItems: function (menuContextItemList) {
    Tfsi.Shell._ContextMenu.callBaseMethod(this, 'setMenuContextItems', [menuContextItemList]);
    this._contextDict = new Tfsi.KeyedItemDictionary();
    var itemFilter = new Array();
    var action = function (menuContextItem) {
        var key = menuContextItem.get_ContextKey();
        var value = menuContextItem.get_ContextValue();
        if (value) {
            this._contextDict.add(key, value);
        }
        if (menuContextItem.get_ShowInMenu()) {
            Array.add(itemFilter, key);
        }
    }
    Tfsi.Shell.MenuContextItemList.forEach(menuContextItemList, action, this);
    this._we.contextArray = itemFilter;
}, _HandleCustomMenuClick: function (menuItemId) {
    if (this._rootMenuItem) {
        var child = this._rootMenuItem.findChild(menuItemId);
        if (child) {
            var func = child.get_Func();
            if (func) {
                func(child, new Sys.EventArgs());
            }
        }
    }
}}
Tfsi.Shell._ContextMenu.registerClass('Tfsi.Shell._ContextMenu', Tfsi.Shell._ContextMenuBase, Tfsi.Shell.IContextMenu);
Tfsi.Navigation.SubFunctionMenuStyle = function () {
};
Tfsi.Navigation.SubFunctionMenuStyle.prototype = {none: 0, addAsRoot: 1, showInNavTree: 2}
Tfsi.Navigation.SubFunctionMenuStyle.registerEnum("Tfsi.Navigation.SubFunctionMenuStyle");
Tfsi.Navigation.SubFunctionItem = function (id, name, contexts, menuStyle) {
    var e = Function._validateParams(arguments, [
        {name: "id", type: String},
        {name: "name", type: String},
        {name: "contexts", type: Tfsi.StringDictionary, mayBeNull: true, optional: true},
        {name: "menuStyle", type: Tfsi.Navigation.SubFunctionMenuStyle, mayBeNull: true, optional: true}
    ]);
    if (e)throw e;
    this._id = id;
    this._name = name;
    this._contexts = contexts;
    this._menuStyle = menuStyle;
}
Tfsi.Navigation.SubFunctionItem.prototype = {get_Id: function () {
    return this._id;
}, get_Name: function () {
    return this._name;
}, get_Contexts: function () {
    return this._contexts;
}, get_MenuStyle: function () {
    return this._menuStyle;
}}
Tfsi.Navigation.SubFunctionItem.registerClass('Tfsi.Navigation.SubFunctionItem', null);
Tfsi.Navigation.SubFunctionItemList = function () {
    this._items = [];
}
Tfsi.Navigation.SubFunctionItemList.prototype = {addItem: function (id, name, contexts, menuStyle) {
    var item = new Tfsi.Navigation.SubFunctionItem(id, name, contexts, menuStyle);
    this.add(item);
    return item;
}, add: function (item) {
    var e = Function._validateParams(arguments, [
        {name: "item", type: Tfsi.Navigation.SubFunctionItem}
    ]);
    if (e)throw e;
    Array.add(this._items, item);
}, remove: function (id) {
    var e = Function._validateParams(arguments, [
        {name: "id", type: String}
    ]);
    if (e)throw e;
    for (var i = 0; i < this._items.length; i++) {
        if (this._items[i].get_Id() == id) {
            Array.removeAt(this._items, i);
            break;
        }
    }
}, clear: function () {
    this._items = [];
}, _get_Items: function () {
    return this._items;
}}
Tfsi.Navigation.SubFunctionItemList.registerClass('Tfsi.Navigation.SubFunctionItemList', null);
Tfsi.Navigation.SubFunctionItemList.forEach = function (subFunctionItemList, method, instance) {
    var e = Function._validateParams(arguments, [
        {name: "subFunctionItemList", type: Tfsi.Navigation.SubFunctionItemList},
        {name: "method", type: Function},
        {name: "instance", mayBeNull: true, optional: true}
    ]);
    if (e)throw e;
    var items = subFunctionItemList._get_Items();
    for (var i = 0; i < items.length; i++) {
        if (method.call(instance, items[i])) {
            break;
        }
    }
}
Tfsi.Navigation.SubFunctionInvokedEventArgs = function (currentValue) {
    var e = Function._validateParams(arguments, [
        {name: "currentValue", type: String}
    ]);
    if (e)throw e;
    Tfsi.Preferences.PreferencesChangedEventArgs.initializeBase(this);
    this._currentValue = currentValue;
}
Tfsi.Navigation.SubFunctionInvokedEventArgs.prototype = {get_CurrentSubFunction: function () {
    return this._currentValue;
}}
Tfsi.Navigation.SubFunctionInvokedEventArgs.registerClass('Tfsi.Navigation.SubFunctionInvokedEventArgs', Sys.EventArgs);
Tfsi.Navigation._SubFunction = function (we, subFunctionService, name) {
    this._we = we;
    this._subFunctionService = subFunctionService;
    this._name = name;
    this._handler = null;
    this._itemList = null;
}
Tfsi.Navigation._SubFunction.prototype = {add: function (subFunctionItemList, handler) {
    var e = Function._validateParams(arguments, [
        {name: "subFunctionItemList", type: Tfsi.Navigation.SubFunctionItemList},
        {name: "handler", type: Function, optional: true}
    ]);
    if (e)throw e;
    this._handler = handler;
    this._clear = false;
    this._itemList = subFunctionItemList;
    var action = function (item) {
        var contexts = item.get_Contexts();
        var id = item.get_Id();
        var name = item.get_Name();
        var menuStyle = item.get_MenuStyle();
        var contextStr = 'SubFunction=' + id;
        if (contexts) {
            var actionContexts = function (key, value) {
                contextStr += ';' + key + '=' + value;
            }
            Tfsi.StringDictionary.forEach(contexts, actionContexts, this);
        }
        if (!menuStyle || menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.none) {
            try {
            }
            catch (e) {
            }
        }
        else if (menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.showInNavTree) {
        }
        this._we.AddSubFunction(id, name, contexts);
    }
    Tfsi.Navigation.SubFunctionItemList.forEach(subFunctionItemList, action, this);
    this._we.SubmitsubFunction();
}, clear: function () {
    this._we.ClearFavoriteMenuItems();
    this._clear = true;
}}
Tfsi.Navigation._SubFunction.registerInterface('Tfsi.Navigation._SubFunction', Tfsi.Navigation.ISubFunction);
function HandleSetSubFunctionsList_TF(subFunctions) {
    var sfService = Tfsi.ServiceFactory.getService("ISubFunction");
    if (sfService._clear) {
        var action = function (item) {
            var contextRequirments = item.get_ContextRequirments();
            var name = item.get_Name();
            var menuStyle = item.get_MenuStyle();
            if (menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.showInNavTree) {
            }
        }
        Tfsi.Navigation.SubFunctionItemList.forEach(sfService._itemList, action, sfService);
        sfService._clear = false;
    }
}
Tfsi.Shell._PropertyBag = function (we) {
    Tfsi.Shell._PropertyBag.initializeBase(this);
    this._we = we;
}
Tfsi.Shell._PropertyBag.prototype = {add: function (key, value) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'add', [key, value]);
    if (this._we.webProperties.get(key)) {
        throw Error.argument(key, "An element with the same key already exists in the PropertyBag.")
    }
    this.set_Item(key, value);
}, set_Item: function (key, value) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'set_Item', [key, value]);
    if (typeof(value) == 'string') {
        this._we.webProperties.set(key, value);
    }
}, set_Items: function (keyedItemDict) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'set_Items', [keyedItemDict]);
}, get_Item: function (key) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'get_Item', [key]);
    var value = this._we.webProperties.get(key);
    if (value && typeof(value) == 'string') {
        return value;
    }
    return null;
}, get_Keys: function () {
    var arr = new Array();
    var properties = this._we.webProperties.internalGetContextForProperty();
    if (!properties) {
        return arr;
    }
    for (var property in properties) {
        if (properties[property].attribute) {
            Array.add(arr, properties[property].attribute.name);
        }
    }
    return arr;
}, containsKey: function (key) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'containsKey', [key]);
    if (this._we.webProperties.get(key)) {
        return true;
    }
    else {
        return false;
    }
}, clear: function () {
    this._we.webProperties.clear();
}, remove: function (key) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'remove', [key]);
    this._we.webProperties.set(key, null);
}, get_Count: function () {
    var length = 0;
    var properties = this._we.webProperties.internalGetContextForProperty();
    if (!properties) {
        return length;
    }
    for (var property in properties) {
        if (properties[property].attribute) {
            length++;
        }
    }
    return length;
}, forEach: function (action) {
    Tfsi.Shell._PropertyBag.callBaseMethod(this, 'forEach', [action]);
    var properties = this._we.webProperties.internalGetContextForProperty();
    for (var property in properties) {
        if (property.name) {
            action(property.name, property.value);
        }
    }
}}
Tfsi.Shell._PropertyBag.registerClass('Tfsi.Shell._PropertyBag', Tfsi.Shell._PropertyBagBase, Tfsi.Shell.IPropertyBag);
Tfsi.Shell._Thomlet = function (we) {
    Tfsi.Shell._Thomlet.initializeBase(this);
    this._we = we;
    this._thomletEventsObj = null;
    this._visible = true;
    this._focused = false;
    this._closing = false;
    this._callbackDelegate = Function.createDelegate(this, this._statusChangeCallback);
}
Tfsi.Shell._Thomlet.prototype = {get_OldDomain: function () {
    return this._we.oldDomain;
}, registerEventObject: function (thomletEventsObj) {
    Tfsi.Shell._Thomlet.callBaseMethod(this, 'registerEventObject', [thomletEventsObj]);
    this._thomletEventsObj = thomletEventsObj;
    if (thomletEventsObj) {
        this._we.registerStatusChangeCallbackFn(this._callbackDelegate);
    }
    else {
        this._we.registerStatusChangeCallbackFn(null);
    }
}, _statusChangeCallback: function (status, statusName) {
    if (statusName == "focus") {
        this._focused = status;
        if (this._thomletEventsObj && this._thomletEventsObj.focusChanged) {
            this._thomletEventsObj.focusChanged(this, new Sys.EventArgs());
        }
    }
    else if (statusName == "visibility") {
        this._visible = status;
        if (this._thomletEventsObj && this._thomletEventsObj.focusChanged) {
            this._thomletEventsObj.visibleChanged(this, new Sys.EventArgs());
        }
    }
}, get_Visible: function () {
    return this._visible;
}, get_Focused: function () {
    return this._focused;
}, get_Listening: function () {
    return!this._we.isWindowLocked();
}, get_Closing: function () {
    return this._closing;
}, get_ThomletId: function () {
    return this._we.thomletId;
}, extendSession: function (extendSessionTime) {
    this._we.resetIdleTimeOutValue(extendSessionTime);
}, close: function () {
    this._we.closeWindow();
}, get_WindowState: function () {
}, set_CollapsedWindowSize: function (height, width) {
    Tfsi.Shell._Thomlet.callBaseMethod(this, 'set_CollapsedWindowSize', [height, width]);
}}
Tfsi.Shell._Thomlet.registerClass('Tfsi.Shell._Thomlet', Tfsi.Shell._ThomletBase, Tfsi.Shell.IThomlet);
Tfsi.Shell._ShelvingManager = function (we) {
    Tfsi.Shell._ShelvingManager.initializeBase(this);
    this._we = we;
}
Tfsi.Shell._ShelvingManager.prototype = {start: function () {
    this._we.hideOnPageSwitch(true);
}, stop: function () {
    this._we.hideOnPageSwitch(false);
}}
Tfsi.Shell._ShelvingManager.registerClass('Tfsi.Shell._ShelvingManager', Tfsi.Shell._ShelvingBase, Tfsi.Shell.IShelvingManager);
Tfsi.Preferences._PreferenceBroker = function (we) {
    Tfsi.Preferences._PreferenceBroker.initializeBase(this);
    this._we = we;
    this._thomletPrefCallback = null;
    this._lastPrefs = null;
}
Tfsi.Preferences._PreferenceBroker.prototype = {setPreference: function (key, value) {
    Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'setPreference', [key, value]);
    var preferenceDict = new Tfsi.StringDictionary();
    preferenceDict.add(key, value);
    this.setPreferences(preferenceDict);
}, setPreferences: function (preferenceDict) {
    Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'setPreferences', [preferenceDict]);
    var weContext = this._we.context.contextUpdate;
    if (!weContext) {
        weContext = this._we.context.initialContext;
    }
    var listArray = preferenceDict._get_Items();
    var sb = new Sys.StringBuilder();
    sb.append("<Context>");
    for (var key in listArray) {
        var value = listArray[key];
        sb.append('<Preference name="' + key + '">' + value + '</Preference>');
    }
    sb.append("</Context>");
    this._we.contextChange(sb.toString());
}, getPreferences: function () {
    var weContext = this._we.context.contextUpdate;
    if (!weContext) {
        weContext = this._we.context.initialContext;
    }
    var wePres = weContext['Preference'];
    var itemDict;
    if (wePres) {
        itemDict = new Tfsi.Preferences.PreferenceDictionary();
        for (var i in wePres) {
            var key = wePres[i].attribute['name'];
            var value = wePres[i].value;
            var item = new Tfsi.Preferences.PreferenceItem(key, value);
            itemDict._add(key, item);
        }
    }
    return itemDict;
}, getPreference: function (key) {
    Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'getPreference', [key]);
    var itemList = this.getPreferences();
    if (itemList) {
        return itemList.get_Item(key);
    }
}, setPreferenceChangedHandler: function (handler) {
    Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'setPreferenceChangedHandler', [handler]);
    this._thomletPrefCallback = handler;
    var cbMgr = Tfsi.Context._getCallbackManager();
    if (handler) {
        cbMgr._registerPrefCallback(true);
    }
    else {
        cbMgr._registerPrefCallback(false);
    }
}, isPreferenceSupported: function (key) {
    Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'isPreferenceSupported', [key]);
    if (this.getPreference(key)) {
        return true;
    }
    else {
        return false;
    }
}, _PreferenceChangedCallback: function (newPreferences) {
    var prefObj = this._getPreObj(newPreferences);
    if (!prefObj) {
        return false;
    }
    if (!this._lastPrefs) {
        var weContext = this._we.context.initialContext;
        this._lastPrefs = this._getPreObj(weContext);
    }
    var newPref = this._diffPrefObject(prefObj, this._lastPrefs);
    this._lastPrefs = prefObj;
    if (newPref.get_Count() == 0) {
        return false;
    }
    if (this._thomletPrefCallback == null) {
        return true;
    }
    var args = new Tfsi.Preferences.PreferencesChangedEventArgs(newPref);
    if (!this._thomletPrefCallback(this, args)) {
        return false;
    }
    return true;
}, _diffPrefObject: function (prefObj1, prefObj2) {
    if (!prefObj2) {
        return prefObj1;
    }
    var newPrefs = new Tfsi.Preferences.PreferenceDictionary();
    for (var key in prefObj1) {
        if (prefObj1[key] != prefObj2[key]) {
            var item = new Tfsi.Preferences.PreferenceItem(key, prefObj1[key]);
            newPrefs._add(key, item);
        }
    }
    return newPrefs;
}, _getPreObj: function (weContext) {
    var wePres = weContext['Preference'];
    var arr;
    if (wePres) {
        arr = new Object();
        for (var i in wePres) {
            var id = wePres[i].attribute['name'];
            var value = wePres[i].value;
            arr[id] = value;
        }
    }
    return arr;
}}
Tfsi.Preferences._PreferenceBroker.registerClass('Tfsi.Preferences._PreferenceBroker', Tfsi.Preferences._PreferenceBase, Tfsi.Preferences.IPreferenceBroker);
Tfsi.ServiceFactory.getService = function (serviceName, optionalInfo) {
    var e = Function._validateParams(arguments, [
        {name: "serviceName", type: String},
        {name: "optionalInfo", type: String, mayBeNull: true, optional: true}
    ]);
    if (e)throw e;
    var svcInstance = Tfsi.__ServiceInstances[serviceName];
    if (!svcInstance) {
        var serviceType = Tfsi.ServiceFactory._getServiceType(serviceName);
        if (serviceType) {
            svcInstance = Tfsi.__ServiceInstances[serviceName] = new serviceType(Tfsi._wePriv);
        }
        else {
            throw Error.serviceNotDefinedException(serviceName);
        }
    }
    return svcInstance;
}
Tfsi._weAttach = function Tfsi$_weAttach() {
    var topFrame = Tfsi._weGetTop(self);
    if (topFrame) {
        var thomletId = self.id;
        var frameId = self.name;
        var weWindow = self.parent;
        while (weWindow && weWindow != topFrame) {
            if (weWindow.we) {
                we = weWindow.we;
                if (we.__isAttached) {
                }
                we.__isAttached = true;
                break;
            }
            if (weWindow == top && top.opener) {
                weWindow = top.opener;
            }
            else {
                weWindow = weWindow.parent;
            }
        }
        Tfsi._wePriv = we;
        we.oldDomain = Tfsi._oldDomain;
        we.registerFrameByName(frameId, self);
        we.streamingManager.RemoveAllStreamingElements();
        we.streamingManager.SetFrame(window);
        if (!document.oncontextmenu) {
            document.oncontextmenu = Tfsi._attachOnContextMenu;
        }
        window.resizeTo = Tfsi._resizewindow;
        if (!weWindow.Tfsi) {
            weWindow.document.body.scroll = "no";
        }
        if (we.parent && (we.parent.isCombiner || we.parent.isChildOfCombiner)) {
            we.isChildOfCombiner = true;
        }
    }
}
Tfsi._weGetTop = function Tfsi$_weGetTop(pf) {
    var topFrame;
    if (top.wfGlobal) {
        return top;
    } else if (top.opener && top.opener.wfGlobal) {
        return top.opener.top;
    } else if (top.T1FrameName) {
        topFrame = top.frames[top.T1FrameName];
        return topFrame;
    } else {
        try {
            topFrame = window.top.frames["t1HiddenFrame"];
            if (topFrame != null)
                return topFrame;
        } catch (e) {
        }
        return null;
    }
}
Tfsi._init = function Tfsi$_init() {
    if (!Tfsi._wePriv) {
        var cookie = new Tfsi._CookieAccess('TF_Framework_Cookies');
        var domain = cookie.get_SubValue('T1Domain');
        if (domain != null) {
            Tfsi._oldDomain = document.domain;
            var popForDS = Tfsi._CreatePopupIfDS(domain);
            document.domain = domain;
            Tfsi._weAttach();
            if (popForDS) {
                we.popWindowForDS = popForDS;
            }
        }
    }
}
Tfsi._attachOnContextMenu = function Tfsi$_attachOnContextMenu() {
    if (!event.ctrlKey) {
        var we = Tfsi._wePriv;
        var xMenu = event.clientX + document.documentElement.scrollLeft;
        var yMenu = event.clientY + document.documentElement.scrollTop;
        we.contextMenu(we, xMenu, yMenu, window.document.body, we.name);
        event.cancelBubble = true;
        event.returnValue = false;
        return false;
    }
    else {
        return true;
    }
}
Tfsi._resizewindow = function Tfsi$_resizewindow(width, height) {
    we.resizeWindow(width, height);
    return true;
}
Tfsi._CreatePopupIfDS = function Tfsi$_CreatePopupIfDS(domain) {
    var isDesktopService = false;
    try {
        if (!top.globalPopWindow) {
            isDesktopService = true;
        }
    }
    catch (e) {
    }
    var popupForDS;
    if (isDesktopService) {
        popupForDS = window.createPopup();
        var popBase = popupForDS.document.createElement("BASE");
        popBase.href = document.location.protocol + "//" + domain;
        var head = popupForDS.document.getElementsByTagName("HEAD")[0];
        head.appendChild(popBase);
        popupForDS.document.domain = domain;
    }
    return popupForDS;
}
Tfsi._getQueryVariable = function Tfsi$_getQueryVariable(url, key) {
    var queryStrings = url.substring(url.indexOf('?') + 1, url.length);
    var vars = queryStrings.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == key) {
            return pair[1];
        }
    }
}
Tfsi._init();
var we = Tfsi._wePriv;
if (typeof(Sys) !== 'undefined')Sys.Application.notifyScriptLoaded();