/***********************************************/
/* Thomson Web Integration API Standard        */
/* Release Version 1.1                         */
/* Copyright (c) 2006-2010 Thomson Financial   */
/***********************************************/
///<reference name="MicrosoftAjax.debug.js" />
///<reference path="FsiInterfaces.js" />

//
// FSI types for smart client framework (override types defined in FsiInterfaces.js)
//

// Redefine registerClass with Ajax implementation specific code for unregistering a type
// so ajax doesn't complain when we redefine types.
if (window.__registeredTypes == undefined || window.__registeredTypes == null)
{
    window.__registeredTypes = {};
}
Tfsi.__SmartOldRegisterClass = Type.prototype.registerClass;
Type.prototype.registerClass = function Tfsi$registerSmartClassHook(typeName, baseType, interfaceTypes)
{
    /// <param name="typeName" type="String"></param>
    /// <param name="baseType" type="Type" optional="true" mayBeNull="true"></param>
    /// <param name="interfaceTypes" parameterArray="true" type="Type"></param>
    /// <returns type="Type"></returns>
    var e = Function._validateParams(arguments, [
        {name: "typeName", type: String},
        {name: "baseType", type: Type, mayBeNull: true, optional: true},
        {name: "interfaceTypes", type: Type, parameterArray: true}
    ]);
    window.__registeredTypes[typeName] = false;
    Tfsi.__SmartOldRegisterClass.call(this, typeName, baseType, interfaceTypes);
}

Tfsi.__SmartOldRegisterInterface = Type.prototype.registerInterface;
Type.prototype.registerInterface = function Tfsi$registerSmartInterfaceHook(typeName)
{
    /// <param name="typeName" type="String"></param>
    /// <returns type="Type"></returns>
    var e = Function._validateParams(arguments, [
        { name: "typeName", type: String }
    ]);
    window.__registeredTypes[typeName] = false;
    Tfsi.__SmartOldRegisterInterface.call(this, typeName);
}

Tfsi.__SmartOldRegisterEnum = Type.prototype.registerEnum;
Type.prototype.registerEnum = function Tfsi$registerSmartEnumHook(name, flags) {
    /// <param name="name" type="String"></param>
    /// <param name="flags" type="Boolean" optional="true"></param>
    var e = Function._validateParams(arguments, [
        { name: "name", type: String },
        { name: "flags", type: Boolean, optional: true }
    ]);
    window.__registeredTypes[name] = false;
    if (flags)
    {
        Tfsi.__SmartOldRegisterEnum.call(this, name, flags);
    }
    else
    {
        Tfsi.__SmartOldRegisterEnum.call(this, name);
    }
}

//Exceptions
Error.keyNotFoundException = function Error$keyNotFoundException(message) {
    /// <param name="message" type="String" optional="true" mayBeNull="true"></param>
    /// <returns></returns>
    var e = Function._validateParams(arguments, [
        {name: "message", type: String, mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    var displayMessage = "Sys.KeyNotFoundException: " + (message ? message : "Key not found.");

    var e = Error.create(displayMessage, {name: 'Sys.KeyNotFoundException'});
    e.popStackFrame();
    return e;
}

Error.fsiContextAccessDeniedException = function Error$fsiContextAccessDeniedException(message) {
    var e = Function._validateParams(arguments, [
        {name: "message", type: String, mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    var displayMessage = "Tfsi.Context.ContextAccessDeniedException: " + (message ? message : "Thomlet is not allowed to set context.");

    var e = Error.create(displayMessage, {name: 'Tfsi.Context.ContextAccessDeniedException'});
    e.popStackFrame();
    return e;
}

Error.fsiPreferenceAccessDeniedException = function Error$fsiPreferenceAccessDeniedException(message) {
    var e = Function._validateParams(arguments, [
        {name: "message", type: String, mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    var displayMessage = "Tfsi.Preferences.PreferenceAccessDeniedException: " + (message ? message : "Thomlet is not allowed to set Preference.");

    var e = Error.create(displayMessage, {name: 'Tfsi.Preferences.PreferenceAccessDeniedException'});
    e.popStackFrame();
    return e;
}

Tfsi._buildStringArray = function Tfsi$_buildStringArray(managedStringCollection) {

    var keys = new Array();
    if (managedStringCollection) {
        var count = managedStringCollection.Count;
        for (var i = 0; i < count; i++) {
            keys[i] = managedStringCollection.Item(i);
        }
    }
    return keys;
}

//StringCollection
Tfsi.StringCollection = function(managedStringCollection) {
    if (!managedStringCollection) {
        managedStringCollection = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.StringCollection, ManagedFsiCom");
    }
    this._managedStringCollection = managedStringCollection;
    if (!this._managedStringCollection) {
        // throw an exception
    }
}

Tfsi.StringCollection.prototype = {
    ManagedStringCollection : function(){
        return this._managedStringCollection;
    },
    add : function(value) {
        var e = Function._validateParams(arguments, [
            {name: "value", type: String}
        ]);
        if (e) throw e;

        this._managedStringCollection.Add(value);
    },
    get_Items : function(){
        var items = this._managedStringCollection.Items;
        return items;
    },
    contains : function(value) {
        var e = Function._validateParams(arguments, [
            { name: "value", type: String }
        ]);
        if (e) throw e;

        return this._managedStringCollection.Contains(value);
    }
}

Tfsi.StringCollection.registerClass('Tfsi.StringCollection', null);

//StringDictionary
Tfsi.StringDictionary = function(managedStringStringDictionary){
    if (!managedStringStringDictionary) {
        managedStringStringDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.StringStringDictionary, ManagedFsiCom");
    }
    this._managedStringStringDictionary = managedStringStringDictionary;
    if (!this._managedStringStringDictionary){
        // throw an exception
    }
}

//
Tfsi.StringDictionary.prototype = {
    ManagedStringStringDictionary : function(){
        return this._managedStringStringDictionary;
    },
    add : function(key, value) {
        var e = Function._validateParams(arguments, [
            {name: "key", type: String},
            {name: "value", type: String}
        ]);
        if (e) throw e;

        this._managedStringStringDictionary.Add(key, value);
    },
    get_Item : function(key){
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e) throw e;

        if(!this.containsKey(key)) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        var item = this._managedStringStringDictionary.Item(key);
        return item;
    },
    set_Item : function(key, value){
        var e = Function._validateParams(arguments, [
            {name: "key", type: String},
            {name: "value", type: String}
        ]);
        if (e) throw e;

        this._managedStringStringDictionary.Item(key) = value;
    },
    containsKey : function(key) {
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e) throw e;

        var value = this._managedStringStringDictionary.ContainsKey(key);
        return value;
    },
    get_Count : function() {
        var count = this._managedStringStringDictionary.Count;
        return count;
    },
    _get_Keys: function() {
        var managedStringCollection = this._managedStringStringDictionary.Keys;
        var keys = Tfsi._buildStringArray(managedStringCollection);
        return keys;
    },
    _get_ItemsClone: function() {
        var keys = this._get_Keys();
        var items = new Object();
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            items[key] = this.get_Item(key);
        }
        return items;
    }
}

Tfsi.StringDictionary.registerClass('Tfsi.StringDictionary', null);

Tfsi.StringDictionary.forEach = function(dictionary, method, instance){
    var e = Function._validateParams(arguments, [
        {name: "dictionary", type: Tfsi.StringDictionary},
        {name: "method", type: Function},
        {name: "instance", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    var keys = dictionary._get_Keys();
    var item;
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        item = dictionary.get_Item(key);
        if(method.call(instance, key, item)){
            break;
        }
    }
}

//KeyedItemDictionary
Tfsi.KeyedItemDictionary = function(){
    this._managedStringContextValueDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextValueDictionary, ManagedFsiCom");

    if (!this._managedStringContextValueDictionary){
        // throw an exception
    }
}

//
Tfsi.KeyedItemDictionary.prototype = {
    ManagedStringContextValueDictionary : function(){
        return this._managedStringContextValueDictionary;
    },
    SetManagedStringContextValueDictionary: function(managedStringContextValueDictionary) {
        this._managedStringContextValueDictionary = managedStringContextValueDictionary;
    },
    add : function(key, value) {
        // The type of value could be either String or Tfsi.Context.ContextValue
        var e = Function._validateParams(arguments, [
            {name: "key", type: String},
            {name: "value", mayBeNull: true}
        ]);
        if (e) throw e;

        var managedContextValue = null;

        var name = key;
        if (name == "Entity") {
            name = "Symbol";
        }
        // Retrieve the managed ContextValue from the value first if value is of Tfsi.Context.ContextValue type
        if(Tfsi.Context.ContextValue.isInstanceOfType(value)){
            managedContextValue = value.ManagedContextValue();
        }
        else if (!value) {
            value = "";
            var contextValue = new Tfsi.Context.ContextValue(name, value);
            managedContextValue = contextValue.ManagedContextValue();
        }
        else if(typeof value == "string") {
            // If value is a string, create a managed ContextValue
            var contextValue = new Tfsi.Context.ContextValue(name, value);
            managedContextValue = contextValue.ManagedContextValue();
        }
        else if(typeof value == "object") {
            var contextValue = new Tfsi.Context.ContextValue(name, value[0].value);
            managedContextValue = contextValue.ManagedContextValue();
        }

        this._managedStringContextValueDictionary.Add(name, managedContextValue);
    },
    // Returns a Tfsi.Context.ContextValue
    get_Item : function(key){
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e) throw e;

        var name = key;
        if (key == "Entity") {
            if (!this._managedStringContextValueDictionary.ContainsKey(key)) {
                name = "Symbol";
            }
        }

        if (!this.containsKey(name)) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        // Get the item using name instead of key
        var managedContextValue = this._managedStringContextValueDictionary.Item(name);

        // Create a Tfsi.Context.ContextValue to wrap the managed ContextValue
        var item = new Tfsi.Context.ContextValue(key, null);
        item.SetManagedContextValue(managedContextValue);

        return item;
    },
    set_Item : function(key, value){
        var e = Function._validateParams(arguments, [
            {name: "key", type: String},
            {name: "value", mayBeNull: true}
        ]);
        if (e) throw e;
        if(!value){
            value = "";
        }

        var name = key;
        if (key == "Entity") {
            if (!this.containsKey(key)) {
                name = "Symbol";
            }
        }

        // Retrieve the managed ContextValue from the value first if value is of Tfsi.Context.ContextValue type
        if(Tfsi.Context.ContextValue.isInstanceOfType(value)){
            managedContextValue = value.ManagedContextValue();
        }
        else if(typeof value == "string") {
            // If value is a string, create a managed ContextValue
            var contextValue = new Tfsi.Context.ContextValue(key, value);
            managedContextValue = contextValue.ManagedContextValue();
        }

        this._managedStringContextValueDictionary.Item(key) = managedContextValue;
    },
    containsKey : function(key) {
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e) throw e;

        var name = key;
        if (key == "Entity") {
            if (!this._managedStringContextValueDictionary.ContainsKey(key)) {
                name = "Symbol";
            }
        }

        var value = this._managedStringContextValueDictionary.ContainsKey(name);
        return value;
    },
    get_Count : function() {
        var count = this._managedStringContextValueDictionary.Count;
        return count;
    },
    _get_Keys : function() {
        var managedStringCollection = this._managedStringContextValueDictionary.Keys;
        var keys = Tfsi._buildStringArray(managedStringCollection);
        return keys;
    }
}

Tfsi.KeyedItemDictionary.registerClass('Tfsi.KeyedItemDictionary', null);

Tfsi.KeyedItemDictionary.forEach = function(dictionary, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "dictionary", type: Tfsi.KeyedItemDictionary },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var keys = dictionary._get_Keys();
    var contextValue;
    for (i = 0; i < keys.length; i++) {
        var key = keys[i];
        contextValue = dictionary.get_Item(key);
        if (key == "Symbol") {
            key = "Entity";
        }
        if (method.call(instance, key, contextValue)) {
            break;
        }
    }
}

//ContextItem
Tfsi.Context.ContextItem= function(key, value) {
    // The type of value could be String or Tfsi.Context.ContextValue
    var e = Function._validateParams(arguments, [
        {name: "key", type: String},
        {name: "value", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    if (value != null){
        var managedContextValue = null;
        if(Tfsi.Context.ContextValue.isInstanceOfType(value)){
            managedContextValue = value.ManagedContextValue();
        }
        else if(typeof value == "string") {
            var contextValueArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
            contextValueArgs.AddStringValue(value);
            managedContextValue = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Context.ContextValue, Thomson.Financial.Framework.ManagedFsi", contextValueArgs);
        }
        else {
            // throw an exception
        }

        var readOnly = false;
        var contextItemArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
        contextItemArgs.Add(key);
        contextItemArgs.Add(managedContextValue);
        contextItemArgs.Add(readOnly);

        this._managedContextItem = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Context.ContextItem, Thomson.Financial.Framework.ManagedFsi", contextItemArgs);

        if (!this._managedContextItem){
            // throw an exception
        }
    }
}

//
Tfsi.Context.ContextItem.prototype = {
    ManagedContextItem: function() {
        return this._managedContextItem;
    },
    get_Key: function() {
        var key = this._managedContextItem.Key;
        if (key == "Symbol") {
            key = "Entity";
        }
        return key;
    },
    get_ReadOnly: function() {
        return this._managedContextItem.Readonly;
    },
    // Return String or Tfsi.Context.ContextValue
    get_Value: function() {
        var managedContextValue = this._managedContextItem.Value;
        var key = this.get_Key();
        var contextValue = new Tfsi.Context.ContextValue(key, null);
        contextValue.SetManagedContextValue(managedContextValue);
        var hasComplexValue = contextValue.ManagedContextValueWrapper().HasComplexValue;
        if (!hasComplexValue) {
            contextValue = contextValue.ManagedContextValueWrapper().SimpleValue;
        }

        return contextValue;
    },
    SetManagedContextItem: function(managedContextItem) {
        this._managedContextItem = managedContextItem;
    }
}

Tfsi.Context.ContextItem.registerClass('Tfsi.Context.ContextItem', null);

//ContextDictionary
Tfsi.Context.ContextDictionary = function(managedStringContextItemDictionary) {
    var e = Function._validateParams(arguments, [
        {name: "managedStringContextItemDictionary", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    if (!managedStringContextItemDictionary) {
        managedStringContextItemDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextItemDictionary, ManagedFsiCom");
    }
    this._managedStringContextItemDictionary = managedStringContextItemDictionary;

    if (!this._managedStringContextItemDictionary){
        // throw an exception
    }
}

//
Tfsi.Context.ContextDictionary.prototype = {
    ManagedStringContextItemDictionary: function() {
        return this._managedStringContextItemDictionary;
    },
    // Return Tfsi.Context.ContextItem
    get_Item: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        if (!this.containsKey(key)) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        var name = key;
        if (name == "Entity") {
            name = "Symbol";
        }
        var managedContextItem = this._managedStringContextItemDictionary.Item(name);

        // Create a Tfsi.Context.ContextItem to wrap the managed ContextItem        
        var item = new Tfsi.Context.ContextItem(key, null);
        item.SetManagedContextItem(managedContextItem);
        return item;
    },
    get_Keys: function() {
        var managedStringCollection = this._managedStringContextItemDictionary.Keys;
        var keys = Tfsi._buildStringArray(managedStringCollection);
        return keys;
    },
    get_Count: function() {
        var count = this._managedStringContextItemDictionary.Count;
        return count;
    },
    containsKey: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        var name = key;
        if (name == "Entity") {
            name = "Symbol";
        }
        var value = this._managedStringContextItemDictionary.ContainsKey(name);
        return value;
    },
    _get_Items: function() {
        var ctxDictionary = new Object();

        var keys = this.get_Keys();
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var contextItem = this.get_Item(key);
            if (key == "Symbol") {
                key = "Entity";
            }
            ctxDictionary[key] = contextItem;
        }
        return ctxDictionary;
    }
}

Tfsi.Context.ContextDictionary.registerClass('Tfsi.Context.ContextDictionary', null);

Tfsi.Context.ContextDictionary.forEach = function(dictionary, method, instance){
    var e = Function._validateParams(arguments, [
        {name: "dictionary", type: Tfsi.Context.ContextDictionary},
        {name: "method", type: Function},
        {name: "instance", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    var keys = dictionary.get_Keys();
    var contextItem;
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        contextItem = dictionary.get_Item(key);
        if(method.call(instance, key, contextItem)){
            break;
        }
    }
}

//ContextChangedEventArgs
Tfsi.Context.ContextChangedEventArgs = function(updatedContext, subFunction, commandArgs, reason) {
    var e = Function._validateParams(arguments, [
        { name: "updatedContext", type: Tfsi.Context.ContextDictionary, mayBeNull: true },
        { name: "subFunction", type: String, mayBeNull: true, optional: true },
        { name: "commandArgs", type: String, mayBeNull: true, optional: true },
        { name: "reason", type: Tfsi.Context.ContextChangedReason, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    Tfsi.Context.ContextChangedEventArgs.initializeBase(this);
    this._updatedContext = updatedContext;
    this._subFunction = subFunction;
    this._commandArgs = commandArgs;

    var managedStringContextItemDictionary = null;
    if (updatedContext) {
        managedStringContextItemDictionary = updatedContext.ManagedStringContextItemDictionary();
    }
    else {
        // Create an empty StringContextItemDictionary
        managedStringContextItemDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextItemDictionary, ManagedFsiCom");
    }

    var subFunctionId = subFunction;
    var commandArgs = commandArgs;

    if (reason == undefined) {
        reason = Tfsi.Context.ContextChangedReason.context;
    }
    this._reason = reason;

    var args = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    args.Add(managedStringContextItemDictionary.Dictionary);
    args.Add(subFunctionId);
    args.Add(commandArgs);
    args.Add(reason);

    var argsTypes = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    argsTypes.Add(null);
    argsTypes.Add(null);
    argsTypes.Add(null);
    var throwOnError = false;
    var argType = Tfsi._serviceFactory.FindType("Thomson.Financial.Framework.Managed.Context.ContextChangedReason, Thomson.Financial.Framework.ManagedFsi", throwOnError);
    argsTypes.Add(argType);

    this._contextChangedEventArgs = Tfsi._serviceFactory.CreateInstanceWithArgsAndTypes("Thomson.Financial.Framework.Managed.Context.ContextChangedEventArgs, Thomson.Financial.Framework.ManagedFsi", args, argsTypes);
}

Tfsi.Context.ContextChangedEventArgs.prototype = {
    ManagedContextChangedEventArgs : function(){
        return this._contextChangedEventArgs;
    },
    get_UpdatedContext : function() {
        return this._updatedContext;
    },
    get_SubFunction : function() {
        return this._contextChangedEventArgs.SubFunction;
    },
    get_CommandArgs : function() {
        return this._contextChangedEventArgs.CommandArgs;
    },
    get_Reason: function() {
        return this._reason;
    },
    SetContextChangedEventArgs : function(managedContextChangedEventArgs) {
        this._managedContextChangedEventArgs = managedContextChangedEventArgs;
    }
}

Tfsi.Context.ContextChangedEventArgs.registerClass('Tfsi.Context.ContextChangedEventArgs', Sys.EventArgs);

//_ContextValuePair
Tfsi.Context._ContextValuePair= function(attributes, value) {
    var e = Function._validateParams(arguments, [
        {name: "attributes", type: Tfsi.StringDictionary},
        {name: "value", type: String}
    ]);
    if (e) throw e;

    var managedStringStringDictionary = attributes.ManagedStringStringDictionary();
    var innerManagedAttributes = managedStringStringDictionary.Dictionary;
    var contextValuePairArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    contextValuePairArgs.Add(innerManagedAttributes);
    contextValuePairArgs.Add(value);
    this._managedContextValuePair = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Context.ContextValuePair", contextValuePairArgs);
    if (!this._managedContextValuePair){
        // throw an exception
    }
}

Tfsi.Context._ContextValuePair.prototype = {

    hasAttributes : function(attributes) {
        var e = Function._validateParams(arguments, [
            {name: "attributes", type: Tfsi.StringDictionary}
        ]);
        if (e) throw e;

        var attributesDictionary = this.get_Attributes();
        for(var key in attributes.get_Items()) {
            if(!attributesDictionary.containsKey(key)) {
                return false;
            }

            if(attributes[key] != attributesDictionary[key]) {
                return false;
            }
        }
        return true;
    },
    // String
    get_Value : function() {
        return this._managedContextValuePair.Value;
    },
    set_Value : function(value) {
        var e = Function._validateParams(arguments, [
            {name: "value", type: String}
        ]);
        if (e) throw e;

        var contextValuePairArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
        contextValuePairArgs.Add(this._managedContextValuePair.Attributes);
        contextValuePairArgs.Add(value);
        this._managedContextValuePair = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Context.ContextValuePair", contextValuePairArgs);

    },
    // Return Tfsi.StringDictionary
    get_Attributes : function() {
        var managedAttributes = this._managedContextValuePair.Attributes;
        var stringDictionary = new Tfsi.StringDictionary(managedAttributes);
        return stringDictionary;
    }
}

Tfsi.Context._ContextValuePair.registerClass('Tfsi.Context._ContextValuePair', null);

// ContextValue
Tfsi.Context.ContextValue = function(name, value) {
    //The type of value is String

    this._name = name;

    if (!value) {
        value = "";
    }
    this._value = value;

    var contextValueArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    contextValueArgs.AddStringValue(value);
    this._managedContextValueWrapper = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Interop.Context.ContextValueWrapper, ManagedFsiCom", contextValueArgs);

    if (!this._managedContextValueWrapper) {
        // throw an exception
    }
}

Tfsi.Context.ContextValue.prototype = {
    ManagedContextValueWrapper: function() {
        return this._managedContextValueWrapper;
    },
    ManagedContextValue: function() {
        return this._managedContextValueWrapper.ContextValue;
    },
    get_Name: function() {
        return this._name;
    },
    set_Value: function(attributes, value) {
        var e = Function._validateParams(arguments, [
            { name: "attributes", type: Tfsi.StringDictionary, mayBeNull: true },
            { name: "value", type: String, mayBeNull: true }
        ]);
        if (e) throw e;

        if (!value) {
            value = "";
        }

        var innerManagedAttributes;
        var contextValueArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
        if (attributes) {
            var managedStringStringDictionary = attributes.ManagedStringStringDictionary();
            innerManagedAttributes = managedStringStringDictionary.Dictionary;

            contextValueArgs.Add(innerManagedAttributes);
        }
        //var contextValueArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
        // if (attributes) {
        //    contextValueArgs.Add(attributes);
        // }
        contextValueArgs.Add(value);
        var hasComplexValue = false;
        if (this._managedContextValueWrapper && this._managedContextValueWrapper.HasComplexValue) {
            hasComplexValue = true;
        }
        if (hasComplexValue && attributes) {
            try {
                this._managedContextValueWrapper.AddValue(innerManagedAttributes, value);
            }
            catch (e) {
            }
        }
        else {
            this._managedContextValueWrapper = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Interop.Context.ContextValueWrapper, ManagedFsiCom", contextValueArgs);
        }
    },
    // Return String
    get_Value: function(attributes) {
        var e = Function._validateParams(arguments, [
            { name: "attributes", type: Tfsi.StringDictionary, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;

        if (!attributes) {
            var simpleValue = this._managedContextValueWrapper.SimpleValue;
            if (simpleValue) {
                return simpleValue;
            }
            else {  // Return the Value of the first one in ComplexValues
                var hasComplexValue = this._managedContextValueWrapper.HasComplexValue;
                if (hasComplexValue) {
                    var managedComplexValues = this._managedContextValueWrapper.ComplexValues;
                    var contextValuePairReadOnlyCollectionArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
                    contextValuePairReadOnlyCollectionArgs.Add(managedComplexValues);
                    var managedContextValuePairReadOnlyCollection = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Interop.Context.ContextValuePairReadOnlyCollection, ManagedFsiCom", contextValuePairReadOnlyCollectionArgs);
                    var managedContextValuePair = managedContextValuePairReadOnlyCollection.Item(0);
                    return managedContextValuePair.Value;
                }
            }
            return null;
        }

        var managedStringStringDictionary = attributes.ManagedStringStringDictionary();
        var managedAttributes = managedStringStringDictionary.Dictionary;
        var value = this._managedContextValueWrapper.GetValue(managedAttributes);
        return value;
    },
    get_Count: function() {
        var count = 0;
        var hasComplexValue = this._managedContextValueWrapper.HasComplexValue;
        if (hasComplexValue) {
            var managedComplexValues = this._managedContextValueWrapper.ComplexValues;
            var contextValuePairReadOnlyCollectionArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
            contextValuePairReadOnlyCollectionArgs.Add(managedComplexValues);
            var managedContextValuePairReadOnlyCollection = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Interop.Context.ContextValuePairReadOnlyCollection, ManagedFsiCom", contextValuePairReadOnlyCollectionArgs);
            count = managedContextValuePairReadOnlyCollection.Count;
        }

        return count;
    },

    _get_ManagedComplexValues: function() {
        return this._managedContextValueWrapper.ComplexValues;
    },
    SetManagedContextValue: function(managedContextValue) {
        this._managedContextValueWrapper = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.ContextValueWrapper, ManagedFsiCom");
        this._managedContextValueWrapper.ContextValue = managedContextValue;
        this._value = this._managedContextValueWrapper.SimpleValue;
    }
}

Tfsi.Context.ContextValue.registerClass('Tfsi.Context.ContextValue', null);

Tfsi.Context.ContextValue.forEach = function(ctxValue, method, instance){
    var e = Function._validateParams(arguments, [
        {name: "ctxValue", type: Tfsi.Context.ContextValue},
        {name: "method", type: Function},
        {name: "instance", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    var count = ctxValue.get_Count();
    var managedComplexValues = ctxValue._get_ManagedComplexValues();
    var contextValuePairReadOnlyCollectionArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    contextValuePairReadOnlyCollectionArgs.Add(managedComplexValues);
    var managedContextValuePairReadOnlyCollection = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Interop.Context.ContextValuePairReadOnlyCollection, ManagedFsiCom", contextValuePairReadOnlyCollectionArgs);

    for (var i=0; i< count; i++) {
        var managedContextValuePair = managedContextValuePairReadOnlyCollection.Item(i);
        var managedStringStringDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.StringStringDictionary, ManagedFsiCom");
        managedStringStringDictionary.Dictionary = managedContextValuePair.Attributes;
        var attributes = new Tfsi.StringDictionary(managedStringStringDictionary);
        var value = managedContextValuePair.Value;
        if(method.call(instance, attributes, value)){
            break;
        }
    }
}

// DrilldownDefaultTarget
Tfsi.Navigation.DrilldownDefaultTarget = function(thomletId, subFunction, readOnly, invokingType, searchScopes) {
    var e = Function._validateParams(arguments, [
        {name: "thomletId", type: String},
        {name: "subFunction", type: String, mayBeNull: true, optional : true},
        {name: "readOnly", type: Boolean, mayBeNull: true, optional : true},
        { name: "invokingType", type: Tfsi.Navigation.TargetInvokingType, mayBeNull: true, optional: true },
        { name: "searchScopes", type: Tfsi.Navigation.WorkspaceSearchScopes, mayBeNull: true, optional: true }
    ]);

    if(e)throw e;

    if (thomletId == "") {
        return;
    }

    var _readOnly=false;
    if(readOnly) {
        _readOnly=true;
    }

    if (!subFunction) {
        subFunction = "";
    }

    var _invokingType=Tfsi.Navigation.TargetInvokingType.onDemand;
    if(invokingType){
        _invokingType=invokingType;
    }
    else if (readOnly) {
        _invokingType= Tfsi.Navigation.TargetInvokingType.onDemand;
    }

    if (!searchScopes) {
        searchScopes = Tfsi.Navigation.WorkspaceSearchScopes.all;
    }

    var defaultTargetArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    defaultTargetArgs.Add(thomletId);
    defaultTargetArgs.Add(subFunction);
    defaultTargetArgs.Add(_readOnly);
    //var managedTargetInvokingType = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Navigation.TargetInvokingType, Thomson.Financial.Framework.ManagedFsi");        
    //defaultTargetArgs.Add(managedTargetInvokingType);
    defaultTargetArgs.Add(_invokingType);
    defaultTargetArgs.Add(searchScopes);

    var defaultTargetArgsTypes = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    defaultTargetArgsTypes.Add(null);
    defaultTargetArgsTypes.Add(null);
    defaultTargetArgsTypes.Add(null);
    var throwOnError = false;
    var argType = Tfsi._serviceFactory.FindType("Thomson.Financial.Framework.Managed.Navigation.TargetInvokingType, Thomson.Financial.Framework.ManagedFsi", throwOnError);
    defaultTargetArgsTypes.Add(argType);
    var searchScopeType = Tfsi._serviceFactory.FindType("Thomson.Financial.Framework.Managed.Navigation.WorkspaceSearchScopes, Thomson.Financial.Framework.ManagedFsi", throwOnError);
    defaultTargetArgsTypes.Add(searchScopeType);

    this._managedDrilldownDefaultTarget = Tfsi._serviceFactory.CreateInstanceWithArgsAndTypes("Thomson.Financial.Framework.Managed.Navigation.DrilldownDefaultTarget, Thomson.Financial.Framework.ManagedFsi", defaultTargetArgs, defaultTargetArgsTypes);
}

Tfsi.Navigation.DrilldownDefaultTarget.prototype={
    ManagedDrilldownDefaultTarget:function(){
        return this._managedDrilldownDefaultTarget;
    },
    get_ThomletId:function(){
        if (this._managedDrilldownDefaultTarget) {
            return this._managedDrilldownDefaultTarget.ThomletId;
        }
        else {
            return "";
        }
    },
    get_SubFunction:function(){
        if (this._managedDrilldownDefaultTarget) {
            return this._managedDrilldownDefaultTarget.Subfunction;
        }
        else {
            return "";
        }
    },
    get_ReadOnly:function(){
        if (this._managedDrilldownDefaultTarget) {
            return this._managedDrilldownDefaultTarget.ReadOnly;
        }
        else {
            return false;
        }
    },
    get_TargetInvokingType:function(){
        if (this._managedDrilldownDefaultTarget) {
            return this._managedDrilldownDefaultTarget.TargetInvokingType;
        }
        else {
            return Tfsi.Navigation.TargetInvokingType.normal;
        }
    },
    SetManagedDrilldownDefaultTarget : function (managedDrilldownDefaultTarget){
        this._managedDrilldownDefaultTarget = managedDrilldownDefaultTarget;
    }
}

Tfsi.Navigation.DrilldownDefaultTarget.registerClass('Tfsi.Navigation.DrilldownDefaultTarget',null);

//DrilldownItem
Tfsi.Navigation.DrilldownItem = function(id,name,desc,defaultTarget) {
    var e = Function._validateParams(arguments, [
        {name: "id", type: Number},
        {name: "name", type: String},
        {name: "desc", type: String},
        {name: "defaultTarget", type: Tfsi.Navigation.DrilldownDefaultTarget, mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    this._defaultTarget = defaultTarget;
    var managedDrilldownDefaultTarget = null;
    if (defaultTarget){
        managedDrilldownDefaultTarget = defaultTarget.ManagedDrilldownDefaultTarget();
    }

    var drilldownItemArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    drilldownItemArgs.Add(parseInt(id));
    drilldownItemArgs.Add(name);
    drilldownItemArgs.Add(desc);
    drilldownItemArgs.Add(managedDrilldownDefaultTarget);

    var drilldownItemArgsTypes = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    drilldownItemArgsTypes.Add(null);
    drilldownItemArgsTypes.Add(null);
    drilldownItemArgsTypes.Add(null);
    drilldownItemArgsTypes.Add(null);

    this._managedDrilldownItem = Tfsi._serviceFactory.CreateInstanceWithArgsAndTypes("Thomson.Financial.Framework.Managed.Navigation.DrilldownItem, Thomson.Financial.Framework.ManagedFsi", drilldownItemArgs, drilldownItemArgsTypes);
}

Tfsi.Navigation.DrilldownItem.prototype = {
    ManagedDrilldownItem : function(){
        return this._managedDrilldownItem;
    },
    get_Id : function(){
        return this._managedDrilldownItem.Id;
    },
    get_Name : function(){
        return this._managedDrilldownItem.Name;
    },
    get_Description : function(){
        return this._managedDrilldownItem.Description;
    },
    get_DefaultTarget : function(){
        return this._defaultTarget;
    }
}

Tfsi.Navigation.DrilldownItem.registerClass('Tfsi.Navigation.DrilldownItem', null);

//DrilldownChangedEventArgs
Tfsi.Navigation.DrilldownChangedEventArgs = function(id,tooltip,enabled)
{
    var args = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    args.Add(id);
    args.Add(tooltip);
    args.Add(enabled);

    this._drilldownChangedEventArgs = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Navigation.DrilldownChangedEventArgs, Thomson.Financial.Framework.ManagedFsi", args);
}

Tfsi.Navigation.DrilldownChangedEventArgs.prototype = {
    ManagedDrilldownChangedEventArgs : function(){
        return this._drilldownChangedEventArgs;
    },
    get_Id : function(){
        return this._drilldownChangedEventArgs.Id;
    },
    get_Tooltip : function(){
        return this._drilldownChangedEventArgs.TargetInfo;
    },
    get_Enabled : function(){
        return this._drilldownChangedEventArgs.Enabled;
    }
}

Tfsi.Navigation.DrilldownChangedEventArgs.registerClass('Tfsi.Navigation.DrilldownChangedEventArgs', null);

//DrilldownItemList
Tfsi.Navigation.DrilldownItemList = function(managedDrilldownItemList)
{
    var e = Function._validateParams(arguments, [
        {name: "managedDrilldownItemList", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    if (!managedDrilldownItemList) {
        managedDrilldownItemList = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.DrilldownItemList, Thomson.Financial.SmartOne.FSIScript");
    }
    this._managedDrilldownItemList = managedDrilldownItemList;

    if (!this._managedDrilldownItemList){
        // throw an exception
    }
}

Tfsi.Navigation.DrilldownItemList.prototype = {

    ManagedDrilldownItemList : function(){
        return this._managedDrilldownItemList;
    },

    addItem : function(id,name,desc,defaultTarget){
        var e = Function._validateParams(arguments, [
            {name: "id", type: Number},
            {name: "name", type: String},
            {name: "desc", type: String},
            {name: "defaultTarget", mayBeNull: true, optional: true}
        ]);
        if (e) throw e;

        var item = new Tfsi.Navigation.DrilldownItem(id, name, desc, defaultTarget);
        this.add(item);
        return item;
    },

    add : function(item){
        var e = Function._validateParams(arguments, [
            {name: "item", type: Tfsi.Navigation.DrilldownItem}
        ]);
        if (e) throw e;

        var managedDrilldownItem = item.ManagedDrilldownItem();
        this._managedDrilldownItemList.Add(managedDrilldownItem);
    },

    remove : function(id){
        var e = Function._validateParams(arguments, [
            {name: "id", type: String}
        ]);
        if (e) throw e;

        // Find the drilldownItem with the specified id first
        // then remove that drilldownItem

        var drilldownItem;
        this._managedDrilldownItemList.Remove(drilldownItem);
    },
    clear : function(){
        this._managedDrilldownItemList.Clear();
    },


    get_Count : function() {
        var count = this._managedDrilldownItemList.Count;
        return count;
    },

    _get_Item : function(index) {
        var managedDrilldownItem = this._managedDrilldownItemList.Item(index);
        var id = managedDrilldownItem.Id;
        var name = managedDrilldownItem.Name;
        var desc = managedDrilldownItem.Description;
        var defaultTarget = new Tfsi.Navigation.DrilldownDefaultTarget("");
        defaultTarget.SetManagedDrilldownDefaultTarget(managedDrilldownItem.DefaultTarget);
        var item = new Tfsi.Navigation.DrilldownItem(id, name, desc, defaultTarget);
        return item;
    },

    _get_Items : function() {
        return this._items;
    }

}

Tfsi.Navigation.DrilldownItemList.registerClass('Tfsi.Navigation.DrilldownItemList', null);

Tfsi.Navigation.DrilldownItemList.forEach = function(ddItemList, method, instance){
    var e = Function._validateParams(arguments, [
        {name: "ddItemList", type: Tfsi.Navigation.DrilldownItemList},
        {name: "method", type: Function},
        {name: "instance", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;
    var managedDrilldownItemList = ddItemList.ManagedDrilldownItemList();
    var count = ddItemList.get_Count();
    for (var i=0; i< count; i++) {
        var drilldownItem = ddItemList._get_Item(i);
        if(method.call(instance, drilldownItem)){
            break;
        }
    }
}

// WindowFeatures
Tfsi.Navigation.WindowFeatures=function(windowFeatures){
    var e = Function._validateParams(arguments, [
        {name: "windowFeatures", type: String, mayBeNull: true, optional : true}
    ]);

    if(e)throw e;

    var windowFeaturesObj = Tfsi.Navigation._Drilldown.callBaseMethod(this, '_toWindowFeaturesObj', [windowFeatures]);
    this._managedWindowFeatures = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Navigation.WindowFeatures, Thomson.Financial.Framework.ManagedFsi");

    if(windowFeaturesObj){
        this._managedWindowFeatures.Left         = windowFeaturesObj.Left;
        this._managedWindowFeatures.Top          = windowFeaturesObj.Top;
        this._managedWindowFeatures.Width        = windowFeaturesObj.Width;
        this._managedWindowFeatures.Height       = windowFeaturesObj.Height;
        this._managedWindowFeatures.ShowTitleBar = windowFeaturesObj.TitleBar;
        this._managedWindowFeatures.Resizable    = windowFeaturesObj.Resizable;
        this._managedWindowFeatures.IsModal      = windowFeaturesObj.Modal;
        this._managedWindowFeatures.BackgroundStyle = Tfsi.Navigation.BackgroundStyle.Normal;
        if(windowFeaturesObj.Background == "GRAYED"){
            this._managedWindowFeatures.BackgroundStyle = Tfsi.Navigation.BackgroundStyle.Grayed;
        }
    }
}

Tfsi.Navigation.WindowFeatures.prototype={
    ManagedWindowFeatures:function(){
        return this._managedWindowFeatures;
    },
    get_Left:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.Left;
        }
        else {
            return "";
        }
    },
    get_Top:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.Top;
        }
        else {
            return 0;
        }
    },
    get_Width:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.Width;
        }
    },
    get_Height:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.Height;
        }
    },
    get_ShowTitleBar:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.ShowTitleBar;
        }
    },
    get_Resizable:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.Resizable;
        }
    },
    get_IsModal:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.IsModal;
        }
    },
    get_BackgroundStyle:function(){
        if (this._managedWindowFeatures) {
            return this._managedWindowFeatures.BackgroundStyle;
        }
    }
}

Tfsi.Navigation.WindowFeatures.registerClass('Tfsi.Navigation.WindowFeatures',null);

//BackGroundStyle
Tfsi.Navigation.BackgroundStyle = function(){};
Tfsi.Navigation.BackgroundStyle.prototype =
{
    Normal:    0,
    Grayed:    1
}
Tfsi.Navigation.BackgroundStyle.registerEnum("Tfsi.Navigation.BackgroundStyle");


//_MenuItemBase
Tfsi.Shell.MenuItemBase = function(id){
    this._id = id;
    this._children = new Array();
    this._parent = null;
    this._isSeparator = false;
}

Tfsi.Shell.MenuItemBase.prototype = {
    get_Parent : function() {
        return this._parent;
    },
    _set_Parent : function(parent) {
        var e = Function._validateParams(arguments, [
            {name: "parent", type: Tfsi.Shell.MenuItemBase}
        ]);
        if (e) throw e;
        this._parent = parent;
    },
    _addChild : function(child) {
        var e = Function._validateParams(arguments, [
            {name: "child", type: Tfsi.Shell.MenuItemBase}
        ]);
        if (e) throw e;

        //TODO circular reference check
        child._set_Parent(this);
        Array.add(this._children, child);
    },
    get_Children : function() {
        return this._children
    },
    get_isSeparator : function() {
        return this._isSeparator;
    },
    get_Id : function() {
        return this._id;
    },
    findChild : function(id) {
        if(id == this._id) {
            return this;
        }
        if(this._isSeparator){
            return null;
        }
        for(var i=0; i < this._children.length;i++) {
            var child = this._children[i].findChild(id);
            if(child) {
                return child;
            }
        }
        return null;
    }
}

Tfsi.Shell.MenuItemBase.registerClass('Tfsi.Shell.MenuItemBase', null);

Tfsi.Shell.MenuItemBase._getAutoId = function(){
    if(!Tfsi.Shell.MenuItemBase._autoId){
        Tfsi.Shell.MenuItemBase._autoId = -1;
    }else {
        Tfsi.Shell.MenuItemBase._autoId--;
    }
    return Tfsi.Shell.MenuItemBase._autoId;
}

//MenuSeparator
Tfsi.Shell.MenuSeparator = function(){
    var id = Tfsi.Shell.MenuItemBase._getAutoId();
    Tfsi.Shell.MenuSeparator.initializeBase(this, [id]);

    this._id = id;
    this._children = new Array();
    this._parent = null;
    this._isSeparator = false;

    this._isSeparator = true;
}

Tfsi.Shell.MenuSeparator.prototype = {
    _toStringHelper : function(sb) {
    },
    _addChild : function(child) {
    }
}

Tfsi.Shell.MenuSeparator.registerClass('Tfsi.Shell.MenuSeparator', Tfsi.Shell.MenuItemBase);

//MenuItem
Tfsi.Shell.MenuItem = function(id) {

    var e = Function._validateParams(arguments, [
        { name: "id", type: String, optional: true }
    ]);
    if (e) throw e;
    if (!id) {
        id = Tfsi.Shell.MenuItemBase._getAutoId();
        var args = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
        args.Add(id.toString());
        var isBrowserMutiThreaded = false;
        frameworkFeatureService = Tfsi._serviceFactory.getService ("Thomson.Financial.SmartOne.ThomletHost.FrameworkServices.IFrameworkFeatureService, Thomson.Financial.SmartOne.Shell.Interfaces");
        if (frameworkFeatureService != null)
        {
            if (frameworkFeatureService.IsFeatureImplemented("MutiThreadedBrowser"))
            {
                isBrowserMutiThreaded = true;
            }
        }
        var managedMenuItem;
        if (isBrowserMutiThreaded)
        {
            managedMenuItem = Tfsi._serviceFactory.CreateInstanceWithArgsAndServiceFactory("Thomson.Financial.SmartOne.FSIScript.FsiMenuItem, Thomson.Financial.SmartOne.FSIScript", args);
        }
        else
        {
            managedMenuItem = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.SmartOne.FSIScript.FsiMenuItem, Thomson.Financial.SmartOne.FSIScript", args);
        }
        this._managedMenuItem = managedMenuItem;
    }
    Tfsi.Shell.MenuItem.initializeBase(this, [id]);
    this._id = id;
    this._func = null;
    this._accelerator = '';
    this._iconName = '';
}

Tfsi.Shell.MenuItem.prototype = {
    ManagedMenuItem : function() {
        return this._managedMenuItem;
    },
    SetManagedMenuItem : function(managedMenuItem) {
        this._managedMenuItem = managedMenuItem;
        this._id = managedMenuItem.Id;
    },
    get_Name : function() {
        return this._managedMenuItem.Name
    },
    set_Name : function (name) {
        var e = Function._validateParams(arguments, [
            {name: "name", type: String}
        ]);
        if (e) throw e;

        this._managedMenuItem.Name = name;
    },
    get_Func : function() {
        return this._func;
    },
    set_Func : function(func) {
        var e = Function._validateParams(arguments, [
            {name: "func", type: Function}
        ]);
        if (e) throw e;
        this._func = func;
    },
    get_Checked : function() {
        return this._managedMenuItem.Checked;
    },
    set_Checked : function(checked) {
        var e = Function._validateParams(arguments, [
            {name: "checked", type: Boolean}
        ]);
        if (e) throw e;
        this._managedMenuItem.Checked = checked;
    },
    set_Enabled : function(enabled) {
        var e = Function._validateParams(arguments, [
            {name: "enabled", type: Boolean}
        ]);
        if (e) throw e;
        this._managedMenuItem.Enabled = enabled;
    },
    get_Enabled : function() {
        return this._managedMenuItem.Enabled;
    },
    add : function(id, name, func, checked, enabled, accelerator, iconName, hotKey) {
        var e = Function._validateParams(arguments, [
            {name: "id", type: String},
            {name: "name", type: String},
            {name: "func", type: Function},
            {name: "checked", type: Boolean, optional: true},
            {name: "enabled", type: Boolean, optional : true},
            {name: "accelerator", type: String, mayBeNull: true, optional : true},
            {name: "iconName", type: String, mayBeNull: true, optional : true},
            {name: "hotKey", type: String, mayBeNull: true, optional : true}
        ]);
        if (e) throw e;

        var managedChildMenuItem = this._managedMenuItem.Add(id, name);
        if ((checked != null) && (checked != undefined)) {
            managedChildMenuItem.Checked = checked;
        }
        if ((enabled != null) && (enabled != undefined)) {
            managedChildMenuItem.Enabled = enabled;
        }
        if ((hotKey != null) && (hotKey != undefined)) {
            managedChildMenuItem.Hotkey = hotKey;
        }

        var contextMenuService = Tfsi.ServiceFactory.getService('IContextMenu');
        var managedContextMenuService = contextMenuService.ManagedContextMenuService();
        managedChildMenuItem.SetMenuItemClickCallback(managedContextMenuService);

        contextMenuService.setCallbackHandler(id, func);

        var child = new Tfsi.Shell.MenuItem();
        child.SetManagedMenuItem(managedChildMenuItem);
        child.set_Func(func);
        this._addChild(child);

        return child;
    },
    addSeparator : function(){
        this._managedMenuItem.AddSeparator();
    }
}

Tfsi.Shell.MenuItem.registerClass('Tfsi.Shell.MenuItem', Tfsi.Shell.MenuItemBase);

//MenuContextItem
Tfsi.Shell.MenuContextItem = function(contextkey, contextValue, showInMenu){
    var e = Function._validateParams(arguments, [
        {name: "contextkey", type: String},
        {name: "contextValue", type: String, mayBeNull:true},
        {name: "showInMenu", type: Boolean}
    ]);
    if (e) throw e;
    this._contextkey = contextkey;
    this._contextValue = contextValue;
    this._showInMenu = showInMenu;
}
Tfsi.Shell.MenuContextItem.prototype = {
    get_ContextKey : function(){
        return this._contextkey;
    },
    get_ContextValue : function(){
        return this._contextValue;
    },
    get_ShowInMenu : function(){
        return this._showInMenu;
    }
}

Tfsi.Shell.MenuContextItem.registerClass('Tfsi.Shell.MenuContextItem', null);


//SubFunctionItem
Tfsi.Navigation.SubFunctionItem = function(id, name, contexts, menuStyle) {
    var e = Function._validateParams(arguments, [
        { name: "id", type: String },
        { name: "name", type: String },
        { name: "contexts", type: Tfsi.StringDictionary, mayBeNull: true, optional: true },
        { name: "menuStyle", type: Tfsi.Navigation.SubFunctionMenuStyle, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    this._id = id;
    this._name = name;
    this._contexts = contexts;
    this._menuStyle = menuStyle;

    var contextNames = new Tfsi.StringCollection();
    if (!contexts) {
        contexts = new Tfsi.StringDictionary();
    }
    else {
        var actionContexts = function(key, value) {
            var contextStr = key;
            if (value && value.indexOf("%") == -1) {
                contextStr += '=' + value;
            }
            contextNames.add(contextStr);
        }
        Tfsi.StringDictionary.forEach(contexts, actionContexts, this);
    }

    var managedStringStringDictionary = contexts.ManagedStringStringDictionary();
    var _menuStyle = Tfsi.Navigation.SubFunctionMenuStyle.none;
    if (menuStyle) {
        this._menuStyle = menuStyle;
    }
    var subFunctionItemArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    subFunctionItemArgs.Add(id);
    subFunctionItemArgs.Add(name);
    subFunctionItemArgs.Add(contextNames.get_Items());

    subFunctionItemArgs.Add(_menuStyle);

    var subFunctionItemArgsTypes = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    subFunctionItemArgsTypes.Add(null);
    subFunctionItemArgsTypes.Add(null);
    var throwOnError = false;
    subFunctionItemArgsTypes.Add(null);
    var menuItemStyleArgType = Tfsi._serviceFactory.FindType("Thomson.Financial.Framework.Managed.Navigation.SubFunctionMenuStyle, Thomson.Financial.Framework.ManagedFsi", throwOnError);
    subFunctionItemArgsTypes.Add(menuItemStyleArgType);
    this._managedSubFunctionItem = Tfsi._serviceFactory.CreateInstanceWithArgsAndTypes("Thomson.Financial.Framework.Managed.Navigation.SubFunctionItem, Thomson.Financial.Framework.ManagedFsi", subFunctionItemArgs, subFunctionItemArgsTypes);
}

Tfsi.Navigation.SubFunctionItem.prototype = {
    ManagedSubFunctionItem : function(){
        return this._managedSubFunctionItem;
    },
    get_Id : function(){
        return this._managedSubFunctionItem.Id;
    },
    get_Name : function(){
        return this._managedSubFunctionItem.Name;
    },
    get_Contexts : function(){
        return this._contexts;
    },
    get_MenuStyle : function(){
        return this._menuStyle;
    }
}

Tfsi.Navigation.SubFunctionItem.registerClass('Tfsi.Navigation.SubFunctionItem', null);

//SubFunctionItemList
Tfsi.Navigation.SubFunctionItemList = function(managedSubFunctionItemList){
    var e = Function._validateParams(arguments, [
        {name: "managedSubFunctionItemList", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    if (!managedSubFunctionItemList) {
        managedSubFunctionItemList = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.SubFunctionItemList, Thomson.Financial.SmartOne.FSIScript");
    }
    this._managedSubFunctionItemList = managedSubFunctionItemList;

    if (!this._managedSubFunctionItemList){
        // throw an exception
    }
}

Tfsi.Navigation.SubFunctionItemList.prototype = {
    ManagedSubFunctionItemList : function(){
        return this._managedSubFunctionItemList;
    },

    addItem : function(id, name, contexts, menuStyle){
        var item = new Tfsi.Navigation.SubFunctionItem(id, name, contexts, menuStyle);
        this.add(item);
        return item;
    },

    add : function(item){
        var e = Function._validateParams(arguments, [
            {name: "item", type: Tfsi.Navigation.SubFunctionItem}
        ]);
        if (e) throw e;
        var managedSubFunctionItem = item.ManagedSubFunctionItem();
        this._managedSubFunctionItemList.Add(managedSubFunctionItem);
    },

    remove : function(id){
        var e = Function._validateParams(arguments, [
            {name: "id", type: String}
        ]);
        if (e) throw e;
        this._managedSubFunctionItemList.Remove(id);
    },
    clear : function(){
        _managedSubFunctionItemList.Clear()
    },

    _get_Items : function() {
        return _managedSubFunctionItemList.SubFunctionItems;
    }

}

Tfsi.Navigation.SubFunctionItemList.registerClass('Tfsi.Navigation.SubFunctionItemList', null);

Tfsi.Navigation.SubFunctionItemList.forEach = function(subFunctionItemList, method, instance){
    var e = Function._validateParams(arguments, [
        {name: "subFunctionItemList", type: Tfsi.Navigation.SubFunctionItemList},
        {name: "method", type: Function},
        {name: "instance", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;
    var items = subFunctionItemList._get_Items();
    for (var i=0;i< items.length; i++) {

        if(method.call(instance, items[i])){
            break;
        }
    }
}

//SubFunctionInvokedEventArgs 

Tfsi.Navigation.SubFunctionInvokedEventArgs = function(currentValue) {
    var e = Function._validateParams(arguments, [
        {name: "currentValue", type: String}
    ]);
    if (e) throw e;
    Tfsi.Preferences.PreferencesChangedEventArgs.initializeBase(this);
    this._currentValue = currentValue;
}

Tfsi.Navigation.SubFunctionInvokedEventArgs.prototype = {

    get_CurrentSubFunction : function() {
        return this._currentValue;
    }
}

Tfsi.Navigation.SubFunctionInvokedEventArgs.registerClass('Tfsi.Navigation.SubFunctionInvokedEventArgs', Sys.EventArgs);

//PreferencesChangedEventArgs

Tfsi.Preferences.PreferencesChangedEventArgs= function(updatedPreferences) {
    var e = Function._validateParams(arguments, [
        {name: "updatedContext", type: Tfsi.Preferences.PreferenceDictionary}
    ]);
    if (e) throw e;
    Tfsi.Preferences.PreferencesChangedEventArgs.initializeBase(this);
    this._updatedPreferences = updatedPreferences;
    var managedStringPreferenceItemDictionary = null;
    if (updatedPreferences) {
        managedStringPreferenceItemDictionary = updatedPreferences.ManagedPreferenceDictionary();
    }
    else {
        // Create an empty StringPreferenceItemDictionary
        managedStringPreferenceItemDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Preferences.StringPreferenceItemDictionary, ManagedFsiCom");
    }

    var args = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    args.Add(managedStringPreferenceItemDictionary);

    this._preferencesChangedEventArgs = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Preferences.PreferencesChangedEventArgs, Thomson.Financial.Framework.ManagedFsi", args);

}

Tfsi.Preferences.PreferencesChangedEventArgs.prototype = {
    ManagedPreferencesChangedEventArgs : function(){
        return this._preferencesChangedEventArgs;
    },
    get_UpdatedPreferences : function() {
        return this._updatedPreferences;
    }
}

Tfsi.Preferences.PreferencesChangedEventArgs.registerClass('Tfsi.Preferences.PreferencesChangedEventArgs', Sys.EventArgs);

//PreferenceItem

Tfsi.Preferences.PreferenceItem= function(id, value) {
    var e = Function._validateParams(arguments, [
        {name: "id", type: String},
        {name: "value", type: String, mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    if (value != null){
        var readOnly = false;
        var preferenceItemArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
        preferenceItemArgs.Add(id);
        preferenceItemArgs.Add(value);
        preferenceItemArgs.Add(readOnly);
        this._managedPreferenceItem = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Preferences.PreferenceItem, Thomson.Financial.Framework.ManagedFsi", preferenceItemArgs);

        if (!this._managedPreferenceItem){
            // throw an exception
        }
    }
}

Tfsi.Preferences.PreferenceItem.prototype = {
    ManagedPreferenceItem : function(){
        return this._managedPreferenceItem;
    },
    get_Key : function(){
        return this._managedPreferenceItem.Key;
    },
    get_ReadOnly : function() {
        return this._managedPreferenceItem.ReadOnly;
    },
    get_Value : function () {
        return this._managedPreferenceItem.Value;
    },
    SetManagedPreferenceItem : function (managedPreferenceItem){
        this._managedPreferenceItem = managedPreferenceItem;
    }
}

Tfsi.Preferences.PreferenceItem.registerClass('Tfsi.Preferences.PreferenceItem', null);

//PreferenceDictionary
Tfsi.Preferences.PreferenceDictionary= function(managedPreferenceDictionary) {
    var e = Function._validateParams(arguments, [
        {name: "managedPreferenceDictionary", mayBeNull: true, optional: true}
    ]);
    if (e) throw e;

    if (!managedPreferenceDictionary) {
        managedPreferenceDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Preferences.StringPreferenceItemDictionary, ManagedFsiCom");
    }
    this._managedPreferenceDictionary = managedPreferenceDictionary;

    if (!this._managedPreferenceDictionary){
        // throw an exception
    }
}

Tfsi.Preferences.PreferenceDictionary.prototype = {
    ManagedPreferenceDictionary : function(){
        return this._managedPreferenceDictionary;
    },
    get_Item : function(key){
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e) throw e;

        if(!this.containsKey(key)) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        var managedPreferenceItem = this._managedPreferenceDictionary.Item(key);

        // Create a Tfsi.Preferences.PreferenceItem to wrap the managed PreferenceItem        
        var item = new Tfsi.Preferences.PreferenceItem(key, null);
        item.SetManagedPreferenceItem(managedPreferenceItem);
        return item;
    },
    get_Keys : function() {
        var managedStringCollection = this._managedPreferenceDictionary.Keys;
        var keys = Tfsi._buildStringArray(managedStringCollection);
        return keys;
    },
    get_Count : function() {
        var count = this._managedPreferenceDictionary.Count;
        return count;
    },
    containsKey : function(key){
        var e = Function._validateParams(arguments, [
            {name: "key", type: String}
        ]);
        if (e) throw e;

        var value = this._managedPreferenceDictionary.ContainsKey(key);
        return value;
    }
}

Tfsi.Preferences.PreferenceDictionary.registerClass('Tfsi.Preferences.PreferenceDictionary', null);

Tfsi.Preferences.PreferenceDictionary.forEach = function(dictionary, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "dictionary", type: Tfsi.Preferences.PreferenceDictionary },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var keys = dictionary.get_Keys();
    var preferenceItem;
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        preferenceItem = dictionary.get_Item(key);
        if (method.call(instance, key, preferenceItem)) {
            break;
        }
    }
}

//ITransformResult
Tfsi.Context.TransformResult = function(transformedContext, status) {
    var e = Function._validateParams(arguments, [
        { name: "transformedContext", type: Tfsi.Context.ContextValue, mayBeNull: true },
        { name: "status", type: Tfsi.Context.TransformContextStatus }
    ]);
    if (e) throw e;
    Tfsi.Context.TransformResult.initializeBase(this);
    this._transformedContext = transformedContext;
    this._status = status;
}

Tfsi.Context.TransformResult.prototype = {
    ManagedTransformResult : function(){
        return this._transformResult;
    },
    get_Result : function() {
        return this._transformedContext;
    },
    get_Status : function() {
        return this._status;
    },
    SetTransformResult : function(managedTransformResult) {
        this._managedTransformResult = managedTransformResult;
    }
}

Tfsi.Context.TransformResult.registerClass('Tfsi.Context.TransformResult', null);

// FSI services

//_Context
Tfsi.Context._Context = function() {
    Tfsi.Context._Context.initializeBase(this);
    var contextService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Context.IContextService");
    this._contextService = contextService;

    this._contextChangedHandler = null;
    this._transformCompletedHandler = null;
    var callbackScriptKey = contextService.ContextChangedCallbackScriptKey;
    contextService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Context_CallbackHandler");
    var transformCallbackScriptKey = contextService.TransformCompletedCallbackScriptKey;
    contextService.RegisterCallbackScript(transformCallbackScriptKey, "Tfsi_Context_TransformCallbackHandler");
}

Tfsi.Context._Context.prototype = {
    //
    setContexts: function(contextDict, updateOnly) {
        Tfsi.Context._Context.callBaseMethod(this, 'setContexts', [contextDict, updateOnly]);

        if (contextDict.get_Count() == 0) {
            throw Error.argument(contextDict, "contextDict is empty.");
        }

        var managedStringContextValueDictionary = contextDict.ManagedStringContextValueDictionary();
        var innerManagedContextDictionary = managedStringContextValueDictionary.Dictionary;

        this._contextService.SetContexts(innerManagedContextDictionary, updateOnly);

    },
    //
    setContext: function(name, value, updateOnly) {
        Tfsi.Context._Context.callBaseMethod(this, 'setContext', [name, value, updateOnly]);

        if (!this.isContextSupported(name)) {
            return;
            //throw new Error.fsiContextAccessDeniedException();
        }
        this._contextService.SetContext(name, value, updateOnly);
    },
    // Returns a Tfsi.Context.ContextDictionary
    getContexts: function() {
        var innerStringContextItemDictionary = this._contextService.GetContexts();
        var managedStringContextItemDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextItemDictionary, ManagedFsiCom");
        managedStringContextItemDictionary.Dictionary = innerStringContextItemDictionary;
        var contextDictionary = new Tfsi.Context.ContextDictionary(managedStringContextItemDictionary);
        return contextDictionary;
    },
    // Returns a Tfsi.Context.ContextItem
    getContext: function(key) {
        Tfsi.Context._Context.callBaseMethod(this, 'getContext', [key]);

        var name = key;
        if (name == "Entity") {
            name = "Symbol";
        }

        var managedContextItem = this._contextService.GetContext(name);

        var contextItem = null;
        if (managedContextItem) {
            // Create a Tfsi.Context.ContextItem to wrap the managed ContextItem        
            contextItem = new Tfsi.Context.ContextItem(key, null);
            contextItem.SetManagedContextItem(managedContextItem);
        }
        return contextItem;
    },
    setContextHandler: function(handler) {
        Tfsi.Context._Context.callBaseMethod(this, 'setContextHandler', [handler]);
        this._contextChangedHandler = handler;
    },
    //    get_Name : function(){
    //        return this._name;
    //    },
    _contextChangedCallback: function(sender, event) {
        var contextHandler = this._contextChangedHandler;
        if (contextHandler == null) {
            return true;
        }

        var innerStringContextItemDictionary = event.UpdatedContext;
        var managedStringContextItemDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextItemDictionary, ManagedFsiCom");
        managedStringContextItemDictionary.Dictionary = innerStringContextItemDictionary;
        var updatedContext = new Tfsi.Context.ContextDictionary(managedStringContextItemDictionary);
        var eventArgs = new Tfsi.Context.ContextChangedEventArgs(updatedContext, event.Subfunction, event.CommandArgs, event.ContextChangedReason);
        if (contextHandler(this, eventArgs)) {
            return true;
        }
        return false;
    },
    isContextSupported: function(key) {
        Tfsi.Context._Context.callBaseMethod(this, 'isContextSupported', [key]);

        if (this._contextService.IsContextSupported(key)) {
            return true;
        }
        return false;
    },
    transform: function(ctxValue, ctxInFormat, ctxOutFormat, handler) {
        var e = Function._validateParams(arguments, [
            { name: "ctxValue", type: String },
            { name: "ctxInFormat", type: String, mayBeNull: true, optional: true },
            { name: "ctxOutFormat", type: String, mayBeNull: true, optional: true },
            { name: "handler", type: Function, mayBeNull: true, optional: true }

        ]);
        if (e) throw e;

        var returnValue = ctxValue;

        // Hack for next news
        var entity = ctxValue;
        try
        {
            entity= entity.replace(/&amp;/g,"&");
            entity= entity.replace(/&quot;/g,'"');
            entity= entity.replace(/&apos;/g,"'");
            entity= entity.replace(/&gt;/g,">");
            entity= entity.replace(/&lt;/g,"<");
        }
        catch (e)
        {
        }
        // End of hack

        var context = new Tfsi.KeyedItemDictionary();

        context.add("Entity", entity);

        var managedStringContextValueDictionary = context.ManagedStringContextValueDictionary();
        var innerManagedContextDictionary = managedStringContextValueDictionary.Dictionary;
        if (handler) {
            this._transformCompletedHandler = handler;
            this._contextService.Transform(innerManagedContextDictionary);
        }
        else {
            returnValue = this._contextService.TransformContextSync(innerManagedContextDictionary, ctxOutFormat);
        }
        return returnValue;
    },
    transformcontextsyncwithstatus: function(context, contextValueIn) {
        var e = Function._validateParams(arguments, [
            { name: "context", type: String },
            { name: "contextValueIn", type: Tfsi.Context.ContextValue }
        ]);
        if (e) throw e;
        var transformResult = null;
        var managedContextValue = contextValueIn.ManagedContextValue();
        var managedTransformResult = this._contextService.TransformContextSyncWithStatus(context, managedContextValue);
        if(managedTransformResult)
        {
            var item = new Tfsi.Context.ContextValue(context, null);
            item.SetManagedContextValue(managedTransformResult.Result);
            transformResult = new Tfsi.Context.TransformResult(item, managedTransformResult.Status);
            transformResult.SetTransformResult(managedTransformResult);
        }
        return transformResult;
    },
    transformContext: function(contextValueIn, outFormatFilter, handler) {
        var e = Function._validateParams(arguments, [
            { name: "contextValueIn", type: Tfsi.Context.ContextValue },
            { name: "outFormatFilter", type: Tfsi.StringDictionary, mayBeNull: true },
            { name: "completedHandler", type: Function }
        ]);
        if (e) throw e;
        var managedContextValue = contextValueIn.ManagedContextValue();
        var context = new Tfsi.KeyedItemDictionary();
        context.add(contextValueIn.get_Name(), contextValueIn);
        var managedStringContextValueDictionary = context.ManagedStringContextValueDictionary();
        var innerManagedContextDictionary = managedStringContextValueDictionary.Dictionary;
        this._transformCompletedHandler = handler;
        this._contextService.Transform(innerManagedContextDictionary);

    },
    setTransformCompletedHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
        Tfsi.Context._Context.callBaseMethod(this, 'setTransformCompletedHandler', [handler]);
        this._transformCompletedHandler = handler;
    },
    _transformCompletedCallback: function(sender, event) {
        var transformCompletedHandler = this._transformCompletedHandler;
        if (transformCompletedHandler == null) {
            return true;
        }

        var innerStringContextValueDictionary = event.Result;
        var managedStringContextValueDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextValueDictionary, ManagedFsiCom");
        managedStringContextValueDictionary.Dictionary = innerStringContextValueDictionary;
        var transformedContext = new Tfsi.KeyedItemDictionary();
        transformedContext.SetManagedStringContextValueDictionary(managedStringContextValueDictionary);
        var eventArgs = new Tfsi.Context.TransformCompletedEventArgs(transformedContext, event.Status);
        if (transformCompletedHandler(this, eventArgs)) {
            return true;
        }
        return false;
    }
}

Tfsi.Context._Context.registerClass('Tfsi.Context._Context', Tfsi.Context._ContextBase, Tfsi.Context.IContextBroker);

function Tfsi_Context_CallbackHandler(sender, event) {
    var contextService = Tfsi.ServiceFactory.getService('IContext');
    if (contextService._contextChangedCallback != null) {
        if (!contextService._contextChangedCallback(sender, event)) {
            return true;
        }
    }

    return false;
}

function Tfsi_Context_TransformCallbackHandler(sender, event) {
    var contextService = Tfsi.ServiceFactory.getService('IContext');
    if (contextService._transformCompletedCallback != null) {
        if (!contextService._transformCompletedCallback(sender, event)) {
            return true;
        }
    }

    return false;
}

//TransformCompletedEventArgs
Tfsi.Context.TransformCompletedEventArgs = function(transformedContext, status) {
    var e = Function._validateParams(arguments, [
        { name: "transformedContext", type: Tfsi.KeyedItemDictionary, mayBeNull: true },
        { name: "status", type: Tfsi.Context.TransformContextStatus }
    ]);
    if (e) throw e;
    Tfsi.Context.TransformCompletedEventArgs.initializeBase(this);
    this._transformedContext = transformedContext;
    this._status = status;
    /*     
     var managedStringContextValueDictionary = null;
     if (transformedContext) {
     managedStringContextValueDictionary = transformedContext;
     }
     else {
     // Create an empty StringContextValueDictionary
     managedStringContextValueDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Context.StringContextValueDictionary, ManagedFsiCom");
     }

     var args = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
     args.Add(managedStringContextValueDictionary.Dictionary);

     this._transformCompletedEventArgs = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Context.TransformCompletedEventArgs, Thomson.Financial.Framework.ManagedFsi", args);
     */
}

Tfsi.Context.TransformCompletedEventArgs.prototype = {
    ManagedTransformCompletedEventArgs : function(){
        return this._transformCompletedEventArgs;
    },
    get_Result : function() {
        return this._transformedContext;
    },
    get_Status : function() {
        return this._status;
    },
    SetTransformCompletedEventArgs : function(managedTransformCompletedEventArgs) {
        this._managedTransformCompletedEventArgs = managedTransformCompletedEventArgs;
    }
}

Tfsi.Context.TransformCompletedEventArgs.registerClass('Tfsi.Context.TransformCompletedEventArgs', Sys.EventArgs);

Tfsi.Context._dictionaryToString = function(contextDict){
    var e = Function._validateParams(arguments, [
        {name: "contextDict", type: Tfsi.Context.KeyItemedDictionary}
    ]);
    if (e) throw e;

    var items = contextDict._get_Items();

    var contextStr;

    for(var key in items){
        var name = key;
        if(key == "Entity"){
            name = "Symbol";
        }
        if(key == "SubFunction"){
            continue;
        }
        var itemValue = items[key];
        var value;
        if(typeof itemValue == "string") {
            value = itemValue;
        }
        else if(Tfsi.Context.ContextValue.isInstanceOfType(itemValue)){
            value = itemValue.get_Value();
        }
        if(contextStr){
            contextStr += ";";
            contextStr += name + "=" + value;
        }
        else{
            contextStr = name + "=" + value;
        }


    }

    return contextStr;
}

Tfsi.Navigation._Drilldown = function() {
    Tfsi.Navigation._Drilldown.initializeBase(this);
    var drilldownService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Navigation.IDrilldownService");
    this._drilldownService = drilldownService;

    this._drilldownChangedHandler = null;
    var callbackScriptKey = drilldownService.DrilldownChangedCallbackScriptKey;
    drilldownService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Drilldown_CallbackHandler");
}

Tfsi.Navigation._Drilldown.prototype = {
    register : function(drilldownList,handler){
        Tfsi.Navigation._Drilldown.callBaseMethod(this, 'register', [drilldownList,handler]);

        this._drilldownService.Clear();
        this._drilldownChangedHandler = handler;

        var managedDrilldownItems = drilldownList.ManagedDrilldownItemList();
        var innerManagedDrilldownItems = managedDrilldownItems.Items;
        this._drilldownService.Register(innerManagedDrilldownItems, null);
    },
    clear : function(){
        this._drilldownChangedHandler = null;
        this._drilldownService.Clear();
    },

    invoke : function(id, contextDict, commandArgs, resetTarget, windowFeatures){
        Tfsi.Navigation._Drilldown.callBaseMethod(this, 'invoke', [id, contextDict, commandArgs, resetTarget, windowFeatures]);

        var _resetTarget=false;
        if (resetTarget) {
            _resetTarget=true;
        }

        if (!commandArgs) {
            commandArgs = "";
        }

        if (!contextDict){
            contextDict = new Tfsi.KeyedItemDictionary();
        }
        var managedStringContextValueDictionary = contextDict.ManagedStringContextValueDictionary();
        var innerManagedContextDictionary = managedStringContextValueDictionary.Dictionary;
        var windowFeature = new Tfsi.Navigation.WindowFeatures(windowFeatures);

        var managedwindowFeatures = windowFeature.ManagedWindowFeatures();


        this._drilldownService.InvokeDrilldown(id, innerManagedContextDictionary, commandArgs, _resetTarget, managedwindowFeatures);
    },

    openThomletInFrame : function(frame,thomletId, contextDict, commandArgs, sessionPersistent, lockWindow){
        Tfsi.Navigation._Drilldown.callBaseMethod(this, 'openThomletInFrame', [frame,thomletId, contextDict, commandArgs, sessionPersistent, lockWindow]);

    },

//    get_Name : function(){
//        return this._name;
//    },

    _drilldownChangedCallback : function(sender, event) {
        var drilldownHandler = this._drilldownChangedHandler;
        if (drilldownHandler == null) {
            return true;
        }

        var eventArgs = new Tfsi.Navigation.DrilldownChangedEventArgs(event.Id, event.TargetInfo, event.Enabled);
        if (drilldownHandler(this, eventArgs)) {
            return true;
        }
        return false;
    }
}

Tfsi.Navigation._Drilldown.registerClass('Tfsi.Navigation._Drilldown', Tfsi.Navigation._DrilldownBase, Tfsi.Navigation.IDrilldown);

function Tfsi_Drilldown_CallbackHandler(sender, event) {

    var drilldownService = Tfsi.ServiceFactory.getService('IDrilldown');
    if (drilldownService._drilldownChangedCallback != null) {
        if (!drilldownService._drilldownChangedCallback(sender, event)) {
            return true;
        }
    }

    return false;
}


//ContextMenu
//override for thin
Tfsi.Shell.MenuSeparator.prototype._toStringHelper = function(sb) {
    var e = Function._validateParams(arguments, [
        {name: "sb", type: Sys.StringBuilder}
    ]);
    if (e) throw e;
    sb.append('<menuitem id="' + this._id + '"/>');
}

Tfsi.Shell.MenuItem.prototype._toStringHelper = function(sb) {
    var e = Function._validateParams(arguments, [
        {name: "sb", type: Sys.StringBuilder}
    ]);
    if (e) throw e;
    var children = this.get_Children();

    //root node
    if(!this._parent) {
        sb.append('<custommenu>');
        for(var i=0; i < children.length;i++) {
            sb.append(children[i]._toStringHelper(sb));
        }
        sb.append('</custommenu>');
        return;
    }
    //regular menu item
    sb.append('<menuitem id="' + this._id + '" name="' + this._name + '" enabled="' + this._enabled +'"');
    if(children.length == 0) {
        sb.append('/>');
    }
    else {
        sb.append('>');
        for(var i=0; i < children.length;i++) {
            sb.append(children[i]._toStringHelper(sb));
        }
        sb.append('</menuitem>');
    }
}

//_ContextMenu
Tfsi.Shell._ContextMenuService = function() {
    Tfsi.Shell._ContextMenuService.initializeBase(this);
    var contextMenuService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Shell.IContextMenuService");
    this._contextMenuService = contextMenuService;

    var callbackScriptKey = contextMenuService.MenuItemClickCallbackScriptKey;
    contextMenuService.RegisterCallbackScript(callbackScriptKey, "Tfsi_ContextMenu_CallbackHandler");

    this._callbackHandlers = new Array();
    this._managedMenuContextItemCollection = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.Shell.MenuContextItemCollection, ManagedFsiCom");
}

Tfsi.Shell._ContextMenuService.prototype = {
    ManagedContextMenuService: function() {
        return this._contextMenuService;
    },
    add: function(rootMenuItem) {
        Tfsi.Shell._ContextMenuService.callBaseMethod(this, 'add', [rootMenuItem]);

        var fsiMenuItem = rootMenuItem.ManagedMenuItem();
        var menuItemsCount = fsiMenuItem.MenuItemsCount;
        var rootMenuItemChildren = rootMenuItem.get_Children();
        var count = rootMenuItemChildren.length;
        if (menuItemsCount == 0 && count != 0) {
            try {
                this.clear();
                for (var i = 0; i < count; i++) {
                    var child = rootMenuItemChildren[i];
                    var managedChildMenuItem = child.ManagedMenuItem();
                    fsiMenuItem.AddChild(managedChildMenuItem);
                }
                menuItemsCount = fsiMenuItem.MenuItemsCount;
            } catch (e) {
            }
        }

        var managedMenuItemCollection = fsiMenuItem.MenuItems;

        fsiMenuItem.ClearItems();
        this._contextMenuService.SetMenuItems(managedMenuItemCollection);
    },
    clear: function() {
        this._contextMenuService.Clear();
    },
    removeFromContextMenu: function(menuItemName) {
        Tfsi.Shell._ContextMenuService.callBaseMethod(this, 'removeFromContextMenu', [menuItemName]);
        try {
            this._contextMenuService.RemoveFromContextMenu(menuItemName);
        }
        catch (e) {
        }
    },
    contextMenu: function(xPos, yPos, srcElement, contextMenuSections) {
        Tfsi.Shell._ContextMenuService.callBaseMethod(this, 'contextMenu', [xPos, yPos, srcElement, contextMenuSections]);

        var innerManagedMenuContextItems = this._managedMenuContextItemCollection.MenuContextItems;
        var commandArgs = "";
        if (contextMenuSections == undefined) {
            contextMenuSections = Tfsi.Shell.ContextMenuSections.all;
        }

        var innerManagedMenuContextItems = this._managedMenuContextItemCollection.MenuContextItems;
        this._contextMenuService.ShowContextMenu(xPos, yPos, innerManagedMenuContextItems, commandArgs, contextMenuSections);

    },
    setMenuContextItems: function(menuContextItemList) {
        Tfsi.Shell._ContextMenuService.callBaseMethod(this, 'setMenuContextItems', [menuContextItemList]);

        this._managedMenuContextItemCollection.Clear();

        var action = function(menuContextItem) {
            var contextKey = menuContextItem.get_ContextKey();
            var value = menuContextItem.get_ContextValue();
            var header = "";
            if (contextKey == "Entity") {
                contextKey = "Symbol";
            }

            var contextValue = new Tfsi.Context.ContextValue(contextKey, value);
            managedContextValue = contextValue.ManagedContextValue();

            var menuContextItemArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
            menuContextItemArgs.Add(contextKey);
            menuContextItemArgs.Add(managedContextValue);
            menuContextItemArgs.Add(header);
            menuContextItemArgs.Add(menuContextItem.get_ShowInMenu());
            var managedMenuContextItem = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Shell.MenuContextItem, Thomson.Financial.Framework.ManagedFsi", menuContextItemArgs);

            this._managedMenuContextItemCollection.Add(managedMenuContextItem);
        }
        Tfsi.Shell.MenuContextItemList.forEach(menuContextItemList, action, this);

        var menuContextItems = this._managedMenuContextItemCollection.MenuContextItems;
        this._contextMenuService.SetMenuContextItems(menuContextItems);
    },
    setCallbackHandler: function(id, func) {
        this._callbackHandlers[id] = func;
    },
    getCallbackHandler: function(id) {
        return this._callbackHandlers[id];
    }
}

Tfsi.Shell._ContextMenuService.registerClass('Tfsi.Shell._ContextMenuService', Tfsi.Shell._ContextMenuBase, Tfsi.Shell.IContextMenu);

//callback
function Tfsi_ContextMenu_CallbackHandler(sender, event) {

    var contextMenuService = Tfsi.ServiceFactory.getService('IContextMenu');
    var id = sender.Id;
    var func = contextMenuService.getCallbackHandler(id);
    if (func != null) {
        var menuItem = new Tfsi.Shell.MenuItem();
        menuItem.SetManagedMenuItem(sender);
        if (!func(menuItem, new Sys.EventArgs())) {
            return true;
        }
    }

    return false;
}

Tfsi.Navigation._SubFunctionService = function() {
    Tfsi.Navigation._SubFunctionService.initializeBase(this);
    this._subFunctionService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Navigation.ISubFunctionService");

    this._handler = null;
    this._itemList=null;
}
Tfsi.Navigation._SubFunctionService.prototype = {
    add: function(subFunctionItemList) {
        Tfsi.Navigation._SubFunctionService.callBaseMethod(this, 'add', [subFunctionItemList]);

        this._clear = false;
        this._itemList = subFunctionItemList;
        var managedSubFunctionItems = subFunctionItemList.ManagedSubFunctionItemList();
        var innerManagedSubFunctionItems = managedSubFunctionItems.Items;
        this._subFunctionService.Add(innerManagedSubFunctionItems);
    },

    clear : function(){
        this._subFunctionService.Clear();
        this._clear = true;
    }
}

Tfsi.Navigation._SubFunctionService.registerClass('Tfsi.Navigation._SubFunctionService', Tfsi.Navigation._SubFunctionBase, Tfsi.Navigation.ISubFunction);

function HandleSetSubFunctionsList_TF(subFunctions){

    var sfService = Tfsi.ServiceFactory.getService("ISubFunction");
    if(sfService._clear){
        var action = function(item){
            var contextRequirments = item.get_ContextRequirments();
            var name = item.get_Name();
            var menuStyle = item.get_MenuStyle();

            if(menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.showInNavTree){
                //window.external.FireOnAddSubFunction(name);
            }
        }
        Tfsi.Navigation.SubFunctionItemList.forEach(sfService._itemList, action, sfService);
        //window.external.FireOnSetSubFunctionsFinished();
        sfService._clear = false;
    }
}

//IPropertyBag
Tfsi.Shell._PropertyBagService = function() {
    Tfsi.Shell._PropertyBagService.initializeBase(this);
    var propertyBagService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Shell.IPropertyBagService");

    var managedStringStringDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.StringStringDictionary, ManagedFsiCom");
    managedStringStringDictionary.Dictionary = propertyBagService.PropertyBag;
    this._managedPropertyBagDictionary = managedStringStringDictionary;
}
Tfsi.Shell._PropertyBagService.prototype = {
    add : function(key, value){
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'add', [key, value]);

        if(this.containsKey(key)){
            throw Error.argument(key, "An element with the same key already exists in the PropertyBag.")
        }
        this.set_Item(key, value);
    },
    set_Item : function(key, value){
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'set_Item', [key, value]);

        this._managedPropertyBagDictionary.Item(key) = value;
    },
    set_Items : function(keyedItemDict){
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'set_Items', [keyedItemDict]);

        var action = function(key,value){

            this.set_Item(key, value);
        }
        Tfsi.KeyedItemDictionary.forEach(keyedItemDict,action,this);
    },
    get_Item : function(key){
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'get_Item', [key]);

        if (!this.containsKey(key))
        {
            return null;
        }
        var item = this._managedPropertyBagDictionary.Item(key);
        return item;

    },
    get_Keys : function(){
        var managedStringCollection = _managedPropertyBagDictionary.Keys;
        var keys = Tfsi._buildStringArray(managedStringCollection);
        return keys;
    },
    containsKey : function(key){
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'containsKey', [key]);

        var value = this._managedPropertyBagDictionary.ContainsKey(key);
        return value;
    },
    clear : function(){
        this._managedPropertyBagDictionary.Clear();
    },
    remove : function(key){
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'remove', [key]);

        this._managedPropertyBagDictionary.Remove(key);
    },
    get_Count : function() {
        var count = this._managedPropertyBagDictionary.Count;
        return count;
    },
    forEach : function(action) {
        Tfsi.Shell._PropertyBagService.callBaseMethod(this, 'forEach', [action]);

        var keys = get_Keys();
        var item;
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            item = get_Item(key);
            if(action.call(key, item, this)){
                break;
            }
        }
    }
}

Tfsi.Shell._PropertyBagService.registerClass('Tfsi.Shell._PropertyBagService', Tfsi.Shell._PropertyBagBase, Tfsi.Shell.IPropertyBag);

//_Preference
Tfsi.Preferences._Preference = function() {
    Tfsi.Preferences._Preference.initializeBase(this);
    var preferenceService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Preferences.IPreferenceService");
    this._preferenceService = preferenceService;

    this._preferenceChangedHandler = null;
    var callbackScriptKey = preferenceService.PreferencesChangedCallbackScriptKey;
    preferenceService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Preferences_CallbackHandler");
}

Tfsi.Preferences._Preference.prototype = {
    setPreference : function(key, value){
        Tfsi.Preferences._Preference.callBaseMethod(this, 'setPreference', [key, value]);

        if(!this.isPreferenceSupported(key)){
            throw new Error.fsiPreferenceAccessDeniedException();
        }

        var updateOnly = true;
        this._preferenceService.SetPreference(key, value, updateOnly);
    },
    setPreferences : function(preferenceDict){
        Tfsi.Preferences._Preference.callBaseMethod(this, 'setPreferences', [preferenceDict]);

        if(preferenceDict.get_Count() == 0){
            throw Error.argument(preferenceDict, "preferenceDict is empty.");
        }

        var updateOnly = true;
        var managedStringStringDictionary = preferenceDict.ManagedPreferenceDictionary();
        var innerManagedStringStringDictionary = managedStringStringDictionary.Dictionary;
        this._preferenceService.SetPreferences(innerManagedStringStringDictionary, updateOnly);
    },
    // Returns Tfsi.Preferences.PreferenceDictionary
    getPreferences : function(){
        var managedStringPreferenceItemDictionary = this._preferenceService.GetPreferences();
        var preferenceDictionary = new Tfsi.Preferences.PreferenceDictionary(managedStringPreferenceItemDictionary);
        return preferenceDictionary;
    },
    // Returns Tfsi.Context.PreferenceItem(
    getPreference : function(key){
        Tfsi.Preferences._Preference.callBaseMethod(this, 'getPreference', [key]);

        var name = key;
        //if(name == "Entity"){
        //    name = "Symbol";
        //}
        var managedPreferenceItem = this._preferenceService.GetPreference(name);

        var preferenceItem = null;
        if (managedPreferenceItem){
            // Create a Tfsi.Context.PreferenceItem to wrap the managed PreferenceItem
            preferenceItem = new Tfsi.Preferences.PreferenceItem(key, null);
            preferenceItem.SetManagedPreferenceItem(managedPreferenceItem);
        }
        return preferenceItem;
    },
    setPreferenceChangedHandler : function(handler){
        var e = Function._validateParams(arguments, [
            {name: "handler", type: Function, mayBeNull: true}
        ]);
        if (e) throw e;

        this._preferencesChangedHandler = handler;
    },
//    get_Name : function(){
//        return this._name;
//    },
    _preferencesChangedCallback : function(sender, event) {
        var preferenceHandler = this._preferencesChangedHandler;
        if( preferenceHandler == null) {
            return true;
        }

        var managedStringPreferenceItemDictionary = event.UpdatedPreferences;
        var updatedPreferences = new Tfsi.Preferences.PreferenceDictionary(managedStringPreferenceItemDictionary);
        var eventArgs = new Tfsi.Preferences.PreferencesChangedEventArgs(updatedPreferences);
        if( preferenceHandler(this, eventArgs) ) {
            return true;
        }
        return false;
    },
    isPreferenceSupported : function(key){
        Tfsi.Preferences._Preference.callBaseMethod(this, 'isPreferenceSupported', [key]);

        if (this._preferenceService.IsPreferenceSupported(key)) {
            return true;
        }
        return false;
    }
}

function Tfsi_Preferences_CallbackHandler(sender, event) {

    var preferenceService = Tfsi.ServiceFactory.getService('IPreference');
    if (preferenceService._preferencesChangedCallback != null) {
        if (!preferenceService._preferencesChangedCallback(sender, event)) {
            return true;
        }
    }

    return false;
}

Tfsi.Preferences._Preference.registerClass('Tfsi.Preferences._Preference', Tfsi.Preferences._PreferenceBase, Tfsi.Preferences.IPreferenceBroker);

//IThomlet
Tfsi.Shell._ThomletService = function() {
    Tfsi.Shell._ThomletService.initializeBase(this);
    this._thomletService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Shell.IThomletService");

    this._thomletEventsObj = null;
}

Tfsi.Shell._ThomletService.prototype = {
    get_ThomletOldDomain: function() {
        this._thomletService.OldDomain;
    },
    registerEventObject: function(thomletEventsObject) {
        Tfsi.Shell._ThomletService.callBaseMethod(this, 'registerEventObject', [thomletEventsObject]);

        this._thomletEventsObject = thomletEventsObject;
        if (thomletEventsObject) {
            var callbackScriptKey = this._thomletService.VisibleChangedCallbackScriptKey;
            this._thomletService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Thomlet_VisibleChanged_CallbackHandler");

            callbackScriptKey = this._thomletService.FocusChangedCallbackScriptKey;
            this._thomletService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Thomlet_FocusChanged_CallbackHandler");

            callbackScriptKey = this._thomletService.ListeningChangedCallbackScriptKey;
            this._thomletService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Thomlet_ListeningChanged_CallbackHandler");

            callbackScriptKey = this._thomletService.SavePropertyBagCallbackScriptKey;
            this._thomletService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Thomlet_SavePropertyBag_CallbackHandler");

            callbackScriptKey = this._thomletService.ClosingCallbackScriptKey;
            this._thomletService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Thomlet_Closing_CallbackHandler");
        }
    },
    _statusChangeCallback: function(status, statusName) {
        var thisObject = Tfsi.Shell._ThomletService;
        if (statusName == "focus") {
            thisObject._focused = status;
            if (thisObject._thomletEventsObj && thisObject._thomletEventsObj.focusChanged) {
                thisObject._thomletEventsObj.focusChanged(thisObject, new Sys.EventArgs());
            }
        }
        else if (statusName == "visibility") {
            thisObject._visible = status;
            if (thisObject.thomletEventsObject && thisObject.thomletEventsObject.focusChanged) {
                thisObject.thomletEventsObject.visibleChanged(thisObject, new Sys.EventArgs());
            }
        }
    },
    get_Visible: function() {
        return this._thomletService.Visible;
    },
    get_Focused: function() {
        return this._thomletService.HasFocused;
    },
    get_Listening: function() {
        return this._thomletService.Listening;
    },
    get_Closing: function() {
        return this._thomletService.Closing;
    },
    get_ThomletId: function() {
        return this._thomletService.ThomletId;
    },
    close: function() {
        return this._thomletService.Close;
    },
    resizeTo: function(width, height) {
        Tfsi.Shell._ThomletService.callBaseMethod(this, 'resizeTo', [width, height]);
        this._thomletService.ResizeTo(width, height);
    },
    resizeBy: function(x, y) {
        Tfsi.Shell._ThomletService.callBaseMethod(this, 'resizeBy', [x, y]);
        this._thomletService.ResizeBy(x, y);
    }
}

Tfsi.Shell._ThomletService.registerClass('Tfsi.Shell._ThomletService', Tfsi.Shell._ThomletBase,Tfsi.Shell.IThomlet);

function Tfsi_Thomlet_VisibleChanged_CallbackHandler(sender, event) {
    var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
    if (thomletService._thomletEventsObject && thomletService._thomletEventsObject.visibleChanged) {
        thomletService._thomletEventsObject.visibleChanged(thomletService, new Sys.EventArgs());
    }
}

function Tfsi_Thomlet_FocusChanged_CallbackHandler(sender, event) {
    var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
    if (thomletService._thomletEventsObject && thomletService._thomletEventsObject.focusChanged) {
        thomletService._thomletEventsObject.focusChanged(thomletService, new Sys.EventArgs());
    }
}

function Tfsi_Thomlet_ListeningChanged_CallbackHandler(sender, event) {
    var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
    if (thomletService._thomletEventsObject && thomletService._thomletEventsObject.listeningChanged) {
        thomletService._thomletEventsObject.listeningChanged(thomletService, new Sys.EventArgs());
    }
}

function Tfsi_Thomlet_Closing_CallbackHandler(sender, event) {
    var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
    if (thomletService._thomletEventsObject && thomletService._thomletEventsObject.closing) {
        var eventArgs = new Sys.CancelEventArgs();
        thomletService._thomletEventsObject.closing(thomletService, eventArgs);
        // Need the try/catch block since ExtendedClosingEventArgs was not Com visible 
        try {
            event.Cancel = eventArgs.get_cancel();
        }
        catch (e) {
        }
    }
}


//IPreferenceWindow
Tfsi.Preferences._PreferenceWindow = function() {
    Tfsi.Preferences._PreferenceWindow.initializeBase(this);
    var preferenceWindowService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Preferences.IPreferenceWindowService");
    this._preferenceWindowService = preferenceWindowService;

    this._ValidatingHandler = null;
    this._ApplyHandler = null;
    var applyCallbackScriptKey = preferenceWindowService.ApplyCallbackScriptKey;
    var validatingCallbackScriptKey = preferenceWindowService.ValidatingCallbackScriptKey;
    preferenceWindowService.RegisterCallbackScript(applyCallbackScriptKey, "Tfsi_Preferences_ApplyCallbackHandler");
    preferenceWindowService.RegisterCallbackScript(validatingCallbackScriptKey, "Tfsi_Preferences_ValidatingCallbackHandler");
}

Tfsi.Preferences._PreferenceWindow.prototype = {
    set_IsDirty : function(isDirty){
        Tfsi.Preferences._PreferenceWindow.callBaseMethod(this, 'set_IsDirty', [isDirty]);
        this._preferenceWindowService.IsDirty = isDirty;
    },
    get_IsDirty : function(){
        return this._preferenceWindowService.IsDirty();
    },
    setValidatingHandler : function(handler){
        Tfsi.Preferences._PreferenceWindow.callBaseMethod(this, 'setValidatingHandler', [handler]);
        this._ValidatingHandler = handler;
    },
    _validatingCallback : function(sender, event) {
        var validatingHandler = this._ValidatingHandler;
        if( validatingHandler == null) {
            return false;
        }
        var eventArgs = new Tfsi.Preferences.ValidatingEventArgs();
        validatingHandler(this, eventArgs)
        event.ErrorMessage = eventArgs.get_ErrorMessage();
        event.Cancel = eventArgs.get_Cancel();
        return true;
    },
    setApplyHandler : function(handler){
        Tfsi.Preferences._PreferenceWindow.callBaseMethod(this, 'setApplyHandler', [handler]);
        this._ApplyHandler = handler;
    },
    _applyCallback : function(sender, event) {
        var applyHandler = this._ApplyHandler;
        if( applyHandler == null) {
            return true;
        }

        var eventArgs = new Tfsi.Preferences.ApplyEventArgs(event.PreferenceDictionary);
        applyHandler(this, eventArgs)
        return true;
    }
}

function Tfsi_Preferences_ApplyCallbackHandler(sender, event) {
    var preferenceWindowService = Tfsi.ServiceFactory.getService('IPreferenceWindow');
    if (preferenceWindowService._applyCallback != null) {
        if (!preferenceWindowService._applyCallback(sender, event)) {
            return true;
        }
    }
    return false;
}

function Tfsi_Preferences_ValidatingCallbackHandler(sender, event) {
    var preferenceWindowService = Tfsi.ServiceFactory.getService('IPreferenceWindow');
    if (preferenceWindowService._validatingCallback != null) {
        if (!preferenceWindowService._validatingCallback(sender, event)) {
            return true;
        }
    }
    return false;
}

Tfsi.Preferences._PreferenceWindow.registerClass('Tfsi.Preferences._PreferenceWindow', Tfsi.Preferences._PreferenceWindowBase, Tfsi.Preferences.IPreferenceWindow);

//PreferenceWindow ValidatingEventArgs
Tfsi.Preferences.ValidatingEventArgs = function()
{
    this._validatingEventArgs = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Preferences.ValidatingEventArgs, Thomson.Financial.Framework.ManagedFsi");
}

Tfsi.Preferences.ValidatingEventArgs.prototype = {
    ManagedValidatingEventArgs : function(){
        return this._validatingEventArgs;
    },
    set_ErrorMessage : function(errorMessage){
        this._validatingEventArgs.ErrorMessage = errorMessage;
    },
    get_ErrorMessage : function(){
        return this._validatingEventArgs.ErrorMessage;
    },
    set_Cancel : function(cancel){
        this._validatingEventArgs.Cancel = cancel;
    },
    get_Cancel : function(){
        return this._validatingEventArgs.Cancel;
    }
}

Tfsi.Preferences.ValidatingEventArgs.registerClass('Tfsi.Preferences.ValidatingEventArgs',Sys.EventArgs);

//PreferenceWindow ApplyEventArgs
Tfsi.Preferences.ApplyEventArgs = function(preferenceDictionary)
{
    var e = Function._validateParams(arguments, [
        {name: " preferenceDictionary ", Type:Tfsi.StringDictionary}
    ]);
    if (e) throw e;
    Tfsi.Preferences.ApplyEventArgs.initializeBase(this);
    this._preferenceDictionary = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.Framework.Managed.Interop.StringStringDictionary, ManagedFsiCom");
    this._preferenceDictionary.Dictionary = preferenceDictionary ;

    var args = Tfsi._serviceFactory.CreateInstance("Thomson.Financial.SmartOne.FSIScript.ObjectList, Thomson.Financial.SmartOne.FSIScript");
    args.Add(preferenceDictionary);

    this._applyEventArgs = Tfsi._serviceFactory.CreateInstanceWithArgs("Thomson.Financial.Framework.Managed.Preferences.ApplyEventArgs, Thomson.Financial.Framework.ManagedFsi",args);
}

Tfsi.Preferences.ApplyEventArgs.prototype = {
    ManagedApplyEventArgs : function(){
        return this._applyEventArgs;
    },
    get_UpdatedPreferences : function(){
        return this._preferenceDictionary;
    }
}

Tfsi.Preferences.ApplyEventArgs.registerClass('Tfsi.Preferences.ApplyEventArgs',Sys.EventArgs);

//INavigation
Tfsi.Navigation._Navigation = function() {
    Tfsi.Navigation._Navigation.initializeBase(this);
    var navigationService = Tfsi._serviceFactory.getService("Thomson.Financial.SmartOne.ThomletHost.FrameworkServices.INavigationService, Thomson.Financial.SmartOne.Shell.Interfaces");
    this._navigationService = navigationService;

    callbackScriptKey = navigationService.RefreshCallbackScriptKey;
    this._navigationService.RegisterCallbackScript(callbackScriptKey, "Tfsi_Navigation_Refresh_CallbackHandler");
}

Tfsi.Navigation._Navigation.prototype = {
    goHome : function(){
        this._navigationService.GoHome();
    },
    navigateTo : function(relativeUrl) {
        var e = Function._validateParams(arguments, [
            {name: "relativeUrl", type: String}
        ]);
        if (e) throw e;

        this._navigationService.NavigateTo(relativeUrl);
    },
    get_OpenPopupInIE : function() {
        return this._navigationService.OpenPopupInIE;
    },
    set_OpenPopupInIE : function(openPopupInIE) {
        var e = Function._validateParams(arguments, [
            {name: "openPopupInIE", type: Boolean}
        ]);
        if (e) throw e;
        this._navigationService.OpenPopupInIE = openPopupInIE;
    },
    setRefreshHandler : function(handler){
        Tfsi.Navigation._Navigation.callBaseMethod(this, 'setRefreshHandler', [handler]);
        this._refreshHandler = handler;
    },
    _refreshCallback : function(sender, event) {
        var refreshHandler = this._refreshHandler;
        if (refreshHandler == null) {
            return false;
        }

        if (refreshHandler()) {
            return true;
        }
        return false;
    }
}

Tfsi.Navigation._Navigation.registerClass('Tfsi.Navigation._Navigation', Tfsi.Navigation._NavigationBase, Tfsi.Navigation.INavigation);

function Tfsi_Navigation_Refresh_CallbackHandler(sender, event) {
    var navigationService = Tfsi.ServiceFactory.getService('INavigation'); ;
    if (navigationService._refreshCallback != null) {
        if (navigationService._refreshCallback(sender, event)) {
            return true;
        }
    }
    return false;
}

Tfsi.Logging._Logger = function() {
    Tfsi.Logging._Logger.initializeBase(this);
    this._loggingService = Tfsi._serviceFactory.getService("Thomson.Financial.Framework.Managed.Logging.ILoggerService");
}

Tfsi.Logging._Logger.prototype = {
    writeMessage: function(message, category) {
        Tfsi.Logging._Logger.callBaseMethod(this, 'writeMessage', [message, category]);
        var categoryName = "";
        if (category) {
            categoryName = this._categoryToCategoryName(category);
        }
        this._loggingService.WriteMessage(categoryName, message);
    },
    writeInfo: function(info) {
        Tfsi.Logging._Logger.callBaseMethod(this, 'writeInfo', [info]);
        this._loggingService.WriteInfo(info);
    },
    _categoryToCategoryName: function(category) {
        var e = Function._validateParams(arguments, [
            { name: "category", type: Tfsi.Logging.Category, optional: true }
        ]);
        if (e) throw e;
        var categoryName = "";
        switch (category) {
            case Tfsi.Logging.Category.audit:
                categoryName = "Audit";
                break;
            case Tfsi.Logging.Category.error:
                categoryName = "Error";
                break;
            case Tfsi.Logging.Category.fatalError:
                categoryName = "FatalError";
                break;
            case Tfsi.Logging.Category.info:
                categoryName = "Info";
                break;
            case Tfsi.Logging.Category.remoteCall:
                categoryName = "RemoteCall";
                break;
            case Tfsi.Logging.Category.remoteReturn:
                categoryName = "RemoteReturn";
                break;
            case Tfsi.Logging.Category.security:
                categoryName = "Security";
                break;
            case Tfsi.Logging.Category.traceHigh:
                categoryName = "TraceHigh";
                break;
            case Tfsi.Logging.Category.traceLow:
                categoryName = "TraceLow";
                break;
            case Tfsi.Logging.Category.warning:
                categoryName = "Warning";
                break;
        }
        return categoryName;
    }
}

Tfsi.Logging._Logger.registerClass('Tfsi.Logging._Logger', Tfsi.Logging._LoggerBase, Tfsi.Logging.ILogger);

Tfsi._ILXWab = function(){
    if(!document.getElementById('Tfsi_span')){
        var tempStr = "<SPAN name='Tfsi_span' id='Tfsi_span' STYLE='display: none;'></SPAN>";
        document.body.insertAdjacentHTML("AfterBegin", tempStr);
        var tempstr = "<OBJECT id='Tfsi_WebAppHelper' CLASSID='clsid:42E317A5-86A1-447B-BCED-1B802844D74D'></OBJECT>";
        Tfsi_span.innerHTML = tempstr;
        Tfsi_WebAppHelper.externalinterface=window.external;
    }
    this._span = document.getElementById('Tfsi_span');
    this._symbolListsBehavior = null;
}
Tfsi._ILXWab.prototype = {
    _initQueries: function(progName, func) {
        if (this._span.savedQueries) {
            return;
        }

        this._span.symlistAppName = progName;
        this._span.onsymbollistchange = Tfsi._OnSavedQueryChange;

        try {
            // If symbol list behavior is already attached, needs to remove it first
            // and then attaches it again so the symlistAppName could take effect.
            if (this._symbolListsBehavior) {
                this._span.removeBehavior(this._symbolListsBehavior);
            }

            this._symbolListsBehavior = this._span.addBehavior("#Tfsi_WebAppHelper#SymbolLists");

            this._span.savedQueries = true;
            this._span.savedQueryHandler = func;

        }
        catch (e) {
            this._span.savedQueries = false;
        }
    },
    getQueryList: function() {
        try {
            var list = this._span.GetQueries();
            return list.toArray();
        }
        catch (e) {
        }
        return null;
    },
    getQuery: function(qName) {
        try {
            var qry = this._span.GetQueryByName(qName);
            return qry;
        }
        catch (e) {
        }

        return null;
    },
    addQuery: function(qName, qText) {
        try {
            var old = this.getQuery(qName);
            if (old == qText) {
                return false;
            }
            if (old) {
                this.deleteQuery(qName);
            }
            if (qText) {
                this._span.AddQuery(qName, qText);
            }
            return true;
        }
        catch (e) {
            return false;
        }
    },
    deleteQuery: function(qName) {
        try {
            this._span.DeleteQuery(qName);
        }
        catch (e) { }
    },

    renameQuery: function(oldName, newName) {
        try {
            this._span.RenameQuery(oldName, newName);
        }
        catch (e) { }
    },
    initSymbolLists: function() {
        if (!this._symbolListsBehavior) {
            this._symbolListsBehavior = this._span.addBehavior("#Tfsi_WebAppHelper#SymbolLists");
            var list = this._span.GetILXSymbolLists();
            this._span.symbolLists = true;
        }
    },
    setSymbolListHandler: function(func) {
        this._span.onsymbollistchange2 = func;
    },
    getSymbolLists: function(filter) {
        //try {
        var list;
        if (filter == undefined) {
            list = this._span.GetILXSymbolLists();
        }
        else {
            list = this._span.GetSymbolLists(filter);
        }
        return list.toArray();
        //}
        //catch(e) {
        //}

        //return null;
    },

    getSymbolsFromList: function(listName) {
        try {
            var list = this._span.GetILXSymbolsFromList(listName);
            return list.toArray();
        }
        catch (e) { }

        return null;
    },

    getTopasIdBySymListName: function(listName) {
        try {
            return this._span.GetTopasIdBySymListName(listName);
        }
        catch (e) { }

        return -1;
    },
    getSymbolList: function(symbolListId) {
        //try {
        return this._span.GetSymbolList(symbolListId);
        //}
        //catch(e) {
        //}

        //return null;
    },
    getSymbolListByTopasId: function(topasId, downloadFromPortfolioWarehouse) {
        //try {
        return this._span.GetSymbolList2(topasId, downloadFromPortfolioWarehouse);
        //}
        //catch(e) {
        //}

        //return null;
    }
}

Tfsi._ILXWab.registerClass('Tfsi._ILXWab',null);

Tfsi._getILXWab = function() {
    if(!Tfsi._ilxWabObj){
        Tfsi._ilxWabObj = new Tfsi._ILXWab();
    }
    return Tfsi._ilxWabObj;
}

Tfsi._OnSavedQueryChange = function() {
    var savedQueryHandler=window.event.srcElement.savedQueryHandler;
    var symListName = window.event.getAttribute("SymListName");
    var eventType = window.event.getAttribute("EventType");
    if( savedQueryHandler == null || savedQueryHandler(symListName, eventType) ) {
        event.returnValue = true;
    }

}

//_SymbolList
Tfsi.SymbolList._SymbolList = function() {
    Tfsi.SymbolList._SymbolList.initializeBase(this);
    this._wab = Tfsi._getILXWab();
    if(this._wab){
        this._wab.initSymbolLists();
        this._wab.setSymbolListHandler(Tfsi.SymbolList._SymbolList._OnSymbolListChanged);
    }
    this._handler = null;
}

Tfsi.SymbolList._SymbolList.prototype = {
    getSymbolLists: function(symbolListTypeFilter) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'getSymbolLists', [symbolListTypeFilter]);
        if (!symbolListTypeFilter) {
            symbolListTypeFilter = Tfsi.SymbolList.SymbolListTypes.all;
        }

        if (this._wab) {
            var nativeLists = this._wab.getSymbolLists(symbolListTypeFilter);
            var symbolLists = new Tfsi.SymbolList.SymbolListInfoList(nativeLists);

            return symbolLists;
        }
    },
    getSymbolListById: function(symbolListId) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'getSymbolListById', [symbolListId]);
        if (this._wab) {
            var nativeObject = this._wab.getSymbolList(symbolListId);
            if (nativeObject) {
                return new Tfsi.SymbolList.SymbolListInfo(nativeObject);
            }
        }

    },
    getSymbolListByTopasListId: function(topasListID, downloadFromPortfolioWarehouse) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'getSymbolListByTopasListId', [topasListID, downloadFromPortfolioWarehouse]);
        if (this._wab) {
            var nativeObject = this._wab.getSymbolListByTopasId(topasListID, downloadFromPortfolioWarehouse);
            if (nativeObject) {
                return new Tfsi.SymbolList.SymbolListInfo(nativeObject);
            }
        }
    },
    setSymbolListChangedHandler: function(handler) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'setSymbolListChangedHandler', [handler]);
        this._handler = handler;
    }
}

Tfsi.SymbolList._SymbolList.registerClass('Tfsi.SymbolList._SymbolList', Tfsi.SymbolList._SymbolListBase, Tfsi.SymbolList.ISymbolListManager);

Tfsi.SymbolList._SymbolList._OnSymbolListChanged = function(){
    //alert(symListName + " " + eventType);
    var symListId = window.event.getAttribute("ID");
    var topasId = window.event.getAttribute("TOPAS_LIST_ID");
    var eventType = window.event.getAttribute("EventType");

    var symbolList = Tfsi.ServiceFactory.getService('ISymbolListManager');
    if(symbolList && symbolList._handler){
        var action = function(){
            var eventArgs = new Tfsi.SymbolList.SymbolListChangedEventArgs(symListId, topasId, eventType);
            symbolList._handler(symbolList, eventArgs);
        }
        window.setTimeout(action,200);
    }
}


Tfsi._init = function Tfsi$_init() {
    if(!Tfsi._serviceFactory) {
        Tfsi._serviceFactory = window.external.ServiceFactory;
    }
}

Tfsi._init();

// window.resizeBy browser function override
window.resizeBy = function(x, y) {
    try {
        var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
        thomletService.resizeBy(x, y);
    }
    catch (e) { }
}

// window.resizeTo browser function override
window.resizeTo = function(width, height) {
    try {
        var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
        thomletService.resizeTo(width, height);
    }
    catch (e) { }
}

// window.open browser function override
window.oldwindowopen = window.open;
window.open = function(url, name, features, replace, openPopupInIE)
{
    if (openPopupInIE) {
        try {
            var navigationService = Tfsi.ServiceFactory.getService('INavigation');
            navigationService.set_OpenPopupInIE(true);
        }
        catch(e) {}
    }
    if (name == undefined) {
        name = "";
    }
    if (features == undefined) {
        features = "";
    }
    if (replace == undefined) {
        replace = false;
    }
    return window.oldwindowopen(url, name, features, replace);
}


//the last line
if (typeof (Sys) !== 'undefined') Sys.Application.notifyScriptLoaded(); 