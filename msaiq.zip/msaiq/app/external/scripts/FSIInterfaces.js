/***********************************************/
/* Thomson Web Integration API Standard        */
/* Release Version 1.1.1.1                         */
/* Copyright (c) 2006-2010 Thomson Reuters     */
/***********************************************/
///<reference name="MicrosoftAjax.debug.js" />

//Exceptions
Error.keyNotFoundException = function Error$keyNotFoundException(message) {
    /// <param name="message" type="String" optional="true" mayBeNull="true"></param>
    /// <returns></returns>
    var e = Function._validateParams(arguments, [
        { name: "message", type: String, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var displayMessage = "Sys.KeyNotFoundException: " + (message ? message : "Key not found.");

    var e = Error.create(displayMessage, { name: 'Sys.KeyNotFoundException' });
    e.popStackFrame();
    return e;
}

Error.fsiContextAccessDeniedException = function Error$fsiContextAccessDeniedException(message) {
    var e = Function._validateParams(arguments, [
        { name: "message", type: String, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var displayMessage = "Tfsi.Context.ContextAccessDeniedException: " + (message ? message : "Thomlet is not allowed to set context.");

    var e = Error.create(displayMessage, { name: 'Tfsi.Context.ContextAccessDeniedException' });
    e.popStackFrame();
    return e;
}

Error.fsiPreferenceAccessDeniedException = function Error$fsiPreferenceAccessDeniedException(message) {
    var e = Function._validateParams(arguments, [
        { name: "message", type: String, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var displayMessage = "Tfsi.Preferences.PreferenceAccessDeniedException: " + (message ? message : "Thomlet is not allowed to set Preference.");

    var e = Error.create(displayMessage, { name: 'Tfsi.Preferences.PreferenceAccessDeniedException' });
    e.popStackFrame();
    return e;
}
Error.serviceNotDefinedException = function Error$serviceNotDefinedException(message) {
    /// <param name="message" type="String" optional="true" mayBeNull="true"></param>
    /// <returns></returns>
    var e = Function._validateParams(arguments, [
        { name: "message", type: String, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var displayMessage = "Service Not Defined: " + (message ? message : "service not defined.");

    var e = Error.create(displayMessage, { name: 'Tfsi.ServiceFactory.ServiceNotDefinedException' });
    e.popStackFrame();
    return e;
}
//Type.registerNamespace('Thomson');
//Type.registerNamespace('Thomson.Financial');
//Type.registerNamespace('Thomson.Financial.Framework');
if (typeof (Tfsi) == 'undefined') {
    Type.registerNamespace('Tfsi');
}
Tfsi.__ServiceInstances = new Object();
//StringDictionary
Tfsi.StringDictionary = function() {
    this._arrDictionary = new Object();
}

Tfsi.__useBaseImplementation = false;

Tfsi.StringDictionary.prototype = {
    add: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value", type: String }
        ]);
        if (e) throw e;
        if (this._arrDictionary[key]) {
            throw Error.argument(key, "An element with the same key already exists in the Dictionary.")
        }
        this._arrDictionary[key] = value;
    },

    get_Item: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        if (!this._arrDictionary[key]) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        return this._arrDictionary[key];
    },

    set_Item: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value", type: String }
        ]);
        if (e) throw e;
        this._arrDictionary[key] = value;
    },

    containsKey: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
        if (!this._arrDictionary[key]) {
            return false;
        } else {
            return true;
        }
    },
    get_Count: function() {
        var count = 0;
        for (var prop in this._arrDictionary) {
            if (!this._arrDictionary.hasOwnProperty(prop)) {
                continue;
            }
            ++count;
        }
        return count;
    },
    _get_Items: function() {

        return this._arrDictionary;
    },
    _get_ItemsClone: function() {

        var items = new Object();
        for (var key in this._arrDictionary) {
            if (!this._arrDictionary.hasOwnProperty(key)) {
                continue;
            }
            items[key] = this._arrDictionary[key];
        }
        return items;
    }

}

Tfsi.StringDictionary.registerClass('Tfsi.StringDictionary', null);
Tfsi.StringDictionary.forEach = function(dict, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "dict", type: Tfsi.StringDictionary },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = dict._get_Items();
    for (var key in items) {
        if (!items.hasOwnProperty(key)) {
            continue;
        }
        if (method.call(instance, key, items[key])) {
            continue;
        }
    }
}
//KeyedItemDictionary
Tfsi.KeyedItemDictionary = function() {
    this._arrDictionary = new Object();
}

Tfsi.KeyedItemDictionary.prototype = {
    add: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value", mayBeNull: true }
        ]);
        if (e) throw e;
        if (this._arrDictionary[key]) {
            throw Error.argument(key, "An element with the same key already exists in the Dictionary.")
        }
        if (!value) {
            value = "";
        }

        this._arrDictionary[key] = value;
    },

    get_Item: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        if (!this.containsKey(key)) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        return this._arrDictionary[key];
    },

    set_Item: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value", mayBeNull: true }
        ]);
        if (e) throw e;
        if (!value) {
            value = "";
        }
        this._arrDictionary[key] = value;
    },

    containsKey: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
        var value = this._arrDictionary[key];
        if (value == null || value == undefined) {
            return false;
        } else {
            return true;
        }
    },
    get_Count: function() {
        var count = 0;
        for (var prop in this._arrDictionary) {
            if (!this._arrDictionary.hasOwnProperty(prop)) {
                continue;
            }
            ++count;
        }
        return count;
    },
    _get_Items: function() {
        return this._arrDictionary;

    },
    remove: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        if (!this._arrDictionary[key]) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        this._arrDictionary[key] = null;
    }
}

Tfsi.KeyedItemDictionary.registerClass('Tfsi.KeyedItemDictionary', null);
Tfsi.KeyedItemDictionary.forEach = function(dict, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "dict", type: Tfsi.KeyedItemDictionary },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = dict._get_Items();
    for (var key in items) {
        if (!items.hasOwnProperty(key)) {
            continue;
        }
        if (method.call(instance, key, items[key])) {
            break;
        }
    }
}
//IServiceFactory
Tfsi.IServiceFactory = function() { }
Tfsi.IServiceFactory.prototype = {
    getService: function(serviceName, optionalInfo) { }
}
Tfsi.IServiceFactory.registerInterface('Tfsi.IServiceFactory');

Tfsi.ServiceFactory = function() {
}
Tfsi.ServiceFactory.getService = function(serviceName, optionalInfo) {

    var e = Function._validateParams(arguments, [
        { name: "serviceName", type: String },
        { name: "optionalInfo", type: String, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var svcInstance = Tfsi.__ServiceInstances[serviceName];
    if (!svcInstance) {
        var serviceType = Tfsi.ServiceFactory._getServiceType(serviceName);
        if (serviceType) {
            svcInstance = Tfsi.__ServiceInstances[serviceName] = new serviceType();
        }
        else {
            throw Error.serviceNotDefinedException(serviceName);
        }
    }
    return svcInstance;
}
Tfsi.ServiceFactory._getServiceType = function(serviceName) {
    if (svc = Tfsi.__ServiceTypes[serviceName]) {
        return svc.type;
    }
}
Tfsi.__updateServiceType = function(baseType, serviceType) {
    var e = Function._validateParams(arguments, [
        { name: "baseType", type: Type },
        { name: "serviceType", type: Type }
    ]);
    if (e) throw e;
    for (var name in Tfsi.__ServiceTypes) {
        var svc = Tfsi.__ServiceTypes[name];
        if (svc.type == baseType) {
            svc.type = serviceType;
            svc.implemented = true;
            return true;
        }
    }
    return false;
}
Tfsi.ServiceFactory.registerClass('Tfsi.ServiceFactory', null, Tfsi.IServiceFactory);

//IFrameworkService
Tfsi.IFrameworkService = function() { }
Tfsi.IFrameworkService.prototype = {
    get_Name: function() { },
    get_Implemented: function() { }
}
Tfsi.IFrameworkService.registerInterface('Tfsi.IFrameworkService');
//_ServiceBase
Tfsi._ServiceBase = function(name) {
    this.__name = name;
}
Tfsi._ServiceBase.prototype = {
    get_Name: function() {
        return this.__name;
    },
    get_Implemented: function() {
        var svc = Tfsi.__ServiceTypes[this.get_Name()]
        Sys.Debug.assert(svc != null);
        if (svc) {
            return svc.implemented;
        }
        return false;
    }

}
Tfsi._ServiceBase.registerClass('Tfsi._ServiceBase', null, Tfsi.IFrameworkService);

//IContextBroker
Type.registerNamespace('Tfsi.Context');

Tfsi.Context.IContextBroker = function() { }
Tfsi.Context.IContextBroker.prototype = {
    setContexts: function(contextList, updateOnly) { },
    getContexts: function() { },
    getContext: function(key) { },
    setContextHandler: function(func) { },
    setContext: function(name, value, updateOnly) { },
    isContextSupported: function(key) { },
    transform: function(ctxValue, ctxInFormat, ctxOutFormat) { },
    transformContext: function(contextValueIn, outFormatFilter, handler) { },
    transformContexts: function(contextValuesIn, outFormatFilters, handler) { }
}
Tfsi.Context.IContextBroker.registerInterface('Tfsi.Context.IContextBroker');

//_ContextBase
Tfsi.Context._ContextBase = function() {
    Tfsi.Context._ContextBase.initializeBase(this, ['IContext']);
}

Tfsi.Context._ContextBase.prototype = {
    setContexts: function(contextDict, updateOnly) {
        var e = Function._validateParams(arguments, [
            { name: "contextDict", type: Tfsi.KeyedItemDictionary },
            { name: "updateOnly", type: Boolean }
        ]);
        if (e) throw e;
        if (contextDict.get_Count() == 0) {
            throw Error.argument(contextDict, "contextDict is empty.");
        }
        var checkDict = function(name, value) {
            if (value && typeof (value) != "string" && !Tfsi.Context.ContextValue.isInstanceOfType(value)) {
                throw Error.argument(contextDict, "contextDict contains value other than string or ContextValue type.");
            }
        }
        Tfsi.KeyedItemDictionary.forEach(contextDict, checkDict, this);
    },
    setContext: function(name, value, updateOnly) {
        var e = Function._validateParams(arguments, [
            { name: "name", type: String },
            { name: "value", type: String, mayBeNull: true },
            { name: "updateOnly", type: Boolean }
        ]);
        if (e) throw e;
    },
    getContexts: function() {
        return new Tfsi.Context.ContextDictionary();
    },
    getContext: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
    },
    setContextHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
    },
    isContextSupported: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
        return false;
    },
    transform: function(ctxValue, ctxInFormat, ctxOutFormat) {
        var e = Function._validateParams(arguments, [
            { name: "ctxValue", type: String },
            { name: "ctxInFormat", type: String, mayBeNull: true, optional: true },
            { name: "ctxOutFormat", type: String, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
    },
    transformContext: function(contextValueIn, outFormatFilter, completedHandler) {
        var e = Function._validateParams(arguments, [
            { name: "contextValueIn", type: Tfsi.Context.ContextValue },
            { name: "outFormatFilter", type: Tfsi.StringDictionary, mayBeNull: true },
            { name: "completedHandler", type: Function }
        ]);
        if (e) throw e;
    },
    transformContexts: function(contextValuesIn, outFormatFilters, handler) {
        var e = Function._validateParams(arguments, [
            { name: "contextValuesIn", type: Array, elementType: Tfsi.Context.ContextValue },
            { name: "outFormatFilters", type: Array, elementType: Tfsi.StringDictionary, mayBeNull: true },
            { name: "completedHandler", type: Function }
        ]);
        if (e) throw e;
        if (contextValuesIn.length != outFormatFilters.length) {
            throw Error.argument(outFormatFilters, "The number of outFormatFilters should match that of contextValuesIn.")
        }
    }
}

Tfsi.Context._ContextBase.registerClass('Tfsi.Context._ContextBase', Tfsi._ServiceBase, Tfsi.Context.IContextBroker);

//TransformResultCode
Tfsi.Context.TransformContextStatus = function() { };
Tfsi.Context.TransformContextStatus.prototype =
{
    success: 1,
    invalidInput: 2,
    timeout: 3,
    fail: 4,
    unknown: 5
}
Tfsi.Context.TransformContextStatus.registerEnum("Tfsi.Context.TransformContextStatus");

//TransformContextCompletedEventArgs
Tfsi.Context.TransformContextCompletedEventArgs = function(result, status) {
    var e = Function._validateParams(arguments, [
        { name: "result", type: Array, elementType: Tfsi.Context.ContextValue, mayBeNull: true, elementMayBeNull: true },
        { name: "status", type: Array, elementType: Tfsi.Context.TransformContextStatus, mayBeNull: true, elementMayBeNull: true }

    ]);
    if (e) throw e;
    this._result = result;
    this._status = status;
}

Tfsi.Context.TransformContextCompletedEventArgs.prototype = {

    get_Result: function() {
        return this._result;
    },
    get_Status: function() {
        return this._status;
    }
}

Tfsi.Context.TransformContextCompletedEventArgs.registerClass('Tfsi.Context.TransformContextCompletedEventArgs', Sys.EventArgs);

//ContextItem

Tfsi.Context.ContextItem = function(key, value) {
    var e = Function._validateParams(arguments, [
        { name: "key", type: String },
        { name: "value" }
    ]);
    if (e) throw e;
    this._key = key;
    this._value = value;
    this._readonly = false;
}

Tfsi.Context.ContextItem.prototype = {
    get_Key: function() {
        return this._key;
    },
    get_ReadOnly: function() {
        return this._readonly;
    },
    get_Value: function() {
        return this._value;
    },
    _set_ReadOnly: function(readOnly) {
        var e = Function._validateParams(arguments, [
            { name: "readOnly", Type: Boolean }
        ]);
        if (e) throw e;
        this._readOnly = readOnly;
    }
}
Tfsi.Context.ContextItem.registerClass('Tfsi.Context.ContextItem', null);
//ContextDictionary
Tfsi.Context.ContextDictionary = function() {
    this._ctxDictionary = new Object();
}

Tfsi.Context.ContextDictionary.prototype = {
    _add: function(key, item) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "item", type: Tfsi.Context.ContextItem }
        ]);
        if (e) throw e;
        if (this._ctxDictionary[key]) {
            throw Error.argument(key, "An element with the same key already exists in the Dictionary.")
        }

        this._ctxDictionary[key] = item;
    },
    _set_Item: function(key, item) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "item", type: Tfsi.Context.ContextItem }
        ]);
        if (e) throw e;
        this._ctxDictionary[key] = item;
    },
    get_Item: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        //if(!this._ctxDictionary[key]) {
        //    throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        //}
        return this._ctxDictionary[key];
    },
    get_Keys: function() {
        var arr = new Array();
        for (var key in this._ctxDictionary) {
            if (!this._ctxDictionary.hasOwnProperty(key)) {
                continue;
            }
            Array.add(arr, key);
        }
        return arr;
    },
    get_Count: function() {
        var count = 0;
        for (var prop in this._ctxDictionary) {
            if (!this._ctxDictionary.hasOwnProperty(prop)) {
                continue;
            }
            ++count;
        }
        return count;
    },
    _remove: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        if (!this._ctxDictionary[key]) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        this._ctxDictionary[key] = null;

    },

    _clear: function() {
        this._ctxDictionary = new Object();

    },

    containsKey: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
        if (!this._ctxDictionary[key]) {
            return false;
        }
        else {
            return true;
        }

    },

    _get_Items: function() {
        return this._ctxDictionary;
    }
}

Tfsi.Context.ContextDictionary.registerClass('Tfsi.Context.ContextDictionary', null);
Tfsi.Context.ContextDictionary.forEach = function(dict, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "dict", type: Tfsi.Context.ContextDictionary },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = dict._get_Items();
    for (var key in items) {
        if (!items.hasOwnProperty(key)) {
            continue;
        }
        if (method.call(instance, key, items[key])) {
            break;
        }
    }
}

//ContextChangedReason
Tfsi.Context.ContextChangedReason = function() { };

Tfsi.Context.ContextChangedReason.prototype =
{
    context: 0,
    activation: 1,
    drilldown: 2,
    contextMenu: 3,
    dragAndDrop: 4
}
Tfsi.Context.ContextChangedReason.registerEnum("Tfsi.Context.ContextChangedReason");

//ContextChangedEventArgs
Tfsi.Context.ContextChangedEventArgs = function(updatedContext, subFunction, commandArgs, reason, sourceContext) {
    var e = Function._validateParams(arguments, [
        { name: "updatedContext", type: Tfsi.Context.ContextDictionary, mayBeNull: true },
        { name: "subFunction", type: String, mayBeNull: true },
        { name: "commandArgs", type: String, mayBeNull: true },
        { name: "reason", type: Tfsi.Context.ContextChangedReason, mayBeNull: true, optional: true },
        { name: "sourceContext", type: Tfsi.Context.ContextDictionary, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    Tfsi.Context.ContextChangedEventArgs.initializeBase(this);
    this._updatedContext = updatedContext;
    this._subFunction = subFunction;
    this._commandArgs = commandArgs;
    if (!reason) {
        reason = Tfsi.Context.ContextChangedReason.context;
    }
    this._reason = reason;
    this._sourceContext = sourceContext;
}

Tfsi.Context.ContextChangedEventArgs.prototype = {

    get_UpdatedContext: function() {
        return this._updatedContext;
    },
    get_SubFunction: function() {
        return this._subFunction;
    },
    get_CommandArgs: function() {
        return this._commandArgs;
    },
    get_Reason: function() {
        return this._reason;
    },
    get_SourceContext: function() {
        return this._sourceContext;
    }
}

Tfsi.Context.ContextChangedEventArgs.registerClass('Tfsi.Context.ContextChangedEventArgs', Sys.EventArgs);

//_ContextValue

Tfsi.Context._ContextValuePair = function(attributes, value) {
    var e = Function._validateParams(arguments, [
        { name: "attributes", type: Tfsi.StringDictionary },
        { name: "value", type: String }
    ]);
    if (e) throw e;

    this._value = value;
    this._attributes = attributes;
}

Tfsi.Context._ContextValuePair.prototype = {

    hasAttributes: function(attributes) {
        var e = Function._validateParams(arguments, [
            { name: "attributes", type: Tfsi.StringDictionary }
        ]);
        if (e) throw e;
        var hasChanged = true;
        var action = function(key, value) {
            if (value != this._attributes._arrDictionary[key]) {
                hasChanged = false;
                return true;
            }
        }
        Tfsi.StringDictionary.forEach(attributes, action, this);
        return hasChanged;
    },
    get_Value: function() {
        return this._value;
    },
    set_Value: function(value) {
        var e = Function._validateParams(arguments, [
            { name: "value", type: String }
        ]);
        if (e) throw e;
        this._value = value;
    },
    get_Attributes: function() {
        return this._attributes;
    }
}

Tfsi.Context._ContextValuePair.registerClass('Tfsi.Context._ContextValuePair', null);

Tfsi.Context.ContextValue = function(name, value) {
    this._name = name;
    this._value = value;
    this._contextValues = new Array();
}

Tfsi.Context.ContextValue.prototype = {
    get_Name: function() {
        return this._name;
    },

    _serialize: function() {
        var sb = new Sys.StringBuilder();
        if (this._value && this._value.length > 0) {
            sb.append("<" + this._name + ">" + this._value + "</" + this._name + ">");
        }
        for (var i = 0; i < this._contextValues.length; i++) {
            sb.append("<" + this._name);
            var attrs = this._contextValues[i].get_Attributes();
            if (attrs) {
                var attrItems = attrs._get_Items();
                for (var key in attrItems) {
                    sb.append(" " + key + "='" + attrItems[key] + "'");
                }
            }

            sb.append(">" + this._contextValues[i].get_Value() + "</" + this._name + ">");
        }
        return sb.toString();
    },

    set_Value: function(attributes, value) {
        var e = Function._validateParams(arguments, [
            { name: "attributes", type: Tfsi.StringDictionary, mayBeNull: true },
            { name: "value", type: String, mayBeNull: true }
        ]);
        if (e) throw e;
        if (!value) {
            value = "";
        }
        if (!attributes) {
            this._value = value;
            return;
        }
        for (var i = 0; i < this._contextValues.length; i++) {
            if (this._contextValues[i].hasAttributes(attributes)) {
                this._contextValues[i].set_Value(value);
                return;
            }
        }
        var ctxValue = new Tfsi.Context._ContextValuePair(attributes, value);
        Array.add(this._contextValues, ctxValue);
    },

    get_Value: function(attributes) {
        var e = Function._validateParams(arguments, [
            { name: "attributes", type: Tfsi.StringDictionary, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;

        if (!attributes) {
            if (this._value) {
                return this._value;
            }
            else if (this._contextValues[0]) {
                return this._contextValues[0].get_Value();
            }
            return null;
        }

        for (var i = 0; i < this._contextValues.length; i++) {
            if (this._contextValues[i].hasAttributes(attributes)) {
                return this._contextValues[i].get_Value();
            }
        }
        return null;
    },
    get_Count: function() {
        return this._contextValues.length;
    },

    _get_Items: function() {
        return this._contextValues;
    }
}

Tfsi.Context.ContextValue.registerClass('Tfsi.Context.ContextValue', null);
Tfsi.Context.ContextValue.forEach = function(ctxValue, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "ctxValue", type: Tfsi.Context.ContextValue },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = ctxValue._get_Items();
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (method.call(instance, item.get_Attributes(), item.get_Value())) {
            break;
        }
    }
}
//Tfsi.Navigation
//IDrilldown

Type.registerNamespace('Tfsi.Navigation');

//InvokingType
Tfsi.Navigation.TargetInvokingType = function() { };
Tfsi.Navigation.TargetInvokingType.prototype =
{
    normal: 1,
    onDemand: 2,
    createNew: 3
}
Tfsi.Navigation.TargetInvokingType.registerEnum("Tfsi.Navigation.TargetInvokingType");

//DrilldownTargetType
Tfsi.Navigation.DrilldownTargetType = function() { };
Tfsi.Navigation.DrilldownTargetType.prototype =
{
    defaultTarget: 1,
    drilldownSource: 2
}
Tfsi.Navigation.DrilldownTargetType.registerEnum("Tfsi.Navigation.DrilldownTargetType");

//WorkspaceSearchScopes
Tfsi.Navigation.WorkspaceSearchScopes = function() { };
Tfsi.Navigation.WorkspaceSearchScopes.prototype =
{
    none: 0,
    docked: 1,
    desktop: 2,
    otherPages: 4,
    currentPage: 8,
    //pages: this.otherPages | this.currentPage
    pages: 12,
    //all: this.docked | this.pages | this.desktop
    all: 15
}
Tfsi.Navigation.WorkspaceSearchScopes.registerEnum("Tfsi.Navigation.WorkspaceSearchScopes", true);

Tfsi.Navigation.IDrilldown = function() { }
Tfsi.Navigation.IDrilldown.prototype = {
    register: function(drilldownList, func) { },
    clear: function() { },
    invoke: function(id, contextData, commandArgs, resetTarget, windowFeature) { },
    openThomletInFrame: function(frame, thomletId, contextData, commandArgs, sessionPersistent, lockWindow) { }
}
Tfsi.Navigation.IDrilldown.registerInterface('Tfsi.Navigation.IDrilldown');

//DrilldownDefaultTarget
Tfsi.Navigation.DrilldownDefaultTarget = function(thomletId, subFunction, readOnly, invokingType, searchScopes) {
    var e = Function._validateParams(arguments, [
        { name: "thomletId", type: String },
        { name: "subFunction", type: String, mayBeNull: true, optional: true },
        { name: "readOnly", type: Boolean, mayBeNull: true, optional: true },
        { name: "invokingType", type: Tfsi.Navigation.TargetInvokingType, mayBeNull: true, optional: true },
        { name: "searchScopes", type: Tfsi.Navigation.WorkspaceSearchScopes, mayBeNull: true, optional: true }
    ]);

    if (e) throw e;



    this._thomletId = thomletId;
    this._subFunction = subFunction;
    if (readOnly) {
        this._readOnly = true;
    }
    else {
        this._readOnly = false;
    }
    if (invokingType) {
        this._invokingType = invokingType;
    }
    else {
        this._invokingType = Tfsi.Navigation.TargetInvokingType.onDemand;
    }
    if (searchScopes != null) {
        this._searchScopes = searchScopes;
    }
    else {
        this._searchScopes = Tfsi.Navigation.WorkspaceSearchScopes.all;
    }
}

Tfsi.Navigation.DrilldownDefaultTarget.prototype = {
    get_ThomletId: function() {
        return this._thomletId;
    },
    get_SubFunction: function() {
        return this._subFunction;
    },
    get_ReadOnly: function() {
        return this._readOnly;
    },
    get_TargetInvokingType: function() {
        return this._invokingType;
    },
    get_SearchScopes: function() {
        return this._searchScopes;
    }
}

Tfsi.Navigation.DrilldownDefaultTarget.registerClass('Tfsi.Navigation.DrilldownDefaultTarget', null);

//DrilldownItem
Tfsi.Navigation.DrilldownItem = function(id, name, desc, defaultTarget, targetType) {
    var e = Function._validateParams(arguments, [
        { name: "id", type: Number },
        { name: "name", type: String },
        { name: "desc", type: String },
        { name: "defaultTarget", type: Tfsi.Navigation.DrilldownDefaultTarget, mayBeNull: true, optional: true },
        { name: "targetType", type: Tfsi.Navigation.DrilldownTargetType, mayBeNull: true, optional: true }

    ]);
    if (e) throw e;

    this._id = id;
    this._name = name;
    this._description = desc;
    this._defaultTarget = defaultTarget;
    if (!targetType) {
        targetType = Tfsi.Navigation.DrilldownTargetType.defaultTarget;
    }

    this._targetType = targetType
}

Tfsi.Navigation.DrilldownItem.prototype = {
    get_Id: function() {
        return this._id;
    },
    get_Name: function() {
        return this._name;
    },
    get_Description: function() {
        return this._description;
    },
    get_DefaultTarget: function() {
        return this._defaultTarget;
    },
    get_TargetType: function() {
        return this._targetType;
    }
}

Tfsi.Navigation.DrilldownItem.registerClass('Tfsi.Navigation.DrilldownItem', null);

//DrilldownChangedEventArgs
Tfsi.Navigation.DrilldownChangedEventArgs = function(id, tooltip, enabled) {
    var e = Function._validateParams(arguments, [
        { name: "id", type: Number },
        { name: "tooltip", type: String },
        { name: "enabled", type: Boolean }
    ]);
    if (e) throw e;

    this._id = id;
    this._tooltip = tooltip;
    this._enabled = enabled;
}

Tfsi.Navigation.DrilldownChangedEventArgs.prototype = {
    get_Id: function() {
        return this._id;
    },

    get_Tooltip: function() {
        return this._tooltip;
    },
    get_Enabled: function() {
        return this._enabled;
    }
}

Tfsi.Navigation.DrilldownChangedEventArgs.registerClass('Tfsi.Navigation.DrilldownChangedEventArgs', null);

//DrilldownItemList
Tfsi.Navigation.DrilldownItemList = function() {
    this._items = [];
}

Tfsi.Navigation.DrilldownItemList.prototype = {
    addItem: function(id, name, desc, defaultTarget, targetType) {
        var e = Function._validateParams(arguments, [
            { name: "id", type: Number },
            { name: "name", type: String },
            { name: "desc", type: String },
            { name: "defaultTarget", type: Tfsi.Navigation.DrilldownDefaultTarget, mayBeNull: true, optional: true },
            { name: "targetType", type: Tfsi.Navigation.DrilldownTargetType, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;

        var item = new Tfsi.Navigation.DrilldownItem(id, name, desc, defaultTarget, targetType);
        this.add(item);
        return item;
    },

    add: function(item) {
        var e = Function._validateParams(arguments, [
            { name: "item", type: Tfsi.Navigation.DrilldownItem }
        ]);
        if (e) throw e;
        Array.add(this._items, item);
    },

    remove: function(id) {
        var e = Function._validateParams(arguments, [
            { name: "id", type: Number }
        ]);
        if (e) throw e;
        for (var i = 0; i < this._items.length; i++) {
            if (this._items[i].get_Id() == id) {
                Array.removeAt(this._items, i);
                break;
            }
        }
    },
    clear: function() {
        this._items = [];
    },

    _get_Items: function() {
        return this._items;
    }

}

Tfsi.Navigation.DrilldownItemList.registerClass('Tfsi.Navigation.DrilldownItemList', null);
Tfsi.Navigation.DrilldownItemList.forEach = function(ddItemList, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "ddItemList", type: Tfsi.Navigation.DrilldownItemList },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = ddItemList._get_Items();
    for (var i = 0; i < items.length; i++) {

        if (method.call(instance, items[i])) {
            break;
        }
    }
}
//_DrilldownBase
Tfsi.Navigation._DrilldownBase = function() {
    Tfsi.Navigation._DrilldownBase.initializeBase(this, ['IDrilldown']);
}

Tfsi.Navigation._DrilldownBase.prototype = {
    register: function(drilldownList, handler) {
        var e = Function._validateParams(arguments, [
            { name: "drilldownList", type: Tfsi.Navigation.DrilldownItemList },
            { name: "handler", type: Function }
        ]);
        if (e) throw e;
    },
    clear: function() {
    },

    invoke: function(id, contextDict, commandArgs, resetTarget, windowFeature) {
        var e = Function._validateParams(arguments, [
            { name: "id", type: Number },
            { name: "contextDict", type: Tfsi.KeyedItemDictionary, mayBeNull: true, optional: true },
            { name: "commandArgs", type: String, mayBeNull: true, optional: true },
            { name: "resetTarget", type: Boolean, mayBeNull: true, optional: true },
            { name: "windowFeature", type: String, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
    },
    openThomletInFrame: function(frame, thomletId, contextDict, commandArgs, sessionPersistent, lockWindow) {
        var e = Function._validateParams(arguments, [
            { name: "frame" },
            { name: "thomletId", type: String },
            { name: "contextDict", type: Tfsi.KeyedItemDictionary, mayBeNull: true },
            { name: "commandArgs", type: String, mayBeNull: true },
            { name: "sessionPersistent", type: Boolean },
            { name: "lockWindow", type: Boolean }
        ]);
        if (e) throw e;
    },
    _toWindowFeaturesObj: function(windowFeatures) {
        if (typeof (windowFeatures) != "undefined") {
            var tmpWindowFeature = windowFeatures.split(",");
            var splittedValue;
            var obj = new Object();
            obj.Top = 0;
            obj.Left = 0;
            obj.Width = 0;
            obj.Height = 0;
            obj.TitleBar = true;
            obj.Resizable = true;
            obj.Modal = false;
            obj.Background = "GRAYED";

            if (tmpWindowFeature != null && tmpWindowFeature.length > 0) {
                for (var winFIndex = 0; winFIndex < tmpWindowFeature.length; winFIndex++) {
                    tmpVar = tmpWindowFeature[winFIndex].toLowerCase();

                    if (tmpVar.indexOf("top") != -1) {
                        splittedValue = tmpVar.split("=");
                        obj.Top = parseInt(splittedValue[1]);
                    }

                    if (tmpVar.indexOf("left") != -1) {
                        splittedValue = tmpVar.split("=");
                        obj.Left = parseInt(splittedValue[1]);
                    }

                    if (tmpVar.indexOf("width") != -1) {
                        splittedValue = tmpVar.split("=");
                        obj.Width = parseInt(splittedValue[1]);
                    }

                    if (tmpVar.indexOf("height") != -1) {
                        splittedValue = tmpVar.split("=");
                        obj.Height = parseInt(splittedValue[1]);
                    }

                    if (tmpVar.indexOf("titlebar") != -1) {
                        splittedValue = tmpVar.split("=");
                        if (splittedValue[1].toLowerCase() == "no" || splittedValue[1] == "0") {
                            obj.TitleBar = false;
                        }
                    }

                    if (tmpVar.indexOf("resizable") != -1) {
                        splittedValue = tmpVar.split("=");
                        if (splittedValue[1].toLowerCase() == "no" || splittedValue[1] == "0") {
                            obj.Resizable = false;
                        }
                    }

                    if (tmpVar.indexOf("background") != -1) {
                        splittedValue = tmpVar.split("=");
                        if (splittedValue[1].toLowerCase() == "normal") {
                            obj.Background = "NORMAL";
                        }
                    }
                    if (tmpVar.indexOf("modal") != -1) {
                        splittedValue = tmpVar.split("=");
                        if (splittedValue[1].toLowerCase() == "yes" || splittedValue[1] == "1") {
                            obj.Modal = true;
                        }
                    }
                }
            }
            return obj;
        }
        return null;
    }


}

Tfsi.Navigation._DrilldownBase.registerClass('Tfsi.Navigation._DrilldownBase', Tfsi._ServiceBase, Tfsi.Navigation.IDrilldown);

Tfsi.Navigation.INavigation = function() { }
Tfsi.Navigation.INavigation.prototype = {
    goHome: function() { },
    navigateTo: function(relativeUrl) { },
    goForward: function() { },
    goBack: function() { },
    setRefreshHandler: function(func) { }
}
Tfsi.Navigation.INavigation.registerInterface('Tfsi.Navigation.INavigation');

//_NavigationBase
Tfsi.Navigation._NavigationBase = function() {
    Tfsi.Navigation._NavigationBase.initializeBase(this, ['INavigation']);
}
Tfsi.Navigation._NavigationBase.prototype = {
    goHome: function() {
    },
    navigateTo: function(relativeUrl) {
        var e = Function._validateParams(arguments, [
            { name: "relativeUrl", type: String }
        ]);
        if (e) throw e;
    },
    goForward: function() {
        return false;
    },
    goBack: function() {
        return false;
    },
    setRefreshHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function }
        ]);
        if (e) throw e;
    }
}
Tfsi.Navigation._NavigationBase.registerClass('Tfsi.Navigation._NavigationBase', Tfsi._ServiceBase, Tfsi.Navigation.INavigation);


Type.registerNamespace('Tfsi.Shell');

//IPropertyBag

Type.registerNamespace('Tfsi.PropertyBag');

Tfsi.Shell.IPropertyBag = function() { }
Tfsi.Shell.IPropertyBag.prototype = {
    add: function(key, value) { },
    set_Item: function(key, value) { },
    set_Items: function(stringDict) { },
    get_Item: function(key) { },
    clear: function() { },
    remove: function(key) { },
    get_Count: function() { },
    containsKey: function() { },
    get_Keys: function() { },
    forEach: function() { propertyBagForEachCallback }

}
Tfsi.Shell.IPropertyBag.registerInterface('Tfsi.Shell.IPropertyBag');

//_PropertyBagBase

Tfsi.Shell._PropertyBagBase = function() {
    Tfsi.Shell._PropertyBagBase.initializeBase(this, ['IPropertyBag']);
}
Tfsi.Shell._PropertyBagBase.prototype = {
    add: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value" }
        ]);
        if (e) throw e;
    },
    set_Item: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value" }
        ]);
        if (e) throw e;
    },
    set_Items: function(keyedItemDict) {
        var e = Function._validateParams(arguments, [
            { name: "keyedItemDict", type: Tfsi.KeyedItemDictionary }
        ]);
        if (e) throw e;
    },
    get_Item: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
    },
    get_Keys: function() {
        return new Array();
    },
    containsKey: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
    },
    clear: function() {
    },
    remove: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
    },
    get_Count: function() {
        return 0;
    },
    forEach: function(action) {
        var e = Function._validateParams(arguments, [
            { name: "action", type: Function }
        ]);
        if (e) throw e;
    }


}
Tfsi.Shell._PropertyBagBase.registerClass('Tfsi.Shell._PropertyBagBase', Tfsi._ServiceBase, Tfsi.Shell.IPropertyBag);

//ContextMenuSections
Tfsi.Shell.ContextMenuSections = function() { };
Tfsi.Shell.ContextMenuSections.prototype =
{
    none: 0,
    favorites: 1,
    thomlet: 2,
    container: 4,
    //all : this.Favorites | this.Thomlet | this.Container
    all: 7

}
Tfsi.Shell.ContextMenuSections.registerEnum("Tfsi.Shell.ContextMenuSections", true);

//IContextMemu

Tfsi.Shell.IContextMenu = function() { }
Tfsi.Shell.IContextMenu.prototype = {
    add: function(rootMenuItem) { },
    clear: function() { },
    contextMenu: function(xPos, yPos, srcElement, contextMenuSections) { },
    setMenuContextItems: function(menuContextItemList) { },
    removeFromContextMenu : function(menuItemName) { }
}
Tfsi.Shell.IContextMenu.registerInterface('Tfsi.Shell.IContextMenu');

//_ContextMenuBase
Tfsi.Shell._ContextMenuBase = function() {
    Tfsi.Shell._ContextMenuBase.initializeBase(this, ['IContextMenu']);
}

Tfsi.Shell._ContextMenuBase.prototype = {
    add: function(rootMenuItem) {
        var e = Function._validateParams(arguments, [
            { name: "rootMenuItem", type: Tfsi.Shell.MenuItem }
        ]);
        if (e) throw e;
    },
    clear: function() {
    },
    contextMenu: function(xPos, yPos, srcElement, contextMenuSections) {
        var e = Function._validateParams(arguments, [
            { name: "xPos", type: Number },
            { name: "yPos", type: Number },
            { name: "srcElement", optional: true, mayBeNull: true },
            { name: "contextMenuSections", optional: true, mayBeNull: true }
        ]);
        if (e) throw e;
    },
    setMenuContextItems: function(menuContextItemList) {
        var e = Function._validateParams(arguments, [
            { name: "menuContextItemList", type: Tfsi.Shell.MenuContextItemList }
        ]);
        if (e) throw e;
    },
    removeFromContextMenu : function(menuItemName) {
        var e = Function._validateParams(arguments, [
            { name: "menuItemName", type: String }
        ]);
        if (e) throw e;
    }
}
Tfsi.Shell._ContextMenuBase.registerClass('Tfsi.Shell._ContextMenuBase', Tfsi._ServiceBase, Tfsi.Shell.IContextMenu);

//_MenuItemBase
Tfsi.Shell.MenuItemBase = function(id) {
    this._id = id;
    this._children = new Array();
    this._parent = null;
    this._isSeparator = false;
}

Tfsi.Shell.MenuItemBase.prototype = {
    get_Parent: function() {
        return this._parent;
    },
    _set_Parent: function(parent) {
        var e = Function._validateParams(arguments, [
            { name: "parent", type: Tfsi.Shell.MenuItemBase }
        ]);
        if (e) throw e;
        this._parent = parent;
    },
    _addChild: function(child) {
        var e = Function._validateParams(arguments, [
            { name: "child", type: Tfsi.Shell.MenuItemBase }
        ]);
        if (e) throw e;

        //TODO circular reference check
        child._set_Parent(this);
        Array.add(this._children, child);
    },
    get_Children: function() {
        return this._children
    },
    get_isSeparator: function() {
        return this._isSeparator;
    },
    get_Id: function() {
        return this._id;
    },
    findChild: function(id) {
        if (id == this._id) {
            return this;
        }
        if (this._isSeparator) {
            return null;
        }
        for (var i = 0; i < this._children.length; i++) {
            var child = this._children[i].findChild(id);
            if (child) {
                return child;
            }
        }
        return null;
    },
    _deleteChild: function(child) {
        var e = Function._validateParams(arguments, [
            { name: "child", type: Tfsi.Shell.MenuItem }
        ]);
        if (e) throw e;
        Array.remove(this._children, child);
    }
}

Tfsi.Shell.MenuItemBase.registerClass('Tfsi.Shell.MenuItemBase', null);

Tfsi.Shell.MenuItemBase._getAutoId = function() {
    if (!Tfsi.Shell.MenuItemBase._autoId) {
        Tfsi.Shell.MenuItemBase._autoId = -1;
    } else {
        Tfsi.Shell.MenuItemBase._autoId--;
    }
    return Tfsi.Shell.MenuItemBase._autoId;
}

//MenuSeparator
Tfsi.Shell.MenuSeparator = function() {
    var id = Tfsi.Shell.MenuItemBase._getAutoId();
    Tfsi.Shell.MenuSeparator.initializeBase(this, [id]);

    this._id = id;
    this._children = new Array();
    this._parent = null;
    this._isSeparator = false;

    this._isSeparator = true;
}

Tfsi.Shell.MenuSeparator.prototype = {
    _toStringHelper: function(sb) {
    },
    _addChild: function(child) {
    }
}

Tfsi.Shell.MenuSeparator.registerClass('Tfsi.Shell.MenuSeparator', Tfsi.Shell.MenuItemBase);


//MenuItem
Tfsi.Shell.MenuItem = function(id) {

    var e = Function._validateParams(arguments, [
        { name: "id", type: String, optional: true }
    ]);
    if (e) throw e;
    if (!id) {
        id = Tfsi.Shell.MenuItemBase._getAutoId();
    }

    Tfsi.Shell.MenuItem.initializeBase(this, [id]);
    this._id = id;
    this._children = new Array();
    this._parent = null;
    this._isSeparator = false;


    this._name = '';
    this._func = null;
    this._checked = null;
    this._enabled = true;
    this._accelerator = '';
    this._iconName = '';
    this._hotkey = '';

}

Tfsi.Shell.MenuItem.prototype = {
    get_Name: function() {
        return this._name;
    },
    set_Name: function(name) {
        var e = Function._validateParams(arguments, [
            { name: "name", type: String }
        ]);
        if (e) throw e;
        this._name = name;
    },
    get_Func: function() {
        return this._func;
    },
    set_Func: function(func) {
        var e = Function._validateParams(arguments, [
            { name: "func", type: Function }
        ]);
        if (e) throw e;
        this._func = func;
    },
    get_Checked: function() {
        return this._checked;
    },
    set_Checked: function(checked) {
        var e = Function._validateParams(arguments, [
            { name: "checked", mayBeNull: true, type: Boolean }
        ]);
        if (e) throw e;
        this._checked = checked;
    },
    set_Enabled: function(enabled) {
        var e = Function._validateParams(arguments, [
            { name: "enabled", type: Boolean }
        ]);
        if (e) throw e;
        this._enabled = enabled;
    },
    get_Enabled: function() {
        return this._enabled;
    },
    add: function(id, name, func, checked, enabled, accelerator, iconName, hotKey) {
        var e = Function._validateParams(arguments, [
            { name: "id", type: String },
            { name: "name", type: String },
            { name: "func", type: Function },
            { name: "checked", type: Boolean, mayBeNull: true, optional: true },
            { name: "enabled", type: Boolean, optional: true },
            { name: "accelerator", type: String, mayBeNull: true, optional: true },
            { name: "iconName", type: String, mayBeNull: true, optional: true },
            { name: "hotKey", type: String, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
        var child = new Tfsi.Shell.MenuItem(id);
        child.set_Name(name);
        child.set_Func(func);
        if (enabled != null) {
            child.set_Enabled(enabled);
        }
        if (checked != null) {
            child.set_Checked(checked);
        }
        if (accelerator != null) {
            child.set_Accelerator(accelerator);
        }
        if (iconName != null) {
            child.set_IconName(iconName);
        }
        if (hotKey != null) {
            child.set_Hotkey(hotKey);
        }
        this._addChild(child);
        return child;
    },
    addSeparator: function() {
        var child = new Tfsi.Shell.MenuSeparator();
        this._addChild(child);
    },
    _toString: function() {
        var sb = new Sys.StringBuilder();
        this._toStringHelper(sb);
        return sb.toString();
    },
    _toStringHelper: function(sb) {

    },
    get_Accelerator: function() {
        return this._accelerator;
    },
    set_Accelerator: function(accelerator) {
        var e = Function._validateParams(arguments, [
            { name: "accelerator", type: String }
        ]);
        if (e) throw e;
        this._accelerator = accelerator;
    },
    get_Hotkey: function() {
        return this._hotkey;
    },
    set_Hotkey: function(hotkey) {
        var e = Function._validateParams(arguments, [
            { name: "hotkey", type: String }
        ]);
        if (e) throw e;
        this._hotkey = hotkey;
    },
    get_IconName: function() {
        return this._iconName;
    },
    set_IconName: function(iconName) {
        var e = Function._validateParams(arguments, [
            { name: "iconName", type: String }
        ]);
        if (e) throw e;

        this._iconName = iconName;
    },
    get_ClickHandler: function() {
        return this._func;
    },
    set_ClickHandler: function(clickHandler) {
        var e = Function._validateParams(arguments, [
            { name: "clickHandler", type: Function }
        ]);
        if (e) throw e;
        this._func = clickHandler;
    },
    _getChildByName: function(name) {
        var e = Function._validateParams(arguments, [
            { name: "name", type: String }
        ]);
        if (e) throw e;
        var children = this.get_Children();
        for (var i = 0; i < children.length; i++) {
            if (children[i].get_Id() > 0 && children[i].get_Name() == name) {
                return children[i];
            }

        }
        return null;
    }
    //TODO
}

Tfsi.Shell.MenuItem.registerClass('Tfsi.Shell.MenuItem', Tfsi.Shell.MenuItemBase);

//MenuContextItem
Tfsi.Shell.MenuContextItem = function(contextkey, contextValue, showInMenu) {
    var e = Function._validateParams(arguments, [
        { name: "contextkey", type: String },
        { name: "contextValue", type: String, mayBeNull: true },
        { name: "showInMenu", type: Boolean }
    ]);
    if (e) throw e;
    this._contextkey = contextkey;
    this._contextValue = contextValue;
    this._showInMenu = showInMenu;
}
Tfsi.Shell.MenuContextItem.prototype = {
    get_ContextKey: function() {
        return this._contextkey;
    },
    get_ContextValue: function() {
        return this._contextValue;
    },
    get_ShowInMenu: function() {
        return this._showInMenu;
    }
}
Tfsi.Shell.MenuContextItem.registerClass('Tfsi.Shell.MenuContextItem', null);
//MenuContextItemList
Tfsi.Shell.MenuContextItemList = function() {
    this._items = [];
}

Tfsi.Shell.MenuContextItemList.prototype = {
    addItem: function(contextkey, contextValue, showInMenu) {
        var item = new Tfsi.Shell.MenuContextItem(contextkey, contextValue, showInMenu);
        this.add(item);
        return item;
    },

    add: function(item) {
        var e = Function._validateParams(arguments, [
            { name: "item", type: Tfsi.Shell.MenuContextItem }
        ]);
        if (e) throw e;
        Array.add(this._items, item);
    },

    remove: function(contextkey) {
        var e = Function._validateParams(arguments, [
            { name: "contextkey", type: String }
        ]);
        if (e) throw e;
        for (var i = 0; i < this._items.length; i++) {
            if (this._items[i].get_ContextKey() == contextkey) {
                Array.removeAt(this._items, i);
                break;
            }
        }
    },
    clear: function() {
        this._items = [];
    },

    containsKey: function(contextkey) {
        var e = Function._validateParams(arguments, [
            { name: "contextkey", type: String }
        ]);
        if (e) throw e;
        for (var i = 0; i < this._items.length; i++) {
            if (this._items[i].get_ContextKey() == contextkey) {
                return true;
            }
        }
        return false;
    },

    _get_Items: function() {
        return this._items;
    }

}

Tfsi.Shell.MenuContextItemList.registerClass('Tfsi.Shell.MenuContextItemList', null);
Tfsi.Shell.MenuContextItemList.forEach = function(menuContextItemList, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "menuContextItemList", type: Tfsi.Shell.MenuContextItemList },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = menuContextItemList._get_Items();
    for (var i = 0; i < items.length; i++) {

        if (method.call(instance, items[i])) {
            break;
        }
    }
}
//SubFunctionMenuStyle
Tfsi.Navigation.SubFunctionMenuStyle = function() { };
Tfsi.Navigation.SubFunctionMenuStyle.prototype =
{
    none: 0,
    addAsRoot: 1,
    showInNavTree: 2
}
Tfsi.Navigation.SubFunctionMenuStyle.registerEnum("Tfsi.Navigation.SubFunctionMenuStyle");

//SubFunctionItem
Tfsi.Navigation.SubFunctionItem = function(id, name, contexts, menuStyle) {
    var e = Function._validateParams(arguments, [
        { name: "id", type: String },
        { name: "name", type: String },
        { name: "contexts", type: Tfsi.StringDictionary, mayBeNull: true, optional: true },
        { name: "menuStyle", type: Tfsi.Navigation.SubFunctionMenuStyle, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    this._id = id;
    this._name = name;
    this._contexts = contexts;
    this._menuStyle = menuStyle;
}
Tfsi.Navigation.SubFunctionItem.prototype = {
    get_Id: function() {
        return this._id;
    },
    get_Name: function() {
        return this._name;
    },
    get_Contexts: function() {
        return this._contexts;
    },
    get_MenuStyle: function() {
        return this._menuStyle;
    }
}
Tfsi.Navigation.SubFunctionItem.registerClass('Tfsi.Navigation.SubFunctionItem', null);

//SubFunctionItemList
Tfsi.Navigation.SubFunctionItemList = function() {
    this._items = [];
}

Tfsi.Navigation.SubFunctionItemList.prototype = {
    addItem: function(id, name, contexts, menuStyle) {
        var item = new Tfsi.Navigation.SubFunctionItem(id, name, contexts, menuStyle);
        this.add(item);
        return item;
    },

    add: function(item) {
        var e = Function._validateParams(arguments, [
            { name: "item", type: Tfsi.Navigation.SubFunctionItem }
        ]);
        if (e) throw e;
        Array.add(this._items, item);
    },

    remove: function(id) {
        var e = Function._validateParams(arguments, [
            { name: "id", type: String }
        ]);
        if (e) throw e;
        for (var i = 0; i < this._items.length; i++) {
            if (this._items[i].get_Id() == id) {
                Array.removeAt(this._items, i);
                break;
            }
        }
    },
    clear: function() {
        this._items = [];
    },

    _get_Items: function() {
        return this._items;
    }

}

Tfsi.Navigation.SubFunctionItemList.registerClass('Tfsi.Navigation.SubFunctionItemList', null);
Tfsi.Navigation.SubFunctionItemList.forEach = function(subFunctionItemList, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "subFunctionItemList", type: Tfsi.Navigation.SubFunctionItemList },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = subFunctionItemList._get_Items();
    for (var i = 0; i < items.length; i++) {

        if (method.call(instance, items[i])) {
            break;
        }
    }
}

//ISubFunction
Tfsi.Navigation.ISubFunction = function() { }
Tfsi.Navigation.ISubFunction.prototype = {
    add: function(subFunctionItemList) { },
    clear: function() { }
}

Tfsi.Navigation.ISubFunction.registerInterface('Tfsi.Navigation.ISubFunction');

//_SubFunctionBase
Tfsi.Navigation._SubFunctionBase = function() {
    Tfsi.Navigation._SubFunctionBase.initializeBase(this, ['ISubFunction']);
}

Tfsi.Navigation._SubFunctionBase.prototype = {
    add: function(subFunctionItemList) {
        var e = Function._validateParams(arguments, [
            { name: "subFunctionItemList", type: Tfsi.Navigation.SubFunctionItemList }
        ]);
        if (e) throw e;
    },
    clear: function() { }


}
Tfsi.Navigation._SubFunctionBase.registerClass('Tfsi.Navigation._SubFunctionBase', Tfsi._ServiceBase, Tfsi.Navigation.ISubFunction);


//IThomlet
//InvokingType
Tfsi.Shell.WindowState = function() { };
Tfsi.Shell.WindowState.prototype =
{
    normal: 0,
    minimized: 1,
    maximized: 2,
    collapsed: 3
}
Tfsi.Shell.WindowState.registerEnum("Tfsi.Shell.WindowState");

Tfsi.Shell.IThomlet = function() { }
Tfsi.Shell.IThomlet.prototype = {
    get_OldDomain: function() { },
    get_ThomletId: function() { },
    registerEventObject: function(thomletEventsObj) { },
    get_Visible: function() { },
    get_Focused: function() { },
    get_Listening: function() { },
    get_Closing: function() { },
    close: function() { },
    get_WindowState: function() { },
    resizeTo: function(width, height) { },
    resizeBy: function(x, y) { },
    set_CollapsedWindowSize: function(height, width) { }
}
Tfsi.Shell.IThomlet.registerInterface('Tfsi.Shell.IThomlet');

//_ThomletBase

Tfsi.Shell._ThomletBase = function() {
    Tfsi.Shell._ThomletBase.initializeBase(this, ['IThomlet']);
}
Tfsi.Shell._ThomletBase.prototype = {
    get_OldDomain: function() {
    },
    registerEventObject: function(thomletEventsObj) {
        var e = Function._validateParams(arguments, [
            { name: "thomletEventsObj", type: Tfsi.Shell.IThomletEvents, mayBeNull: true }
        ]);
        if (e) throw e;
    },
    get_Visible: function() { },
    get_Focused: function() { },
    get_Listening: function() { },
    get_ThomletId: function() { },
    close: function() { },
    get_WindowState: function() { },
    resizeTo: function(width, height) {
        var e = Function._validateParams(arguments, [
            { name: "width", type: Number },
            { name: "height", type: Number }
        ]);
        if (e) throw e;
    },
    resizeBy: function(x, y) {
        var e = Function._validateParams(arguments, [
            { name: "x", type: Number },
            { name: "y", type: Number }
        ]);
        if (e) throw e;
    },
    set_CollapsedWindowSize: function(height, width) {
        var e = Function._validateParams(arguments, [
            { name: "height", type: Number },
            { name: "width", type: Number, mayBeNull: true }
        ]);
        if (e) throw e;
    }

}
Tfsi.Shell._ThomletBase.registerClass('Tfsi.Shell._ThomletBase', Tfsi._ServiceBase, Tfsi.Shell.IThomlet);

//IThomletEvents

Tfsi.Shell.IThomletEvents = function() { }
Tfsi.Shell.IThomletEvents.prototype = {
    focusChanged: function(sender, eventArgs) { },
    listeningChanged: function(sender, eventArgs) { },
    visibleChanged: function(sender, eventArgs) { },
    closing: function(sender, eventArgs) { },
    windowStateChanged: function(sender, eventArgs) { }
}
Tfsi.Shell.IThomletEvents.registerInterface('Tfsi.Shell.IThomletEvents');

//IShelvingManager 

Tfsi.Shell.IShelvingManager = function() { }
Tfsi.Shell.IShelvingManager.prototype = {
    start: function() { },
    stop: function() { }

}
Tfsi.Shell.IShelvingManager.registerInterface('Tfsi.Shell.IShelvingManager');

//_ShelvingBase
Tfsi.Shell._ShelvingBase = function() {
    Tfsi.Shell._ShelvingBase.initializeBase(this, ['IShelving']);
}
Tfsi.Shell._ShelvingBase.prototype = {
    start: function() { },
    stop: function() { }
}
Tfsi.Shell._ShelvingBase.registerClass('Tfsi.Shell._ShelvingBase', Tfsi._ServiceBase, Tfsi.Shell.IShelvingManager);


Type.registerNamespace('Tfsi.Preferences');

//IPreferenceBroker
Tfsi.Preferences.IPreferenceBroker = function() { }
Tfsi.Preferences.IPreferenceBroker.prototype = {
    setPreference: function(key, value) { },
    setPreferences: function(preferenceDict) { },
    getPreferences: function() { },
    getPreference: function(key) { },
    setPreferenceChangedHandler: function(handler) { },
    isPreferenceSupported: function(key) { }
}
Tfsi.Preferences.IPreferenceBroker.registerInterface('Tfsi.Preferences.IPreferenceBroker');

//_PreferenceBase
Tfsi.Preferences._PreferenceBase = function() {
    Tfsi.Preferences._PreferenceBase.initializeBase(this, ['IPreference']);
}
Tfsi.Preferences._PreferenceBase.prototype = {
    setPreference: function(key, value) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "value", type: String }
        ]);
        if (e) throw e;
    },
    setPreferences: function(preferenceDict) {
        var e = Function._validateParams(arguments, [
            { name: "preferenceDict", type: Tfsi.StringDictionary }
        ]);
        if (e) throw e;
    },
    getPreferences: function() {
        return new Tfsi.Preferences.PreferenceDictionary();
    },
    getPreference: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
    },
    setPreferenceChangedHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
    },
    isPreferenceSupported: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
    }

}
Tfsi.Preferences._PreferenceBase.registerClass('Tfsi.Preferences._PreferenceBase', Tfsi._ServiceBase, Tfsi.Preferences.IPreferenceBroker);

//PreferencesChangedEventArgs

Tfsi.Preferences.PreferencesChangedEventArgs = function(updatedPreferences) {
    var e = Function._validateParams(arguments, [
        { name: "updatedContext", type: Tfsi.Preferences.PreferenceDictionary }
    ]);
    if (e) throw e;
    Tfsi.Preferences.PreferencesChangedEventArgs.initializeBase(this);
    this._updatedPreferences = updatedPreferences;
}

Tfsi.Preferences.PreferencesChangedEventArgs.prototype = {

    get_UpdatedPreferences: function() {
        return this._updatedPreferences;
    }
}

Tfsi.Preferences.PreferencesChangedEventArgs.registerClass('Tfsi.Preferences.PreferencesChangedEventArgs', Sys.EventArgs);

//PreferenceItem

Tfsi.Preferences.PreferenceItem = function(id, value) {
    this._id = id;
    this._value = value;
    this._readonly = false;
}

Tfsi.Preferences.PreferenceItem.prototype = {
    get_Key: function() {
        return this._key;
    },
    get_ReadOnly: function() {
        return this._readonly;
    },
    get_Value: function() {
        return this._value;
    },
    _set_ReadOnly: function(readOnly) {
        var e = Function._validateParams(arguments, [
            { name: "readOnly", Type: Boolean }
        ]);
        if (e) throw e;
        this._readOnly = readOnly;
    }

}
Tfsi.Preferences.PreferenceItem.registerClass('Tfsi.Preferences.PreferenceItem', null);

//PreferenceDictionary
Tfsi.Preferences.PreferenceDictionary = function() {
    this._prefDictionary = new Object();
}

Tfsi.Preferences.PreferenceDictionary.prototype = {
    _add: function(key, item) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "item", type: Tfsi.Preferences.PreferenceItem }
        ]);
        if (e) throw e;
        if (this._prefDictionary[key]) {
            throw Error.argument(key, "An element with the same key already exists in the Dictionary.")
        }

        this._prefDictionary[key] = item;
    },
    _set_Item: function(key, item) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String },
            { name: "item", type: Tfsi.Preferences.PreferenceItem }
        ]);
        if (e) throw e;
        this._prefDictionary[key] = item;
    },
    get_Item: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        //if(!this._prefDictionary[key]) {
        //    throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        //}
        return this._prefDictionary[key];
    },
    get_Keys: function() {
        var arr = new Array();
        for (var key in this._prefDictionary) {
            if (!this._prefDictionary.hasOwnProperty(key)) {
                continue;
            }
            Array.add(arr, key);
        }
        return arr;
    },
    get_Count: function() {
        var count = 0;
        for (var prop in this._prefDictionary) {
            if (!this._prefDictionary.hasOwnProperty(prop)) {
                continue;
            }
            ++count;
        }
        return count;
    },
    _remove: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;

        if (!this._prefDictionary[key]) {
            throw Error.keyNotFoundException('Key: "' + key + '"is not found in the Dictionary.');
        }

        this._prefDictionary[key] = null;

    },

    _clear: function() {
        this._prefDictionary = new Object();

    },

    containsKey: function(key) {
        var e = Function._validateParams(arguments, [
            { name: "key", type: String }
        ]);
        if (e) throw e;
        if (!this._prefDictionary[key] || !this._prefDictionary.hasOwnProperty(key)) {
            return false;
        }
        else {
            return true;
        }

    },

    _get_Items: function() {
        return this._prefDictionary;
    }
}
Tfsi.Preferences.PreferenceDictionary.registerClass('Tfsi.Preferences.PreferenceDictionary', null);
Tfsi.Preferences.PreferenceDictionary.forEach = function(dict, method, instance) {
    var e = Function._validateParams(arguments, [
        { name: "dict", type: Tfsi.Preferences.PreferenceDictionary },
        { name: "method", type: Function },
        { name: "instance", mayBeNull: true, optional: true }
    ]);
    if (e) throw e;
    var items = dict._get_Items();
    for (var key in items) {
        if (!items.hasOwnProperty(prop)) {
            continue;
        }
        if (method.call(instance, key, items[key])) {
            break;
        }
    }
}

//IPreferenceWindow
Tfsi.Preferences.IPreferenceWindow = function() { }

Tfsi.Preferences.IPreferenceWindow.prototype = {
    set_IsDirty: function(isDirty) { },
    get_IsDirty: function() { },
    setValidatingHandler: function(handler) { },
    setApplyHandler: function(handler) { }
}

Tfsi.Preferences.IPreferenceWindow.registerInterface('Tfsi.Preferences.IPreferenceWindow');

Tfsi.Preferences.ApplyEventArgs = function(preferenceDictionary) {
    var e = Function._validateParams(arguments, [
        { name: " preferenceDictionary ", Type: Tfsi.StringDictionary }
    ]);
    if (e) throw e;
    Tfsi.Preferences.ApplyEventArgs.initializeBase(this);
    this._updatedPreferences = preferenceDictionary;
}
Tfsi.Preferences.ApplyEventArgs.prototype = {
    get_UpdatedPreferences: function() {
        return this._updatedPreferences;
    }
}

Tfsi.Preferences.ApplyEventArgs.registerClass('Tfsi.Preferences.ApplyEventArgs', Sys.EventArgs);

//PreferenceWindow ValidatingEventArgs
Tfsi.Preferences.ValidatingEventArgs = function() {
    Tfsi.Preferences.ValidatingEventArgs.initializeBase(this);
    this._errorMessage = null;
    this._cancel = null;
}

Tfsi.Preferences.ValidatingEventArgs.prototype = {
    set_ErrorMessage: function(errorMessage) {
        var e = Function._validateParams(arguments, [
            { name: "errorMessage", type: String }
        ]);
        if (e) throw e;

        this._errorMessage = errorMessage;
    },
    get_ErrorMessage: function() {
        return this._errorMessage;
    },
    set_Cancel: function(cancel) {
        var e = Function._validateParams(arguments, [
            { name: "cancel", type: Boolean }
        ]);
        if (e) throw e;

        this._cancel = cancel;
    },
    get_Cancel: function() {
        return this._cancel;
    }
}

Tfsi.Preferences.ValidatingEventArgs.registerClass('Tfsi.Preferences.ValidatingEventArgs', Sys.EventArgs);


//_PreferenceWindowBase
Tfsi.Preferences._PreferenceWindowBase = function() {
    Tfsi.Preferences._PreferenceWindowBase.initializeBase(this, ['IPreferenceWindow']);
}

Tfsi.Preferences._PreferenceWindowBase.prototype = {
    get_IsDirty: function() {
        return false;
    },
    set_IsDirty: function(isDirty) {
        var e = Function._validateParams(arguments, [
            { name: "isDirty", Type: Boolean }
        ]);
        if (e) throw e;
    },
    setValidatingHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
    },
    setApplyHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
    }
}

Tfsi.Preferences._PreferenceWindowBase.registerClass('Tfsi.Preferences._PreferenceWindowBase', Tfsi._ServiceBase, Tfsi.Preferences.IPreferenceWindow);

//ISymbolList
Type.registerNamespace('Tfsi.SymbolList');

//SymbolListType flag
Tfsi.SymbolList.SymbolListTypes = function() { };
Tfsi.SymbolList.SymbolListTypes.prototype =
{
    unspecified: 1,
    localUploadable: 2,
    remote: 4,
    external: 8,
    portfolioWarehouse: 16,
    localNotUploadable: 32,
    //all : this.localUploadable | this.remote | this.external | this.portfolioWarehouse | this.localNotUploadable
    //all: 1 | 2 | 4 | 8 | 16 | 32
    all : 63
}
Tfsi.SymbolList.SymbolListTypes.registerEnum("Tfsi.SymbolList.SymbolListTypes", true);

//Symbol
Tfsi.SymbolList.Symbol = function(nativeSymbol) {
    var e = Function._validateParams(arguments, [
        { name: "nativeSymbol", type: Object }
    ]);
    if (e) throw e;
    this._nativeSymbol = nativeSymbol;
}

Tfsi.SymbolList.Symbol.prototype = {
    get_Id: function() {
        return this._nativeSymbol.ID;
    },
    get_Name: function() {
        return this._nativeSymbol.Name;
    },
    get_ComponentId: function() {
        return this._nativeSymbol.ComponentID;
    }
}
Tfsi.SymbolList.Symbol.registerClass('Tfsi.SymbolList.Symbol', null);

//SymbolListInfo
Tfsi.SymbolList.SymbolListInfo = function(nativeInfo) {
    var e = Function._validateParams(arguments, [
        { name: "nativeInfo", type: Object }
    ]);
    if (e) throw e;
    this._nativeInfo = nativeInfo;
}

Tfsi.SymbolList.SymbolListInfo.prototype = {
    get_Id: function() {
        return this._nativeInfo.ID;
    },
    get_Name: function() {
        return this._nativeInfo.Name;
    },
    get_LongName: function() {
        return this._nativeInfo.LongName;
    },
    get_Creator: function() {
        return this._nativeInfo.Creator;
    },
    get_TopasListID: function() {
        return this._nativeInfo.TOPASListID;
    },
    get_Type: function() {
        return this._nativeInfo.Type;
    },
    get_Count: function() {
        return this._nativeInfo.SymbolCount;
    },
    contains: function(symbolName) {
        var e = Function._validateParams(arguments, [
            { name: "symbolName", type: String }
        ]);
        if (e) throw e;
        return this._nativeInfo.Contains(symbolName);

    },
    getSymbolByComponentId: function(componentId) {
        var e = Function._validateParams(arguments, [
            { name: "componentId", type: Number }
        ]);
        if (e) throw e;
        var symbol = this._nativeInfo.GetSymbol(componentId);
        if(symbol){
            return new Tfsi.SymbolList.Symbol(symbol);
        }
    },
    getSymbolBySymbolId: function(symbolId) {
        var e = Function._validateParams(arguments, [
            { name: "symbolId", type: Number }
        ]);
        if (e) throw e;
        var symbol = this._nativeInfo.GetSymbol2(symbolId);
        if (symbol) {
            return new Tfsi.SymbolList.Symbol(symbol);
        }
    },
    forEach: function(distinct, method, instance) {
        var e = Function._validateParams(arguments, [
            { name: "destinct", type: Boolean },
            { name: "method", type: Function },
            { name: "instance", mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
        var symbols;
        if (distinct) {
            symbols = this._nativeInfo.GetDistinctSymbols().toArray();
        }
        else {
            symbols = this._nativeInfo.Symbols.toArray();
        }
        for (var i = 0; i < symbols.length; i++) {
            var symbol = symbols[i];
            if (symbol) {
                var symbolWrapper = new Tfsi.SymbolList.Symbol(symbol);
                if (method.call(instance, symbolWrapper)) {
                    break;
                }
            }
        }
    }
}
Tfsi.SymbolList.SymbolListInfo.registerClass('Tfsi.SymbolList.SymbolListInfo', null);

//SymbolListInfoList
Tfsi.SymbolList.SymbolListInfoList = function(nativeLists) {
    if (nativeLists) {
        this._items = nativeLists;
    }
    else {
        this._items = new Array();
    }
}

Tfsi.SymbolList.SymbolListInfoList.prototype = {

    get_Count: function() {
        return this._items.length;
    },
    forEach: function(method, instance) {
        var e = Function._validateParams(arguments, [
            { name: "method", type: Function },
            { name: "instance", mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
        var items = this._items;
        for (var i in items) {

            if (method.call(instance, new Tfsi.SymbolList.SymbolListInfo(items[i]))) {
                break;
            }
        }
    }

}

//SymbolListChangedEventType
Tfsi.SymbolList.SymbolListChangedEventType = function() { };
Tfsi.SymbolList.SymbolListChangedEventType.prototype =
{
    add: 0,
    remove: 1,
    rename: 2,
    modified: 3,
    savedToPortfolioWarehouse: 4,
    downloadedFromPortfolioWarehouse: 5,
    updatedInPortfolioWarehouse: 6

}
Tfsi.SymbolList.SymbolListChangedEventType.registerEnum("Tfsi.SymbolList.SymbolListChangedEventType");


Tfsi.SymbolList.ISymbolListManager = function() { }

Tfsi.SymbolList.ISymbolListManager.prototype = {
    //return a Tfsi.SymbolList.SymbolListInfoList,
    //symbolListTypeFilter: Tfsi.SymbolList.SymbolListType, can be null, Local, remote or Local|Remote
    getSymbolLists: function(symbolListTypeFilter) { },

    //return a Tfsi.SymbolList.SymbolListInfo by Id
    getSymbolListById: function(symbolListId) { },

    //return a Tfsi.SymbolList.SymbolListInfo by TopasListId
    getSymbolListByTopasListId: function(topasListID, downloadFromPortfolioWarehouse) { },

    //hook up the SymbolListChanged callback
    setSymbolListChangedHandler: function(handler) { }

}

Tfsi.SymbolList.ISymbolListManager.registerInterface('Tfsi.SymbolList.ISymbolListManager');

Tfsi.SymbolList.SymbolListChangedEventArgs = function(symbolListId, topasListID, eventType) {
    var e = Function._validateParams(arguments, [
        { name: "symbolListId", Type: String },
        { name: "topasListID", Type: String, mayBeNull: true },
        { name: "eventType" }
    ]);
    if (e) throw e;
    Tfsi.SymbolList.SymbolListChangedEventArgs.initializeBase(this);
    this._symbolListId = symbolListId;
    this._topasListID = topasListID;
    this._eventType = parseInt(eventType);
}
Tfsi.SymbolList.SymbolListChangedEventArgs.prototype = {
    // id of the symbol list
    get_SymbolListId: function() {
        return this._symbolListId;
    },
    // TopasId of the symbol list
    get_TopasListId: function() {
        return this._topasListID;
    },
    //return one of the event type defined in Tfsi.SymbolList.SymbolListChangedEventType
    get_EventType: function() {
        return this._eventType;
    }
}

Tfsi.SymbolList.SymbolListChangedEventArgs.registerClass('Tfsi.SymbolList.SymbolListChangedEventArgs', Sys.EventArgs);

//_SymbolListBase
Tfsi.SymbolList._SymbolListBase = function() {
    Tfsi.SymbolList._SymbolListBase.initializeBase(this, ['ISymbolListManager']);
}

Tfsi.SymbolList._SymbolListBase.prototype = {
    getSymbolLists: function(symbolListTypeFilter) {
        var e = Function._validateParams(arguments, [
            { name: "symbolListTypeFilter", type: Tfsi.SymbolList.SymbolListTypes, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
    },
    getSymbolListById: function(symbolListId) {
        var e = Function._validateParams(arguments, [
            { name: "symbolListId", type: Number }
        ]);
        if (e) throw e;
    },
    getSymbolListByTopasListId: function(topasListID, downloadFromPortfolioWarehouse) {
        var e = Function._validateParams(arguments, [
            { name: "symbolListId", type: Number },
            { name: "downloadFromPortfolioWarehouse", type: Boolean }
        ]);
        if (e) throw e;
    },
    setSymbolListChangedHandler: function(handler) {
        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
    }

}

Tfsi.SymbolList._SymbolListBase.registerClass('Tfsi.SymbolList._SymbolListBase', Tfsi._ServiceBase, Tfsi.SymbolList.ISymbolListManager);


Type.registerNamespace('Tfsi.Logging');

//Logging Category Enum
Tfsi.Logging.Category = function() { };
Tfsi.Logging.Category.prototype =
{
    audit: 0x80,
    error: 0x20,
    fatalError: 0x40,
    info: 4,
    remoteCall: 0x100,
    remoteReturn: 0x200,
    security: 0x10,
    traceHigh: 1,
    traceLow: 2,
    warning: 8

}
Tfsi.Logging.Category.registerEnum("Tfsi.Logging.Category");

Tfsi.Logging.ILogger = function() { }

Tfsi.Logging.ILogger.prototype = {
    writeMessage: function(message, category) { },
    writeInfo: function(info) { }
}

Tfsi.Logging.ILogger.registerInterface('Tfsi.Logging.ILogger');

//_LoggingBase
Tfsi.Logging._LoggerBase = function() {
    Tfsi.Logging._LoggerBase.initializeBase(this, ['ILogger']);
}

Tfsi.Logging._LoggerBase.prototype = {
    writeMessage: function(message, category) {
        var e = Function._validateParams(arguments, [
            { name: "message", type: String },
            { name: "category", type: Tfsi.Logging.Category, mayBeNull: true, optional: true }
        ]);
        if (e) throw e;
    },
    writeInfo: function(info) {
        var e = Function._validateParams(arguments, [
            { name: "info", type: String }
        ]);
        if (e) throw e;
    }
}

Tfsi.Logging._LoggerBase.registerClass('Tfsi.Logging._LoggerBase', Tfsi._ServiceBase, Tfsi.Logging.ILogger);

//Map between FSI service name and type
Tfsi.__ServiceTypes = {
    IContext: { name: 'IContext', type: Tfsi.Context._ContextBase, implemented: false },
    IDrilldown: { name: 'IDrilldown', type: Tfsi.Navigation._DrilldownBase, implemented: false },
    IContextMenu: { name: 'IContextMenu', type: Tfsi.Shell._ContextMenuBase, implemented: false },
    IPropertyBag: { name: 'IPropertyBag', type: Tfsi.Shell._PropertyBagBase, implemented: false },
    ISubFunction: { name: 'ISubFunction', type: Tfsi.Navigation._SubFunctionBase, implemented: false },
    INavigation: { name: 'INavigation', type: Tfsi.Navigation._NavigationBase, implemented: false },
    IThomlet: { name: 'IThomlet', type: Tfsi.Shell._ThomletBase, implemented: false },
    IPreference: { name: 'IPreference', type: Tfsi.Preferences._PreferenceBase, implemented: false },
    IShelving: { name: 'IShelving', type: Tfsi.Shell._ShelvingBase, implemented: false },
    IPreferenceWindow: { name: 'IPreferenceWindow', type: Tfsi.Preferences._PreferenceWindowBase, implemented: false },
    ISymbolListManager: { name: 'ISymbolListManager', type: Tfsi.SymbolList._SymbolListBase, implemented: false },
    ILogger: { name: 'ILogger', type: Tfsi.Logging._LoggerBase, implemented: false }
}
Tfsi.__oldregisterClass = Type.prototype.registerClass;
Type.prototype.registerClass = function Tfsi$registerClassHook(typeName, baseType, interfaceTypes) {
    Tfsi.__oldregisterClass.apply(this, arguments);
    if (baseType && baseType.inheritsFrom(Tfsi._ServiceBase) && !Tfsi.__useBaseImplementation) {
        Tfsi.__updateServiceType(baseType, this);
    }
}

if (typeof (Sys) !== 'undefined') Sys.Application.notifyScriptLoaded();