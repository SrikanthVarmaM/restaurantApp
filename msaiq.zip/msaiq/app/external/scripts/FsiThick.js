/***********************************************/
/* Thomson Web Integration API Standard        */
/* Release Version 1.1						   */
/* FsiInterface: 1.2.1.1	       */
/* FsiSymbolList: 1.2.1.0	           */
/* FsiThick: 1.2.1.8			       */
/* Copyright (c) 2006-2010 Thomson Reuters     */
/***********************************************/

Tfsi._ILXWab = function () {
    if (!document.getElementById('Tfsi_span')) {
        var tempStr = "<SPAN name='Tfsi_span' id='Tfsi_span' STYLE='display: none;'></SPAN>";
        document.body.insertAdjacentHTML("AfterBegin", tempStr);
        var tempstr = "<OBJECT id='Tfsi_WebAppHelper' CLASSID='clsid:42E317A5-86A1-447B-BCED-1B802844D74D'></OBJECT>";
        Tfsi_span.innerHTML = tempstr;
        Tfsi_WebAppHelper.externalinterface = window.external;
    }
    this._span = document.getElementById('Tfsi_span');
    this._symbolListsBehavior = null;
}

Tfsi._ILXWab.prototype = {
    _initQueries: function (progName, func) {
        if (this._span.savedQueries) {
            return;
        }

        this._span.symlistAppName = progName;
        this._span.onsymbollistchange = Tfsi._OnSavedQueryChange;

        try {
            // If symbol list behavior is already attached, needs to remove it first
            // and then attaches it again so the symlistAppName could take effect.
            if (this._symbolListsBehavior) {
                this._span.removeBehavior(this._symbolListsBehavior);
            }

            this._symbolListsBehavior = this._span.addBehavior("#Tfsi_WebAppHelper#SymbolLists");

            this._span.savedQueries = true;
            this._span.savedQueryHandler = func;

        }
        catch (e) {
            this._span.savedQueries = false;
        }
    },
    getQueryList: function () {
        try {
            var list = this._span.GetQueries();
            return list.toArray();
        }
        catch (e) {
        }
        return null;
    },
    getQuery: function (qName) {
        try {
            var qry = this._span.GetQueryByName(qName);
            return qry;
        }
        catch (e) {
        }

        return null;
    },
    addQuery: function (qName, qText) {
        try {
            var old = this.getQuery(qName);
            if (old == qText) {
                return false;
            }
            if (old) {
                this.deleteQuery(qName);
            }
            if (qText) {
                this._span.AddQuery(qName, qText);
            }
            return true;
        }
        catch (e) {
            return false;
        }
    },
    deleteQuery: function (qName) {
        try {
            this._span.DeleteQuery(qName);
        }
        catch (e) {
        }
    },

    renameQuery: function (oldName, newName) {
        try {
            this._span.RenameQuery(oldName, newName);
        }
        catch (e) {
        }
    },
    initSymbolLists: function () {
        if (!this._symbolListsBehavior) {
            this._symbolListsBehavior = this._span.addBehavior("#Tfsi_WebAppHelper#SymbolLists");
            var list = this._span.GetILXSymbolLists();
            this._span.symbolLists = true;
        }
    },
    setSymbolListHandler: function (func) {
        this._span.onsymbollistchange2 = func;
    },
    getSymbolLists: function (filter) {
        //try {
        var list = this._span.GetSymbolLists(filter);
        return list.toArray();
        //}
        //catch(e) {
        //}

        //return null;
    },

    getSymbolsFromList: function (listName) {
        try {
            var list = this._span.GetILXSymbolsFromList(listName);
            return list.toArray();
        }
        catch (e) {
        }

        return null;
    },

    getTopasIdBySymListName: function (listName) {
        try {
            return this._span.GetTopasIdBySymListName(listName);
        }
        catch (e) {
        }

        return -1;
    },
    getSymbolList: function (symbolListId) {
        //try {
        return this._span.GetSymbolList(symbolListId);
        //}
        //catch(e) {
        //}

        //return null;
    },
    getSymbolListByTopasId: function (topasId, downloadFromPortfolioWarehouse) {
        //try {
        return this._span.GetSymbolList2(topasId, downloadFromPortfolioWarehouse);
        //}
        //catch(e) {
        //}

        //return null;
    }
}
Tfsi._ILXWab.registerClass('Tfsi._ILXWab', null);

Tfsi._getILXWab = function () {
    if (!Tfsi._ilxWabObj) {
        Tfsi._ilxWabObj = new Tfsi._ILXWab();
    }
    return Tfsi._ilxWabObj;
}

Tfsi._OnSavedQueryChange = function () {
    var savedQueryHandler = window.event.srcElement.savedQueryHandler;
    var symListName = window.event.getAttribute("SymListName");
    var eventType = window.event.getAttribute("EventType");
    if (savedQueryHandler == null || savedQueryHandler(symListName, eventType)) {
        event.returnValue = true;
    }

}

//_SymbolList
Tfsi.SymbolList._SymbolList = function () {
    Tfsi.SymbolList._SymbolList.initializeBase(this);
    this._wab = Tfsi._getILXWab();
    if (this._wab) {
        this._wab.initSymbolLists();
        this._wab.setSymbolListHandler(Tfsi.SymbolList._SymbolList._OnSymbolListChanged);
    }
    this._handler = null;
}

Tfsi.SymbolList._SymbolList.prototype = {
    getSymbolLists: function (symbolListTypeFilter) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'getSymbolLists', [symbolListTypeFilter]);
        if (!symbolListTypeFilter) {
            symbolListTypeFilter = Tfsi.SymbolList.SymbolListTypes.all;
        }

        if (this._wab) {
            var nativeLists = this._wab.getSymbolLists(symbolListTypeFilter);
            var symbolLists = new Tfsi.SymbolList.SymbolListInfoList(nativeLists);

            return symbolLists;
        }
    },
    getSymbolListById: function (symbolListId) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'getSymbolListById', [symbolListId]);
        if (this._wab) {
            var nativeObject = this._wab.getSymbolList(symbolListId);
            if (nativeObject) {
                return new Tfsi.SymbolList.SymbolListInfo(nativeObject);
            }
        }

    },
    getSymbolListByTopasListId: function (topasListID, downloadFromPortfolioWarehouse) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'getSymbolListByTopasListId', [topasListID, downloadFromPortfolioWarehouse]);
        if (this._wab) {
            var nativeObject = this._wab.getSymbolListByTopasId(topasListID, downloadFromPortfolioWarehouse);
            if (nativeObject) {
                return new Tfsi.SymbolList.SymbolListInfo(nativeObject);
            }
        }
    },
    setSymbolListChangedHandler: function (handler) {
        Tfsi.SymbolList._SymbolList.callBaseMethod(this, 'setSymbolListChangedHandler', [handler]);
        this._handler = handler;
    }
}

Tfsi.SymbolList._SymbolList.registerClass('Tfsi.SymbolList._SymbolList', Tfsi.SymbolList._SymbolListBase, Tfsi.SymbolList.ISymbolListManager);

Tfsi.SymbolList._SymbolList._OnSymbolListChanged = function () {
    //alert(symListName + " " + eventType);
    var symListId = window.event.getAttribute("ID");
    var topasId = window.event.getAttribute("TOPAS_LIST_ID");
    var eventType = window.event.getAttribute("EventType");

    var symbolList = Tfsi.ServiceFactory.getService('ISymbolListManager');
    if (symbolList && symbolList._handler) {
        var action = function () {
            var eventArgs = new Tfsi.SymbolList.SymbolListChangedEventArgs(symListId, topasId, eventType);
            symbolList._handler(symbolList, eventArgs);
        }
        window.setTimeout(action, 200);
    }
}

///<reference name="MicrosoftAjax.debug.js" />
///<reference path="FsiInterfaces.js" />

// Tell the base interface to use the base implementation
// if we are not running in Thomson ONE.
Tfsi.T1Version = null;
if (!window.external || !window.external.IlxVersion) {
    Tfsi.__useBaseImplementation = true;
}
else {
    Tfsi.T1Version = window.external.GetContext2("T1Version");
}

//_Context
Tfsi.Context._Context = function () {
    Tfsi.Context._Context.initializeBase(this);
    this._contextChangedHandler = null;
    this._rawContexts = null;
}

Tfsi.Context._Context.prototype = {
    setContexts: function (contextDict, updateOnly) {
        Tfsi.Context._Context.callBaseMethod(this, 'setContexts', [contextDict, updateOnly]);

        if (contextDict.get_Count() == 0) {
            throw Error.argument(contextDict, "contextDict is empty.");
        }

        var distribute = true;
        var attributes = "IlxReason=prog";
        if (updateOnly) {
            attributes += ";UpdateOnly";
        }
        var reason = "UI";

        var xmlContext = Tfsi.Context._dictionaryToXmlDom(contextDict);

        /* Update our context */
        window.external.SetContext2(xmlContext, attributes);
        /* Distribute the Symbol */
        if (distribute) {
            var persistOption = "";
            if (attributes != null && attributes.indexOf("NoPersist=N") != -1) {
                persistOption = ";NoPersist=N";
            } else if (attributes != null && attributes.indexOf("NoPersist=Y") != -1) {
                persistOption = ";NoPersist=Y";
            }

            window.external.FireOnContextChanged(xmlContext, "IlxReason=" + reason + persistOption);
        }
        this._rawContexts = this._getRawContexts();
    },
    setContext: function (name, value, updateOnly) {
        Tfsi.Context._Context.callBaseMethod(this, 'setContext', [name, value, updateOnly]);

        if (!this.isContextSupported(name)) {
            throw new Error.fsiContextAccessDeniedException();
        }
        var ctxDict = new Tfsi.KeyedItemDictionary();
        ctxDict.add(name, value);
        this.setContexts(ctxDict, updateOnly);

    },
    getContexts: function () {
        var retVal = new Tfsi.Context.ContextDictionary();

        var xmlContext = window.external.GetContext2();
        if (xmlContext) {
            retVal = Tfsi.Context._XmlDomToDictionary(xmlContext);
        }

        return retVal;
    },
    getContext: function (key) {
        Tfsi.Context._Context.callBaseMethod(this, 'getContext', [key]);

        var name = key;
        if (name == "Entity") {
            name = "Symbol";
        }

        var xmlContext = window.external.GetContext2(name, "Format=document");
        if (xmlContext) {
            var retVal = new Tfsi.Context.ContextDictionary();
            retVal = Tfsi.Context._XmlDomToDictionary(xmlContext);
            if (retVal.containsKey(key)) {
                return retVal.get_Item(key);
            }
        }
    },
    setContextHandler: function (handler) {
        Tfsi.Context._Context.callBaseMethod(this, 'setContextHandler', [handler]);

        var e = Function._validateParams(arguments, [
            { name: "handler", type: Function, mayBeNull: true }
        ]);
        if (e) throw e;
        this._contextChangedHandler = handler;
        this._rawContexts = this._getRawContexts();
    },
    _ContextChangedCallback: function (newContext, orignalReason) {
        var currentContexts = this._getRawContexts(newContext);

        var ctxtHandler = this._contextChangedHandler;

        if (ctxtHandler == null) {
            return true;
        }
        var ctxDict = new Tfsi.Context.ContextDictionary();
        var subFunction = null;
        var commandArgs = null;
        var items = currentContexts ? currentContexts._get_Items() : null;
        for (var name in items) {
            var newItem = items[name].get_Value();
            var newValue;
            if (typeof newItem == "string") {
                newValue = newItem;
            }
            else if (Tfsi.Context.ContextValue.isInstanceOfType(newItem)) {
                newValue = newItem.get_Value();
            }
            else if (Tfsi.Context.ContextItem.isInstanceOfType(newItem)) {
                newItem = newItem.get_Value(); //From ContextItem to ContextValue (w/wo contextValues[])
                if (typeof newItem == "string") {
                    newValue = newItem;
                }
                else {
                    newValue = newItem.get_Value();
                }
            }

            if (this._rawContexts && this._rawContexts.containsKey(name)) {
                var oldItem = this._rawContexts.get_Item(name).get_Value();
                var oldValue;
                if (typeof oldItem == "string") {
                    oldValue = oldItem;
                }
                else if (Tfsi.Context.ContextValue.isInstanceOfType(oldItem)) {
                    oldValue = oldItem.get_Value();
                }
                else if (Tfsi.Context.ContextItem.isInstanceOfType(oldItem)) {
                    oldItem = oldItem.get_Value(); //From ContextItem to ContextValue (w/wo contextValues[])
                    if (typeof oldItem == "string") {
                        oldValue = oldItem;
                    }
                    else {
                        oldValue = oldItem.get_Value();
                    }
                }

                if (oldItem && oldValue == newValue && name != "SubFunction" &&
                    name != "CommandArgs" && name != "AddlURLParams") {
                    continue;
                }
            }

            if (name == "Symbol" || name == "Entity") {
                if (ctxDict.containsKey("Entity")) {
                    continue;
                }
                ctxDict._set_Item("Entity", new Tfsi.Context.ContextItem("Entity", newItem));
            }
            else if (name == "NewSymbol") {
                ctxDict._set_Item("Entity", new Tfsi.Context.ContextItem("Entity", newItem));
            }
            else if (name == "SubFunction") {
                subFunction = newValue;
            }
            else if (name == "CommandArgs" && newValue.length > 0) {
                if (Tfsi.T1Version && Tfsi.CompareVersions(Tfsi.T1Version, "4.6.0.0") < 0) {
                    newValue = decodeURIComponent(newValue);
                }
                commandArgs = newValue;
            }
            else if (name == "AddlURLParams" && newValue.length > 0) {
                newValue = newValue.replace("CommandArgs=", "");
                if (Tfsi.T1Version && Tfsi.CompareVersions(Tfsi.T1Version, "4.6.0.0") < 0) {
                    newValue = decodeURIComponent(newValue);
                }
                commandArgs = newValue;
            }
            else {
                ctxDict._set_Item(name, new Tfsi.Context.ContextItem(name, newItem));
            }
        }
        this._rawContexts = this._getRawContexts();

        var reason = Tfsi.Context.ContextChangedReason.context;
        if (orignalReason == "dnd") {
            reason = Tfsi.Context.ContextChangedReason.dragAndDrop;
        }
        else if (orignalReason == "ddn") {
            reason = Tfsi.Context.ContextChangedReason.drilldown;
        }
        else if (orignalReason == "rmb") {
            reason = Tfsi.Context.ContextChangedReason.contextMenu;
        }
        var args = new Tfsi.Context.ContextChangedEventArgs(ctxDict, subFunction, commandArgs, reason);
        if (ctxtHandler(this, args)) {
            return true;
        }
        return false;
    },
    isContextSupported: function (key) {
        Tfsi.Context._Context.callBaseMethod(this, 'isContextSupported', [key]);

        return true;
    },
    transform: function (ctxValue, ctxInFormat, ctxOutFormat) {
        var retVal = ctxValue;
        var ctxSupportedIn = null;
        var ctxSupportedOut = null;

        var ctxIn = "<Context><Prop Name='Symbol' Value='" + ctxValue + "' /></Context>";

        if (ctxInFormat) {
            ctxSupportedIn = "<Context><Prop Name='Symbol' Type ='" + ctxInFormat + "' /></Context>";
        }

        if (ctxOutFormat) {
            ctxSupportedOut = "<Context><Prop Name='Symbol' Type ='" + ctxOutFormat + "' /></Context>";
        }

        try {
            var ctx = "" + window.external.Transform(ctxIn, ctxSupportedIn, ctxSupportedOut, null);
            retVal = ctx.split('=')[1];
        } catch (e) {
            retVal = ctxValue;
        }

        return retVal;
    },
    transformContext: function (contextValueIn, outFormatFilter, handler) {
        Tfsi.Context._Context.callBaseMethod(this, 'transformContext', [contextValueIn, outFormatFilter, handler]);

        var tcEvtArgs = this._transformContext(contextValueIn, outFormatFilter);
        if (handler) {
            handler(this, tcEvtArgs);
        }
    },
    transformContexts: function (contextValuesIn, outFormatFilters, handler) {
        Tfsi.Context._Context.callBaseMethod(this, 'transformContexts', [contextValuesIn, outFormatFilters, handler]);
        var ctxSupportedIn = null;
        var ctxSupportedOut = null;
        var arrTCtxKIDict = new Array();
        var arrTCtxStatus = new Array();

        var nMaxTCtx = contextValuesIn.length;
        for (var i = 0; i < nMaxTCtx; i++) {
            var itemEvtArgs = this._transformContext(contextValuesIn[i], outFormatFilters[i]);
            var itemResult = itemEvtArgs.get_Result();
            var itemStatus = itemEvtArgs.get_Status();
            if (itemResult.length > 0) {
                arrTCtxKIDict[i] = itemResult[0];
                arrTCtxStatus[i] = itemStatus[0];
            }
        }

        var tcEvtArgs = new Tfsi.Context.TransformContextCompletedEventArgs(arrTCtxKIDict, arrTCtxStatus);
        if (handler) {
            handler(this, tcEvtArgs);
        }
    },
    _getRawContexts: function (newContext) {
        if (!newContext) {
            newContext = window.external.GetContext2();
        }

        var retVal = new Tfsi.Context.ContextDictionary();
        if (newContext) {
            retVal = Tfsi.Context._XmlDomToDictionary(newContext);
        }

        return retVal;
    },
    _transformContext: function (contextValueIn, outFormatFilter) {
        var e = Function._validateParams(arguments, [
            { name: "contextValueIn", type: Tfsi.Context.ContextValue },
            { name: "outFormatFilter", type: Tfsi.StringDictionary, mayBeNull: true }
        ]);
        if (e) throw e;

        var ctxSupportedIn = null;
        var ctxSupportedOut = null;
        var arrTCtxKIDict = new Array();
        var arrTCtxStatus = new Array();

        arrTCtxStatus[0] = Tfsi.Context.TransformContextStatus.success;

        if (contextValueIn && contextValueIn.get_Value()) {
            ctxIn = "<Context><Prop Name='Symbol' Value='" + contextValueIn.get_Value() + "' /></Context>";
        }

        if (contextValueIn._contextValues && contextValueIn._contextValues[0]) {
            var attrs = contextValueIn._contextValues[0].get_Attributes();
            if (attrs && attrs.containsKey("Type")) {
                ctxSupportedIn = "<Context><Prop Name='Symbol' Type ='" + attrs.get_Item("Type") + "' /></Context>";
            }
        }

        if (outFormatFilter && outFormatFilter.containsKey("Type")) {
            ctxSupportedOut = "<Context><Prop Name='Symbol' Type ='" + outFormatFilter.get_Item("Type") + "' /></Context>";
        }

        var value;
        var xmlTCtxRet = null;
        try { // TONE 4.6+ support
            xmlTCtxRet = window.external.Transform2(ctxIn, ctxSupportedIn, ctxSupportedOut, null)
        }
        catch (e) {
            arrTCtxStatus[0] = Tfsi.Context.TransformContextStatus.fail;
        }

        if (xmlTCtxRet) {
            var tctxDict = new Tfsi.Context.ContextDictionary();
            tctxDict = Tfsi.Context._XmlDomToDictionary(xmlTCtxRet);
            if (tctxDict && tctxDict.containsKey("RetVal")) {
                var trVal = tctxDict.get_Item("RetVal").get_Value();
                if (typeof trVal == "string") {
                    value = trVal;
                }
                else if (Tfsi.Context.ContextValue.isInstanceOfType(trVal)) {
                    value = trVal.get_Value();
                }
                else if (Tfsi.Context.ContextItem.isInstanceOfType(trVal)) {
                    trVal = trVal.get_Value(); //From ContextItem to ContextValue (w/wo contextValues[])
                    if (typeof trVal == "string") {
                        value = trVal;
                    }
                    else {
                        value = trVal.get_Value();
                    }
                }

                if (value == "FAIL") {
                    arrTCtxStatus[0] = Tfsi.Context.TransformContextStatus.fail;
                }
            }

            if (tctxDict && tctxDict.containsKey("Entity")) {
                var tcVal = tctxDict.get_Item("Entity").get_Value();
                if (typeof tcVal == "string") {
                    value = tcVal;
                }
                else if (Tfsi.Context.ContextValue.isInstanceOfType(tcVal)) {
                    value = tcVal.get_Value();
                }
                else if (Tfsi.Context.ContextItem.isInstanceOfType(tcVal)) {
                    tcVal = tcVal.get_Value(); //From ContextItem to ContextValue (w/wo contextValues[])
                    if (typeof tcVal == "string") {
                        value = tcVal;
                    }
                    else {
                        value = tcVal.get_Value();
                    }
                }
                arrTCtxKIDict[0] = new Tfsi.Context.ContextValue("Entity", value);
            }
        }

        var tcEvtArgs = new Tfsi.Context.TransformContextCompletedEventArgs(arrTCtxKIDict, arrTCtxStatus);
        return tcEvtArgs;
    }
}

Tfsi.Context._Context.registerClass('Tfsi.Context._Context', Tfsi.Context._ContextBase, Tfsi.Context.IContextBroker);


Tfsi.Context._Context._getNewSymbolContextItem = function (name, value) {
    var vars = value.split(";");
    if (vars.length > 0) {
        var ctxValue = new Tfsi.Context.ContextValue();
        for (var j = 0; j < vars.length; j++) {
            var pair = vars[j].split("=");
            if (pair.length == 2) {
                var attr = new Tfsi.StringDictionary()
                attr.add('type', pair[0]);
                ctxValue.set_Value(attr, pair[1]);
            }
        }
        var ctxItem = new Tfsi.Context.ContextItem(name, ctxValue);
        return ctxItem;
    }
    else {
        return new Tfsi.Context.ContextItem(name, value);
    }
}
//Need this function in the exact signature
HandleSetContext_TF = function (reason, xmlContext, reason2) {
    if (!xmlContext) {
        xmlContext = window.event.getAttribute("Context");
    }

    var ctxService = Tfsi.ServiceFactory.getService('IContext');
    if (ctxService && ctxService._ContextChangedCallback != null) {

        if (reason2 == "rmb" || reason2 == "ddn") {
            reason = reason2;
        }
        if (!ctxService._ContextChangedCallback(xmlContext, reason)) {
            return true;
        }
    }

    return false;
}

Tfsi.Context._dictionaryToXmlDom = function (contextDict) {
    var e = Function._validateParams(arguments, [
        {name: "contextDict", type: Tfsi.Context.KeyItemedDictionary}
    ]);
    if (e) throw e;

    var items = contextDict._get_Items();

    var contextStr = new ActiveXObject("Msxml2.DOMDocument");
    contextStr.async = false;

    var ctxNode = contextStr.createNode(1, "Context", "");
    contextStr.appendChild(ctxNode);

    for (var key in items) {
        var name = key;
        if (key == "Entity") {
            name = "Symbol";
        }
        if (key == "SubFunction") {
            continue;
        }
        var itemValue = items[key];
        var value;
        if (typeof itemValue == "string") {
            value = itemValue;
        }
        else if (Tfsi.Context.ContextValue.isInstanceOfType(itemValue)) {
            value = itemValue.get_Value();
        }
        else if (Tfsi.Context.ContextItem.isInstanceOfType(itemValue)) {
            itemValue = itemValue.get_Value(); //From ContextItem to ContextValue (w/wo contextValues[])
            if (typeof itemValue == "string") {
                value = itemValue;
            }
            else {
                value = itemValue.get_Value();
            }
        }

        var propNode = contextStr.createNode(1, "Prop", "");
        var attr = contextStr.createAttribute("Name");
        attr.text = name;
        propNode.attributes.setNamedItem(attr);

        attr = contextStr.createAttribute("Value");
        if (value != null) {
            attr.text = value;
        } else {
            attr.text = "";
        }
        propNode.attributes.setNamedItem(attr);

        if (itemValue._contextValues && itemValue._contextValues[0]) { // Same level attributes
            var attrs = itemValue._contextValues[0].get_Attributes();
            if (attrs) {
                var attrItems = attrs._get_Items();
                for (var key in attrItems) {
                    attr = contextStr.createAttribute(key);
                    attr.text = attrItems[key];
                    propNode.attributes.setNamedItem(attr);
                }
            }
        }

        ctxNode.appendChild(propNode);
    }

    return contextStr;
}

Tfsi.Context._dictionaryToString = function (contextDict, incSubFunction) {
    var e = Function._validateParams(arguments, [
        { name: "contextDict", type: Tfsi.Context.KeyItemedDictionary },
        { name: "incSubFunction", type: Boolean, mayBeNull: true, optional: true }
    ]);
    if (e) throw e;

    var items = contextDict._get_Items();

    var contextStr;

    for (var key in items) {
        var name = key;
        if (key == "Entity") {
            name = "Symbol";
        }
        if (!incSubFunction && key == "SubFunction") {
            continue;
        }
        var itemValue = items[key];
        var value;
        if (typeof itemValue == "string") {
            value = itemValue;
        }
        else if (Tfsi.Context.ContextValue.isInstanceOfType(itemValue)) {
            value = itemValue.get_Value();
        }
        else if (Tfsi.Context.ContextItem.isInstanceOfType(itemValue)) {
            itemValue = itemValue.get_Value(); //From ContextItem to ContextValue (w/wo contextValues[])
            if (typeof itemValue == "string") {
                value = itemValue;
            }
            else {
                value = itemValue.get_Value();
            }
        }

        if (contextStr) {
            contextStr += ";";
            contextStr += name + "=" + value;
        }
        else {
            contextStr = name + "=" + value;
        }
    }

    return contextStr;
}

Tfsi.Context._XmlDomToDictionary = function (xmlContext) {
    var retVal = new Tfsi.Context.ContextDictionary();

    var nodeList = xmlContext.selectNodes("Context/Prop");
    if (nodeList.length == 0) {
        retVal = null;
    }
    else {
        var T1Attrs = new Array("Name", "Value", "Display", "SubMenu", "Default", "NoPersist", "IsColor",
            "IsFont", "IsTrans", "_EditLabel", "_NoEdit", "_EditType", "_Dir",
            "_NVPair", "_Header", "Attributes");

        for (var i = 0; i < nodeList.length; i++) {
            var IsWebProp = nodeList[i].getAttribute("WebProp");
            var IsPreference = nodeList[i].getAttribute("IsPreference");

            if (IsWebProp || IsPreference) {
                continue;
            }

            var name = nodeList[i].getAttribute("Name");// Used as the name for the context item
            var value = nodeList[i].getAttribute("Value"); // Used as the value for the context item

            var ctxItem;
            if (name == "Symbol") {
                name = "Entity";
                if (retVal.containsKey(name)) {
                    continue;
                }
            }
            if (name == "NewSymbol") {
                name = "Entity";
                ctxItem = Tfsi.Context._Context._getNewSymbolContextItem(name, value);
            }
            else {
                ctxItem = new Tfsi.Context.ContextItem(name, value);
            }

            var ctxAttrs = new Tfsi.StringDictionary();
            var contextValue = new Tfsi.Context.ContextValue(name, value);
            // Used as attribute collection for the context item
            for (var j = 0; j < nodeList[i].attributes.length; j++) {
                var attrName = nodeList[i].attributes[j].name;
                var bSkipT1Attr = false;
                for (var k = 0; false == bSkipT1Attr && k < T1Attrs.length; k++) {
                    if (attrName == T1Attrs[k])
                        bSkipT1Attr = true;
                }
                if (bSkipT1Attr)
                    continue;

                var attrValue = nodeList[i].attributes[j].value;

                ctxAttrs.add(attrName, attrValue);
            }

            if (ctxItem) {
                retVal._set_Item(name, ctxItem);
            }

            if (ctxAttrs.get_Count() > 0) {
                contextValue.set_Value(ctxAttrs, value);
                var attrCxtItem = new Tfsi.Context.ContextItem(name, contextValue);
                retVal._set_Item(name, attrCxtItem);
            }
        }
    }
    return retVal;
}

Tfsi.Navigation._Drilldown = function () {
    Tfsi.Navigation._Drilldown.initializeBase(this);
    this._func = null;
    this._subFunctionMap = new Object();
}

Tfsi.Navigation._Drilldown.prototype = {
    register: function (drilldownList, handler) {
        Tfsi.Navigation._Drilldown.callBaseMethod(this, 'register', [drilldownList, handler]);

        this.clear();
        var action = function (item) {
            var defaultTarget = "";
            var ddTarget = item.get_DefaultTarget();
            var readOnly = false;
            var onDemand = false;
            var popup = false;
            var nwsScope = Tfsi.Navigation.WorkspaceSearchScopes;
            var srchScope = nwsScope.none;
            if (ddTarget) {
                defaultTarget = ddTarget.get_ThomletId();
                this._subFunctionMap[item.get_Id()] = ddTarget.get_SubFunction();
                if (defaultTarget.length > 0) {
                    readOnly = ddTarget.get_ReadOnly();
                    srchScope = ddTarget.get_SearchScopes();
                    if (ddTarget.get_TargetInvokingType() == Tfsi.Navigation.TargetInvokingType.onDemand) {
                        if (srchScope == nwsScope.none) {
                            popup = true;
                        }
                        else {
                            onDemand = true;
                        }
                    }
                    else if (ddTarget.get_TargetInvokingType() == Tfsi.Navigation.TargetInvokingType.createNew) {
                        popup = true;
                    }
                }
            }

            if (onDemand && !popup) {
                var srchWsp = window.external.IsFeatureSupported("OnDemand with Workspace Search");
                if (srchScope != nwsScope.desktop && srchWsp) {
                    try {
                        window.external.RegisterLockedOnDemandDrillDown(item.get_Id(), item.get_Name(), item.get_Description(), defaultTarget);
                    }
                    catch (e) {
                        window.external.RegisterOnDemandDrillDownWithWorkspaceSearch(item.get_Id(), item.get_Name(), item.get_Description(), defaultTarget);
                    }
                }
                else {
                    window.external.RegisterOnDemandDrillDown(item.get_Id(), item.get_Name(), item.get_Description(), defaultTarget);
                }
            }
            else if (popup) {
                window.external.RegisterOnDemandDrillDownWithNewInstance(item.get_Id(), item.get_Name(), item.get_Description(), defaultTarget);
            }
            else if (readOnly) {
                window.external.RegisterReadonlyDrillDown(item.get_Id(), item.get_Name(), item.get_Description(), defaultTarget);
            }
            else {
                window.external.RegisterDrillDown(item.get_Id(), item.get_Name(), item.get_Description(), defaultTarget);
            }
        }
        Tfsi.Navigation.DrilldownItemList.forEach(drilldownList, action, this);
        this._func = handler;
        window.external.FireOnValidateLinks();
    },
    clear: function () {
        this._func = null;
        this._subFunctionMap = new Object();
        window.external.ClearDrillDowns();
    },

    invoke: function (id, contextDict, commandArgs, resetTarget, windowFeature) {
        Tfsi.Navigation._Drilldown.callBaseMethod(this, 'invoke', [id, contextDict, commandArgs, resetTarget, windowFeature]);

        var incCDSubFunc = true;
        var DDSubFunc = this._subFunctionMap[id];
        if (DDSubFunc)
            incCDSubFunc = false;

        var context = "";
        if (contextDict && contextDict.get_Count()) {
            context = Tfsi.Context._dictionaryToString(contextDict, incCDSubFunc);
        }
        if (DDSubFunc) {
            if (context != "") {
                context += ";";
            }
            context += "SubFunction=" + DDSubFunc;
        }

        var bUrlEncode = true;
        if (commandArgs) {
            if (context != "") {
                context += ";";
            }
            var cmdArgsKey = "CommandArgs=";
            if (Tfsi.T1Version && Tfsi.CompareVersions(Tfsi.T1Version, "4.6.0.0") < 0) {
                cmdArgsKey = "AddlURLParams=CommandArgs=";
                commandArgs = encodeURIComponent(commandArgs);
                bUrlEncode = false;
            }
            context += cmdArgsKey + commandArgs;
        }

        if (window.external.IsFeatureSupported("UrlEncode")) {
            window.external.UseUrlEncode = bUrlEncode;
        }

        var bDDFire = true;
        if (windowFeature) { // TONE 4.6+ support
            try {
                window.external.FireOnDrillDown3(id, window.external.IlxDropAppName, context, ";", windowFeature);
                bDDFire = false;
            }
            catch (e) {
            }
        }

        if (bDDFire) { //TONE 4.5- support
            window.external.FireOnDrillDown(id, window.external.IlxDropAppName, context, ";");
        }
    },
    openThomletInFrame: function (frame, thomletId, contextDict, commandArgs, sessionPersistent, lockWindow) {
        Tfsi.Navigation._Drilldown.callBaseMethod(this, 'openThomletInFrame', [frame, thomletId, contextDict, commandArgs, sessionPersistent, lockWindow]);

        var context = "";
        if (contextDict) {
            context = Tfsi.Context._dictionaryToString(contextDict, true); //  this._subFunctionMap[] is N/A for this usage
        }

        var bUrlEncode = true;
        if (commandArgs) {
            if (context != "") {
                context += ";";
            }
            var cmdArgsKey = "CommandArgs=";
            if (Tfsi.T1Version && Tfsi.CompareVersions(Tfsi.T1Version, "4.6.0.0") < 0) {
                cmdArgsKey = "AddlURLParams=CommandArgs=";
                commandArgs = encodeURIComponent(commandArgs);
                bUrlEncode = false;
            }
            context += cmdArgsKey + commandArgs;
        }

        if (window.external.IsFeatureSupported("UrlEncode")) {
            window.external.UseUrlEncode = bUrlEncode;
        }

        window.external.FireOnDrillDown2(0, "", thomletId, context, ";");
    },
    _DrilldownChangedCallback: function (info) {
        var e = Function._validateParams(arguments, [
            {name: "info", type: Object}
        ]);
        if (e) throw e;
        if (this._func) {
            var args = new Tfsi.Navigation.DrilldownChangedEventArgs(info.ID, info.Tooltip, info.Enabled);
            this._func(this, args);
        }
    }

}

Tfsi.Navigation._Drilldown.registerClass('Tfsi.Navigation._Drilldown', Tfsi.Navigation._DrilldownBase, Tfsi.Navigation.IDrilldown);

//INavigation
Tfsi.Navigation._Navigation = function () {
    this._refreshHandler = null;
}
Tfsi.Navigation._Navigation.prototype = {
    goHome: function () {
        try {
            window.external.GoHome();
        }
        catch (e) {
        }
    },

    navigateTo: function (relativeUrl) {
        var strUrl = relativeUrl;
        try {
            window.external.Navigate(strUrl);
        }
        catch (e) {
        }
    },

    goForward: function () {
        var retVal = false;
        try {
            window.external.GoForward();
            retVal = true;
        }
        catch (e) {
            retVal = false;
        }

        return retVal;
    },

    goBack: function () {
        var retVal = false;
        try {
            window.external.GoBack();
            retVal = true;
        }
        catch (e) {
            retVal = false;
        }

        return retVal;
    },
    setRefreshHandler: function (handler) {
        Tfsi.Navigation._Navigation.callBaseMethod(this, 'setRefreshHandler', [handler]);
        if (window.external.IsFeatureSupported("HandleOnRefresh")) {
            if (handler != null) {
                window.external.NeedRefreshNotification = true;
            }
            else {
                window.external.NeedRefreshNotification = false;
            }
            this._refreshHandler = handler;
        }
    },
    _getRefreshHandler: function () {
        return this._refreshHandler;
    }
}
Tfsi.Navigation._Navigation.registerClass('Tfsi.Navigation._Navigation', Tfsi.Navigation._NavigationBase, Tfsi.Navigation.INavigation);

HandleRefreshNotification_TF = function () {
    var navService = Tfsi.ServiceFactory.getService("INavigation");
    var refreshHandler = navService._getRefreshHandler();
    if (refreshHandler == null || refreshHandler()) {
        return true;
    }

    return false;
}

//ContextMenu
//override for thin
Tfsi.Shell.MenuSeparator.prototype._toStringHelper = function (sb) {

    sb.append('<menuitem id="' + this._id + '"/>');
}

Tfsi.Shell.MenuItem.prototype._toStringHelper = function (sb) {

    var children = this.get_Children();

    //root node
    if (!this._parent) {
        sb.append('<custommenu>');
        for (var i = 0; i < children.length; i++) {
            sb.append(children[i]._toStringHelper(sb));
        }
        sb.append('</custommenu>');
        return;
    }
    if (!this._parent._parent && this.get_Name() == "Options") {
        return;
    }
    //regular menu item
    sb.append('<menuitem id="' + this._id + '" name="' + this._name + '" enabled="' + this._enabled + '"');
    if (this._checked != null) {
        sb.append(' checked="' + this._checked + '"');
    }
    if (children.length == 0) {
        sb.append('/>');
    }
    else {
        sb.append('>');
        for (i = 0; i < children.length; i++) {
            sb.append(children[i]._toStringHelper(sb));
        }
        sb.append('</menuitem>');
    }
}

//_ContextMenu
Tfsi.Shell._ContextMenu = function () {
    Tfsi.Shell._ContextMenu.initializeBase(this);
    this._contextDict = null;
}

Tfsi.Shell._ContextMenu.prototype = {
    add: function (rootMenuItem) {
        Tfsi.Shell._ContextMenu.callBaseMethod(this, 'add', [rootMenuItem]);

        var optionItem = rootMenuItem._getChildByName("Options");
        if (optionItem) {
            window.external.ClearContextMenu();
            var optionChildren = optionItem.get_Children();
            for (var i = 0; i < optionChildren.length; i++) {
                var itemId = optionChildren[i].get_Id();
                var displayName = optionChildren[i].get_Name();
                var checked = optionChildren[i].get_Checked();
                window.external.AddToContextMenu(displayName, itemId, checked ? checked : false);
            }
        }

        Tfsi.Shell._ContextMenu._currentMenuItem = rootMenuItem;
        var menuXml = rootMenuItem._toString();
        window.external.AppendContextMenuItems(menuXml);
        ;
    },
    clear: function () {
        Tfsi.Shell._ContextMenu._currentMenuItem = null;
        window.external.ClearCustomContextMenu();
        window.external.ClearContextMenu();
    },
    contextMenu: function (xPos, yPos, srcElement, contextMenuSections) {
        Tfsi.Shell._ContextMenu.callBaseMethod(this, 'contextMenu', [xPos, yPos, srcElement, contextMenuSections]);

        if (this._contextDict) {
            var allAttributes = "IlxReason=prog;NoPersist=Y;UpdateOnly";
            var action = function (key, value) {
                window.external.SetContext2(key, allAttributes, value);
            }
            Tfsi.KeyedItemDictionary.forEach(this._contextDict, action, this);
        }

        var bShowSCM = true;
        if (contextMenuSections) { // TONE 4.6+ support
            try {
                window.external.ShowContextMenuWithZone(xPos, yPos, contextMenuSections);
                bShowSCM = false;
            }
            catch (e) {
            }
        }

        if (bShowSCM) { //TONE 4.5- support
            window.external.ShowContextMenu(xPos, yPos);
        }
    },
    setMenuContextItems: function (menuContextItemList) {
        Tfsi.Shell._ContextMenu.callBaseMethod(this, 'setMenuContextItems', [menuContextItemList]);

        var allAttributes = "IlxReason=prog;Attribute=IsTrans;UpdateOnly";
        this._contextDict = new Tfsi.KeyedItemDictionary();
        var action = function (menuContextItem) {
            var key = menuContextItem.get_ContextKey();
            if (key == "Entity") {
                key = "Symbol";
            }

            var display = menuContextItem.get_ShowInMenu();
            var value = menuContextItem.get_ContextValue();
            if (value) {
                this._contextDict.add(key, value);
                window.external.SetContext2(key, allAttributes, true); //Set 'IsTrans=1' first
                if (display) {
                    window.external.SetContext2(key, "IlxReason=prog;NoPersist=Y;UpdateOnly", value);
                }
                else {
                    var ctxValNoShow = new Tfsi.Context.ContextValue(key, value);
                    var ctxAttrs = new Tfsi.StringDictionary();
                    ctxAttrs.add("NoShow", "-1");
                    ctxValNoShow.set_Value(ctxAttrs, value)

                    var contextHidden = new Tfsi.KeyedItemDictionary();
                    contextHidden.add(key, ctxValNoShow);

                    var xmlContext = Tfsi.Context._dictionaryToXmlDom(contextHidden);
                    window.external.SetContext2(xmlContext, "IlxReason=prog;NoPersist=Y;UpdateOnly");
                }
            }
            else {
                window.external.SetContext2(key, "IlxReason=prog;Action=remove");
            }
        }
        Tfsi.Shell.MenuContextItemList.forEach(menuContextItemList, action, this);
    }
}
Tfsi.Shell._ContextMenu.registerClass('Tfsi.Shell._ContextMenu', Tfsi.Shell._ContextMenuBase, Tfsi.Shell.IContextMenu);

//callback
HandleCustomMenuSelection_TF = function (menuItemId) {
    var currentMenuItem = Tfsi.Shell._ContextMenu._currentMenuItem;
    if (currentMenuItem) {
        var child = currentMenuItem.findChild(menuItemId);
        if (child) {
            var func = child.get_Func();
            if (func) {
                func(child, new Sys.EventArgs());
            }
        }
    }
    return true;
}

HandleContextMenu_TF = function (menuItemId, checked) {
    var currentMenuItem = Tfsi.Shell._ContextMenu._currentMenuItem;
    if (currentMenuItem) {
        var child = currentMenuItem.findChild(menuItemId);
        if (child) {
            child.set_Checked(checked);
            var func = child.get_Func();
            if (func) {
                func(child, new Sys.EventArgs());
            }
        }
    }
    return true;
}

Tfsi.Navigation._SubFunction = function (we) {
    Tfsi.Navigation._SubFunction.initializeBase(this);
    this._we = we;
    this._itemList = null;
}
Tfsi.Navigation._SubFunction.prototype = {
    add: function (subFunctionItemList) {
        Tfsi.Navigation._SubFunction.callBaseMethod(this, 'add', [subFunctionItemList]);

        this._clear = false;
        this._itemList = subFunctionItemList;
        var action = function (item) {
            var contexts = item.get_Contexts();
            var id = item.get_Id();
            var name = item.get_Name();
            var menuStyle = item.get_MenuStyle();

            var contextStr = 'SubFunction=' + id;

            if (contexts) {
                var actionContexts = function (key, value) {
                    if (value == "%Entity%") {
                        value = "%Symbol%";
                    }
                    contextStr += ';' + key + '=' + value;
                }
                Tfsi.StringDictionary.forEach(contexts, actionContexts, this);
            }

            if (!menuStyle || menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.none) {
                try {
                    name = name.replace("%Entity%", "%Symbol%");
                    window.external.AddFavoriteMenuItem(name, contextStr);
                }
                catch (e) {
                }
            }
            else if (menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.showInNavTree) {
                window.external.FireOnAddSubFunction(name);
            }

        }
        Tfsi.Navigation.SubFunctionItemList.forEach(subFunctionItemList, action, this);
        window.external.FireOnSetSubFunctionsFinished();
        window.external.FireOnGetSubFunctionsList();

    },
    clear: function () {
        window.external.ClearFavoriteMenuItems();
        this._clear = true;
        window.external.FireOnGetSubFunctionsList();
    }

}
Tfsi.Navigation._SubFunction.registerClass('Tfsi.Navigation._SubFunction', Tfsi.Navigation._SubFunctionBase, Tfsi.Navigation.ISubFunction);

HandleSetSubFunctionsList_TF = function (subFunctions) {
    var sfService = Tfsi.ServiceFactory.getService("ISubFunction");
    if (sfService && sfService._clear) {
        var action = function (item) {
            var contextRequirments = item.get_ContextRequirments();
            var name = item.get_Name();
            var menuStyle = item.get_MenuStyle();

            if (menuStyle == Tfsi.Navigation.SubFunctionMenuStyle.showInNavTree) {
                window.external.FireOnAddSubFunction(name);
            }
        }
        Tfsi.Navigation.SubFunctionItemList.forEach(sfService._itemList, action, sfService);
        window.external.FireOnSetSubFunctionsFinished();
        sfService._clear = false;
    }
}
//IPropertyBag

Tfsi.Shell._PropertyBag = function (we) {
    Tfsi.Shell._PropertyBag.initializeBase(this);
    this._we = we;
}
Tfsi.Shell._PropertyBag.prototype = {
    add: function (key, value) {
        Tfsi.Shell._PropertyBag.callBaseMethod(this, 'add', [key, value]);

        if (this._we.webProperties.get(key)) {
            throw Error.argument(key, "An element with the same key already exists in the PropertyBag.")
        }
        this.set_Item(key, value);
    },
    set_Item: function (key, value) {
        Tfsi.Shell._PropertyBag.callBaseMethod(this, 'set_Item', [key, value]);

        window.external.PutWebProperty(key, value);
    },
    set_Items: function (keyedItemDict) {
        Tfsi.Shell._PropertyBag.callBaseMethod(this, 'set_Items', [keyedItemDict]);

        var action = function (key, value) {

            this.set_Item(key, value);
        }
        Tfsi.KeyedItemDictionary.forEach(keyedItemDict, action, this);
    },
    get_Item: function (key) {
        Tfsi.Shell._PropertyBag.callBaseMethod(this, 'get_Item', [key]);

        return window.external.GetWebProperty(key);

    },
    get_Keys: function () {
        throw Error.notImplemented('Not supported in thick framework yet');
    },
    containsKey: function (key) {
        Tfsi.Shell._PropertyBag.callBaseMethod(this, 'containsKey', [key]);

        if (window.external.GetWebProperty(key)) {
            return true;
        }
        else {
            return false;
        }
    },
    clear: function () {
        window.external.DeleteAllWebProperties();
        ;
    },
    remove: function (key) {
        Tfsi.Shell._PropertyBag.callBaseMethod(this, 'remove', [key]);

        window.external.DeleteWebProperty(key);
    },
    get_Count: function () {
        throw Error.notImplemented('Not supported in thick framework yet');
    }
}
Tfsi.Shell._PropertyBag.registerClass('Tfsi.Shell._PropertyBag', Tfsi.Shell._PropertyBagBase, Tfsi.Shell.IPropertyBag);


//_Thomlet

Tfsi.Shell._Thomlet = function () {
    Tfsi.Shell._Thomlet.initializeBase(this);
    this._thomletEventsObj = null;
    this._visible = true;
    this._focused = false;
    this._closing = false;
    this._windowState = Tfsi.Shell.WindowState.normal;
    this._callbackDelegate = Function.createDelegate(this, this._statusChangeCallback);
}
Tfsi.Shell._Thomlet.prototype = {
    get_OldDomain: function () {
    },
    registerEventObject: function (thomletEventsObj) {
        Tfsi.Shell._Thomlet.callBaseMethod(this, 'registerEventObject', [thomletEventsObj]);

        this._thomletEventsObj = thomletEventsObj;
    },
    _statusChangeCallback: function (status, statusName) {
        if (statusName == "focus") {
            this._focused = status;
            if (this._thomletEventsObj && this._thomletEventsObj.focusChanged) {
                this._thomletEventsObj.focusChanged(this, new Sys.EventArgs());
            }
        }
        else if (statusName == "visibility") {
            this._visible = status;
            if (this._thomletEventsObj && this._thomletEventsObj.visibleChanged) {
                this._thomletEventsObj.visibleChanged(this, new Sys.EventArgs());
            }
        }
        else if (statusName == "windowState") {
            this._windowState = status;
            if (this._thomletEventsObj && this._thomletEventsObj.windowStateChanged) {
                this._thomletEventsObj.windowStateChanged(this, new Sys.EventArgs());
            }
        }
    },
    get_Visible: function () {
        return this._visible;
    },
    get_Focused: function () {
        return this._focused;
    },
    get_Listening: function () {
        return false;
    },
    get_Closing: function () {
        return this._closing;
    },
    get_ThomletId: function () {
    },
    close: function () {
        var retVal = true;
        try {
            retVal = window.external.CloseWindow(0);
        }
        catch (e) {
            retval = false;
        }
        return retVal;
    },
    get_WindowState: function () {
        return this._windowState;
    },
    set_CollapsedWindowSize: function (height, width) {
        Tfsi.Shell._Thomlet.callBaseMethod(this, 'set_CollapsedWindowSize', [height, width]);
    }
}
Tfsi.Shell._Thomlet.registerClass('Tfsi.Shell._Thomlet', Tfsi.Shell._ThomletBase, Tfsi.Shell.IThomlet);

//Need this function in the exact signature
HandleThomletStatusChange_TF = function (status, statusName) {
    var thomletService = Tfsi.ServiceFactory.getService('IThomlet');
    if (thomletService && thomletService._statusChangeCallback != null) {
        if (!thomletService._statusChangeCallback(status, statusName)) {
            return true;
        }
    }

    return false;
}

//IPreferenceBroker
Tfsi.Preferences._PreferenceBroker = function (we) {
    Tfsi.Preferences._PreferenceBroker.initializeBase(this);

    this._supportWAB = true;

    if (Tfsi.T1Version) {
        if (Tfsi.CompareVersions(Tfsi.T1Version, "4.5.0.0") >= 0) {
            this._supportWAB = false;
            this._rawPreferences = null;
        }
    }

    if (this._supportWAB) {
        this._wab = Tfsi._getILXWab();
        if (this._wab) {
            this._wab._initQueries(Tfsi.Preferences._progName, Tfsi.Preferences._PreferenceBroker._OnSavedQueryChanged);
        }
    }

    this._thomletPrefCallback = null;
}

Tfsi.Preferences._PreferenceBroker.prototype = {
    setPreference: function (key, value) {
        Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'setPreference', [key, value]);

        var itemDict;
        if (!this._supportWAB) {
            itemDict = new Tfsi.StringDictionary();
            itemDict.add(key, value);
            this.setPreferences(itemDict);
        }
        else {
            if (this._wab.addQuery(key, value)) {
                if (this._thomletPrefCallback == null) {
                    return;
                }

                itemDict = new Tfsi.Preferences.PreferenceDictionary();
                var item = new Tfsi.Preferences.PreferenceItem(key, value);
                itemDict._add(key, item);

                var args = new Tfsi.Preferences.PreferencesChangedEventArgs(itemDict);
                var prefObj = this;
                var prefCallback = this._thomletPrefCallback;
                var action = function () {
                    prefCallback(prefObj, args);
                }
                setTimeout(action, 100);
            }
        }
    },
    setPreferences: function (preferenceDict) {
        Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'setPreferences', [preferenceDict]);

        if (preferenceDict.get_Count() == 0) {
            throw Error.argument(preferenceDict, "preferenceDict is empty.");
        }

        var listArray = preferenceDict._get_Items();

        if (!this._supportWAB) {
            var distribute = true;
            var attributes = "IlxReason=prog";
            //if(updateOnly){
            //  attributes += ";UpdateOnly";
            //}
            var reason = "UI";

            var sb = new Sys.StringBuilder();
            sb.append("<Context>");
            for (var key in listArray) {
                var value = listArray[key];
                sb.append('<Prop Name="' + key + '" Value="' + value + '" IsPreference="True"></Prop>');
            }
            sb.append("</Context>");

            /* Update our Preference */
            var xmlPreference = new ActiveXObject("Msxml2.DOMDocument");
            xmlPreference.loadXML(sb.toString());
            window.external.SetContext2(xmlPreference, attributes);

            /* Distribute the Symbol */
            if (distribute) {
                var persistOption = "";
                if (attributes != null && attributes.indexOf("NoPersist=N") != -1) {
                    persistOption = ";NoPersist=N";
                } else if (attributes != null && attributes.indexOf("NoPersist=Y") != -1) {
                    persistOption = ";NoPersist=Y";
                }

                window.external.FireOnContextChanged(xmlPreference, "IlxReason=" + reason + persistOption);
            }
            this._rawPreferences = this._getRawPreferences();
        }
        else {
            for (var key in listArray) {
                var value = listArray[key];
                this._wab.addQuery(key, value);
            }
            if (this._thomletPrefCallback == null) {
                return;
            }
            var args = new Tfsi.Preferences.PreferencesChangedEventArgs(preferenceDict);
            var prefObj = this;
            var prefCallback = this._thomletPrefCallback;
            var action = function () {
                prefCallback(prefObj, args);
            }
            setTimeout(action, 100);
        }
    },
    getPreferences: function () {
        var itemDict;
        if (!this._supportWAB) {
            var xmlPreference = window.external.GetContext2();
            var nodeList = xmlPreference.selectNodes("Context/Prop[@IsPreference='True']");
            if (nodeList.length > 0) {
                itemDict = new Tfsi.Preferences.PreferenceDictionary();
                for (var i = 0; i < nodeList.length; i++) {
                    var name = nodeList[i].getAttribute("Name");
                    var value = nodeList[i].getAttribute("Value");

                    var item = new Tfsi.Preferences.PreferenceItem(name, value);
                    if (item) {
                        itemDict._add(name, item);
                    }
                }
            }
        }
        else {
            var wePres = this._wab.getQueryList();
            if (wePres && wePres.length > 0) {
                itemDict = new Tfsi.Preferences.PreferenceDictionary();
                for (var i = 0; i < wePres.length; i++) {
                    var key = wePres[i];
                    var value = this._wab.getQuery(key);

                    var item = new Tfsi.Preferences.PreferenceItem(key, value);
                    if (item) {
                        itemDict._add(key, item);
                    }
                }
            }
        }
        return itemDict;
    },
    getPreference: function (key) {
        Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'getPreference', [key]);

        var value;
        if (!this._supportWAB) {
            value = window.external.GetContext2(key);
        }
        else {
            value = this._wab.getQuery(key);
        }

        if (value) {
            return new Tfsi.Preferences.PreferenceItem(key, value);
        }
        return '';
    },
    setPreferenceChangedHandler: function (handler) {
        Tfsi.Preferences._PreferenceBroker.callBaseMethod(this, 'setPreferenceChangedHandler', [handler]);

        this._thomletPrefCallback = handler;

    },
    isPreferenceSupported: function (key) {
        if (this.getPreference(key)) {
            return true;
        }
        else {
            return false;
        }
    },
    _PreferenceChangedCallback: function (newPrefName, eventType) {
        if (this._thomletPrefCallback == null) {
            return true;
        }
        if (!newPrefName) {
            return false;
        }
        var itemDict = new Tfsi.Preferences.PreferenceDictionary();

        if (this._supportWAB) {
            var prefItem;
            if (eventType == "DelSymbolList") {
                prefItem = new Tfsi.Preferences.PreferenceItem(newPrefName, null);
            }
            else {
                prefItem = this.getPreference(newPrefName);
            }

            if (!prefItem) {
                return false;
            }
            itemDict._add(newPrefName, prefItem);
        }
        else {
            itemDict = this._getDictionaryPreferences(newPrefName);
        }

        var args = new Tfsi.Preferences.PreferencesChangedEventArgs(itemDict);
        if (!this._thomletPrefCallback(this, args)) {
            return true;
        }
        return false;
    },
    //inherited from IFrameworkService
    get_Name: function () {
        return this._name;
    },
    _getRawPreferences: function (newPreference) {
        if (!newPreference) {
            newPreference = window.external.GetContext2();
        }

        var retVal = new Object();
        var nodeList = newPreference.selectNodes("Context/Prop[@IsPreference='True']");

        for (var i = 0; i < nodeList.length; i++) {
            var name = nodeList[i].getAttribute("Name");
            var value = nodeList[i].getAttribute("Value");

            retVal[name] = value;

        }
        return retVal;
    },
    _getDictionaryPreferences: function (xmlPreference) {
        if (!xmlPreference) {
            xmlPreference = window.external.GetContext2();
        }

        var itemDict = new Tfsi.Preferences.PreferenceDictionary();
        var nodeList = xmlPreference.selectNodes("Context/Prop[@IsPreference='True']");
        if (nodeList.length > 0) {
            for (var i = 0; i < nodeList.length; i++) {
                var name = nodeList[i].getAttribute("Name");
                var value = nodeList[i].getAttribute("Value");

                var item = new Tfsi.Preferences.PreferenceItem(name, value);
                if (item) {
                    itemDict._add(name, item);
                }
            }
        }
        return itemDict;
    }
}

Tfsi.Preferences._PreferenceBroker.registerClass('Tfsi.Preferences._PreferenceBroker', Tfsi.Preferences._PreferenceBase, Tfsi.Preferences.IPreferenceBroker);

Tfsi.Preferences._PreferenceBroker._OnSavedQueryChanged = function (symListName, eventType) {
    //alert(symListName + " " + eventType);
    var pref = Tfsi.ServiceFactory.getService('IPreference');
    if (pref) {
        var action = function () {
            pref._PreferenceChangedCallback(symListName, eventType);
        }
        window.setTimeout(action, 200);
    }
}

//Need this function in the exact signature
HandleSetPreference_TF = function (xmlPreference) {
    if (!xmlPreference) {
        xmlPreference = window.event.getAttribute("Context"); // IsPreference='True' makes the difference
    }

    var prefService = Tfsi.ServiceFactory.getService('IPreference');
    if (prefService && prefService._PreferenceChangedCallback != null) {
        if (!prefService._PreferenceChangedCallback(xmlPreference)) {
            return true;
        }
    }

    return false;
}

Tfsi.ServiceFactory.getService = function (serviceName, optionalInfo) {
    var e = Function._validateParams(arguments, [
        {name: "serviceName", type: String},
        {name: "optionalInfo", type: String, mayBeNull: true, optional: true}

    ]);
    if (e) throw e;

    var svcInstance = Tfsi.__ServiceInstances[serviceName];
    if (!svcInstance) {
        var serviceType = Tfsi.ServiceFactory._getServiceType(serviceName);
        if (serviceType) {
            svcInstance = Tfsi.__ServiceInstances[serviceName] = new serviceType();
        }
        else {
            throw Error.serviceNotDefinedException(serviceName);
        }
    }
    return svcInstance;

}

HandleDrillDownChanged_TF = function (dd) {
    if (!dd) {
        dd = window.event.getAttribute(TWIA_DRILLDOWN);
    }
    var ddService = Tfsi.ServiceFactory.getService('IDrilldown');
    if (ddService && ddService._DrilldownChangedCallback != null) {
        ddService._DrilldownChangedCallback(dd);
    }
    return true;
}

Tfsi.CompareVersions = function (V1, V2) {
    var cmpVer = 0; // V1 = V2(0); V1 < V2(-1); V1 > V2(1);
    var arrV1 = V1.split(".");
    var arrV2 = V2.split(".");
    for (var nPos = 0; nPos < 4 && cmpVer == 0 && nPos < arrV1.length && nPos < arrV2.length; nPos++) {
        var valV1 = parseInt(arrV1[nPos]);
        var valV2 = parseInt(arrV2[nPos]);
        if (valV1 > valV2) {
            cmpVer = 1;
        }
        else if (valV1 < valV2) {
            cmpVer = -1;
        }
    }
    return cmpVer;
}

//_Logger
Tfsi.Logging._Logger = function () {
    Tfsi.Logging._Logger.initializeBase(this);
}

Tfsi.Logging._Logger.prototype = {
    writeMessage: function (message, category) {
        Tfsi.Logging._Logger.callBaseMethod(this, 'writeMessage', [message, category]);

        var logSeverity = 0;
        if (category == Tfsi.Logging.Category.audit || category == Tfsi.Logging.Category.info ||
            category == Tfsi.Logging.Category.remoteCall || category == Tfsi.Logging.Category.remoteReturn ||
            category == Tfsi.Logging.Category.security || category == Tfsi.Logging.Category.traceHigh ||
            category == Tfsi.Logging.Category.traceLow) {
            logSeverity = 1;
        }
        else if (category == Tfsi.Logging.Category.warning) {
            logSeverity = 2;
        }
        else if (category == Tfsi.Logging.Category.error || category == Tfsi.Logging.Category.fatalError) {
            logSeverity = 3;
        }

        window.external.LogMsg(message, logSeverity);
    },
    writeInfo: function (info) {
        Tfsi.Logging._Logger.callBaseMethod(this, 'writeInfo', [info]);

        window.external.LogMsg(info, 1);
    }
}

Tfsi.Logging._Logger.registerClass('Tfsi.Logging._Logger', Tfsi.Logging._LoggerBase, Tfsi.Logging.ILogger);

// window.open browser function override
window.oldwindowopen = window.open;
window.open = function (URL, Name, Features, Replace, UseIEPopup) {
    if (UseIEPopup) {
        try {
            window.external.UseIEforPopup();
        }
        catch (e) {
        }
    }
    return window.oldwindowopen(URL, Name, Features, Replace);
}

// window.resizeBy browser function override
window.oldresizeBy = window.resizeBy;
window.resizeBy = function (numHort, numVert) {
    try {
        window.external.resizeBy(numHort, numVert);
    }
    catch (e) {
    }
}

// window.resizeTo browser function override
window.oldresizeTo = window.resizeTo;
window.resizeTo = function (numWidth, numHeight) {
    try {
        window.external.resizeTo(numWidth, numHeight);
    }
    catch (e) {
    }
}

if (typeof (Sys) !== 'undefined') Sys.Application.notifyScriptLoaded();