'use strict';

msaiqApp.directive('createWatchListDirective', function () {
    return{
        restrict: 'A',
        transclude: true,
        templateUrl: 'directives/watchlist/createWatchListTmpl.html',
        scope: {
            watchlistTitle: '@',             //whether like show dropdown or not
            showWatchlist: '@',     //watchlist header name
            watchlistType: '@',     //"WITH_TICKER or WITH_SPPWID"
            selectedIdentifiers: '='    //watchlist sppwid's or ticker to add
        },
        controller: function ($scope, $rootScope, $log, articleResourceFactory, $, msaMessageController, WatchlistDataService, AutoSuggestService,$filter){
            $scope.loading = true;
            $scope.WatchlistDataService = WatchlistDataService;
            $scope.wTitle = '';
            $scope.showWDdField = false;

            $scope.activeFormPanel  = function(){
                $scope.wTitle = '';
                $scope.showWDdField = true;
            }
            $scope.closeFormPanel  = function(){
                $scope.showWDdField = false;
                $scope.wTitle = '';
            }
            $('.create-watchlist-items-form').click(function (e) {
                e.stopPropagation();
            });

            $scope.WatchlistDataService.watchlistData.$promise.then(function(watchlistData){
                $scope.watchlistItems = watchlistData.watchLists;
                $scope.loading = false;
            });

            $scope.createWatchList=function(wTitle, type, id){
                var decodeHTML = $filter('decodeHTML');
                wTitle = decodeHTML(wTitle);
                if($scope.watchlistType === 'WITH_TICKER' && $scope.selectedIdentifiers.length != 0){
                    var tickers = $scope.selectedIdentifiers;
                    $scope.selectedIdentifiers = [];
                    var count = 0;
                    angular.forEach(tickers, function(ticker){
                        AutoSuggestService.getTickerInformation(ticker,function(data){
                                count = count+1;
                                if(data.sppwId != 'blank') {
                                    $scope.selectedIdentifiers.push(data.sppwId);
                                    if(count === tickers.length) {
                                        $scope.callCrudOperation(wTitle, type, id);
                                    }
                                } else if(tickers.length == 1){
                                    window.scrollTo(0,0);
                                    if ($rootScope.checkHumaneMargins()) {
                                        humane.log("Unable to Save Watchlist, Invalid Identifier...!", {addnCls: 'humaneResize'});
                                    } else {
                                        humane.log("Unable to Save Watchlist, Invalid Identifier...!");
                                    }
                                }
                            }
                        );
                    });
                } else if($scope.watchlistType === 'WITH_SPPWID' &&  $scope.selectedIdentifiers.length != 0){
                    $scope.callCrudOperation(wTitle, type, id);
                } else {
                    window.scrollTo(0,0);
                    if ($rootScope.checkHumaneMargins()) {
                        humane.log("Unable to Save Watchlist, Please Try Again...!", {addnCls: 'humaneResize'});
                    } else {
                        humane.log("Unable to Save Watchlist, Please Try Again...!");
                    }
                }
            };
            $scope.callCrudOperation = function(wTitle, type, id){
                if(type==='ADD_TO_WATCHLIST'){
                    $scope.loading = true;
                    if($scope.watchlistTitle === 'CREATE/ADD TO WATCHLIST' && $scope.selectedIdentifiers.length == 1){
                        if(WatchlistDataService.isWatchlistItemExists(id, $scope.selectedIdentifiers[0]) == 'exists') {
                            window.scrollTo(0,0);
                            if ($rootScope.checkHumaneMargins()) {
                                humane.log("This Security already exists in this Watchlist", {addnCls: 'humaneResize'});
                            } else {
                                humane.log("This Security already exists in this Watchlist");
                            }
                            $scope.loading = false;
                            $('.create-watchlist-items-inner').removeClass('open');
                            return;
                        } else {
                            $scope.WatchlistDataService.watchlistCrudOperations($scope.creatingFormParams(wTitle,'ADD_TO_WATCHLIST',$scope.selectedIdentifiers,'',id)).$promise.then(function(watchlistData){
                                window.scrollTo(0,0);
                                $scope.watchlistItems = watchlistData.watchLists;
                                if ($rootScope.checkHumaneMargins()) {
                                    humane.log("You have successfully added assets to your "+wTitle+ " watchlist", {addnCls: "humaneResize"});
                                } else {
                                    humane.log("You have successfully added assets to your "+wTitle+ " watchlist");
                                }
                                $scope.loading = false;
                            });
                            $('.create-watchlist-items-inner').removeClass('open');
                            return;
                        }
                    }
                    $scope.WatchlistDataService.watchlistCrudOperations($scope.creatingFormParams(wTitle,'ADD_TO_WATCHLIST',$scope.selectedIdentifiers,'',id)).$promise.then(function(watchlistData){
                        window.scrollTo(0,0);
                        $scope.watchlistItems = watchlistData.watchLists;
                        if ($rootScope.checkHumaneMargins()) {
                            humane.log("You have successfully added assets to your "+wTitle+ " watchlist", {addnCls: 'humaneReize'});
                        } else {
                            humane.log("You have successfully added assets to your "+wTitle+ " watchlist");
                        }
                        $scope.loading = false;
                        $scope.selectedIdentifiers = [];
                    });
                } else if(type === 'CREATE_AND_ADD'){
                    $scope.loading = true;
                    if($scope.watchlistTitle === 'CREATE/ADD TO WATCHLIST' && $scope.selectedIdentifiers.length == 1){
                        $scope.WatchlistDataService.watchlistCrudOperations($scope.creatingFormParams(wTitle,'CREATE_AND_ADD',$scope.selectedIdentifiers,'','')).$promise.then(function(watchlistData){
                            $scope.watchlistItems = watchlistData.watchLists;
                            window.scrollTo(0,0);
                            if ($rootScope.checkHumaneMargins()) {
                                humane.log("You have successfully added assets to your "+wTitle+ " watchlist", {addnCls: 'humaneResize'});
                            } else {
                                humane.log("You have successfully added assets to your "+wTitle+ " watchlist");
                            }
                            $scope.loading = false;
                        });
                        $('.create-watchlist-items-inner').removeClass('open');
                        return;
                    }
                    $scope.WatchlistDataService.watchlistCrudOperations($scope.creatingFormParams(wTitle,'CREATE_AND_ADD',$scope.selectedIdentifiers,'','')).$promise.then(function(watchlistData){
                        $scope.watchlistItems = watchlistData.watchLists;
                        window.scrollTo(0,0);
                        if ($rootScope.checkHumaneMargins()) {
                            humane.log("You have successfully added assets to your "+wTitle+ " watchlist", {addnCls: 'humaneResize'});
                        } else {
                            humane.log("You have successfully added assets to your "+wTitle+ " watchlist");
                        }
                        $scope.loading = false;
                        $scope.selectedIdentifiers = [];
                    });
                }
                $('.create-watchlist-items-inner').removeClass('open');
            };

            $scope.creatingFormParams = function(wTitle,wType,wSPPWIds,wSeqNum,wId){
                var formData = {}; var sppwIdArray = [];
                angular.forEach(wSPPWIds, function(wSPPWId){
                    sppwIdArray.push(wSPPWId);
                });
                if(wType === 'ADD_TO_WATCHLIST'){
                    formData['operationCode'] =  wType;
                    formData['watchListId'] = wId;
                    formData['sppwIds'] =  sppwIdArray;
                    formData['securityIds']  = sppwIdArray;
                } else if(wType === 'CREATE_AND_ADD') {
                    formData['operationCode'] =  wType;
                    formData['watchlist.name'] = wTitle;
                    formData['watchlist.sequenceNumber'] = wSeqNum;
                    formData['sppwIds'] =  sppwIdArray;
                    formData['securityIds']  = sppwIdArray;
                }
                return formData
            };
        }
    };
});