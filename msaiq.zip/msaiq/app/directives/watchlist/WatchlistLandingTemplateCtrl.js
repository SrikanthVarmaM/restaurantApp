'use strict';

msaiqApp.directive('msaWatchlistLandingPage', function () {
    return{
        restrict: 'A',
        transclude: true,
        templateUrl: 'directives/watchlist/watchlistLandingTemplate.html',
        replace: true,
        controller: function ($scope, $rootScope, _,$, $routeParams,$log, $resource, userResourceResourceFactory, msaMessageController,ngTableParams,QuickViewService,AutoSuggestService, WatchlistDataService) {

            $scope.AutoSuggestService= AutoSuggestService;
            $scope.WatchlistDataService = WatchlistDataService;
            $scope.dropdownLoading = true;
            $scope.addWatchlistDisabled=true;
            $scope.selectedWatchlistItemDelete = true;
            $scope.defaultPageLoading = false;

            $scope.openQV =function(data){ QuickViewService.openQV(data); };

            WatchlistDataService.watchlistData.$promise.then(function(watchlistData){
                $scope.watchlistItems = watchlistData.watchLists;
                $scope.dropdownLoading = false;
            });

            $scope.$on('refreshWatchLandingPage', function () {
                $scope.dropdownLoading = true;
                $scope.defaultPageLoading = true;
                WatchlistDataService.watchlistData.$promise.then(function(watchlistData){
                    $scope.watchlistItems = watchlistData.watchLists;
                    $scope.selectedWatchlist =  watchlistData.watchLists[0];
                    $scope.dropdownLoading = false;
                });
            });

            $scope.$on('handleBroadcast', function () {
                if (msaMessageController.message.messageType === 'SECURITY_INFO') {
                    $scope.messageToAddWatchlist= msaMessageController.message.messageBody;
                }
            });

            $scope.deleteWatchlistConfirm = function(){
                $scope.WatchlistDataService.openWatchlistConfirmWindow({source :$scope, action :'delete', securityName: $scope.selectedWatchlist.name});
            };

            $scope.deleteWatchlist = function(){
                var title= $scope.selectedWatchlist.name;
                $scope.dropdownLoading = true;
                WatchlistDataService.deleteWatchlist({operationCode: 'DELETE',watchListId:$scope.selectedWatchlist.id}).$promise.then(function(watchlistData){
                    $scope.watchlistItems = watchlistData.watchLists;
                    if ($rootScope.checkHumaneMargins()) {
                        humane.log("You have successfully deleted "+title+ " watchlist", {addnCls: 'humaneResize'});
                    } else {
                        humane.log("You have successfully deleted "+title+ " watchlist");
                    }
                    $scope.selectedWatchlist =  watchlistData.watchLists[0];
                    $scope.addToHypo($scope.selectedWatchlist.items);
                    $scope.dropdownLoading = false;
                });
            };
            $scope.deleteWatchlistItemsConfirm = function(watchlistId, watchlistItemId, securityName){
                $scope.selectedWatchlistItemDelete = true;
                $scope.WatchlistDataService.openWatchlistConfirmWindow({source :$scope, action :'deleteWItem', securityName:securityName, watchlistItemId :watchlistItemId,watchlistId :watchlistId});
            };

            $scope.deleteWatchlistItems = function(watchlistId, watchlistItemId){
                angular.forEach($scope.selectedWatchlist.items,function(item,index){
                    if(item.id === watchlistItemId) { $scope.selectedWatchlist.items[index].currencyCode = 'loading';return; }
                });
                WatchlistDataService.deleteWatchlist({operationCode: 'DELETE_ITEM',watchListId:watchlistId,watchListItemId:watchlistItemId}).$promise.then(function(watchlistData){
                    $scope.watchlistItems = watchlistData.watchLists;
                    angular.forEach(watchlistData.watchLists ,function(watchlist){
                        if(watchlist.id === watchlistId){
                            $scope.selectedWatchlist =  watchlist;
                        }
                    })
                    $scope.addToHypo($scope.selectedWatchlist.items);
                });
            };

            $scope.clearSearch = function(){
                var messageWrapper = { messageType: 'CLEAR_SEARCH' };
                msaMessageController.prepForBroadcast(messageWrapper);
            };

            $scope.handleWatchlistButtonState = function(value){
                $scope.addWatchlistDisabled=value;
                $scope.$digest();  //  since angular does not throw view refresh on scope value change until it is bound to some input element through ng-model"
            };

            $scope.showSelectedWatchlist = function(watchlistItem){
                $scope.selectedWatchlist = watchlistItem;
                $scope.addToHypo($scope.selectedWatchlist.items);
                $scope.defaultPageLoading = true;
            };

            $scope.addToSelectedWatchlist = function () {
                var data=$scope.messageToAddWatchlist;

                if(WatchlistDataService.isWatchlistItemExists($scope.selectedWatchlist.id, data.sppw_id) == 'exists'){
                    if ($rootScope.checkHumaneMargins()) {
                        humane.log("This Security already exists in this Watchlist", {addnCls: 'humaneResize'});
                    } else {
                        humane.log("This Security already exists in this Watchlist");
                    }
                    $scope.clearSearch();
                    $scope.addWatchlistDisabled=true;
                } else {
                    var watchlistId = $scope.selectedWatchlist.id;
                    if($scope.selectedWatchlist.items.length == 0) {
                        $scope.dropdownLoading = true;
                    }
                    WatchlistDataService.watchlistCrudOperations($scope.addToSelectedWatchlistFormParams('ADD_TO_WATCHLIST',data.sppw_id,watchlistId)).$promise.then(function(watchlistData){
                        $scope.watchlistItems = watchlistData.watchLists;
                        angular.forEach($scope.watchlistItems ,function(watchlist){
                            if(watchlist.id === watchlistId){
                                $scope.selectedWatchlist =  watchlist;
                            }
                        })
                        $scope.addToHypo($scope.selectedWatchlist.items);
                        $scope.dropdownLoading = false;
                    });
                    $scope.clearSearch();
                    $scope.addWatchlistDisabled=true;
                }
            };

            $scope.addToSelectedWatchlistFormParams = function(wType,wSppwId,wId){
                var formData = {};
                if(wType === 'ADD_TO_WATCHLIST'){
                    formData['operationCode'] =  wType;
                    formData['watchListId'] = wId;
                    formData['sppwIds'] =  wSppwId;
                    formData['securityIds']  = wSppwId;
                }
                return formData;
            };

            $scope.creatingFormParams = function(wTitle,wType,wSPPWIds,wSeqNum,wId){
                var formData = {};
                if(wType === 'ADD_TO_WATCHLIST'){
                    var sppwIdArray = [];
                    formData['operationCode'] =  wType;
                    formData['watchListId'] = wId;
                    angular.forEach(wSPPWIds, function(wSPPWId){
                        sppwIdArray.push(wSPPWId);
                    });
                    formData['sppwIds'] =  sppwIdArray;
                    formData['securityIds']  = sppwIdArray;
                } else if(wType === 'CREATE_AND_ADD') {
                    var sppwIdArray = [];
                    formData['operationCode'] =  wType;
                    formData['watchlist.name'] = wTitle;
                    formData['watchlist.sequenceNumber'] = wSeqNum;
                    angular.forEach(wSPPWIds, function(wSPPWId){
                        sppwIdArray.push(wSPPWId);
                    });
                    formData['sppwIds'] =  sppwIdArray;
                    formData['securityIds']  = sppwIdArray;
                }
                return formData
            };


            $scope.addToHypo = function(watchlistItem){
                $scope.hypoTickerArray = [];
                angular.forEach(watchlistItem, function(ticker){
                    $scope.hypoTickerArray.push(ticker.symbol);
                });

                $scope.hypoTickerString=$scope.hypoTickerArray.toString();
            };

        }
    }
});
