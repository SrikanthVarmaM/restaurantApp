'use strict';

msaiqApp.directive('watchList', function () {
    return{
        transclude: true,
        templateUrl: 'directives/watchlist/watchList.html',
        scope: { type:'@' },
        controller: function ($scope, $log,articleResourceFactory,$location, WatchlistDataService,$filter,$rootScope){
            $scope.WatchlistDataService=WatchlistDataService;
            $scope.goToPage = function(data,typeAction,title) {
                $rootScope.watchlistTitleForPrerolled = title;
                $scope.watchlistItems=WatchlistDataService.watchlistData.watchLists;
                var identifierArray = [];
                if(typeAction === 'one'){
                      angular.forEach(data.items,function(watchlistItem){
                          if( watchlistItem.issueType === $scope.type ){
                              identifierArray.push( watchlistItem.sppwId );
                          }
                      });
                } else{
                    angular.forEach($scope.watchlistItems,function(watchlist){
                        angular.forEach(watchlist.items,function(watchlistItem){
                            if( watchlistItem.issueType === $scope.type ){
                                identifierArray.push( watchlistItem.sppwId );
                            }
                        });
                    });
                }

                var sppwIds = identifierArray.join(',');
                sppwIds = sppwIds.length > 0?sppwIds:-1;
                if($scope.type === 'stock'){
                    $location.url('/'+ $scope.type +'s/watchlist/'+ data.id +'/'+ sppwIds);
                } else {
                    $location.url('/'+ $scope.type +'/watchlist/'+ data.id +'/'+ sppwIds);
                }
            };
        }
    };

});