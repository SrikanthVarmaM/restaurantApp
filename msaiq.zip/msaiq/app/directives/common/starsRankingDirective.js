'use strict';


msaiqApp.directive('msaSpStars', function () {
    return{
        restrict: 'A',  // attribute
        transclude: false,
        template: '<span ng-show="num <= 0">NR </span><span ng-show="num > 0" class="glyphicon glyphicon-star stars-small" ng-repeat="i in getNumArray(num);"></span>',
        replace: false,
        link: function (scope, attrs) {
            attrs.num = scope.num;

            scope.getNumArray = function(num){

                var array = new Array(num);
                for (var i=0; i < num; i++){
                    array[i] = i+1;
                }
                return array;
            };
        },
        scope: {
            num: '@'
        }
    };
});
