msaiqApp.directive('msaDynamicImage', function($) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
           var loadingLayer= $('<div class="loading"></div>').appendTo($(element).parent());
            $(element).parent().addClass('loading-container');
            element.bind('load', function() {
                loadingLayer.toggle(false);
            });
            var defaultSrc = attrs.src;
            element.bind('error', function() {
            element.attr('src', 'images/chart_not_available_small.gif');
            });
        }
    };
});
