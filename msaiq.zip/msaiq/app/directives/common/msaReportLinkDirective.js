'use strict';

msaiqApp.directive('msaReportLink', function () {
    return{
        restrict: 'A',
        transclude: true,
        template: '<a style="margin: 2px 0px 2px 0px;" href="javascript:void(0)" ng-click="getTo();" ng-transclude>',
        scope:{
            url: '@' , params: '@'
        },

        controller: function ($scope, $log,ga,$rootScope) {

            $scope.getTo = function () {
                var pdfUrl = '/SP/msa/reports.pdf?reportURL='+$scope.url;

                if($scope.params)
                {
                    pdfUrl = pdfUrl+$scope.params;
                }
                $log.info('pdf through directive' );

                // Google anaytics code to track PDF downloaded
                ga('send', 'pageview', {
                    'page': pdfUrl,
                    'title': 'MSA PDF',
                    'dimension1': $rootScope.currentUser,
                    'dimension2': $rootScope.partner_name,
                    'dimension3': $rootScope.company,
                    'dimension6':$rootScope.partnerIdm
                });
               // Google Analytics Code ENDs

                window.open(pdfUrl,'','resizable=yes');
            };
        }

    };
});

