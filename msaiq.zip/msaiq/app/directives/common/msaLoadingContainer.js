'use strict';
/*jshint unused:false*/

msaiqApp.directive('msaLoadingContainer', function ($,_) {
    return {
        restrict: 'A',
        transclude:true,

        scope: {
            resource: '=', q: '='
        },

        template: '<div class="loading" ng-transclude></div>',

        link: function (scope, element, attrs) {
            $('<div class="loading"></div>').appendTo(element);
            $(element).addClass('loading-container');

            if(scope.resource && scope.resource.$promise){
                scope.resource.$promise.then(function(){
                    $(element).removeClass('loading-container');

                });

            } else if(!_.isEmpty(scope.q )){
                scope.q.promise.then(function(resolved){
                    $(element).removeClass('loading-container');
                });

            }


        }
    };
});