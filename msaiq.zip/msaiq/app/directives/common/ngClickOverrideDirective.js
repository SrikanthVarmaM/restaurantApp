'use strict';
/*jshint unused:false*/

msaiqApp.directive('ngClick', function ($parse, $log) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {

         //   $log.info(attrs.ngClick);
            var clickAttr = attrs.ngClick;
            if (clickAttr.toLowerCase().indexOf('pdf') !== -1) {
                element.bind('click', function (event) {

                    $log.info("ng-click directive ovveridden"+clickAttr);

                   // $log.info(clickAttr);
               //     ga('send', 'event', 'PDF Downloaded', 'PDF Location: ' + clickAttr);

                });
            }

        }
    };
});