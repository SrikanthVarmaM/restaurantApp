'use strict';


msaiqApp.directive('msaDateTime', function () {
    return {
        restrict: 'A',  // attribute
        transclude: false,
        template: '<span class="date-and-time">{{date | msadatefilter:getFormat(format)}} {{getTz(tz)}}</span>',
        replace: false,
        link: function (scope, attrs) {
            attrs.date = scope.date;
            attrs.format = scope.format;
            attrs.tz = scope.tz;

            scope.getFormat = function (format) {
                if (format === undefined || format === '') {
                    return 'MM/dd/yyyy-hh:mm a';
                }
                return format;
            };
            scope.getTz = function (tz) {
                if (tz === undefined) {
                    return '';
                }
                return tz;
            };
        },
        scope: {
            date: '@', format: '@', tz: '@'
        }
    };
});
