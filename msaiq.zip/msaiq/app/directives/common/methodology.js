'use strict';

msaiqApp.directive('methodologyAndDefinitions', function () {
    return {
        restrict: 'A',  // attribute
        templateUrl: 'directives/common/methodology.html',
        replace: true,
        scope: {
            type:'@'
        },
        controller: function ($scope, $location, $log){
           $log.debug('Methodology and Defintions for ' + $scope.type);
           $scope.message = "STANDARD & POOR'S " +  $scope.type + " METHODOLOGY AND DEFINITIONS";

            if ($scope.type === 'Funds'){
                $scope.message = "STANDARD & POOR'S CHANGED ITS MUTUAL FUND RANKING METHODOLOGY:";
                $scope.methodlist = [
                    {name: 'METHODOLOGY DOCUMENT', url: "http://www.standardandpoors.com/servlet/BlobServer?blobheadername3=MDT-Type&blobcol=urldata&blobtable=MungoBlobs&blobheadervalue2=inline%3B+filename%3DMutualFundRankingMethodology+2013.pdf&blobheadername2=Content-Disposition&blobheadervalue1=application%2Fpdf&blobkey=id&blobheadername1=content-type&blobwhere=1244333778266&blobheadervalue3=UTF-8"}
              //      {name: 'GRADINGS DEFINITIONS', url: "http://www.standardandpoors.com/servlet/BlobServer?blobheadername3=MDT-Type&blobcol=urldata&blobtable=MungoBlobs&blobheadervalue2=inline%3B+filename%3Doffshore_funds%2C0.pdf&blobheadername2=Content-Disposition&blobheadervalue1=application%2Fpdf&blobkey=id&blobheadername1=content-type&blobwhere=1244089878804&blobheadervalue3=UTF-8"}
                ]
             // TBD have ETF Landing page use this directive
            }else if ($scope.type === 'Etfs'){
                $scope.message = "LEARN MORE ABOUT S&P'S ETF RANKING METHODOLOGY";
                $scope.methodlist = [
                    {name: 'METHODOLOGY DOCUMENT', url: "http://www.standardandpoors.com/servlet/BlobServer?blobheadername3=MDT-Type&blobcol=urldata&blobtable=MungoBlobs&blobheadervalue2=inline%3B+filename%3DSP_ETF_METHOD_FINAL.pdf&blobheadername2=Content-Disposition&blobheadervalue1=application%2Fpdf&blobkey=id&blobheadername1=content-type&blobwhere=1244237819220&blobheadervalue3=UTF-8"}
                ]
            }else{
                $scope.message = "";
                $scope.methodlist = [];
            }

            $scope.goTo = function (url, windowName) {
                window.open(url, windowName);
            };
        }
    };
});