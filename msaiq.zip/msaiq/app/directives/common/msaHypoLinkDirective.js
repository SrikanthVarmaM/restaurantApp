'use strict';

msaiqApp.directive('msaHypoLink', function () {
    return{
        restrict: 'A',
        transclude: true,
        template: '<button type="button" class="btn btn-mini sp2-sky-blue-background dropdown-toggle font11px remove-padding" ng-click="goTo()"><span class="glyphicon glyphicon-play extra-space-around"></span><span class="hypo_text">RUN HYPOTHETICAL&nbsp;&nbsp;&nbsp;&nbsp;</span></button>',
        scope: {
            ticker: '@', // ticker
            fromqv : '@'

        },
        controller: function ($scope, $log, $location){

            $scope.goTo = function () {

                $log.info('$scope.fromqv'+$scope.fromqv);
                if($scope.fromqv==='noclick'){ return false;}

                if($scope.fromqv==='y'){ $scope.$parent.$modalClose();}
                if ( $scope.ticker && typeof($scope.ticker)=="string" && $scope.ticker.indexOf("/") > -1) {// for tickers having a back slash , angular routing fails, encoding backslash   eg  rr /ln
                    $scope.ticker = $scope.ticker.replace("/","*");
                }

                $location.path('/marketscope/analyzeportfolios/'+$scope.ticker);
            };

        }
    };
});


