'use strict';

msaiqApp.directive('msaDate', function () {
    return {
        restrict: 'A',  // attribute
        transclude: false,
        template: '<span class="date-and-time">{{value | date:getFormat(format)}} {{getTz(tz)}}</span>',
        replace: false,
        link: function (scope, attrs) {
            attrs.value = scope.value;
            attrs.format = scope.format;
            attrs.tz = scope.tz;

            scope.getFormat = function (format) {
                if (format === undefined || format === '') {
                    return 'MM/dd/yyyy-hh:mm a';
                }
                return format;
            };
            scope.getTz = function (tz) {
                if (tz === undefined) {
                    return '';
                }
                return tz;
            };
        },
        scope: {
            value: '@', format: '@', tz: '@'
        }
    };
});
