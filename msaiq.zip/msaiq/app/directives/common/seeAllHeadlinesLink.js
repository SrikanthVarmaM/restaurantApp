'use strict';

msaiqApp.directive('seeAllHeadlinesLink', function () {
    return {
        restrict: 'A',  // attribute
        template: '<a ng-href="#{{currentURL}}/related" class="see-all-link">SEE ALL RELATED HEADLINES</a>',
        replace: true,
        scope: {
            article:'=',route:'@',source:'@'
        },
        controller: function ($scope, $location, $log){

            $scope.currentURL = $location.url();

        }
    };
});