'use strict';

msaiqApp.directive('msaReadMore', function () {
    return {
        restrict: 'A',  // attribute
        template: '<a class="read-more" ng-href="#/{{route}}/{{article.articleCode}}/{{article.articleId}}/{{source}}">Read More</a>',
        replace: true,
        scope: {
            article: '=',route:'@',source:'@'
        }
    };
});