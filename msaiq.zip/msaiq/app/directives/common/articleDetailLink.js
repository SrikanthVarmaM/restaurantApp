'use strict';

msaiqApp.directive('msaArticleLink', function () {
    return {
        restrict: 'A',  // attribute
        template: '<a ng-href="#/{{route}}/{{article.articleCode}}/{{article.articleId}}/{{source}}" class="link" ng-bind-html="article.headline | fixAllCaps"></a>',
        replace: true,
        scope: {
            article:'=',route:'@',source:'@'
        }
    };
});
