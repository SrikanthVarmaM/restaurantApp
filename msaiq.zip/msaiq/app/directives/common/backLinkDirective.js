'use strict';

msaiqApp.directive('msaBackLink', function () {
    return {
        restrict: 'A',
        template: '<a href="javascript:void(0)" class ="back" onclick="history.go(-1);return false"><span class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-backward"></span>  Back</span></a>',
        replace: true
    };
});