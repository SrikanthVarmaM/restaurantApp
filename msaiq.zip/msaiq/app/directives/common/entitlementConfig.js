'use strict';


msaiqApp.directive('entCheckedLink', function () {
    return {
        restrict: 'A',
        transclude: true,
        template: '<button class="{{useLinkStyle}}"; ng-click="handleClick()" '+
            'ng-transclude '+//'ng-class="{linkStyle:!isButton }"' +
            'ng-disabled="!checkEnabled(ent.apCon.resolved,paramsLoaded)">' +
            //'ng-show="checkEnabled(ent.apCon.resolved,paramsLoaded)">' +
            '</button>', //paramsLoaded is a dummy variable that triggers view change on an ajax return in below code
        replace: true,   //ent.apCon.resolved triggers view change when EntitlementService loads user entitlement config
        scope: {
            isbutton:'@' , key: '@', region: '@', sectype: '@', qvparam: '&', linkparam: '@', callbackf: '&', callbackparam: '@', hide: '@'
        },
        controller: function ($scope, EntitlementService, QuickViewService, _, AutoSuggestService,$location ,ga, $rootScope,$log) {
            if ($scope.hide && $scope.isbutton){
                $scope.useLinkStyle = 'buttonShowHide';
            }else if ($scope.hide){
                $scope.useLinkStyle = 'linkStyleShowHide';
            } else if ($scope.isbutton) {
                $scope.useLinkStyle = '';
            } else {
                $scope.useLinkStyle = 'linkStyle';
            }
           // $scope.useLinkStyle=$scope.isbutton ? ' ' : 'linkStyle' ;

            $scope.ent = EntitlementService;
            $scope.paramsLoaded = false;
            $scope.count=0;
            $scope.handleClick = function () {
                if ($scope.key === 'quickviewLinks') {
                    QuickViewService.openQV($scope.qvparam());

                } else if ($scope.key === 'downloadReportsLinks' || $scope.key === 'downloadReportsLink' ||  $scope.key === 'downloadReportsLink.usIndSurv' || $scope.key === 'downloadReportsLink.globalIndSurv') {
                    $log.info('downloaded PDF entitlement');
                    // Google anaytics code to track PDF downloaded

                    ga('send', 'pageview', {
                        'page': $scope.linkparam,
                        'title': 'MSA PDF',
                        'dimension1': $rootScope.currentUser,
                        'dimension2': $rootScope.partner_name,
                        'dimension3': $rootScope.company,
                        'dimension6':$rootScope.partnerIdm
                    });

                    // Google Analytics Code ENDs

                    window.open($scope.linkparam,'_blank', 'resizable=yes');

                }
                else if (($scope.key === 'equityDetailsPage' || $scope.key === 'quickview.relatedNews') && $scope.callbackparam) {
                    $scope.callbackf({path: $scope.callbackparam});
                }
                else if($scope.key.startsWith('pageIndex.')){

                    $location.path($scope.linkparam);
                }
                else {

                  //window.open($scope.linkparam, '_self');
                    if ($scope.linkparam){
                        $location.path($scope.linkparam.substring(2));
                    }


                }

            };


            $scope.checkEnabled = function (resolved, paramsLoaded) {
                try {

                    if (!resolved) {
                        return false;  //entitlements config data not loaded yet
                    }
                    var isAssetLink = ($scope.key === 'quickviewLinks' || $scope.key === 'downloadReportsLink' || $scope.key === 'equityDetailsPage');

                    //1. for non asset links

                    if (!isAssetLink) {

                        return  $scope.getNestedKey(EntitlementService.apCon, $scope.key);

                    }

                    //2. for  asset links   that does not need region to check if entitled ,eg etf ,bonds
                    //3.a for  asset links that needs region and region is nonempty

                    var sType = $scope.mapSecurityType($scope.sectype);
                    var etfOrBonds = !_.isEmpty(sType) && sType !== 'stock';  //etf bonds etc
                    var assetWithRegion = !_.isEmpty(sType) && !_.isEmpty($scope.region);

                    if (etfOrBonds || assetWithRegion) {
                        return   EntitlementService.apCon[$scope.key][sType]($scope.region);
                    }

                         //3.b for  downloadreport link(which is a type of asset link),that needs region but region is empty here

                    if ($scope.key === 'downloadReportsLink') {
                        return false;
                    }
                    //3.c for rest types ( quickview ), get region if not provided
                    if ( _.isEmpty($scope.qvparam().ticker)) {
                        return false;
                    }
                    if ($scope.paramsLoaded && _.isEmpty($scope.region)){ //region was trying to be fetched but it is not avialable
                        return false;
                    }
                    if (++$scope.count  >1){ // to avoid continuous looping of below call

                        return false;
                    }

             AutoSuggestService.getTickerInformation($scope.qvparam().ticker, function (values) {
                        $scope.sectype = values.type;

                        $scope.region = values.region;
                        $scope.report_ind = values.report_ind;
                        $scope.paramsLoaded = true;
                        $scope.paramT=values;
                        $scope.qvparam= function(){return $scope.paramT;};//because qvparam originally was a function  , so using getter
                    });

                    return false;

                } catch (e) {
                    //humane.log($scope.sectype);
                    return false;
              }


            };

            $scope.getNestedKey = function (obj, path) {
                var current = obj;
                path.split('.').forEach(function (p) {
                    current = current[p];
                });
                return current;
            };
            $scope.mapSecurityType = function (sectype) {
                if (_.isEmpty(sectype)) {
                    return null;
                }
                sectype = sectype.toLowerCase();
                if (sectype === 'exchange traded fund') {
                    return 'etf';
                }else if (sectype === 'stocks'|| sectype === 'stock') {
                    return 'stock';
                } else if (sectype === 'funds') {
                    return 'fund';
                }else if (sectype === 's'){
                    return 'stock';
                }
                return  sectype;


            };


        }
    };
});

msaiqApp.directive('entCheckedDiv', function () {
    return {
        restrict: 'A',  // attribute
        transclude: true,
        template: '<div ng-transclude  ' +
            'ng-show="checkVisible(ent.apCon.resolved)">' +
            '</div>',
        replace: true,


        scope: {
            key: '@'


        },
        controller: function ($scope, EntitlementService) {
            $scope.ent = EntitlementService;

            $scope.checkVisible = function (resolved) {
                if (!resolved) {
                    return false;
                }
                try {
                    var valid = $scope.getNestedKey(EntitlementService.apCon, $scope.key);
                    return valid ? true : false;
                } catch (e) {

                    return false;
                }
            };
            $scope.getNestedKey = function (obj, path) {
                var current = obj;
                var pathArray = path.split('.');
                for (var i = 0; i < pathArray.length; i++) {
                    current = current[pathArray[i]];
                }
                return current;
            };


        }
    };
});