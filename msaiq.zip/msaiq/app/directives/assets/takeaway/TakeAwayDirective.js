'use strict';


msaiqApp.directive('msaTakeAway', function () {
    return {
        restrict: 'A',
        transclude: false,
        templateUrl: 'directives/assets/takeaway/takeAway.html',
        replace: false,
        scope: {
            articleid: '@',
            full: '@',
            advise: '@',
            type: '@',
            takeaway: '=',
            region: '@'
        },
        controller: function ($scope, $log) {
            $log.debug('takeaway directive articleid ' + ($scope.articleid || 'none'));
            $log.debug('takeaway directive full      ' + ($scope.full || 'none'));
            $log.debug('takeaway directive advise    ' + ($scope.advise || 'none'));
            $log.debug('takeaway directive type      ' + ($scope.type || 'none'));
            $log.debug('takeaway directive takeaway  ' + ($scope.takeaway || 'none'));
            if (!$scope.takeaway) {
                $log.debug('takeaway is null - exiting');
                return;
            }
            $scope.showWatchlist = false;
            $scope.selectedSppwidsObj ={
                selectedSppwids : []
            };

            $scope.sortBySymbol = function (a, b) {
                var retval = 0;
                if (a.symbol < b.symbol) {
                    retval = -1;
                } else if (a.symbol > b.symbol) {
                    retval = 1;
                } else {
                    retval = 0;
                }
                return retval;
            };

            $scope.hasEquity = function (equity) {
                var has = false;
                var posneg = $scope.positiveOrig.concat($scope.negativeOrig);
                for (var i = 0; i < posneg.length; i++) {
                    if (posneg[i].equityType === equity) {
                        has = true;
                        break;
                    }
                }
                return has;
            };

            $scope.addEquity = function (value) {
                var positive = $scope.takeaway.positive.slice(0);
                var negative = $scope.takeaway.negative.slice(0);

                for (var i = 0; i < $scope.positiveOrig.length; i++) {
                    if ($scope.positiveOrig[i].equityType === value) {
                        positive.push($scope.positiveOrig[i]);
                    }
                }
                for (var j = 0; j < $scope.negativeOrig.length; j++) {
                    if ($scope.negativeOrig[j].equityType === value) {
                        negative.push($scope.negativeOrig[j]);
                    }
                }
                $scope.takeaway.positive = positive.slice(0).sort($scope.sortBySymbol);
                $scope.takeaway.negative = negative.slice(0).sort($scope.sortBySymbol);
            };

            $scope.removeEquity = function (value) {
                var positive = [];
                var negative = [];

                for (var i = 0; i < $scope.takeaway.positive.length; i++) {
                    if ($scope.takeaway.positive[i].equityType !== value) {
                        positive.push($scope.takeaway.positive[i]);
                    }
                }
                for (var j = 0; j < $scope.takeaway.negative.length; j++) {
                    if ($scope.takeaway.negative[j].equityType !== value) {
                        negative.push($scope.takeaway.negative[j]);
                    }
                }
                $scope.takeaway.positive = positive.slice(0);
                $scope.takeaway.negative = negative.slice(0);
            };

            $scope.getNumArray = function (val) {
                if (isNaN(val)) {
                    return [];
                }
                var array = new Array(val);
                for (var i = 0; i < val; i++) {
                    array[i] = i + 1;
                }
                return array;
            };

            $scope.showAdvise = function () {
                if ($scope.advise !== undefined && $scope.advise === 'true') {
                    return true;
                }
                else {
                    return false;
                }
            };

            $scope.isFullTakeAway = function () {
                if ($scope.full !== undefined && $scope.full === 'true') {
                    return true;
                }
                else {
                    return false;
                }
            };

            $scope.isNum = function (val) {
                if (val === '') {
                    return false;
                }
                else if (isNaN(val)) {
                    return false;
                }
                else {
                    return true;
                }
            };

            $scope.checkToggle = function (value) {
                /*for watchlist disable*/
                    angular.forEach($scope.takeaway.positive,function(positives){ positives.checkLink = false; });
                    angular.forEach($scope.takeaway.negative,function(negative){ negative.checkLink = false; });
                    $scope.selectedSppwidsObj.selectedSppwids = [];$scope.showWatchlist = false;
                /*end*/
                $log.debug('checkToggle ' + value);
                if (value === 'Stocks') {
                    $scope.showStocks = !$scope.showStocks;
                    if ($scope.showStocks) {
                        $scope.addEquity(value);
                    } else {
                        $scope.removeEquity(value);
                    }
                }
                if (value === 'Exchange Traded Fund') {
                    $scope.showEtfs = !$scope.showEtfs;
                    if ($scope.showEtfs) {
                        $scope.addEquity(value);
                    } else {
                        $scope.removeEquity(value);
                    }
                }
                if (value === 'Funds') {
                    $scope.showFunds = !$scope.showFunds;
                    if ($scope.showFunds) {
                        $scope.addEquity(value);
                    } else {
                        $scope.removeEquity(value);
                    }
                }
            };

            $scope.filterType = function (type) {
                $log.debug('filterType ' + type);
                if (type === 'STOCKS') {
                    $scope.removeEquity('Exchange Traded Fund');
                    $scope.removeEquity('Funds');
                } else if (type === 'FUNDS') {
                    $scope.removeEquity('Stocks');
                    $scope.removeEquity('Exchange Traded Fund');
                } else if (type === 'ETFs') {
                    $scope.removeEquity('Stocks');
                    $scope.removeEquity('Funds');
                }
            };

           /* $scope.openQV = function (sppwid, ticker, report_ind, type) {
                $log.debug('open QV ' + type + ' ' + sppwid + ' ' + ticker + ' ' + report_ind);

               if (type === 'Exchange Traded Fund'){
                    QuickViewService.openQV({ticker: (ticker || ''), type:'etf', sppwId: (sppwid || ''), report_ind: (report_ind || 'undefined')});
                }else if (type === 'Funds'){
                    return false;
                }else{
                    QuickViewService.openQV({ticker: (ticker || ''), type:'stock', sppwId: (sppwid || ''), report_ind: (report_ind || 'undefined')});
                }
            };  */

            // takeaways do not come pre-sorted, so sort them
            $scope.takeaway.positive = $scope.takeaway.positive.sort($scope.sortBySymbol).slice(0);
            angular.forEach($scope.takeaway.positive,function(positives){ positives['checkLink'] = false; });
            $scope.takeaway.negative = $scope.takeaway.negative.sort($scope.sortBySymbol).slice(0);
            angular.forEach($scope.takeaway.negative,function(negative){ negative['checkLink'] = false; });

            // save a copy of the original takeaways
            $scope.positiveOrig = $scope.takeaway.positive.slice(0);
            $scope.negativeOrig = $scope.takeaway.negative.slice(0);

            // filter takeaways based on type
            $scope.filterType($scope.type);

            // set initial state to view all
            $scope.showStocks = true;
            $scope.showEtfs = true;
            $scope.showFunds = true;

            $scope.handleCheckBoxChange = function(pos){
                if(pos.checkLink){
                    $scope.selectedSppwidsObj.selectedSppwids.push(pos.sppwId);
                }else{
                    $scope.selectedSppwidsObj.selectedSppwids.splice( $scope.selectedSppwidsObj.selectedSppwids.indexOf(pos.sppwId), 1);
                }
                $scope.showWatchlist = $scope.selectedSppwidsObj.selectedSppwids.length>0 ? true:false;
            };

            $scope.$watch('selectedSppwidsObj.selectedSppwids',function(value){
                if(value.length == 0 && $scope.showWatchlist){
                    angular.forEach($scope.takeaway.positive,function(item){
                        item.checkLink = false;
                    });
                    angular.forEach($scope.takeaway.negative,function(item){
                        item.checkLink = false;
                    });

                    $scope.showWatchlist  = false;
                }
            },true);
        }
    };

});