'use strict';


msaiqApp.directive('msaStockMini', function () {
    return{
        //  restrict: 'A',
        transclude: true,
        templateUrl: 'directives/assets/stocks/stockMini.html',
        replace: false,
        link: function (scope, element, attrs) {
            scope.sppwid = attrs.sppwid;
            scope.ticker = attrs.ticker;
            scope.source = attrs.source;
            scope.report = attrs.report;
            scope.condensed = (attrs.condensed || false);  // hide summary and larger header
            scope.lastpublishdate =  (attrs.lastpublishdate || '');
            scope.pagename = attrs.pagename;
        },
        scope: {
            sppwid:'@', ticker: '@', source: '@', condensed:'@',lastpublishdate:'@', report:'@',pagename:'@'
        },
        controller: function ($scope, $log, $resource, assetsResourceFactory,$rootScope){
            $scope.showWatchlist = true;
            $scope.selectedSppwids = [];
            $scope.$on('reloadMiniStock', function(event, msg){
                $log.info('capture broadcast to reload stock mini');
                $scope.sppwid = msg.sppwid;
                $scope.report = msg.report;
                $scope.loadStockData();
            });
            $scope.ifPrintVisible=function(){
               return  $scope.pagename === 'stockdetail' && $scope.stock.issue_reports.length === 0  ;
            }
            $scope.$on('reloadMiniStockWithReport', function(event, sppwid, report_type){
                $log.info('capture broadcast to reload stock mini');
                $scope.sppwid = sppwid;
                $scope.report = report_type;
                //$scope.loadStockData();
                $scope.loadReportVariables();

            });


            // get resource
            $scope.loadStockData = function(){
                $log.info('stock mini get data');
                $scope.selectedSppwids = [];
                $scope.stockData = assetsResourceFactory.stockDetailsESResource.get({sppwid: $scope.sppwid});


                // what to reformat resource data as Elastic Search returns back deep level json objects like hits.hits[0]
                $scope.stockData.$promise.then(function(stockData){
                    $log.debug('stock mini promised return data');

                    //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
                    if (!stockData.hits || !stockData.hits.hits[0] || !stockData.hits.hits[0]._source){
                        $scope.error = 'Stock ' + $scope.ticker + ' is not available';
                    }else{
                        $scope.stock = stockData.hits.hits[0]._source;
                        $scope.selectedSppwids.push($scope.sppwid);
                        $scope.loadReportVariables();
                    }
                });

            };

            $log.debug('stock mini page page directive for ' + $scope.sppwid + ' from ' + $scope.source + ', condensed:' + $scope.condensed + ', report_ind:' + $scope.report_ind);
             $scope.loadReportVariables =function(){
                 if ($scope.stock) {
                     if( typeof($scope.report) === 'string') {
                         $scope.report =$scope.report.toLowerCase();
                     }
                     $scope.starRankingExists = !_.isEmpty($scope.stock.star_rkng)  || _.isNumber($scope.stock.star_rkng) ;
                     var reportExists = !(_.isEmpty($scope.stock[$scope.report].issue_reports)) && !(_.isEmpty($scope.stock[$scope.report].issue_reports.report_type));
                     //quant stock if (report exist & reporttype quant) , (if report doesnt exist & star rank doesnt exist)
                     $scope.quantFlag = (reportExists && $scope.stock[$scope.report].issue_reports.report_type === 'QUANT') || (!reportExists && !$scope.starRankingExists);
                     //qual  stock if (report exist & reporttype qual) , (if report doesnt exist & star rank  exists)
                     $scope.qualFlag = (reportExists && $scope.stock[$scope.report].issue_reports.report_type === 'QUAL') || (!reportExists && $scope.starRankingExists);
                     $scope.noReportIndicatorFlag = reportExists && $scope.stock[$scope.report].issue_reports.report_type  === 'NONE';
                     $scope.quantButHasStarRankFlag = reportExists && $scope.stock[$scope.report].issue_reports.report_type === 'QUANT' && $scope.starRankingExists;//  read point 4  above
                     $scope.euroAsiaFlag = ($scope.stock.issued_region === 'EUROPE' || $scope.stock.issued_region === 'ASIA');
                 }

             }   ;
            $scope.fairValueRankingArray = [1,2,3,4,5];

            $scope.goTo = function(url, windowName){
                // url = 'http://12.26.55.67/data/EQ/pdf/sr/9/92035510.pdf?tracking=WebSolutions';
                $log.info(url);
              // window.open( url, windowName,'resizable=yes');
                // Google anaytics code to track PDF downloaded
                $log.info('tracking GA');
                ga('send', 'pageview', {
                    'page': url,
                    'title': 'MSA PDF',
                    'dimension1': $rootScope.currentUser,
                    'dimension2': $rootScope.partner_name,
                    'dimension3': $rootScope.company,
                    'dimension6':$rootScope.partnerIdm
                });
                // Google Analytics Code ENDs
               window.open( url,'_blank','resizable=yes');  //removing window name, as for tickers like usb.c , "dots " are causing issue in internet explorer

            };


            /*$scope.openQV = function(sppwId, ticker, report_ind, type){
                QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''),
                    report_ind: (report_ind || $scope.report || $scope.stock.qual.report_ind  || $scope.stock.quant.report_ind || $scope.stock.none.report_ind   || 'undefined')});
            };*/

            // get resource if lookup value is available
            if ($scope.sppwid){
                $scope.loadStockData();
            }

        }
    };

});
