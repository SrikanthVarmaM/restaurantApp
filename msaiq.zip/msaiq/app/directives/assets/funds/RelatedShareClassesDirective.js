'use strict';


msaiqApp.directive('msaRelatedShareClasses', function () {
    return {
        transclude: true,
        templateUrl: 'directives/assets/funds/relatedShareClasses.html',
        replace: true,
        scope: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging, QuickViewService) {

            $scope.showWatchlist = false;
            $scope.selectedSppwidsObj ={
                selectedSppwids : []
            };
            $scope.fundsRelatedShareClassesData = { relatedPeers: [], totalResults: 0}
            $scope.loading = true;
            /* when article is loaded, call the service and pass in the callback loadRelatedShareClassesData  */
            ArticleMessaging.onFundsArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedShareClassesData(message);
                }
            );

            $scope.loadRelatedShareClassesData = function(message){
                $scope.articleid = message.articleid;
                $scope.sppwIds = _.pluck(message.instruments, 'sppwId').join(',');
                $scope.tickers = _.pluck(message.instruments, 'tickerSymbol').join(',');
                if($scope.sppwIds.length !== 0){
                    var fundsRelatedShareClassesRawData = articleResourceFactory.fundsRelatedPeersResource.get({requestType: 'FUND_RELATED_SHARE_CLASSES',sppwId:$scope.sppwIds,ticker:$scope.tickers});
                    fundsRelatedShareClassesRawData.$promise.then(function(data){
                        $scope.loading = false;
                        if(data.hasOwnProperty('relatedPeers')) {
                            angular.forEach(data.relatedPeers,function(item){
                                item['checkLink'] = false;
                            });
                            $scope.fundsRelatedShareClassesData =  data;

                        } else{
                            $scope.fundsRelatedShareClassesData = { relatedPeers: [], totalResults: 0}
                        }
                    });
                }

            };

            $scope.handleCheckBoxChange = function(checkLink, sppwid){
                if(checkLink){
                    $scope.selectedSppwidsObj.selectedSppwids.push(sppwid);
                }else{
                    $scope.selectedSppwidsObj.selectedSppwids.splice( $scope.selectedSppwidsObj.selectedSppwids.indexOf(sppwid), 1);
                }
                $scope.showWatchlist = $scope.selectedSppwidsObj.selectedSppwids.length>0 ? true:false;
            };

            $scope.$watch('selectedSppwidsObj.selectedSppwids',function(value){
                if(value.length == 0 && $scope.showWatchlist){
                    angular.forEach($scope.fundsRelatedShareClassesData.relatedPeers,function(item){
                        item.checkLink = false;
                    });
                    $scope.showWatchlist  = false;
                }
            },true);
        }
    };

});

