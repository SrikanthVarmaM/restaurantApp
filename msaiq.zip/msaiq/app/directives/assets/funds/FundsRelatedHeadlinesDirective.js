'use strict';


msaiqApp.directive('msaFundsRelatedHeadlines', function () {
    return {
        transclude: true,
        templateUrl: 'directives/assets/funds/fundsRelatedHeadlines.html',
        replace: true,
        scope: {
           source: '='
            },
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging, _) {

            /* when article is loaded, call the service and pass in the callback loadRelatedFundsHeadlinesData  */
             ArticleMessaging.onFundsArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedFundsHeadlinesData(message);
                }
            );

            $scope.loadRelatedFundsHeadlinesData = function(message){
                $scope.articleid = message.articleId;
                $scope.sppwIds = _.pluck(message.instruments, 'sppwId').join(',');
                $scope.tickers = _.pluck(message.instruments, 'tickerSymbol').join(',');
                if($scope.sppwIds.length !== 0){
                   $scope.relatedFundsHeadlinesData = articleResourceFactory.fundsRelatedHeadlinesResource.get({tickers: $scope.tickers, sppwIds: $scope.sppwIds, articleId: $scope.articleid});
                }

            };
        }
    };

});
