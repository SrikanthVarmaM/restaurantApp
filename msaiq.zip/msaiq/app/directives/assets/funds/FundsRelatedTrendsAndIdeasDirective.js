'use strict';


msaiqApp.directive('msaFundsRelatedTI', function () {
    return{
        transclude: true,
        templateUrl: 'directives/assets/funds/fundsRelatedTrendsAndIdeas.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging, _){

            /* when article is loaded, call the service and pass in the callback loadRelatedTIData  */
            /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
            ArticleMessaging.onFundsArticleLoad($scope,
                function(event, message){
                    $scope.loadFundsRelatedTIData(message);
                }
            );

            $scope.loadFundsRelatedTIData = function(message){
                // get all sppwids and ticker into 'ticker1, ticker2'  string
                var sppwids = _.pluck(message.instruments, 'sppwId').join(',');
                var tickers = _.pluck(message.instruments, 'tickerSymbol').join(',');
                if(sppwids !== ''){
                    $scope.fundsRelatedTIData = articleResourceFactory.fundsRelatedTIResource.get({tickers: tickers, sppwIds: sppwids});
                }


            };

        }
    };

});
