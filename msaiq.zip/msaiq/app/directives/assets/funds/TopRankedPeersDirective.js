'use strict';


msaiqApp.directive('msaTopRankedPeers', function () {
    return {
        transclude: true,
        templateUrl: 'directives/assets/funds/topRankedPeers.html',
        replace: true,
        scope: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging, QuickViewService) {
            $scope.showWatchlist = false;
            $scope.selectedSppwidsObj = {
                selectedSppwids : []
            }
            /* when article is loaded, call the service and pass in the callback loadTopRankedPeersData  */
            ArticleMessaging.onFundsArticleLoad($scope,
                function(event, message){
                    $scope.loadTopRankedPeersData(message);
                }
            );

            $scope.loadTopRankedPeersData = function(message){
                $scope.articleid = message.articleid;
                var sppwidsArray = _.pluck(message.instruments, 'sppwId');
                var tickersArray = _.pluck(message.instruments, 'tickerSymbol');
                if(sppwidsArray.length !== 0){
                    var fundsTopRankedPeersRawData  = articleResourceFactory.fundsRelatedPeersResource.get({requestType: 'FUNDS',sppwId:sppwidsArray,ticker:tickersArray});
                    fundsTopRankedPeersRawData.$promise.then(function(item){
                        angular.forEach(item.relatedPeers,function(item){
                            item['checkLink'] = false;
                        });
                        $scope.fundsTopRankedPeersData = item;
                    });
                }

            };
            $scope.handleCheckBoxChange = function(checkLink, sppwid){
                if(checkLink){
                    $scope.selectedSppwidsObj.selectedSppwids.push(sppwid);
                }else{
                    $scope.selectedSppwidsObj.selectedSppwids.splice( $scope.selectedSppwidsObj.selectedSppwids.indexOf(sppwid), 1);
                }
                $scope.showWatchlist = $scope.selectedSppwidsObj.selectedSppwids.length>0 ? true:false;
            };

            $scope.$watch('selectedSppwidsObj.selectedSppwids',function(value){
                if(value.length == 0 && $scope.showWatchlist){
                    angular.forEach($scope.fundsTopRankedPeersData.relatedPeers,function(item){
                        item.checkLink = false;
                    });
                  $scope.showWatchlist  = false;
                }
            },true);
        }
    };

});
