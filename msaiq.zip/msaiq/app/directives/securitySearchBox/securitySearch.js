'use strict';


msaiqApp.directive('msaSecuritySearch', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/securitySearchBox/securitySearch.html',
        replace: true,
        link: function (scope, attrs) {
            scope.sppwid = attrs.sppwid;
            scope.ticker = attrs.ticker;
            scope.source = attrs.source;
        },
        scope: {
            sppwid: '@', ticker: '@', source: '@', changeSubmitState : '&'
        },

        controller: function ($scope, $log, $resource, $location, $window, $,msaMessageController,AutoSuggestService) {
            $.placeholder.shim();
            /*if($scope.source==="alert"){
                $('#input02').attr('value','search for security (type symbol here)');
                $('#input02').blur(function(){
                    $(this).val() == '' ? $(this).val('search for security (type symbol here)') : false;
                });
                $('#input02').focus(function(){
                    $(this).val() == 'search for security (type symbol here)' ? $(this).val('') : false;
                });
            }
            else{
                $('#input02').attr('value','search / enter symbol');
                $('#input02').blur(function(){
                    $(this).val() == '' ? $(this).val('search / enter symbol') : false;
                });
                $('#input02').focus(function(){
                    $(this).val() == 'search / enter symbol' ? $(this).val('') : false;
                });
            }*/
            $('#input02').typeahead([
                    {
                        name: 'input02',
                        limit: 11,
                        remote: {
                            url: '/es/ac/power_search/_search?pretty=true&q=ticker',
                            replace: function (url, uriEncodedQuery) {
                                var esQuery = {
                                    'query': {

                                        'multi_match': {
                                            'query': uriEncodedQuery.toLowerCase(),
                                            'analyzer': 'keyword',
                                            'fields': [ 'ticker^100', 'autocomplete_edge_ticker^70', 'name^50', 'autocomplete_edge^30', 'autocomplete_ngram^05' ]
                                        }

                                    },

                                    'sort': [
                                        '_score',
                                        { 'name.untouched': 'desc' }
                                    ],
                                    'highlight': {
                                        'pre_tags': ['<strong>', '<strong>'],
                                        'post_tags': ['</strong>', '</strong>'],
                                        'fields': {
                                            'autocomplete_edge_ticker': {},
                                            'ticker': {},
                                            'autocomplete_edge': {},
                                            'autocomplete_ngram': {},
                                            'name': {}
                                        }
                                    }
                                };

                                return '/es/ac/power_search/_search?pretty=true&source=' + JSON.stringify(esQuery);
                            },
                            rateLimitWait: 50,

                            filter: function (parsedResponse) {
                                var response =AutoSuggestService.parseResponse(parsedResponse,true);
                                var rtn = [];
                                var currentPath = $location.path();
                                var pathComponents = currentPath.split('/');
                                if(pathComponents[2]==="alertLanding") {
                                            $.each(response, function (index, value) {
                                                if(value.security_type!="Fund" &&  value.security_type!="Global Fund" &&  value.security_type!="Funds" &&  value.security_type!="US Fund"){
                                                        rtn.push(value);
                                               }
                                });
                                       return rtn;
                                }else{

                                       return response;
                                   }




                            }
                        },

                        template: [
                            '{{^link}}' +
                                '<table style="font-size: 11px; width: 100%">' +
                                '<tr>' +
                                '<td style="width: 20%;">{{{displayTicker}}}{{#exchange}}:{{exchange}}{{/exchange}}</td>' +
                                '<td style="width: 60%;" >{{{displayName}}}</td>' +
                                '<td style="white-space: nowrap">{{security_type}}&nbsp;{{#report_ind}}({{report_ind}}){{/report_ind}}</td>' +

                                '</tr>' +
                                '</table>' +
                                '{{/link}}' +
                                '{{#link}}' +
                                '<table style="font-size: 11px; width: 100%;" class=".tt-js-header">' +
                                '<tr>' +
                                '<td style="width: 80%;padding: 2px;;">{{title}}</td>' +
                                '<td style="white-space: nowrap">{{report_ind}}{{{link}}}</td>' +
                                '</tr>' +
                                '</table>' +
                                '{{/link}}'
                        ].join(''),
                        engine: Hogan

                    }

                ]).on('typeahead:selected', function (e, selectedDatum) {
                    $scope.changeSubmitState({disbled : false});
                    var messageWrapper ={
                        messageType:'SECURITY_INFO',
                        messageBody:selectedDatum
                    } ;
                    msaMessageController.prepForBroadcast(messageWrapper);

                }).on('typeahead:opened', function (e, selectedDatum) {
                    $scope.changeSubmitState({disabled : true});

                });

            $scope.$on('handleBroadcast', function () {
                if (msaMessageController.message.messageType === 'CLEAR_SEARCH') {
                    $('#input02').typeahead('setQuery', '');
                    $('#input02').blur();
                }
            });
        }
    };
});
