'use strict';


msaiqApp.directive('marketViewComponent', function () {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: 'directives/dowchart/dowChartTemplate.html',
        controller:function ($scope, $element, $, $location, articleResourceFactory) {
            var secure  = ($location.protocol === 'https:');
            var cache   = 0;
            $element.on('show.bs.collapse hide.bs.collapse', function (n) {
                $(n.target).siblings('.panel-heading').find('.panel-title i').toggleClass('glyphicon-chevron-down glyphicon-chevron-right');
                $(n.target).siblings('.panel-heading').find('.panel-title span').toggleClass('link-highlight link-normal');
            });
            $scope.getFXData = articleResourceFactory.getFXData.get();
            $scope.getFXData.$promise.then(
              function(response)
              {
                  $scope.fxpublishedDate = response.publishedDate;
                  $scope.fxData = response.table;
              }
            );
            $scope.getBondsData = articleResourceFactory.getBondsData.get();
            $scope.getBondsData.$promise.then(
                function(response)
                {
                    $scope.bondspublishedDate = response.publishedDate;
                    $scope.bondsData = response.table;
                }
            );
            $scope.getIndexData = articleResourceFactory.getIndexData.query();
            $scope.getIndexData.$promise.then(
                function(response)
                {
                    var time = response[0].delayedPriceTime.split(' ');
                    var hhmm = time[1].split(':');
                    var date = time[0].split('-');
                    $scope.delayTime = new Date(date[0],date[1]-1,date[2],hhmm[0],hhmm[1],hhmm[2].substring(0,hhmm[2].length-2)).getTime();
                    $scope.indexData = $scope.filterData(response);
                }
            );
            $scope.SP500	 = true;
            $scope.SP500URL  = "/SP/msa/servlet/prophetCharts.html?symbol=4359526&isSecure="+secure+"&chartStyle=1&clearCache="+(++cache)+"&currentTime="+new Date().getTime()+"&errorImageSize=small";

            $scope.SP400     = true;
            $scope.SP400URL  = "/SP/msa/servlet/prophetCharts.html?symbol=8404685&isSecure="+secure+"&chartStyle=1&clearCache="+(++cache)+"&currentTime="+new Date().getTime()+"&errorImageSize=small";

            $scope.SP600     = true;
            $scope.SP600URL  = "/SP/msa/servlet/prophetCharts.html?symbol=8404703&isSecure="+secure+"&chartStyle=1&clearCache="+(++cache)+"&currentTime="+new Date().getTime()+"&errorImageSize=small";

            $scope.SPE350    = true;
            $scope.SPE350URL = "/SP/msa/servlet/prophetCharts.html?symbol=8404713&isSecure="+secure+"&chartStyle=1&clearCache="+(++cache)+"&currentTime="+new Date().getTime()+"&errorImageSize=small";

            $scope.NASDAQ      = true;
            $scope.NASDAQURL   = "/SP/msa/servlet/prophetCharts.html?symbol=324985&isSecure="+secure+"&chartStyle=1&clearCache="+(++cache)+"&currentTime="+new Date().getTime()+"&errorImageSize=small";

            $scope.DJI       = true;
            $scope.DJIURL    = "/SP/msa/servlet/prophetCharts.html?symbol=324977&isSecure="+secure+"&chartStyle=1&clearCache="+(++cache)+"&currentTime="+new Date().getTime()+"&errorImageSize=small";

           // $('#collapseOne').collapse('show');

            $scope.createRows = function createRows(specs,responseData) {
                var data = [];
                for(var i=0; i< specs.length; i++) { //for each spec
                    var spec = specs[i];
                    for(var j=0; j < responseData.length; j++){ //for each item
                        var d = responseData[j];
                        if(d.symbol === spec.symbol) {
                            d.companyName = spec.name;
                            data.push(d);
                            break;
                        }
                    }
                }
                return data;
            }
            $scope.filterData = function filterIndexData(data)
            {
                return $scope.createRows([
                    {symbol:'I:DJI', name:'DOW JONES'},
                    {symbol:'I:SP500', name:'S&P 500'},
                    {symbol:'I:SP400', name:'S&P 400'},
                    {symbol:'I:SP600', name:'S&P 600'},
                    {symbol:'I:SPE350', name:'S&P Europe 350'},
                    {symbol:'I:COMP', name:'NASDAQ'}
                ],data);
            }
            $scope.goTo = function (companyName) {
                if( companyName.indexOf("S&P")!=-1){
                $location.path('/marketscope/indices/');}
            };
        }

    };
});


