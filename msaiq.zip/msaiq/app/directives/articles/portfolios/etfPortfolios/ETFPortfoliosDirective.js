'use strict';

msaiqApp.directive('etfPortfolios', function () {
    return{
        transclude: true,
        templateUrl: 'directives/articles/portfolios/etfPortfolios/etfPortfolios.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, $){
            $scope.portfoliosResource = articleResourceFactory.portfolioConfigResource.get();
            $scope.portfoliosResource.$promise.then(function (portfoliosResource) {
                $scope.etfPortfolioListResource = articleResourceFactory.portfolioInfoResource.get({key: 'ETF_PORTFOLIOS', available: portfoliosResource.ETF_PORTFOLIOS});
            });
        }
    };

});