'use strict';


msaiqApp.directive('msaArticlesLanding', function () {
    return{
        transclude: true,
        templateUrl: 'directives/articles/articlesLanding/articlesLanding.html',
        replace: true,
        scope: {
            articletitle:'@', articleCode: '@', route: '@'
        },
        controller: function ($scope, $rootScope, $log, $location,$filter, articleResourceFactory, ngTableParams,  _, $, WatchlistDataService){

            $location.url($scope.route+'/articleList');
            $scope.symbolAction = '';
            $scope.watchlistAction = '';
            var decodeHTML = $filter('decodeHTML');
            $scope.watchlistActionLoading = false;
            $scope.showWatchlistArticlesTable = false;
            $scope.watchListTimeInterval = '';

            if($scope.articleCode == 'RNOTS'){
                $scope.watchListTimeInterval = 90;
                if($rootScope.userIsIntlEntitled){
                    $scope.articleCode = 'GLBRNOTS';
                }
            }

            $log.info('-------------stuff here--------------------');
            $log.info($scope.articleCode);

            $scope.articlesList =  articleResourceFactory.articleLandingPageResource.get({articleCode: $scope.articleCode});
            $scope.articlesList.$promise.then(function(articleList){

                $scope.symbols = _.unique($.map(_.pluck($scope.articlesList.articles, 'articleInstruments'), function(n){ return n; }), function(symbol) {return  symbol.tickerSymbol;});

                angular.forEach(articleList.articles, function(article){
                    article.headlineUpdate = $scope.redoArticleTitle(article.headline, article.articleInstruments);
                });

                $scope.articlesListFiltered = articleList.articles
            });

            $('#article-watchlist-drop-down-input2').click(function (e) {
                $('#watchlist-drop-down-header2').addClass('open');
                e.stopPropagation();
            });
            $('#article-ticker-drop-down-input1').click(function (e) {
                $('#article-drop-down-header2').addClass('open');
                e.stopPropagation();
            });

            WatchlistDataService.watchlistData.$promise.then(function(watchlistData){
                $scope.watchlists = watchlistData.watchLists;
            });

            $scope.goTo = function(url, windowName){
                // Google anaytics code to track PDF downloaded
                $log.info('tracking GA');
                ga('send', 'pageview', {
                    'page': url,
                    'title': 'MSA PDF',
                    'dimension1': $rootScope.currentUser,
                    'dimension2': $rootScope.partner_name,
                    'dimension3': $rootScope.company,
                    'dimension6':$rootScope.partnerIdm
                });
                // Google Analytics Code ENDs
                window.open( url, windowName, 'resizable=yes');
            };

            $scope.redoArticleTitle = function(headline, instruments){
                var mainSymbol = '';  var sppwId = '';
                angular.forEach(instruments, function(instrument){
                    if( instrument.articleRelationship === 'main') {
                        mainSymbol = instrument.tickerSymbol; sppwId = instrument.sppwId;
                    }
                });
                if (mainSymbol){
                    var indexSearch = headline.indexOf('('+mainSymbol+')');
                    if (indexSearch > 0) {
                        return ({headlineStart: headline.substring(0, indexSearch-1).trim(), 'link': mainSymbol, headlineEnd: headline.substring(indexSearch+mainSymbol.length+2, headline.length), sppwId: sppwId});
                    }else{
                        return {headlineStart: headline, 'link': mainSymbol, sppwId: sppwId };
                    }
                } else {
                    return null;
                }
            };

            $scope.showArticles = function(action){
                $scope.symbolAction = action;
                $scope.watchlistAction = '';
                $scope.showWatchlistArticlesTable = false;

                if (action === 'ON THE RISE'){
                    $scope.articlesListFiltered = $filter('filter')( $scope.articlesList.articles, function(article){
                        var val = false;
                        angular.forEach(article.articleInstruments, function(instrument){
                            if( instrument.pctChange > 0){ val = true; }
                        });
                        return val;
                    });
                }else if(action === 'ON THE DECLINE') {
                    $scope.articlesListFiltered = $filter('filter')( $scope.articlesList.articles, function(article){
                        var val = false;
                        angular.forEach(article.articleInstruments, function(instrument){
                            if( instrument.pctChange < 0){ val = true; }
                        });
                        return val;
                    });
                }else if(action === 'RECENT UPGRADES') {
                    var searchUpgradeParams = {articleCode: $scope.articleCode, requestType: 'UPGRADE', start: '0', limit: 20, sort: 'lastPublishDate', dir: 'DESC', timeInterval:90};
                    var recentUpgradeResource = articleResourceFactory.articleListRequestTypeResource.get(searchUpgradeParams);
                    recentUpgradeResource.$promise.then(function(){
                        $scope.articleLandingTableParams =  new ngTableParams({
                            page: 1,            // show first page
                            total: recentUpgradeResource.total_records,           // length of data
                            count:searchUpgradeParams.limit,          // count per page
                            sorting: {
                                lastPublishDate: 'desc'     // initial sorting
                            },
                            searchParams: searchUpgradeParams
                        });
                    });

                }else if(action === 'RECENT DOWNGRADES') {
                    var searchDownGradeParams =  {articleCode: $scope.articleCode, requestType: 'DOWNGRADE', start: '0', limit: 20, sort: 'lastPublishDate', dir: 'DESC', timeInterval:90};
                    var recentDowngradeResource = articleResourceFactory.articleListRequestTypeResource.get(searchDownGradeParams);
                    recentDowngradeResource.$promise.then(function(){
                        $scope.articleLandingTableParams =  new ngTableParams({
                            page: 1,            // show first page
                            total: recentDowngradeResource.total_records,           // length of data
                            count: searchDownGradeParams.limit,          // count per page
                            sorting: {
                                lastPublishDate: 'desc'     // initial sorting
                            },
                            searchParams: searchDownGradeParams
                        });
                    });
                }else if(action === 'SEE ALL') {
                    var searchExtendParams = {articleCode: $scope.articleCode, timeInterval: 90, start: '0', limit: 20, sort: 'lastPublishDate', dir: 'DESC'};
                    var extendResource = articleResourceFactory.articleListTimePeriodResource.get(searchExtendParams);
                    extendResource.$promise.then(function(){
                        $scope.articleLandingTableParams =  new ngTableParams({
                            page: 1,            // show first page
                            total: extendResource.total_records,           // length of data
                            count: searchExtendParams.limit,          // count per page
                            sorting: {
                                lastPublishDate: 'desc'     // initial sorting
                            },
                            searchParams: searchExtendParams
                        });
                    });
                }
                $('#article-ticker-drop-down-input1').val($scope.symbolAction);
                $('#article-watchlist-drop-down-input2').val($scope.watchlistAction);
            };

            $scope.showArticlesBySymbol = function(symbol){
                $scope.symbolAction = symbol.tickerSymbol + '-' +  symbol.companyName;
                $scope.watchlistAction = '';
                $scope.showWatchlistArticlesTable = false;

                var articleIdsWithSymbol = _.reduce($scope.articlesList.articles, function(result,article, key){
                    var symbolFind = _.find(article.articleInstruments, {'tickerSymbol': symbol.tickerSymbol});
                    if (symbolFind){
                        result.push(article);
                    }
                    return result;
                }, []);
                if (articleIdsWithSymbol && articleIdsWithSymbol.length > 1){
                    $log.debug('Going to filter it somehow');
                    $scope.articlesListFiltered = $filter('filter')( $scope.articlesList.articles, function(article){
                        var val = false;
                        angular.forEach(articleIdsWithSymbol, function(articleSym){
                            if( articleSym.articleId === article.articleId){
                                val = true;
                            }
                        });
                        return val;
                    });
                }else if (articleIdsWithSymbol){
                    $log.debug('Going to ' + $scope.route + '/' + $scope.articleCode  + '/' + articleIdsWithSymbol[0].articleId);
                    $location.path($scope.route + '/' + $scope.articleCode  + '/' + articleIdsWithSymbol[0].articleId);
                }

                $('#article-ticker-drop-down-input1').val($scope.symbolAction);
                $('#article-watchlist-drop-down-input2').val($scope.watchlistAction);
            };

            $scope.showArticlesByWatchlist = function(title,watchlist,typeAction) {
                $scope.symbolAction = '';
                title = decodeHTML(title);
                $scope.watchlistAction = title;
                $scope.articlesListFiltered = {};
                $scope.watchlistActionLoading = true;
                var sppwIdArray = [];
                if(typeAction === 'one'){
                    watchlist.items.forEach(function(item){
                        sppwIdArray.push(item.sppwId);
                    });
                } else{
                    $scope.watchlists.forEach(function(watchlist){
                        watchlist.items.forEach(function(watchlistItem){
                            sppwIdArray.push( watchlistItem.sppwId );
                        });
                    });
                }
                sppwIdArray = sppwIdArray.join(',');
                sppwIdArray = sppwIdArray.length > 0?sppwIdArray:-1;
                var searchExtendParams = {start: 0,limit: 20,articleCode: $scope.articleCode,sppwIds: sppwIdArray,requestType: 'watchlist',symbol:'',gicsCode:'',author:'',timeInterval:$scope.watchListTimeInterval};
                var extendResource = articleResourceFactory.articleListRequestTypeWatchlistResource.get(searchExtendParams);
                extendResource.$promise.then(function(){
                    $scope.articleLandingTableParams =  new ngTableParams({
                        page: 1,            // show first page
                        total: extendResource.total_records,           // length of data
                        count: searchExtendParams.limit,          // count per page
                        sorting: {
                            lastPublishDate: 'desc'     // initial sorting
                        },
                        searchParams: searchExtendParams
                    });
                    $scope.articlesListFiltered = extendResource.articles;
                    if (extendResource.total_records == 1){
                        $log.debug('Going to ' + $scope.route + '/' + $scope.articleCode  + '/' + $scope.articlesListFiltered[0].articleId);
                        $location.path($scope.route + '/' + $scope.articleCode  + '/' + $scope.articlesListFiltered[0].articleId);
                    }
                    $scope.watchlistActionLoading = false;
                });
                $scope.showWatchlistArticlesTable = true;
                $('#article-ticker-drop-down-input1').val($scope.symbolAction);
                $('#article-watchlist-drop-down-input2').val($scope.watchlistAction);
            };

            $scope.$watch('articleLandingTableParams', function(params) {

                if (!params){
                    $log.debug('Initial load, ignore');
                }else{
                    var resource = null;
                    if(params.searchParams.requestType == 'watchlist'){
                        resource = articleResourceFactory.articleListRequestTypeWatchlistResource.get({start: ((params.page-1) * params.count),limit:  params.count,articleCode: $scope.articleCode,sppwIds: params.searchParams.sppwIds,requestType: 'watchlist',symbol:'',gicsCode:'',author:'',timeInterval:$scope.watchListTimeInterval});

                    } else if(params.searchParams.requestType){
                        resource = articleResourceFactory.articleListRequestTypeResource.get({articleCode: $scope.articleCode, requestType: params.searchParams.requestType, timeInterval: params.searchParams.timeInterval, start: ((params.page-1) * params.count), limit: params.count, sort: (params.sorting.headline? 'headline': 'lastPublishDate'), dir: (params.sorting.headline || params.sorting.lastPublishDate) });
                    } else {
                        resource = articleResourceFactory.articleListTimePeriodResource.get({articleCode: $scope.articleCode, timeInterval: params.searchParams.timeInterval, start: ((params.page-1) * params.count), limit: params.count, sort: (params.sorting.headline? 'headline': 'lastPublishDate'), dir: (params.sorting.headline || params.sorting.lastPublishDate) });
                    }
                    resource.$promise.then(function(){
                        $scope.articlesListFiltered = {};
                        $scope.articlesListFiltered = resource.articles;
                        $scope.articleLandingTableParams.total = resource.total_records;
                    });
                    $scope.articleLandingTableParams.counts = null;
                }
            }, true);
        }
    };

});
