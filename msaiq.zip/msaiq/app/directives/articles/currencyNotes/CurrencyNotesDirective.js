'use strict';


msaiqApp.directive('msaCurrencyNotes', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/currencyNotes/currencyNotes.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory){
            $log.debug('currency notes');
            $scope.currencyNotes = articleResourceFactory.articleDataResource.get({articleCode: 'ECRCM', start: 0, limit: 1});

        }
    };

});    