'use strict';


msaiqApp.directive('msaArticleDetails', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/articleDetails/articleDetails.html',
        replace: true,
        link: function (scope, element, attrs) {
            attrs.articlecode = scope.articleCode; /* pass from directive as param */
            attrs.articleid = scope.articleId;
            attrs.article = scope.article;
        },
        scope: {
            articlecode: '@', articleid: '@', article: '='
        },
        controller: function ($scope, $log, articleResourceFactory,$rootScope){
          /* can be passed as param or article as object */

          if (!$scope.article && $scope.articleId){
                $scope.article = articleResourceFactory.articlesSimpleDetailsResource.get({articleId: $scope.articleId});
          }
          $log.info('article details page directive');

          $scope.goTo = function(url, windowName){
              window.open( url, windowName, 'resizable=yes');

          };

            $scope.trackGA = function(path){
                // Google anaytics code to track PDF downloaded
                $log.info('tracking GA');
                ga('send', 'pageview', {
                    'page': path,
                    'title': 'MSA PDF',
                    'dimension1': $rootScope.currentUser,
                    'dimension2': $rootScope.partner_name,
                    'dimension3': $rootScope.company,
                    'dimension6':$rootScope.partnerIdm
                });
                // Google Analytics Code ENDs
            };

         /* $scope.openQV = function(sppwId, ticker, report_ind, type){
              QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
          }; */
        }
    };
});
