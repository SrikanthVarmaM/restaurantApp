'use strict';

msaiqApp.directive('subSectorRelatedPeerGrid', function () {
    return{
        transclude: true,
        scope:{
            security: '@',id: '@',symbol: '@',rank: '@',report: '@', report_type: '@', region: '@'
        },
        templateUrl: 'directives/articles/sectors/sectorRelatedPeersGrid.html',
        controller: function ($scope, $log ,articleResourceFactory){
            $scope.noPeerResultMsgLower = 'THERE IS NO PEER GROUP DATA AVAILABLE FOR THE SELECTED COMPANY.';
            $scope.openSectorRelatedGrid = 0;
           /* $scope.openQV = function(sppwId, ticker, report_ind, type){
                QuickViewService.openQV({ticker: (ticker || ''), type: (type || 'stock').toLowerCase(), sppwId: (sppwId || ''), report_ind: (report_ind || 'undefined')});
            };*/

            $scope.openRelatedPeerGrid = function(sppwId){
                $scope.sectorRelatedPeersData = articleResourceFactory.sectorRelatedPeersResource.get({sppwId:sppwId,requestType:'ALL_PEER_DETAILS'});
            };
        }
    };
});