'use strict';


msaiqApp.directive('msaRelatedTrendsAndIdeas', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedTrendsAndIdeas/relatedTrendsAndIdeas.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging, _){

            /* when article is loaded, call the service and pass in the callback loadRelatedTIData  */
            /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedTIData(message);
                }
            );

            $scope.loadRelatedTIData = function(message){
                // get all sppwids and ticker into 'ticker1, ticker2'  string
                var sppwids = _.pluck(message.instruments, 'sppwId').join(',');
                var tickers = _.pluck(message.instruments, 'tickerSymbol').join(',');

                $log.debug('related trends and Ideas directive with ' + tickers+ ', ' + sppwids);
                if(sppwids !== ''){
                    $scope.relatedTIData = articleResourceFactory.relatedTIResource.get({tickers: tickers, sppwIds: sppwids});
                }


            };

        }
    };

});
