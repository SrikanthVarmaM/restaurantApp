'use strict';


msaiqApp.directive('msaRelatedEtfTrendsAndIdeas', function () {
    return {
        //restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedTrendsAndIdeas/relatedEtfTrendsAndIdeas.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging) {

            /* when article is loaded, call the service and pass in the callback loadRelatedEtfTrendsAndIdeasData  */
            ArticleMessaging.onEtfArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedEtfTrendsAndIdeasData(message);
                }
            );


            $scope.loadRelatedEtfTrendsAndIdeasData = function (message) {
                $scope.sppwid = message.sppwId;
                $scope.ticker = message.ticker;

                $scope.relatedEtfTIData = articleResourceFactory.relatedEtfTIResource.get({ticker: $scope.ticker, sppwId: $scope.sppwid});

                // action on data object when returned
                $scope.relatedEtfTIData.$promise.then(function (relatedEtfTIData) {
                    $log.info('received etf TI data ');
                    $scope.relatedEtfTIData = relatedEtfTIData;
                });
            };


            if ($scope.ticker && $scope.sppwid) {
                $scope.loadData();
            }
        }
    };

});
