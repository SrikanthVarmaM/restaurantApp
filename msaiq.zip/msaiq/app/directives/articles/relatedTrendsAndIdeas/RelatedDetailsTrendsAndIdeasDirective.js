'use strict';


msaiqApp.directive('msaRelatedDetailsTrendsAndIdeas', function () {
    return {
        //restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedTrendsAndIdeas/relatedDetailsTrendsAndIdeas.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging, _) {

            /* when article is loaded, call the service and pass in the callback loadRelatedDetailsTrendsAndIdeasData  */
            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedDetailsTrendsAndIdeasData(message);
                }
            );

            $scope.loadRelatedDetailsTrendsAndIdeasData = function (message) {
                $scope.sppwids = _.pluck(message.instruments, 'sppwId').join(',');
                $scope.articleId = message.articleId;

                $log.debug('related details trends and ideas directive for articleId: ' + message.articleId);
                $scope.relatedDetailsTIData = articleResourceFactory.relatedDetailsTIResource.get({sppwIds: $scope.sppwids, articleId: $scope.articleId});

            };
        }
    };

});
