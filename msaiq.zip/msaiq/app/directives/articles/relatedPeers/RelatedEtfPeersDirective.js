'use strict';


msaiqApp.directive('msaRelatedEtfPeers', function () {
    return {
        //restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedPeers/relatedEtfPeers.html',
        replace: true,
        scope: true,
        controller: function ($scope, $log, $filter, articleResourceFactory, QuickViewService, ArticleMessaging) {
            $scope.QuickViewService = QuickViewService;
            $scope.showWatchlist = false;
            $scope.selectedSppwIdsObj ={
                selectedSppwids : []
            };
            /* when article is loaded, call the service and pass in the callback loadRelatedETFPeersData  */
            ArticleMessaging.onEtfArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedEtfPeersData(message);
                }
            );

            $scope.loadRelatedEtfPeersData = function (message) {
                $scope.overallInd = message.relatedParam.overallInd;
                $scope.sppwId = message.sppwId;

                var relatedParams = message.relatedParam;

                var params_1;
                if (relatedParams && relatedParams.holdingsRegion) {
                    params_1 = {inferedPropertyName: 'holdingsRegion', operationValue: relatedParams.holdingsRegion, property: 'holdingsRegion'};
                }else{
                    params_1 = {inferedPropertyName: 'holdingAssetClass', operationValue: relatedParams.holdingsAssetClass, property: 'holdingAssetClass'};
                }

                $scope.relatedEtfPeersData = articleResourceFactory.relatedEtfPeersResourceOpt.get(
                  {   inferedPropertyName_0: 'overallInd', operation1Value_0: relatedParams.overallInd, propertyName_0: 'overallInd',
                      inferedPropertyName_1: params_1.inferedPropertyName, operation1Value_1:params_1.operationValue, propertyName_1: params_1.property,
                      inferedPropertyName_2: 'etfType', operation1Value_2: relatedParams.etfType, propertyName_2:'etfType',
                      start:0, limit:6, sort:'sortableMarketCap', dir: 'DESC', resort: 'false'
                  }
                );

                // action on data object when returned
                $scope.relatedEtfPeersData.$promise.then(function (relatedEtfPeersData) {

                    $scope.total_records = relatedEtfPeersData.total_records;

                    // filter out the same sppwid
                    $scope.relatedEtfPeersData = $filter('filter')(relatedEtfPeersData.equities, function(peer){
                        return (peer.sppwId !== $scope.sppwId );
                    });

                    angular.forEach($scope.relatedEtfPeersData,function(item){
                        item['checkLink'] = false;
                    });
                });
            };

            $scope.handleCheckBoxChange = function(checkLink, sppwid){
                if(checkLink){
                    $scope.selectedSppwIdsObj.selectedSppwids.push(sppwid);
                }else{
                    $scope.selectedSppwIdsObj.selectedSppwids.splice( $scope.selectedSppwIdsObj.selectedSppwids.indexOf(sppwid), 1);
                }
                $scope.showWatchlist = $scope.selectedSppwIdsObj.selectedSppwids.length>0 ? true:false;
            };

            $scope.$watch('selectedSppwIdsObj.selectedSppwids',function(value){
                if(value.length == 0 && $scope.showWatchlist){
                    angular.forEach($scope.relatedEtfPeersData,function(item){
                        item.checkLink = false;
                    });
                    $scope.showWatchlist  = false;
                }
            },true);

            if ($scope.holdingsRegion && $scope.etfType) {
                $scope.loadRelatedEtfPeersData();
            }

        }
    };

});
