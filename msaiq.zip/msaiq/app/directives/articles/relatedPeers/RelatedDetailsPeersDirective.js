'use strict';

msaiqApp.directive('msaRelatedDetailsPeers', function () {
    return {
        //restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedPeers/relatedDetailsPeers.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, QuickViewService, ArticleMessaging) {
            /* when article is loaded, call the service and pass in the callback loadRelatedETFPeersData  */

            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedDetailsPeersData(message);
                }
            );

            $scope.loadRelatedDetailsPeersData = function (message) {
                $log.debug('related details peers directive for articleId: ' + message.articleId);

                $scope.relatedDetailsPeersData =  articleResourceFactory.relatedDetailsPeersResource.get();
            };
        }
    };

});
