'use strict';


msaiqApp.directive('msaRelatedPeers', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedPeers/relatedPeers.html',
        replace: true,
        scope:true,
        controller: function ($scope, $log, articleResourceFactory, QuickViewService, ArticleMessaging, _){

            $scope.showWatchlist = false;
            $scope.selectedSppwIdsObj ={
                selectedSppwids : []
            };
            $scope.QuickViewService = QuickViewService;

            /* when article is loaded, call the service and pass in the callback loadRelatedPeers  */
            /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedPeersData(message);
                }
            );

            $scope.loadRelatedPeersData = function(message){
                // only get the first ticker's related peers
                var sppwidsArray = _.pluck(message.instruments, 'sppwId');
                var tickersArray = _.pluck(message.instruments, 'tickerSymbol');

                $log.debug('related peers directive with ' + sppwidsArray[0] + ', ' + tickersArray[0]);
                if(sppwidsArray.length !== 0){
                    $scope.relatedPeersData =  articleResourceFactory.relatedPeersResource.get({ticker: tickersArray[0], sppwId: sppwidsArray[0]});
                    $scope.relatedPeersData.$promise.then(function(data){
                        if(data){
                            angular.forEach(data.relatedPeers,function(item){
                                item['checkLink'] = false;
                            });
                        }
                    });
                }
            };
            $scope.handleCheckBoxChange = function(checkLink, sppwid){
                if(checkLink){
                    $scope.selectedSppwIdsObj.selectedSppwids.push(sppwid);
                }else{
                    $scope.selectedSppwIdsObj.selectedSppwids.splice( $scope.selectedSppwIdsObj.selectedSppwids.indexOf(sppwid), 1);
                }
                $scope.showWatchlist = $scope.selectedSppwIdsObj.selectedSppwids.length>0 ? true:false;
            };

            $scope.$watch('selectedSppwIdsObj.selectedSppwids',function(value){
                if(value.length == 0 && $scope.showWatchlist){
                    angular.forEach($scope.relatedPeersData.relatedPeers,function(item){
                        item.checkLink = false;
                    });
                    $scope.showWatchlist  = false;
                }
            },true);
        }
    };

});
