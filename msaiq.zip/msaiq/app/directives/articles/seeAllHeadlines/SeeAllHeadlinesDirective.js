'use strict';

msaiqApp.directive('msaSeeAllHeadlines', function () {
    return{
        transclude: true,
        templateUrl: 'directives/articles/seeAllHeadlines/seeAllHeadlines.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, _, ngTableParams, $routeParams, $filter, assetsResourceFactory){
            $scope.loadingState = true;
            $scope.ticker = $routeParams.ticker;
            $scope.sppwid = $routeParams.sppwid;
            $scope.articleId = $routeParams.articleId;
            $scope.source = $routeParams.source;
            $scope.showFocus = false;
            $scope.tableParams = new ngTableParams({
                page: 1,
                total: 0,
                count: 20,
                counts: [],
                sorting: { lastPublishDate: 'desc' }
            });
            //for setting no of pages
            if ($routeParams.equityType === 'stocks') {

                if($scope.articleId){
                    $scope.relatedHeadlinesData =  articleResourceFactory.seeAllStockHeadlinesWithArticleID.get({ticker: $scope.ticker, sppwId: $scope.sppwid, start:0,articleId:$scope.articleId});
                }else{
                    $scope.relatedHeadlinesData =  articleResourceFactory.seeAllStockHeadlinesWithoutArticleID.get({ticker: $scope.ticker, sppwId: $scope.sppwid, start:0});
                }
                $scope.relatedHeadlinesData.$promise.then(function(relatedHeadlinesData){
                    $scope.tableParams.total = relatedHeadlinesData.relatedHeadlines.totalHeadlinesCount;
                    if($scope.tableParams.total === 0){
                        $scope.error = 'STOCKS  ' + $scope.ticker + ' is not available';
                    }
                });
                if($scope.articleId) {
                    $scope.article = articleResourceFactory.articlesSimpleDetailsResource.get({articleId: $scope.articleId});
                    $scope.article.$promise.then(function(article) {


                        $scope.isArticle = true;
                        $scope.articleHeadline = article.articleDetails.headline;
                        $log.info(article);

                    });
                }

                $scope.stockData = assetsResourceFactory.stockDetailsESResource.get({sppwid: $scope.sppwid});
                $scope.stockData.$promise.then(function(stockData){
                    $log.debug('stock promised return data');

                    if (!stockData.hits || !stockData.hits.hits[0] || !stockData.hits.hits[0]._source){
                        $scope.error = 'Stock ' + $scope.ticker + ' is not available';
                    }else{
                        $scope.stock = stockData.hits.hits[0]._source;
                        $scope.headline = $scope.stock.security_name;
                        $log.info('headline--------------' + $scope.headline);
                    }
                });

            } else if ($routeParams.equityType === 'etf') {

                if($scope.source==='focus'){
                    $scope.showFocus=true;
                    $scope.eqType='ETF';
                }
                $scope.etfResource = assetsResourceFactory.etfDetailsResource.get({ticker: ($scope.ticker||'null'), sppwid: ($scope.sppwid || 'null')});
                $scope.etfResource.$promise.then(function(etfData){
                    //data.hits.hits[0] && (data.hits.hits[0]._source.ticker
                    if (!etfData.hits || !etfData.hits.hits[0] || !etfData.hits.hits[0]._source){
                        $scope.error = 'ETF  ' + $scope.ticker + ' is not available';
                    }else{
                        $scope.etfDetails = etfData.hits.hits[0]._source;
                        $scope.headline = $scope.etfDetails.fund_name;
                        $scope.topTen = _.pluck($scope.etfDetails.topholdings, 'TradingInformation_Ticker').join('%');
                        $scope.relatedHeadlinesData =  articleResourceFactory.seeAllEtfHeadlinesResource.get({ticker: $scope.ticker, sppwId: $scope.sppwid, articleId: $scope.articleId, topTen: $scope.topTen,start: 0});
                        $scope.relatedHeadlinesData.$promise.then(function(relatedHeadlinesData){
                            $scope.tableParams.total = relatedHeadlinesData.relatedHeadlines.totalHeadlinesCount;
                        });
                    }
                });

            } else if($routeParams.equityType === 'funds') {
                if($scope.source==='focus'){
                    $scope.showFocus=true;
                    $scope.eqType='Funds';

                }
                $scope.tableParams.sorting = {};

                if($scope.articleId){
                    $scope.relatedHeadlinesData =  articleResourceFactory.seeAllFundHeadlines.get({ticker: $scope.ticker, sppwId: $scope.sppwid, start:0, limit:20,articleId:$scope.articleId});
                } else {
                    $scope.relatedHeadlinesData =  articleResourceFactory.seeAllFundHeadlines.get({ticker: $scope.ticker, sppwId: $scope.sppwid, start:0, limit:20,articleId:''});
                }
                $scope.relatedHeadlinesData.$promise.then(function(relatedHeadlinesData){
                    $scope.tableParams.total = relatedHeadlinesData.relatedHeadlines.totalHeadlinesCount;
                    if($scope.tableParams.total === 0){ $scope.error = 'FUNDS  ' + $scope.ticker + ' is not available'; }
                });

                if($scope.articleId) {
                    $scope.article = articleResourceFactory.articlesSimpleDetailsResource.get({articleId: $scope.articleId});
                    $scope.article.$promise.then(function(article) {
                        $scope.isArticle = true;
                        $scope.articleHeadline = article.articleDetails.headline;
                    });
                } else {
                    $scope.fundsDataPromise = assetsResourceFactory.fundsDetailsESResource.get({ticker: $routeParams.ticker});
                    $scope.fundsDataPromise.$promise.then(function (fundsData) {
                        if (!fundsData.hits || !fundsData.hits.hits[0] || !fundsData.hits.hits[0]._source) {
                            $scope.error = 'FUNDS ' + $scope.ticker + ' is not available';
                        } else {
                            $scope.fundsData = fundsData.hits.hits[0]._source;
                            $scope.headline = $scope.fundsData.fund_nm_full;
                        }
                    });
                }
            }

            $scope.$watch('tableParams', function(params) {
                if ($routeParams.equityType === 'stocks') {
                    if($scope.tableParams.total !== 0){
                        if($scope.articleId){
                            $scope.relatedHeadlinesData =  articleResourceFactory.seeAllStockHeadlinesWithArticleID.get({ticker: $scope.ticker, sppwId: $scope.sppwid, start:(params.page-1) * params.count0,articleId:$scope.articleId});
                        }else{
                            $scope.relatedHeadlinesData =  articleResourceFactory.seeAllStockHeadlinesWithoutArticleID.get({ticker: $scope.ticker, sppwId: $scope.sppwid, start:(params.page-1) * params.count});
                        }
                        $scope.relatedHeadlinesData.$promise.then(function(relatedHeadlinesData){
                            $scope.related = relatedHeadlinesData.relatedHeadlines.headlines;
                            $scope.loadingState = false;

                        });
                    }
                } else if ($routeParams.equityType === 'etf') {
                    if($scope.tableParams.total !== 0){
                        $scope.relatedHeadlinesData =  articleResourceFactory.seeAllEtfHeadlinesResource.get({ticker: $scope.ticker, sppwId: $scope.sppwid, articleId: $scope.articleId, topTen: $scope.topTen,start: (params.page-1) * params.count});
                        $scope.relatedHeadlinesData.$promise.then(function(relatedHeadlinesData){
                            $scope.related = relatedHeadlinesData.relatedHeadlines.headlines;
                            $scope.loadingState = false;
                        });
                    }
                } else if ($routeParams.equityType === 'funds') {
                    if($scope.tableParams.total !== 0){
                        $scope.relatedHeadlinesData =  articleResourceFactory.seeAllFundHeadlines.get({ticker: $scope.ticker, sppwId: $scope.sppwid,limit:params.count ,articleId:$scope.articleId, start: (params.page-1) * params.count});
                        $scope.relatedHeadlinesData.$promise.then(function(relatedHeadlinesData){
                            $scope.related = relatedHeadlinesData.relatedHeadlines.headlines;
                            $scope.loadingState = false;
                        });
                    }
                }
            }, true);
        }
    };

});