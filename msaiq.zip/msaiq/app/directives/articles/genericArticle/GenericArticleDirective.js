/**
 * Created with IntelliJ IDEA.
 * User: nkakkireni
 * Date: 10/3/13
 * Time: 3:16 PM
 * To change this template use File | Settings | File Templates.
 */
'use strict';


msaiqApp.directive('msaGenericArticle', function () {
    return{
//        restrict: 'E',
        templateUrl: 'directives/articles/genericArticle/genericArticle.html',
        replace: true,
        controller: function ($scope, $log, $resource,articleResourceFactory){
            $log.info('msa generic article page directive');
            $scope.stock = articleResourceFactory.focusStockOfWeekResource.get();

        }
    };
});


