'use strict';

msaiqApp.directive('msaRelatedSectors', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedSectors/relatedSectors.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging){

            /* when article is loaded, call the service and pass in the callback loadRelatedPeers  */
            /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedSectorsData(message);
                }
            );

            $scope.loadRelatedSectorsData = function(message){
                $log.debug('related sector directive with ' + message.articleId );
                $scope.relatedSectorData = articleResourceFactory.relateSectorsResource.get({articleId: message.articleId , type:'S'});

            };
        }
    };

});
