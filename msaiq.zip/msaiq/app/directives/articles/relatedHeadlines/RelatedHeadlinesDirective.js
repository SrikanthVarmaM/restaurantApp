'use strict';


msaiqApp.directive('msaRelatedHeadlines', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedHeadlines/relatedHeadlines.html',
        replace: true,
        controller: function ($scope, $log, articleResourceFactory, _, ArticleMessaging){

            /* when article is loaded, call the service and pass in the callback loadRelatedHeadlineData  */
            /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedHeadlineData(message);
                }
            );

            /* function to call to get the resource */
            $scope.loadRelatedHeadlineData = function(message){

                /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
                // get all sppwids and ticker into 'ticker1, ticker2'  string

                $log.info(message);
                $scope.sppwids = _.pluck(message.instruments, 'sppwId').join(',');
                $scope.tickers = _.pluck(message.instruments, 'tickerSymbol').join(',');
                $scope.articleId = message.articleId;

                $log.debug('related headlines directive with ' + $scope.tickers + ', ' + $scope.sppwids + ', ' + message.articleId);
                $scope.relatedHeadlinesData =  articleResourceFactory.relatedHeadlinesResource.get({tickers: $scope.tickers, sppwIds: $scope.sppwids, articleId:message.articleId});

            };


        }
    };

});
