'use strict';


msaiqApp.directive('msaRelatedEtfHeadlines', function () {
    return {
        //restrict: 'E',
        transclude: true,
        templateUrl: 'directives/articles/relatedHeadlines/relatedEtfHeadlines.html',
        replace: true,
        scope: {
            source: '='
        },
        controller: function ($scope, $log, articleResourceFactory, ArticleMessaging) {

            /* when article is loaded, call the service and pass in the callback loadRelatedEtfHeadlinesData  */
             ArticleMessaging.onEtfArticleLoad($scope,
                function(event, message){
                    $scope.loadRelatedEtfHeadlinesData(message);
                }
            );

            $scope.loadRelatedEtfHeadlinesData = function(message){
                $scope.sppwid = message.sppwId;
                $scope.ticker = message.ticker;
                $scope.articleid = message.articleid;

                $scope.relatedEtfHeadlinesData = articleResourceFactory.relatedEtfHeadlinesResource.get({ticker: $scope.ticker, sppwId: $scope.sppwid, articleId: $scope.articleid});

                // action on data object when returned
                $scope.relatedEtfHeadlinesData.$promise.then(function (relatedEtfHeadlinesData) {
                    $log.info('received etf headline data ');
                    $scope.relatedEtfHeadlinesData = relatedEtfHeadlinesData;
                });

            };


            $scope.getNumArray = function (num) {

                var array = new Array(num);
                for (var i = 0; i < num; i++) {
                    array[i] = i + 1;
                }
                return array;
            };


            if ($scope.ticker && $scope.sppwid){
                $scope.loadData();
            }
        }
    };

});
