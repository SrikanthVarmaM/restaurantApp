'use strict';


msaiqApp.directive('msaCreateAlertButton', function () {
    return{

        transclude: true,
        templateUrl: 'directives/alert/createAlertButtonDirectiveTemplate.html',
        replace: true,
        link: function (scope, attrs) {

        },
        scope: {
            instrumentid: '=', instrumenttype: '=', securitytype: '=',instrumentname : '=' ,instrumentlongname: '='
        },

        controller: function ($scope, $log, $resource, userResourceResourceFactory, msaMessageController, _,AlertDataService,QuickViewService) {

            /**
             *  --------------------------------CONSTANTS------------------------------------------------------
             */

            $scope.stockInNewsArray=['SECURITIES_IN_MARKET_MOVERS','SECURITIES_IN_RESEARCH_NOTES','SECURITIES_IN_BROKER_VIEWSNEWS'] ;

            /**
             * -----------------------------------INITIALIZATION ----------------------------------------------
             *
             */
           $scope.AlertDataService=AlertDataService;
           $scope.alertArray=AlertDataService.getQuickAlertArrayBySecurityType($scope.securitytype) ;

            /**
             * -------------------------------------FUNCTION DEFINITIONS -----------------------------
             *
             */

            /**
             * below function loads data related to the instrument from outer container scope
             *
             */

            $scope.loadSelectedInstrument=function(){
                $scope.selectedInstrument = {};
                $scope.selectedInstrument.instrumentId = $scope.instrumentid;
                $scope.selectedInstrument.instrumentType = $scope.instrumenttype;
                $scope.selectedInstrument.instrumentName = $scope.instrumentname;
                $scope.selectedInstrument.instrumentLongName = $scope.instrumentlongname;
                $scope.selectedInstrument.securityType=$scope.securitytype; // GQF,FMR, for funds , WATCHlist,stock same alerts   ,others are etf
            }   ;


            $scope.addAlert=function(data,alertTemp,alertType){
                //add this alert item
                if (data.name == "STOCKS_IN_NEWS")  {

                    var alertToPushArr= _.filter($scope.alertArray, function (item) {
                        return _.contains($scope.stockInNewsArray,item.name) ;
                    }) ;
                    for (var i=0;i< alertToPushArr.length;i++) {

                        alertToPushArr[i].checked=true;
                        alertTemp.alertItems.push(alertToPushArr[i]);
                    }


                }else {   //any alert other than news alerts
                    var alertToPush= _.find($scope.alertArray, function (item) {
                        return (item.name == data.name)  ;
                    }) ;
                     alertToPush.checked=true;
                    alertTemp.alertItems.push(alertToPush);
                }
                $scope.loadSelectedInstrument();
                $scope.selectedInstrument.alertId=alertTemp.alertId;
                var email= AlertDataService.getEmail();
                AlertDataService.saveThisAlert(alertType,alertTemp.alertItems,email,$scope.selectedInstrument,'ANY');

            };
            //------------ //chec if for this security, if any set of alerts exists, if  exists & then save it, otherwise create the alert & save it--------------

            $scope.createQuickAlert=function(data){


               // ---------------- gt all the alerts for this user-----------------------


                var alertTemp={};
                alertTemp.alertItems=[];
                $scope.addAlert(data,alertTemp,"CREATE");

            } ;
            $scope.openAlertPopup = function (actionType) {
                $scope.loadSelectedInstrument();
                var data = {
                    actionType: actionType,
                    alert: null ,
                    selectedInstrument: $scope.selectedInstrument
                };

                QuickViewService.openAlertWindow(data);

                var messageWrapper = {
                    messageType: 'SECURITY_INFO',
                    messageBody: $scope.selectedInstrument
                };
                msaMessageController.prepForBroadcast(messageWrapper);
            };

        }
    };

});


