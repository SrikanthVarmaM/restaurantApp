'use strict';


msaiqApp.directive('idcFundChart', function () {
    return{
        restrict: 'A',  // attribute
        transclude: true,
        templateUrl:'directives/charts/idcFundSecurityChart.html',
        replace: true,
        scope: {
            isvolumerequired:'@',
            activeTab:'@',
            securityinfo:'&'
        },
        controller: function ($scope, $log, ArticleMessaging){
            var   isVolumeRequired = $scope.isvolumerequired || true;
            var   activeTab =   $scope.activeTab || '1m';
            /* when article is loaded, call the service and pass in the callback loadImage  */
            ArticleMessaging.onEtfArticleLoad($scope,
                function(event, message){
                    $scope.loadImage(message);
                }
            );
            ArticleMessaging.onFundsArticleLoad($scope,
                function(event, message){
                    $scope.loadImage(message);
                }
            );
            ArticleMessaging.onArticleLoad($scope,
                function(event, message){
                    $scope.loadImage(message);
                }
            );

            // older values  width: 560, height:350,
            var width=650, height=300;

            var idcConfig = {
             url: '/SP/msa/servlet/prophetCharts.html',
            '1m': {duration: '1m', width: width, height:height, interval:250, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0},
            '3m': {duration: '3m', width: width, height:height, interval:250, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0},
            '5m': {duration: '5m', width: width, height:height, interval:350, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0},
            '1y': {duration: '1y', width: width, height:height, interval:400, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0},
            '3y': {duration: '3y', width: width, height:height, interval:250, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0},
            '5y': {duration: '5y', width: width, height:height, interval:600, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0},
            'ytd': {duration: 'ytd', width: width, height:height, interval:400, isSecure: false, applyVol:isVolumeRequired, VOL: 'VOLUME', scheme: 'sandp', compareTo: '', priceDisplay: 1, clearCache:0}
          };

           $scope.loadImage = function(message){
               //TODO: unify the message for stocks and etf later

               $scope.sppwid = ( message.sppwId || message.instruments[0].sppwId);
               $scope.symbol = ( message.ticker || message.tickerSymbol ||  message.instruments[0].tickerSymbol);
               $scope.isin = (message.isin || '');
               // initial load show first month image
               $scope.showImage(activeTab);
           };

           $scope.showImage = function(tabValue){
              //TODO: need to clean the current image and have loading div and show the image
               $scope.imageSrc = 'images/loader3.gif';

               $scope.activeTab = tabValue;
               var configValues = idcConfig[tabValue];

               $scope.imageSrc = idcConfig.url + '?' +
                  'symbol=' + $scope.symbol +
                  '&sppwId=' + $scope.sppwid +
                  '&isin='  + $scope.isin +
                  '&duration=' + configValues.duration +
                  '&width=' + configValues.width +
                  '&height=' + configValues.height +
                  '&interval=' +configValues.interval +
                  '&isSecure='+ configValues.isSecure +
                  '&applyVol=' + configValues.applyVol +
                  '&VOL=' + configValues.VOL +
                  '&scheme=' + configValues.scheme +
                  '&compareTo=' + configValues.compareTo +
                  '&priceDisplay=' + configValues.priceDisplay +
                  '&clearCache=' + configValues.clearCache +
                  '&currentTime=' + (+new Date());
           };
            if ($scope.securityinfo()){
                $scope.loadImage($scope.securityinfo());
            }


        }
    };
});
