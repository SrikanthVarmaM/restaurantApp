'use strict';


msaiqApp.directive('msaAutoSuggest', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/autosuggest/autoSuggestTemplate.html',
        replace: true,
        link: function (scope, attrs) {
            scope.sppwid = attrs.sppwid;
            scope.ticker = attrs.ticker;
            scope.source = attrs.source;
        },
        scope: {
            sppwid: '@', ticker: '@', source: '@'
        },

        controller: function ($scope, $log, $resource, $location, $window, $, $route, AutoSuggestService, ThomsonService, QuickViewService, EntitlementService) {
            $('#input01').typeahead([
                    {
                        name: 'twitter-oss',
                        limit: 11,
                        remote: {
                            url: '/es/ac/power_search/_search?pretty=true&q=ticker',
                            replace: function (url, uriEncodedQuery) {
                                return AutoSuggestService.getSearchList(url, uriEncodedQuery);
                            },
                            rateLimitWait: 50,

                            filter: function (parsedResponse) {
                                return AutoSuggestService.parseResponse(parsedResponse, true);
                            }
                        },

                        template: [
                            '{{^link}}' +
                                '<table style="font-size: 11px; width: 100%">' +
                                '<tr>' +
                                '<td style="width: 20%;">{{{displayTicker}}}{{#exchange}}:{{exchange}}{{/exchange}}</td>' +
                                '<td style="width: 60%;" >{{{displayName}}}</td>' +
                                '<td style="white-space: nowrap">{{security_type}}&nbsp;{{#report_ind}}({{report_ind}}){{/report_ind}}</td>' +

                                '</tr>' +
                                '</table>' +
                                '{{/link}}' +
                                '{{#link}}' +
                                '<table style="font-size: 11px; width: 100%;" class=".tt-js-header">' +
                                '<tr>' +
                                '<td style="width: 80%;padding: 2px;;">{{title}}</td>' +
                                '<td style="white-space: nowrap">{{report_ind}}{{{link}}}</td>' +
                                '</tr>' +
                                '</table>' +
                                '{{/link}}'
                        ].join(''),
                        engine: Hogan
                    }

                ]).on('typeahead:selected', function (e, selectedDatum) {

                    // grab the first matching at index[0]
                    var values = {ticker: (selectedDatum.ticker || ''), type: (selectedDatum.security_type || 'stock').toLowerCase(), sppwId: (selectedDatum.sppw_id || ''), report_ind: (selectedDatum.report_ind || 'undefined')};
                    if (values.ticker != "") {
                        if (EntitlementService.apCon.snapshotEnabledOnly) {
                            $scope.openQV(values);
                        } else {
                            $scope.openDetailsPage(values);
                        }
                    }
                });

            $scope.openDetailsPage = function (values) {
                // may do broadcast instead of url route
                $log.debug('ticker: ' + values.ticker);
                if (((values.type).toLowerCase()) === 'stock') {
                    var tempVar = 'stocks';
                } else {
                    var tempVar = values.type;
                }


                // send it back to Thomson this ticker change
                ThomsonService.setContext(values.ticker);
                if (typeof(values.ticker) === 'string') {
                    values.ticker = values.ticker.replace('/', '*') //encoding escape character as $routeprovider will not work with '/' for tickers suchs as rr/ll
                    var index = values.ticker.indexOf(":");
                    if (index !== -1) {
                        values.ticker = values.ticker.substr(0, index);

                    }
                }
                var rpt_ind = (values.report_ind && (values.type === 'stock' || values.type === 'Stock') ) ? '/' + values.report_ind : '';

                if (tempVar === 'stocks' || tempVar === 'stock') {
                    var path = '/' + (tempVar || 'stocks').toLowerCase() + '/details/' + values.sppwId + '/' + values.ticker + rpt_ind + '/powerSearch';
                } else {
                    var path = '/' + (tempVar || 'stocks').toLowerCase() + '/details/' + values.sppwId + '/' + values.ticker + rpt_ind;
                }

                var url = '#' + path;
                // location ref to go to new thing
                $log.debug('type head select url ' + url);

                $location.path(path);
                window.location.href = url;
                $route.reload();
            };

            $scope.openQV = function (values) {
                // may do broadcast instead of url route
                $log.debug('ticker: ' + values.ticker);

                // send it back to Thomson this ticker change
                ThomsonService.setContext(values.ticker);

                // location ref to go to new thing
                $log.debug('autosuggest to open qv');
                QuickViewService.openQV(values);

            };

            /* for the search button */
            $scope.doAutoSuggest = function () {

                // get the ticker value
                var ticker = ($('#input01').val() || '');

                // call auto suggest to get the latest ticker matching
                var url = AutoSuggestService.getSearchList('/es/ac/power_search/_search?pretty=true&q=ticker', ticker);
                $resource(url).get().$promise.then(function (data) {
                    var tickerList = AutoSuggestService.parseResponse(data, true);
                    $log.debug('ThomsonService: best matching type for this symbol is ' + tickerList);

                    // grab the first matching at index[0]

                    var values;
                    if (ticker && tickerList[0].ticker === ticker.toUpperCase() ){
                        values = {ticker: ticker, type: (tickerList[0].security_type || 'stock'), sppwId: (tickerList[0].sppw_id || ''), report_ind: (tickerList[0].report_ind || 'none')};

                    } else {
                        values = {ticker: ticker, type: (tickerList[0].security_type || 'stock'), sppwId: ( ''), report_ind: (tickerList[0].report_ind || 'none')};


                    }
                    if (values.ticker != "") {
                        if (EntitlementService.apCon.snapshotEnabledOnly) {
                            $scope.openQV(values);
                        } else {
                            $scope.openDetailsPage(values);
                        }
                    }
                });
            };
        }
    };

});