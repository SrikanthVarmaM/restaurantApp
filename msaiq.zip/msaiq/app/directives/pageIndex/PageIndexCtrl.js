'use strict';


msaiqApp.directive('msaPageIndex', function () {
    return{
//        restrict: 'E',
        transclude: true,
        templateUrl: 'directives/pageIndex/pageIndexTemplate.html',
        replace: true,
        /*     link: function (scope, attrs) {
         scope.sppwid = attrs.sppwid;
         scope.ticker = attrs.ticker;
         scope.source = attrs.source;
         },
         scope: {
         sppwid: '@', ticker: '@', source: '@'
         },              */

        controller: function ($scope, $log, $resource, $location, $window, $, articleResourceFactory, Hogan,EntitlementService) {
            $scope.ent = EntitlementService;
            $scope.pageIndexTemp = articleResourceFactory.pageIndexResourceTest.get();
            $scope.pageIndexReformated = [];

            var valid;
            $scope.getNestedKey = function (obj, path) {
                var current = obj;
                path.split('.').forEach(function (p) {
                    current = current[p];
                });
                return current;
            };
            EntitlementService.deferred.promise.then(function(result){



            $scope.pageIndexTemp.$promise.then(function(){

                for (var i = 0; i < $scope.pageIndexTemp.hits.hits.length; i++) {
                    var temp =  $scope.pageIndexTemp.hits.hits[i]._source;
                    temp.value = $scope.pageIndexTemp.hits.hits[i]._source.pagenum;
                    var patt1=/\s/g;
                    temp.tokens = $scope.pageIndexTemp.hits.hits[i]._source.title.split(patt1);

                    temp.tokens.push($scope.pageIndexTemp.hits.hits[i]._source.pagenum);

//     $log.info(temp.tokens);




                    valid = $scope.getNestedKey(EntitlementService.apCon, $scope.pageIndexTemp.hits.hits[i]._source.entitlement);

                    if (valid ){
                        $scope.pageIndexReformated.push(temp);
                    }
                }

                $('#pageIndexSearch').typeahead({
                    name: 'pageIndexSearch',
                    limit: 10,

                    local:
                        $scope.pageIndexReformated ,
                    template: '<p><div  ent-checked-div key="{{entitlement}}" ><span style="float : left; width: 30px; padding-bottom: 1px;">{{pagenum}}</span><span style="text-transform: uppercase;"> {{title}} </span></div></p>',
                    engine: Hogan
                }).on('typeahead:selected', function (e, selectedDatum) {

                        $log.info(selectedDatum);
                        var url = '#/'+(selectedDatum.link);
                        $log.info('type head select url ' + url);
                        $window.location.href = url;
                        $('#pageIndexSearch').typeahead('setQuery', '');

                    });
            });
            });
        }
    };
});


