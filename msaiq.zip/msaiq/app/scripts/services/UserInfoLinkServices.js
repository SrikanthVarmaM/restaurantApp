msaiqApp.factory('UserInfoLinkServices', function (_, $rootScope, msaMessageController, createDialog) {
    var self = this;
    self.returnObj = {};

    self.returnObj.openUserSettingsWindow = function () {
        createDialog('site/userInfoLinks/settings/userSettingsWindowTemplate.html', {
                id: 'userSettingsWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title"><span class="glyphicon glyphicon-cog"></span>&nbsp;{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                controller: 'UserSettingsCtrl',
                bodyCSSClass :'remove-padding-bottom',
                modalClass : 'modal padding-top60' ,
                footerTemplate: '<div></div> '
            }
        );
    };

    self.returnObj.openForgetPasswordWindow = function () {
        createDialog('site/userInfoLinks/forgetPassword/forgetPasswordWindowTemplate.html', {
                id: 'userSettingsWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                controller: 'ForgetPasswordCtrl',
                bodyCSSClass :'remove-padding-bottom',
                modalClass : 'modal padding-top60' ,
                footerTemplate: '<div></div> '
            }
        );
    };

    self.returnObj.openErrorMailConfirmWindow = function (data) {
        createDialog('site/msaErrorPage/errorMailConfirmTmpl.html', {
                id: 'msaErrorConfirmModal',
                title: 'Log Sent',
                headerTemplate: '<div></div>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                controller: 'ErrorMailConfirmCtrl',
                bodyCSSClass :'remove-padding-bottom',
                footerCSSClass:'display-none',
                modalClass : 'modal alert-modal-z' ,
                backdropClass : 'modal-backdrop'

            },
            data
        );
    };

    self.returnObj.openUserAuthenticateWindow = function () {
        createDialog('site/userInfoLinks/authenticateWindow/userAuthenticateWindowTemplate.html', {
                id: 'userSettingsWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                controller: 'UserAuthenticateWindowCtrl',
                bodyCSSClass :'remove-padding-bottom',
                modalClass : 'modal padding-top60' ,
                footerTemplate: '<div></div> '
            }
        );
    };

    self.returnObj.openLinkExternalAccountConfirmWindow = function(data) {
        createDialog('site/userInfoLinks/admin/linkExternalAccounts/linkExternalAccConfirmTmpl.html', {
                id: 'userConfirmWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;&nbsp;{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background',
                success: {label: 'Yes', fn: function() {
                    if (data.action === 'Link') {
                        data.source.handleLinkButton();
                    } else if (data.action === 'Unlink') {
                        data.source.handleUnlinkButton();
                    } else if(data.action === 'deleteUser'){
                        data.source.handleMainUpdateButton();
                    }
                }},
                cancel: {label: 'No'},
                backdrop: true,
                controller: 'LinkExternalAccConfirmCtrl',
                bodyCSSClass :'remove-padding-bottom',
                modalClass : 'modal padding-top60' ,
                footerCSSClass:'padding-right-5'
            },
            data
        );
    };

    self.returnObj.openClientUserAdminSeamlessEditWindow = function (data) {
        createDialog('site/userInfoLinks/admin/clientUserAdmin/editSeamlessUserTmpl.html', {
                id: 'userSettingsWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title"><span class="glyphicon glyphicon-cog"></span>&nbsp;{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background edit-seamless-user-modal-header',
                backdrop: true,
                controller: 'EditSeamlessUserCtrl',
                bodyCSSClass :'remove-padding-bottom edit-seamless-user-modal-body',
                modalClass : 'modal padding-top60' ,
                footerTemplate: '<div></div> '
            },data
        );
    };

    return self.returnObj;
});