msaiqApp.factory('AlertDataService', function (_, $rootScope, userResourceResourceFactory, msaMessageController,articleResourceFactory) {

    var quickAlertMenuMap = {
        stocksWatchList: [
            {name: 'STARS_RANK', alertNameDesc: 'S&P STARS Ranking Change' ,checked: false},
            {name: 'STOCKS_IN_NEWS', alertNameDesc: 'S&P Stocks in the News',checked: false},
            {name: 'SECURITIES_IN_MARKET_MOVERS', alertNameDesc: 'MarketMovers',checked: false},
            {name: 'SECURITIES_IN_RESEARCH_NOTES', alertNameDesc: 'Research Notes',checked: false},
            {name: 'SECURITIES_IN_BROKER_VIEWSNEWS', alertNameDesc: 'Broker Views & News',checked: false},
            {name: 'SECURITIES_IN_TRENDS', alertNameDesc: 'S&P Trends & Ideas',checked: false}  ,
            {name: 'HIGH_52WEEKS', alertNameDesc: 'Reaches New 52-Week High', criteria1: 'HIGH_52WEEKS',checked: false},
            {name: 'MOVING_AVG', alertNameDesc: 'Crosses 15-day Moving Average', criteria1: '15',checked: false} ,
            {name: 'TRADE_VOLUME', alertNameDesc: 'Volume Exceeds Average by 50%', criteria1: '50',checked: false}
        ],
        fund: [
            {name: 'HIGH_52WEEKS', alertNameDesc: 'Reaches New 52-Week High', criteria1: 'HIGH_52WEEKS',checked: false},
            {name: 'MOVING_AVG', alertNameDesc: 'Crosses 15-day Moving Average', criteria1: '15',checked: false} ,
            {name: 'TRADE_VOLUME', alertNameDesc: 'Volume Exceeds Average by 50%', criteria1: '50',checked: false},
            {name: 'FMR_CHANGED_RATING', alertNameDesc: 'Fund Changed Gradings', criteria1: 'FMR_CHANGED_RATING',checked: false}
        ],
        etf: [
            {name: 'HIGH_52WEEKS', alertNameDesc: 'Reaches New 52-Week High', criteria1: 'HIGH_52WEEKS',checked: false},
            {name: 'MOVING_AVG', alertNameDesc: 'Crosses 15-day Moving Average', criteria1: '15',checked: false} ,
            {name: 'TRADE_VOLUME', alertNameDesc: 'Volume Exceeds Average by 50%', criteria1: '50',checked: false}
        ]
    }

    var alertTypeLabelMap = {
        STARS_RANK: "Stars", STOCKS_IN_NEWS: "News",
        SECURITIES_IN_MARKET_MOVERS: "News",
        SECURITIES_IN_RESEARCH_NOTES: "News",
        SECURITIES_IN_BROKER_VIEWSNEWS: "News",
        SECURITIES_IN_TRENDS: "Trends & Ideas",
        PRICE_TARGET: "Price",
        TARGET_PRICE_12M: "Price",
        AVG_EST: "Average",
        PRICE_CHANGE: "Price",
        PRICE_INDEX_CHANGE: "Price",
        TRADE_VOLUME: "Volume",
        HIGH_52WEEKS: "Price",
        LOW_52WEEKS: "Price",
        HIGH_LOW_52WEEKS: "Price",
        MOVING_AVG: "Average",
        PORTFOLIO_SEC_ADD: "Change",
        PORTFOLIO_SEC_DELETE: "Change",
        FMR_CHANGED_RATING: "Fund Changed Gradings"
    };
    var getPortfolioName=function(){
        if (_.isEmpty(alertData.alerts || _.isEmpty(portfolioData))){
            return ;
        }

        for (var i=0;i <alertData.alerts.length;i++)  {
            if(alertData.alerts[i]) {
                alertData.alerts[i].checkBoxSelected=false;
            }
            if (alertData.alerts[i] && alertData.alerts[i].instrumentType === "SPPORTFOLIO"){

               var alert=alertData.alerts[i];
                    if(!alert){ return;}
                        var matchedPortfolio= _.find(portfolioData,function(item){
                            return item.portfolioId ===  alert.instrumentId;
                        });
                        if (matchedPortfolio) {
                            alert.instrumentLongName= matchedPortfolio.portfolioName;
                        }

            }
        }
    } ;
    var requestParamGet = {operationCode: 'GET_ALL'};
    var alertData = userResourceResourceFactory.alertResource.postReq(requestParamGet, function (data) {
        alertData = data;
        getPortfolioName();
    });
    var portfolioData = articleResourceFactory.portfolioConfigResource.get(function(portfoliosResource){
        portfolioData= portfoliosResource.portfolioConfig;
        getPortfolioName();
    });
    var refreshAlertData = function () {
        alertData = userResourceResourceFactory.alertResource.postReq(requestParamGet, function (data) {
            alertData = data;
            getPortfolioName();
        });

    };
   var  stringifyPostParam = function (param, key, val) {
        if (val === null || typeof(val) === 'undefined') {
            return param + "&" + key + "=";
        } else {
            return param + "&" + key + "=" + val;
        }

    };



    return {
        getQuickAlertArrayBySecurityType: function(securityType){
            if (securityType === "STOCK" || securityType === "WATCHLIST" ) {
               return quickAlertMenuMap.stocksWatchList;
            }  else if (securityType === "GQF" || securityType ==="FMR"){
                return quickAlertMenuMap.fund;
            } else {
                return  quickAlertMenuMap.etf;
            }
        } ,
        alertData: alertData,
        getAlertCount: function () {
            return _.isEmpty(alertData.alerts) ? 0 : alertData.alerts.length;
        },
        getEmail :function(){
            if (alertData && alertData.email)  {
                return   alertData.email;
            }
            $scope.loginData = userResourceResourceFactory.loginResource.getArrayReq({},function(response){
                var email  = (response.resourceList  === null )?null: response.resourceList.EMAIL;
               return email;
            });
        } ,
        getExistingAlertForThisInstrument :function(instrumentId){
            //find out alert object  for this particular instrument
            var existingAlerts=[];
            var alertTempArr= _.filter(alertData.alerts, function (alert) {
                return (alert.instrumentId == instrumentId)  ;
            }) ;
            existingAlerts= _.flatten(alertTempArr,'alertItems')
               /* for (var i=0;i<alertTempArr.length;i++) {
                existingAlerts.concat(alertTempArr[i].alertItems)

            }  */
            return     existingAlerts;
        },
        deleteAlert: function (alert) {
            if (_.isEmpty(alert)) {
                return;
            }

            var param = "";
            param += 'operationCode=DELETE&';
            param += 'id.id=' + alert.alertId;

          //  var deleted = _.remove(alertData.alerts, function(item) { return item.alertId === alert.alertId; });
            var idx = _.findIndex(alertData.alerts, function(item) {
                return item.alertId === alert.alertId;
            });
            if (idx === -1) {

                return;
            }


            alertData.alerts.splice(idx, 1);



            userResourceResourceFactory.alertResource.postReq(param, function (data) {
                if ($rootScope.checkHumaneMargins()) {
                    humane.log("Alert Deleted", {addnCls: 'humaneResize'});
                } else {
                    humane.log("Alert Deleted");
                }
               // refreshAlertData();
            });


        },
        getSymbolAlertCount :function(){
          if (_.isEmpty(alertData.alerts)){
              return 0;
          }
            var alertCount=0;
            for (var i=0;i <alertData.alerts.length;i++)  {
                if (alertData.alerts[i] && alertData.alerts[i].instrumentType === "INDIVIDUAL"){
                    alertCount+=1;
                }
            }
            return alertCount;
        } ,
        getPortfolioAlertCount :function(){
            if (_.isEmpty(alertData.alerts)){
                return 0;
            }
            var alertCount=0;
            for (var i=0;i <alertData.alerts.length;i++)  {
                if (alertData.alerts[i] && alertData.alerts[i].instrumentType === "SPPORTFOLIO"){
                    alertCount+=1;
                }
            }
            return alertCount;
        } ,
        saveThisAlert  : function(actionType,alertItems,email,selectedInstrument,jointType,qvScope){
            if (!actionType) {
                return;
            }
            if (_.isEmpty(jointType)) {
                jointType='ANY' ;
            }
            var   alertRequestParam=  'operationCode='+actionType;
            var j = 0;
            for (var i = 0; i < alertItems.length; i+=1) {
                if (alertItems[i].checked) {

                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].name', alertItems[i].name);
                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].criteria1', alertItems[i].criteria1);
                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].criteria2',alertItems[i].criteria2);
                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].criteria3', alertItems[i].criteria3);
                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].criteria4', alertItems[i].criteria4);
                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].criteria5', alertItems[i].criteria5);

                    alertRequestParam = stringifyPostParam(alertRequestParam, 'alertItems[' + j + '].jointType', jointType);
                    j+=1;
                }
            }
            alertRequestParam = stringifyPostParam(alertRequestParam, 'email', email);
            alertRequestParam =stringifyPostParam(alertRequestParam, 'instrumentInfos[0].instrumentId', selectedInstrument.instrumentId);
            alertRequestParam = stringifyPostParam(alertRequestParam, 'instrumentInfos[0].instrumentName', selectedInstrument.instrumentName);
            alertRequestParam = stringifyPostParam(alertRequestParam, 'instrumentInfos[0].instrumentLongName',selectedInstrument.instrumentLongName);
            alertRequestParam = stringifyPostParam(alertRequestParam, 'instrumentInfos[0].instrumentType', selectedInstrument.instrumentType);
            if (selectedInstrument.alertId) {
                alertRequestParam = stringifyPostParam(alertRequestParam, 'id.id', selectedInstrument.alertId);

            }
            userResourceResourceFactory.alertResource.postReq(alertRequestParam, function (data) {
               if (actionType === "UPDATE"){
                   if (typeof(data.recentlyUpdatedAlerts[0]) === "undefined")  {
                       if ($rootScope.checkHumaneMargins()) {
                            humane.log(data.errorMessage, {addnCls: 'humaneResize'}) ;
                       } else {
                           humane.log(data.errorMessage) ;
                       }
                       return;
                   }
                   var index = _.findIndex(alertData.alerts, function(item) {
                       return item.alertId === data.recentlyUpdatedAlerts[0].alertId;
                   });
                   alertData.alerts.splice(index,1) ;
                   alertData.alerts.unshift(data.recentlyUpdatedAlerts[0]) ;
                   getPortfolioName();
                   alertData.email=email;
                   if ($rootScope.checkHumaneMargins()) {
                        humane.log("Alert Updated", {addnCls: 'humaneResize'});
                   } else {
                       humane.log("Alert Updated");
                   }
               } else {

                   if (typeof(data.recentlyCreatedAlerts[0]) === "undefined")  {
                       if ($rootScope.checkHumaneMargins()) {
                            humane.log(data.errorMessage, {addnCls: 'humaneResize'}) ;
                       } else {
                           humane.log(data.errorMessage) ;
                       }
                    return;

                   }else {
                       if ($rootScope.checkHumaneMargins()) {
                            humane.log("Alert Created", {addnCls: 'humaneResize'});
                       } else {
                           humane.log("Alert Created");
                       }
                       alertData.alerts.unshift(data.recentlyCreatedAlerts[0]) ;
                       getPortfolioName();
                       alertData.email=email;
                   }
               }
               //
            });


        }   ,
        getAlertDescriptionMapping: function (alert,retType) {
            var alertNamesArr=_.pluck(alert.alertItems, 'name');
            var retString=''   ;
               for (var i =0;i<alertNamesArr.length;i++)  {
                   var key= alertNamesArr[i];
                   if (!_.isEmpty(key)){
                       var val = alertTypeLabelMap[key ];
                       retString+=_.isEmpty(val)?'':val;
                   }
                   if(retType === 'SHORT' ){
                       retString= _.isEmpty(retString)?'-':retString;
                       return (alert.alertItems.length > 1 && retString !='Change' && retString !=='-')?retString+",..." :retString;

                   }
                  retString+= _.isEmpty(val)?'':',' ;

               }
            retString= _.isEmpty(retString)?'-':retString.substring(0, retString.length - 1);
            return retString;
        }
    }


});
