msaiqApp.factory('WatchlistDataService', function (_, $rootScope, msaMessageController, articleResourceFactory, userResourceResourceFactory, createDialog) {
    var self = this;//for easy reference from within functions this is a good practice suggested in various blogs
    self.returnObj = {};
    self.returnObj.dataChanged =false;;
    var requestParamGet = {operationCode: 'READ'};

    self.returnObj.watchlistData = userResourceResourceFactory.watchlistResource.postReq(requestParamGet, function (data) {
        self.returnObj.dataChanged=true;
    });

    self.returnObj.watchlistCrudOperations = function (formData) {
        return articleResourceFactory.assetWatchlistCrudResource.postReq(formData, function (data) {
            self.returnObj.watchlistData = data;
        });
    };

    self.returnObj.deleteWatchlist = function (formData) {
        return userResourceResourceFactory.watchlistResource.postReq(formData, function (data) {
            self.returnObj.watchlistData = data;
        });
    };

    self.returnObj.isWatchlistExists = function(title){
        var status = '';
        if(!_.isEmpty(title)){
            self.returnObj.watchlistData.watchLists.forEach(function(watchlist){
                if(title.toLowerCase() === watchlist.name.toLowerCase()){ status = 'exists'; }
            });
        }
        return status;
    };

    self.returnObj.isWatchlistItemExists = function(watchlistId, sppwid){
        var status = '';
        self.returnObj.watchlistData.watchLists.forEach(function(watchlist){
            if(watchlistId === watchlist.id){
                watchlist.items.forEach(function(watchlistItems){
                    if(watchlistItems.sppwId == sppwid){ status = 'exists'; }
                });
            }
        });
        return status;
    };

    self.returnObj.openWatchlistConfirmWindow = function (data) {
        createDialog('site/watchlist/watchlistConfirmTemplate.html', {
                id: 'confirmYesNoModal',
                title: '',
                headerTemplate: '<div></div>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                success: {label: 'Yes', fn: function() {
                    if (data.action === 'delete') { data.source.deleteWatchlist(); }
                    else if(data.action === 'deleteWItem') { data.source.deleteWatchlistItems(data.watchlistId, data.watchlistItemId); }
                    else if(data.action === 'deleteImportWItem') { data.source.deleteWatchlistItems(data.watchlistId, data.watchlistItemId); }
                }},
                cancel: {label: 'No'},
                controller: 'WatchlistConfirmCtrl',
                bodyCSSClass :'remove-padding-bottom',
                footerCSSClass:'padding-right-5',
                modalClass : 'modal alert-modal-z' ,
                backdropClass :  'modal-backdrop  alert-modal-backdrop-z'
            },
            data
        );
    };

    self.returnObj.openCreateWatchlistWindow = function () {
        createDialog('site/watchlist/createWatchlistWindowTemplate.html', {
                id: 'createWatchlistWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title">{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                controller: 'CreateWatchlistWindowCtrl',
                bodyCSSClass :'remove-padding-bottom',
                modalClass : 'modal alert-modal-z' ,
                footerTemplate: '<div></div> '
            }
        );
    };

    self.returnObj.openImportWatchlistWindow = function () {
        createDialog('site/watchlist/importWatchlistWindowTemplate.html', {
                id: 'importWatchlistWindow',
                title: '',
                headerTemplate: '<h4 class="modal-title">{{headerText}}</h4>',
                headerCSSClass: 'sp-aurora-dark-background',
                backdrop: true,
                controller: 'ImportWatchlistWindowCtrl',
                bodyCSSClass :'remove-padding-bottom',
                modalClass : 'modal' ,
                footerTemplate: '<div></div> '
            }
        );
    };

    return self.returnObj;

});