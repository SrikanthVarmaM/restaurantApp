'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider
        .when('/bonds/bondScreener', {
            templateUrl: 'site/bonds/bondScreener/bondScreener.html',
            controller: 'BondScreenerCtrl'
        })
        .when('/bonds/bondsLanding', {
            templateUrl: 'site/bonds/landing/bondsLanding.html',
            controller: 'BondsLandingCtrl'
        })
        .when('/bonds/bondDetails/:cusip', {
            templateUrl: 'site/bonds/bondDetails/bondDetails.html',
            controller: 'BondDetailsCtrl'
        })
        .when('/bonds/bondDetails/muni/:cusip/:active', {
            templateUrl: 'site/bonds/bondDetails/municipalBonds/muniBondsDetailView.html',
            controller: 'MuniBondsDetailViewCtrl'
        })
        .when('/bonds/bondDetails/corp/:cusip/:active', {
            templateUrl: 'site/bonds/bondDetails/corporateBonds/corpBondsDetailView.html',
            controller: 'CorpBondsDetailViewCtrl'
    })
        .when('/bonds/qv/:cusip/:mode/:partner', {
            template : ' ',
            controller: function(QuickViewService,$routeParams,bondsResourceFactory){

                var checkBondType = bondsResourceFactory.getBondTypeResource.get({cusip:$routeParams.cusip});
                checkBondType.$promise.then(function(response){
                    if (response.type === "CORP")  {
                        QuickViewService.openCorpBondsQV({cusip:$routeParams.cusip,mode:$routeParams.mode,partner:$routeParams.partner,active:response.active|| ''});
                    } else if (response.type === "MUNI") {
                        QuickViewService.openMuniBondsQV({cusip:$routeParams.cusip,mode:$routeParams.mode,partner:$routeParams.partner,active:response.active || ''});
                    } else {   //show no snapshot found
                        QuickViewService.openMuniBondsQV({cusip:'',mode:$routeParams.mode,partner:$routeParams.partner,active:null});

                    }
                },function(error){
                    QuickViewService.openMuniBondsQV({cusip:'',mode:$routeParams.mode,partner:$routeParams.partner,active:null});
                });

            }
        });
});