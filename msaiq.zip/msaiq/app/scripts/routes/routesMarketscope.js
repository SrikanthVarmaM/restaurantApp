'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider

        .when('/home', {
            templateUrl: 'site/home/home_page.html',
            controller: 'HomePageCtrl'
        })
        
        .when('/marketscope/brokerViews', {
            templateUrl: 'site/marketscope/brokerviews/brokerviews.html'
        })

        .when('/marketscope/brokerViewsDetails/articleList', {
            templateUrl: 'site/marketscope/brokerviews/brokerviews.html'
        })

        .when('/marketscope/brokerViewsDetails/:articleCode/:articleId', {
            templateUrl: 'site/marketscope/brokerviews/brokerViewsDetails.html',
            controller: 'BrokerViewsDetailsCtrl'
        })

        .when('/marketscope/marketMovers', {
            templateUrl: 'site/marketscope/marketmovers/marketMovers.html'
        })

        .when('/marketscope/marketMoversDetails/articleList', {
            templateUrl: 'site/marketscope/marketmovers/marketMovers.html'
        })

        .when('/marketscope/marketMoversDetails/:articleCode/:articleId', {
            templateUrl: 'site/marketscope/marketmovers/marketMoversDetails.html',
            controller: 'MarketMoversDetailsCtrl'
        })

        .when('/marketscope/researchNotesDetails/articleList', {
            templateUrl: 'site/marketscope/researchNotes/researchNotes.html'
        })

        .when('/marketscope/researchNotes', {
            templateUrl: 'site/marketscope/researchNotes/researchNotes.html'
        })

        .when('/marketscope/researchNotesDetails/:articleCode/:articleId', {
            templateUrl: 'site/marketscope/researchNotes/researchNotesDetails.html',
            controller: 'ResearchNotesDetailsCtrl'
        })
        .when('/marketscope/marketIntelligence', {
            templateUrl: 'site/marketscope/marketIntelligence/marketIntelligence.html',
            controller: 'MarketIntelligenceCtrl'
        })
        .when('/marketscope/marketIntelligenceDetail/:articleCode/:articleId', {
            templateUrl: 'site/marketscope/marketIntelligence/marketIntelligenceDetail.html',
            controller: 'MarketIntelligenceDetailCtrl'
        })
        .when('/marketscope/marketIntelligence/all', {
            templateUrl: 'site/marketscope/marketIntelligence/marketIntelligenceAll.html',
            controller: 'MarketIntelligenceAllCtrl'
        })
        .when('/marketscope/techAnalysis', {
            templateUrl: 'site/marketscope/techAnalysis/techAnalysis.html'
        })
        .when('/marketscope/traderTactics', {
            templateUrl: 'site/marketscope/traderTactics/traderTactics.html'
        })

        .when('/marketscope/technicalTrends', {
            templateUrl: 'site/marketscope/techAnalysis/technicalTrends.html'
        })
        .when('/marketscope/pageindex', {
            templateUrl: 'site/marketscope/pageIndex/pageIndex.html'
        })
        .when('/marketscope/techPulse', {
            templateUrl: 'site/marketscope/techAnalysis/techPulse.html'
        })
        .when('/marketscope/economyWatch', {
            templateUrl: 'site/marketscope/economyWatch/economyWatch.html',
            controller: 'EconomyWatchCtrl'
        })
        .when('/marketscope/economyWatchAll', {
            templateUrl: 'site/marketscope/economyWatch/economyWatchAll.html',
            controller: 'EconomyWatchAllCtrl'
        })
        .when('/marketscope/economyWatchArticle/:articleCode/:articleId/:source', {
            templateUrl: 'site/marketscope/economyWatch/economyWatchArticleDetail.html',
            controller: 'EconomyWatchArticleDetailCtrl'
        })
        .when('/marketscope/focusStock/previousStockOfWeek', {
            templateUrl: 'site//marketscope/focusStock/previousStockOfWeek/previousStocksOfWeek.html',
            controller: 'PreviousStockOfWeekCtrl'
        })
        .when('/marketscope/focusStock/:articleId', {
            templateUrl: 'site/marketscope/focusStock/focusStock.html',
            controller: 'FocusStockCtrl'
        })
        /*for related headline*/
            .when('/marketscope/focusStockOfWeekDetails/:articleCode/:articleId', {
                templateUrl: 'site/marketscope/focusStock/focusStock.html',
                controller: 'FocusStockCtrl'
            })
            .when('/marketscope/focusETFOfMonthDetails/:articleCode/:articleId', {
                templateUrl: 'site/etf/focusOfTheMonth/focusOfTheMonth.html',
                controller: 'FocusOfTheMonthCtrl'
            })

        .when('/marketscope/focusFUNDOfMonthDetails/:articleCode/:articleId', {
            templateUrl: 'site/funds/focusOfTheMonth/focusFundOfTheMonth.html',
            controller: 'FocusFundOfTheMonthCtrl'
        })
        /*end*/
        .when('/marketscope/morningbriefing', {
            templateUrl: 'site/marketscope/morningbriefing/morningBriefing.html',
            controller: 'MorningBriefingCtrl'
        })

        .when('/articles/:articleCode/:ticker/:articleId', {
            templateUrl: 'site/articles/article_details.html',
            controller: 'ArticleDetailsCtrl'
        })

        .when('/marketscope/streetTalkDetails/articleList', {
            templateUrl: 'site/marketscope/streetTalk/streetTalkHome.html'
        })

        .when('/marketscope/streetTalk', {
            templateUrl: 'site/marketscope/streetTalk/streetTalkHome.html'
        })

        .when('/marketscope/streetTalkDetails/:articleCode/:articleId', {
            templateUrl: 'site/marketscope/streetTalk/streetTalkDetails.html',
            controller: 'StreetTalkDetailsCtrl'
        })
        .when('/marketscope/investmentStrategy/investmentStatArticleDetails/:author/:articleCode/:articleId', {
            templateUrl: 'site/marketscope/investmentStrategy/investmentStatArticleDetails.html'
        })

        .when('/marketscope/investmentStrategy/investmentStatFullArticleList', {
            templateUrl: 'site/marketscope/investmentStrategy/investmentStatFullArticleList.html'
        })
        .when('/marketscope/investmentStrategy/:activeTab', {
            templateUrl: 'site/marketscope/investmentStrategy/investmentStrategy.html'
        })
        .when('/marketscope/sectors', {
            templateUrl: 'site/marketscope/sectors/sectors.html'
        })
        .when('/marketscope/sectors/sectorDetails/:gicCd/:sectorName/:inudstryDesc/:sourceGicCd', {
            templateUrl: 'site/marketscope/sectors/sectorDetails.html'
        })
        .when('/marketscope/sectors/subSectorDetails/:gicCd/:sectorName', {
            templateUrl: 'site/marketscope/sectors/subSectorDetails.html'
        })
        .when('/marketscope/sectors/sectorSurveysFullList/:surveyType', {
            templateUrl: 'site/marketscope/sectors/sectorSurveysFullList.html'
        })
        .when('/marketscope/sectors/sectorArticleList', {
            templateUrl: 'site/marketscope/sectors/sectorArticleList.html'
        })
        .when('/marketscope/sectors/subSectorArticleDetails/:gicCd/:sectorName/:sectorDetail', {
            templateUrl: 'site/marketscope/sectors/subSectorArticleDetails.html'
        })
        .when('/marketscope/sectors/sectorsSTOVLArticleDetails/:articleId', {
            templateUrl: 'site/marketscope/sectors/sectorsSTOVLArticleDetails.html'
        })
        .when('/marketscope/sectors/sectorArticleDetails/:articleId', {
            templateUrl: 'site/marketscope/sectors/sectorArticleDetails.html'
        })
        .when('/marketscope/portfolios', {
            templateUrl: 'site/marketscope/portfolios/portfoliosHome.html',
            controller:'PortfoliosHomeCtrl'
        })
        .when('/marketscope/portfolios/portfoliosSubDetails/:portfolioCode/:subPortfolioTitle/:activeTab', {
            templateUrl: 'site/marketscope/portfolios/portfoliosSubDetails.html',
            controller:'PortfoliosSubDetailsCtrl'
        })
        .when('/marketscope/trendsAndIdeas/:activeTab', {
            templateUrl: 'site/marketscope/trendsAndIdeas/trendsAndIdeas.html',
            controller: 'TrendsAndIdeasCtrl'
        })
        .when('/marketscope/trendsAndIdeas/details/:articleId', {
            templateUrl: 'site/marketscope/trendsAndIdeas/trendsAndIdeasDetails.html',
            controller: 'TrendsAndIdeasDetailsCtrl'
        })
        .when('/marketscope/trendsAndIdeas/topics/:topic', {
            templateUrl: 'site/marketscope/trendsAndIdeas/trendsAndIdeasTopics.html',
            controller: 'TrendsAndIdeasTopicsCtrl'
        })
        .when('/marketscope/trendsAndIdeas/search', {
            templateUrl: 'site/marketscope/trendsAndIdeas/trendsAndIdeasSearch.html',
            controller: 'TrendsAndIdeasSearchCtrl'
        })
        .when('/marketscope/seeAllSharedClasses/:equityType/:sppwid/:ticker/:articleId', {
            templateUrl: 'site/funds/relatedSharedClasses/relatedShareClasses.html',
            controller:'RelatedShareClassesCtrl'
        })
        .when('/marketscope/indices', {
            templateUrl: 'site/marketscope/indices/indices.html',
            controller:'IndicesCtrl'
        })
        .when('/marketscope/indicesDetails/:sppwid', {
            templateUrl: 'site/marketscope/indices/indicesDetails.html',
            controller:'IndicesDetailsCtrl'
        })
        .when('/marketscope/analyzeportfolios/:ticker', {
            templateUrl: 'site/marketscope/portfolios/analyzePortfolios.html',
            controller: 'AnalyzePortfoliosCtrl'
        })
});