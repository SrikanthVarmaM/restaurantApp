'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider
        .when('/admin', {
            templateUrl: 'site/userInfoLinks/admin/adminHomePage.html',
            controller: 'AdminHomePageCtrl'
        })
        .when('/outlookAdmin', {
            templateUrl: 'site/userInfoLinks/outlookAdmin/outlookAdminHomePage.html',
            controller: 'OutlookAdminHomeCtrl'
        }).when('/admin/seamLessAdmin', {
            templateUrl: 'site/userInfoLinks/admin/seamLessAdmin/seamLessAdminPage.html',
            controller: 'SeamLessAdminCtrl'
        }).when('/admin/seamLessLinkGenerator', {
            templateUrl: 'site/userInfoLinks/admin/seamLessLinkGenerator/seamLessLinkGenerator.html',
            controller: 'SeamLessLinkGeneratorCtrl'
        }).when('/admin/appProperties', {
            templateUrl: 'site/userInfoLinks/admin/appProperties/appPropertiesPage.html',
            controller: 'AppPropertiesCtrl'
        }).when('/admin/monitoringAlerts', {
            templateUrl: 'site/userInfoLinks/admin/monitoringAlerts/monitoringAlertsPage.html',
            controller: 'MonitoringAlertsCtrl'
        }).when('/admin/clientUserAdmin/:activeTab', {
            templateUrl: 'site/userInfoLinks/admin/clientUserAdmin/clientUserAdminPage.html',
            controller: 'ClientUserAdminCtrl'
        }).when('/admin/linkExternalAccounts', {
            templateUrl: 'site/userInfoLinks/admin/linkExternalAccounts/linkExternalAccountsPage.html',
            controller: 'LinkExternalAccountsCtrl'
        }).when('/admin/pdfDisclosure', {
            templateUrl: 'site/userInfoLinks/admin/pdfDisclosure/pdfDisclosurePage.html',
            controller: 'PdfDisclosureCtrl'
        }).when('/admin/trialReporting', {
            templateUrl: 'site/userInfoLinks/admin/trialReporting/trialReportingPage.html',
            controller: 'TrialReportingCtrl'
        }).when('/clientAdmin/clientUserAdmin/:activeTab', {
            templateUrl: 'site/userInfoLinks/admin/clientUserAdmin/clientUserAdminPage.html',
            controller: 'ClientUserAdminCtrl'
        }).when('/clientAdmin/pdfDisclosure', {
            templateUrl: 'site/userInfoLinks/admin/pdfDisclosure/pdfDisclosurePage.html',
            controller: 'PdfDisclosureCtrl'
        }).when('/clientAdmin/customizeSetting', {
            templateUrl: 'site/userInfoLinks/clientAdmin/customizeSetting/customizeSettingPage.html',
            controller: 'CustomizeSettingCtrl'
        })
});