'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider
        .when('/stocks/stockScreener', {
            templateUrl: 'site/stocks/stockScreener/stockScreener.html',
            controller: 'StockScreenerCtrl'
        })
        .when('/stocks/starPerformance', {
            templateUrl: 'site/stocks/starsPerformance/starsPerformance.html',
            controller: 'StarsPerformanceCtrl'
        })
        .when('/stocks/techTrends', {
            templateUrl: 'site/stocks/techTrends/techTrends.html',
            controller: 'TechTrendsCtrl'

        })
        .when('/stocks/PutCallIndicator',{
            templateUrl: 'site/stocks/PutCallIndicator/PutCallIndicator.html',
            controller: 'PutCallIndicatorCtrl'
        })
        /*review-question: CZ,  operation1Value => starValue, more readable */
        .when('/stocks/starstocks/:operation1Value', {
            templateUrl: 'site/stocks/starstocks/starstocks.html',
            controller: 'StarStocksCtrl'
        })
        .when('/stocks/fairvalue/:operation1Value', {
            templateUrl: 'site/stocks/fairvalue/fairvalue.html',
            controller: 'FairValueCtrl'
        })

        .when('/stocks/starChanges', {
            templateUrl: 'site/stocks/starChanges/stocksStarsChanges.html',
            controller: 'stocksStarsChangeCtrl'
        })
        .when('/stocks/details/:sppwId/:ticker', {
            templateUrl: 'site/stocks/stockDetails/stockDetails.html',
            controller: 'StockDetailsCtrl'
        })
        .when('/stocks/details/:sppwId/:ticker/:report_ind', {
            templateUrl: 'site/stocks/stockDetails/stockDetails.html',
            controller: 'StockDetailsCtrl'
        })
        .when('/stocks/details/:sppwId/:ticker/:report_ind/:pageRequest', {
            templateUrl: 'site/stocks/stockDetails/stockDetails.html',
            controller: 'StockDetailsCtrl'
        })
        .when('/stocks/recentReports', {
            templateUrl: 'site/stocks/recentAddedReports/recentAddedReports.html',
            controller: 'recentAddedReportsCtrl'
        })
        .when('/stocks/watchlist/:id/:sppwIds', {
            templateUrl: 'site/stocks/watchlist/stocksWatchlistView.html',
            controller: 'StocksWatchlistViewCtrl'
        });
});