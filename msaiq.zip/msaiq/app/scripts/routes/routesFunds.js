'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider
       .when('/fund/details/:sppwId/:ticker', {
            templateUrl: 'site/funds/fundsDetails/fundsDetailView.html',
            controller: 'FundsDetailViewCtrl'
        }).when('/fund/fundTrendsAndIdeas', {
            templateUrl: 'site/funds/trendsAndIdeas/fundsTrendsAndIdeas.html',
            controller: 'FundsTrendsAndIdeasCtrl'
        })
        .when('/fund/stars/:operation1Value', {
            templateUrl: 'site/funds/preRolledSearch/starFunds/starFunds.html',
            controller: 'StarFundsCtrl'
        })
        .when('/fund/fundsLanding', {
            templateUrl: 'site/funds/landing/fundLanding.html',
            controller: 'FundLandingCtrl'
        })
        .when('/fund/previousFocusOfTheMonth', {
            templateUrl: 'site/funds/focusOfTheMonth/prevFocusFundOfTheMonth.html',
            controller: 'PrevFocusFundOfTheMonthCtrl'
        })
        .when('/fund/focusOfTheMonth', {
            templateUrl: 'site/funds/focusOfTheMonth/focusFundOfTheMonth.html',
            controller: 'FocusFundOfTheMonthCtrl'
        })
        .when('/fund/focusOfTheMonth/:articleId', {
            templateUrl: 'site/funds/focusOfTheMonth/focusFundOfTheMonth.html',
            controller: 'FocusFundOfTheMonthCtrl'
        })
        .when('/fund/fundScreener', {
            templateUrl: 'site/funds/fundScreener/fundScreener.html',
            controller: 'FundScreenerCtrl'
        })
        .when('/fund/watchlist/:id/:sppwIds', {
            templateUrl: 'site/funds/watchlist/fundWatchlistView.html',
            controller: 'FundWatchlistViewCtrl'
        });
});