'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider
        .when('/options/optionsLanding', {
            templateUrl: 'site/options/landing/optionsLandingTemplate.html',
            controller: 'OptionsLandingCtrl'
        })
        .when('/options/optionsLanding/:iFrame', {
            templateUrl: 'site/options/landing/optionsLandingTemplate.html',
            controller: 'OptionsLandingCtrl'
        });
});