'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider

        .when('/etf/etfLanding', {
            templateUrl: 'site/etf/landing/etfLanding.html',
            controller: 'EtfLandingCtrl'
        })
        .when('/etf/focusOfTheMonth', {
            templateUrl: 'site/etf/focusOfTheMonth/focusOfTheMonth.html',
            controller: 'FocusOfTheMonthCtrl'
        })
        .when('/etf/focusOfTheMonth/:articleId', {
            templateUrl: 'site/etf/focusOfTheMonth/focusOfTheMonth.html',
            controller: 'FocusOfTheMonthCtrl'
        })
        .when('/etf/previousFocusOfTheMonth', {
            templateUrl: 'site/etf/focusOfTheMonth/previousFocusOfTheMonth.html',
            controller: 'PreviousFocusOfTheMonthCtrl'
        })
        .when('/etf/portfolios', {
            templateUrl: 'site/etf/portfolios/etfPortfolios.html',
            controller: 'EtfPortfoliosCtrl'
        })
        .when('/etf/portfolios/portfoliosSubDetails/:portfolioCode/:subPortfolioTitle/:activeTab', {//for etf portfolios just changing marketScope portfolios
            templateUrl: 'site/marketscope/portfolios/portfoliosSubDetails.html',
            controller:'PortfoliosSubDetailsCtrl'
        })
        .when('/etf/details/:sppwId/:ticker', {
            templateUrl: 'site/etf/etfDetails/etfDetails.html',
            controller: 'EtfDetailsCtrl'
        })
        .when('/etf/etfScreener', {
            templateUrl: 'site/etf/etfScreener/etfScreener.html',
            controller: 'EtfScreenerCtrl'
        })
        .when('/etf/ranking/:operation1Value', {
            templateUrl: 'site/etf/ranking/etfRanking.html',
            controller: 'etfRankingCtrl'
        })
        .when('/etf/watchlist/:id/:sppwIds', {
            templateUrl: 'site/etf/watchlist/etfWatchlistView.html',
            controller: 'EtfWatchlistViewCtrl'
        });

});