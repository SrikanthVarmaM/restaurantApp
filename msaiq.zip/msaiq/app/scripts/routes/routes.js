'use strict';

msaiqApp.config(function ($routeProvider) {
    $routeProvider

        .when('/home', {
            templateUrl: 'site/home/home_page.html',
            controller: 'HomePageCtrl'
        })
        .when('/home/marketCommentary/:articleCode/:articleId', {
            templateUrl: 'site/home/marketCommentary/marketCommentary.html',
            controller: 'MarketCommentaryCtrl'
        })
        .when('/articles/:articleCode/:ticker/:articleId', {
            templateUrl: 'site/articles/article_details.html',
            controller: 'ArticleDetailsCtrl'
        })
        .when('/marketscope/seeAllHeadlines/:equityType/:sppwid/:ticker/:articleId', {
            templateUrl: 'site/articles/seeAllHeadlines.html'
        })
        .when('/marketscope/seeAllHeadlines/:equityType/:sppwid/:ticker/:articleId/:source', {
            templateUrl: 'site/articles/seeAllHeadlines.html'
        })
        .when('/marketscope/toolsLanding/:activeTab', {
            templateUrl: 'site/tools/toolsLandingTemplate.html',
            controller: 'ToolsLandingTemplateCtrl'
        })
        .when('/msaErrorPage', {
            templateUrl: 'site/msaErrorPage/msaErrorPage.html',
            controller: 'MsaErrorPageCtrl'
        })
        .otherwise({
            template :' ',
            controller: function($location,EntitlementService){
                EntitlementService.deferred.promise.then(function(result){
                    $location.path(result.routeDefault);
                });

            }
        });
});