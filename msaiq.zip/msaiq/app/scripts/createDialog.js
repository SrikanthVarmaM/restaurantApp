'use strict';
/** services for this app **/

msaiqApp.factory('createDialog', ['$document', '$compile', '$rootScope', '$controller', '$timeout', '$','$window',
    function ($document, $compile, $rootScope, $controller, $timeout, $,$window) {
        var defaults = {
            id: null,
            template: null,
            templateUrl: null,
            title: 'Default Title',
            backdrop: true,
            success: {label: 'OK', fn: null},
            cancel: {label: 'Close', fn: null},
            controller: null, //just like route controller declaration
            backdropClass: 'modal-backdrop',
            footerTemplate: null,
            headerTemplate: null,
            modalClass: 'modal',
            headerCSSClass: null,
            closeBrowser:false,
            bodyCSSClass: null,
            css: {
            }
        };
        var body = $document.find('body');

        return function Dialog(templateUrl/*optional*/, options, passedInLocals) {

            // Handle arguments if optional template isn't provided.
            if (angular.isObject(templateUrl)) {
                passedInLocals = options;
                options = templateUrl;
            } else {
                options.templateUrl = templateUrl;
            }

            options = angular.extend({}, defaults, options); //options defined in constructor

            var key;
            var idAttr = options.id ? ' id="' + options.id + '" ' : '';

            var header = options.headerTemplate || "";
            var headerCSSClass = options.headerCSSClass || "";
            var bodyCSSClass = options.bodyCSSClass || "";
            var footerCSSClass = options.footerCSSClass || "";
            var closeCSSClass = options.closeCSSClass || "";

            var defaultFooter = '<button type="button" class="btn btn-xs" data-dismiss="modal" ng-click="handleClose();">{{$modalCancelLabel}}</button>' +
                '<button type="button" class="btn btn-primary btn-xs" ng-click="$modalSuccess()">{{$modalSuccessLabel}}</button>';

            var footerTemplate = '<div class="modal-footer ' + footerCSSClass + '">' +
                (options.footerTemplate || defaultFooter) +
                '</div>';
            var modalBody = (function () {
                if (options.template) {
                    if (angular.isString(options.template)) {
                        // Simple string template
                        return '<div class="modal-body ' + bodyCSSClass + '">' + options.template + '</div>';
                    } else {
                        // jQuery/JQlite wrapped object
                        return '<div class="modal-body ' + bodyCSSClass + '">' + options.template.html() + '</div>';
                    }
                } else {
                    // Template url
                    return '<div class="modal-body ' + bodyCSSClass + '" ng-include="\'' + options.templateUrl + '\'"></div>';
                }
            })();
            //We don't have the scope we're gonna use yet, so just get a compile function for modal
            var modalEl = angular.element(
                '<div class="' + options.modalClass + ' "' + idAttr + 'tabindex="-1" role="dialog" style="display: block;">' +
                    '  <div class="modal-dialog">' +
                    '    <div class="modal-content">' +
                    '      <div class="' + headerCSSClass + ' modal-header">' + header +
                    '        <button type="button" class="close ' + closeCSSClass + '" data-dismiss="modal" aria-hidden="true" ng-click="handleClose()"><span class="close_text">CLOSE </span>&times;</button>' +
                    '        <h4 class="modal-title">{{$title}}</h4>' +
                    '        <div id="{{$headerImage}}"></div>' +
                    '      </div>' +
                    modalBody +
                    footerTemplate +
                    '    </div>' +
                    '  </div>' +
                    '</div>');

            for (key in options.css) {
                modalEl.css(key, options.css[key]);
            }

            //  var backdropEl = angular.element('<div ng-click="$modalCancel()">');
            var backdropEl = angular.element('<div >');
            backdropEl.addClass(options.backdropClass);
            backdropEl.addClass('fade in');

            var handleEscPressed = function (event) {
                if (event.keyCode === 27) {
                    scope.$modalCancel();
                }
            };

            var closeFn = function () {
                body.unbind('keydown', handleEscPressed);
                modalEl.remove();
                body.removeClass('modalIsOpen');
                if (options.backdrop) {
                    backdropEl.remove();
                }
            };

            body.bind('keydown', handleEscPressed);

            var ctrl, locals,
                scope = options.scope || $rootScope.$new();

            scope.$title = options.title;
            scope.$headerImage = options.headerImage;

            scope.$modalClose = closeFn;

            scope.$modalCancel = function () {
                var callFn = options.cancel.fn || closeFn;
                callFn.call(this);
                scope.$modalClose();

            };
            scope.handleClose=function(){
                if (options.closeBrowser) {
                    $window.open('', '_self', '');
                    $window.close();

                    return;
                }
                scope.$modalCancel();
            };
            scope.$modalSuccess = function () {
                var callFn = options.success.fn || closeFn;
                callFn.call(this);
                scope.$modalClose();
            };
            scope.$modalSuccessLabel = options.success.label;
            scope.$modalCancelLabel = options.cancel.label;

     /*-------------------------------------------------
     making passedInLocals a part of scope so that angular inject does not fail in modal(eg qv) controller when
     we  have no local variables passed in ,
      in case of accessing the modal(eg.  quick view) via a deep link
      ----------------------------------------------------*/
            if (passedInLocals) {
                scope.modelParam = passedInLocals;
            }

            if (options.controller) {
              //  locals = angular.extend({$scope: scope}, passedInLocals);
                locals = {$scope: scope};
                ctrl = $controller(options.controller, locals);
                // Yes, ngControllerController is not a typo
                modalEl.contents().data('$ngControllerController', ctrl);
            }

            $compile(modalEl)(scope);
            $compile(backdropEl)(scope);
            body.append(modalEl);
            body.addClass('modalIsOpen');
            if (options.backdrop) {
                body.append(backdropEl);
            }

            $timeout(function () {
                modalEl.addClass('in');
            }, 200);
        };
    }]);