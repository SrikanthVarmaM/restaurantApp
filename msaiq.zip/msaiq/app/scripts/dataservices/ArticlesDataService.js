'use strict';

//articleCode=TREND&timeInterval=90&equityType=S
msaiqApp.factory('ArticlesResource', function ($resource) {
  return $resource('/SP/msa/homeLandingPage.html?articleCode=GHOME&country=%20&timeInterval=120000');
});