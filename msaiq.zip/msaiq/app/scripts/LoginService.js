'use strict';

msaiqApp.service('LoginService', function (_, userResourceResourceFactory,$q, $cookies,$log,$http,$location) {
    var self = this;
    self.deferred = $q.defer();


    self.errorObject = {errorMessage: null, errorCode: null,errorTime :null,errorStackTrace: null,url:window.location.href,partnerCode:null};
    self.authObj = {resolved: false, loggedIn: false,errorObject:self.errorObject,loginUserDetail: null,parameters:null};


    var getObjFromUrlParams = function () { // custom function to return  object from URL parameters (angular/jquery  query parameters  function fails on ie)
        var query = window.location.search.substring(1);

        if (query === "" || query == null) {
            query = window.location.hash.substring(1).split("?")[1];
            if (query === "" || query == null) {
                query = window.location.href;
            }
        }
        var query_string = {};
        if (query.indexOf('&') > -1) {
            var vars = query.split("&");
            for (var i = 0; i < vars.length; i++) {
                var pair = vars[i].split("=");

                if (typeof query_string[pair[0]] === "undefined") {
                    query_string[pair[0]] = pair[1];
                } else if (typeof query_string[pair[0]] === "string") {
                    query_string[pair[0]] = [ query_string[pair[0]], pair[1] ];
                } else {
                    query_string[pair[0]].push(pair[1]);
                }
            }
        }
        return query_string;
    };

    var decodeURIParams = function (obj) {
        if (!obj) {
            return;
        }
        if (obj.ln) {
            obj.ln = decodeURIComponent(obj.ln);

        }
        if (obj.fn) {
            obj.fn = decodeURIComponent(obj.fn);

        }
        if (obj.un) {
            obj.un = decodeURIComponent(obj.un);
        }
        if (obj.expirationDate) {
            obj.expirationDate = decodeURIComponent(obj.expirationDate);
        }
            if (obj.partnercode) {
            obj.partnercode = decodeURIComponent(obj.partnercode);
            self.errorObject.partnerCode =  obj.partnercode;
        }else if (obj.clientName) {
            obj.clientName = decodeURIComponent(obj.clientName);
                self.errorObject.partnerCode =  obj.clientName;
        }
        if (obj.em) {
            obj.em = decodeURIComponent(obj.em);
        }
        return obj;

    }
    var notifyAll = function (flag,userDetail) {
        self.authObj.loginUserDetail = userDetail;
       // self.authObj.errorObject = errorObject;
        self.authObj.loggedIn = flag;
        self.authObj.resolved = true;
        self.deferred.resolve(self.authObj);
    }
    var authenticate = function (params) {
       /* if ($cookies.ObSSOCookie) {// check if already logged in
            var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
            loginUserDetail.$promise.then(function(loginUser){
                if(loginUser.resourceList){
                    notifyAll(true,loginUser.resourceList);
                } else {
                    notifyAll(true,null);
                }
            },function error() {
                notifyAll(true,null);
            });
        }
        else {*/
            //Deleting the existing Cookie
            document.cookie = "ObSSOCookie=; expires=Thu, 01 Jan 1970 00:00:01 GMT;";
           //Calling
            var par = params.seamlessLink || params;
            par = decodeURIParams(par);
            $http({method: 'GET',
                url: '/SP/msa/remoteLogin.html',
                params: par,
                cache: false}).
                success(function(data, status, headers, config) {
                    if ($cookies.ObSSOCookie) {
                        if(!params.seamlessLink){
                            window.location.href = $location.$$protocol + '://' +$location.$$host+':'+$location.$$port+window.location.pathname+"Redirect.html";
                        }
                        var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
                            loginUserDetail.$promise.then(function(loginUser){
                                if(loginUser.resourceList){
                                    notifyAll(true,loginUser.resourceList);
                                } else {
                                    notifyAll(true,null);
                                }
                            },function error() {
                                notifyAll(true,null);
                            });
                        } else {
                            self.errorObject.errorCode = headers('error-code');
                            self.errorObject.errorMessage = headers('error-message');
                            self.errorObject.errorTime = headers('error-time');
                            self.errorObject.errorStackTrace = headers('stack-trace');
                            notifyAll(false,null);
                        }

                }).
                error(function(data, status, headers, config) {
                    self.errorObject.errorCode = headers('error-code');
                    self.errorObject.errorMessage = headers('error-message');
                    self.errorObject.errorTime = headers('error-time');
                    self.errorObject.errorStackTrace = headers('stack-trace');
                    notifyAll(false,null);
                });
    }
    var parseAndAuthenticate = function () {
        var params = getObjFromUrlParams();
        if (params.seamlessLink) {
            params.seamlessLink = JSON.parse(decodeURIComponent(params.seamlessLink));
            params.asset = JSON.parse(decodeURIComponent(params.asset));
            self.authObj.quickViewMode = true;
            self.authObj.parameters = params;
            authenticate(params);

        } else {    // for non quickview links

            if (params.partnercode || params.clientName) {
                authenticate(params);
            }else if($cookies.ObSSOCookie){
                var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
                loginUserDetail.$promise.then(function(loginUser){
                    if(loginUser.resourceList){
                        notifyAll(true,loginUser.resourceList);
                    } else {
                        notifyAll(true,null);
                    }
                },function error() {
                    notifyAll(true,null);
                });
            } else {
                notifyAll(false,null);
            }
        }
    }

    parseAndAuthenticate();


});
