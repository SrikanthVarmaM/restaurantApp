'use strict';
/** services for this app **/


msaiqApp.factory('ArticleMessaging', function() {
    return {
        /* send article loaded message to the directives */
        broadcastArticleLoaded: function(scope, message) {
            /* message needs to be in format of {articleId: '', instruments: [ {sppwId: '', tickerSymbol: ''}, {sppwId: '', tickerSymbol: ''}]} */
            scope.$broadcast('articleLoaded', message);
        },
        /* directives will call this function passing in the callback on what to do when article is loaded */
        onArticleLoad: function(scope, callback){
            scope.$on('articleLoaded',  callback);
        },
        /* send article loaded message to the directives */
        broadcastEtfArticleLoaded: function(scope, message) {
            /*
             message needs to be in format of {sppwid: '', ticker: '', articleId: '', relatedParams: <data object>};
             */
            scope.$broadcast('etfArticleLoaded', message);
        },
        /* directives will call this function passing in the callback on what to do when article is loaded */
        onEtfArticleLoad: function(scope, callback){
            scope.$on('etfArticleLoaded',  callback);
        },
        /* send article loaded message to the directives -- funds */
        broadcastFundsArticleLoaded: function(scope, message) {
            /*
             message needs to be in format of {sppwid: '', ticker: '', articleId: '', relatedParams: <data object>};
             */
            scope.$broadcast('fundsArticleLoaded', message);
        },
        /* directives will call this function passing in the callback on what to do when article is loaded --funds*/
        onFundsArticleLoad: function(scope, callback){
            scope.$on('fundsArticleLoaded',  callback);
        }
    };
});

msaiqApp.factory('AutoSuggestService', function ($, EntitlementService,$resource,$log) {
    var getSearchList = function (url, uriEncodedQuery) {
            var esQuery = {
                'query': {

                    'multi_match': {
                        'query': uriEncodedQuery.toLowerCase(),
                        'analyzer': 'keyword',
                        'fields': [ 'ticker^100', 'autocomplete_edge_ticker^70', 'name^50', 'autocomplete_edge^30', 'autocomplete_ngram^05' ]
                    }
                },

                'sort': [
                    '_score',
                    { 'name.untouched': 'desc' }
                ],
                'highlight': {
                    'pre_tags': ['<strong>', '<strong>'],
                    'post_tags': ['</strong>', '</strong>'],
                    'fields': {
                        'autocomplete_edge_ticker': {},
                        'ticker': {},
                        'autocomplete_edge': {},
                        'autocomplete_ngram': {},
                        'name': {}
                    }
                }
            };


            return '/es/ac/power_search/_search?pretty=true&source=' + encodeURIComponent(JSON.stringify(esQuery));
    };
    var parseResponse= function (parsedResponse,filterByEnt) {
            var rtn = [];

            var filterEntitlements = function(hitResult){

                var sec_type = (hitResult.security_type === 'FUND' || hitResult.security_type === 'Global Fund') ? 'fund' : hitResult.security_type;
                if (_.isString(sec_type)) {
                    sec_type = sec_type.toLowerCase();
               }
                return  EntitlementService.apCon.autoSuggest[sec_type](hitResult.region);


            };

            $.each(parsedResponse.hits.hits, function (index, value) {
                var hitResult = value._source;
                 hitResult.score=value._score;

                hitResult.displayTicker = hitResult.ticker;
                hitResult.displayName = hitResult.name;

                if (value.highlight) {
                    if (value.highlight.ticker) {
                        hitResult.displayTicker = value.highlight.ticker;
                    }
                    else if (value.highlight.autocomplete_edge_ticker) {
                        hitResult.displayTicker = value.highlight.autocomplete_edge_ticker;
                    }
                    else if (value.highlight.name) {
                        hitResult.displayName = value.highlight.name;
                    }
                    else if (value.highlight.autocomplete_edge) {
                        hitResult.displayName = value.highlight.autocomplete_edge;
                    }
                    else if (value.highlight.autocomplete_ngram) {
                        hitResult.displayName = value.highlight.autocomplete_ngram;
                    }


                }

                // filter iso exchanges
                if (hitResult.exchange) {
                    hitResult.exchange = (hitResult.exchange.indexOf('X') === 0) ? hitResult.exchange.replace('X', '') : hitResult.exchange;
                }


                if (hitResult.exchange === '0Ar' || hitResult.exchange === '0Aq') {
                    hitResult.exchange = null;
                }

                if ((hitResult.security_type === 'ETF' || hitResult.security_type === 'Stock') && hitResult.exchange) {
                    hitResult.value = hitResult.ticker + ':' + hitResult.exchange;
                }
                else {
                    hitResult.value = hitResult.ticker;
                }
                if (filterByEnt){
                    if (filterEntitlements(hitResult))  {
                rtn.push(hitResult);
                    }
                }else {
                    rtn.push(hitResult);
                }



            });

        rtn = rtn.sort(function (a, b) {
            if (a.score > b.score && a.ticker !== b.ticker ) return -1;
            if (a.score <  b.score && a.ticker !== b.ticker ) return 1;

            if (a.ticker === b.ticker ) {
                if (a.region ==='UNITED STATES' && b.region !== 'UNITED STATES'){
                    return -1;
                }else if (b.region ==='UNITED STATES' && a.region !== 'UNITED STATES'){
                    return 1;
                }else {
                    return 0;
                }
            }
            if (a.ticker < b.ticker){
                return -1;
            }else if (a.ticker > b.ticker){
                return 1;
            }


        });
        /*console.log("-----")
        for ( var i=0;i<rtn.length;i++){
            console.log(rtn[i].ticker+ ":"+rtn[i].score + ":"+ rtn[i].region + ":" + rtn[i].security_type);
        }*/
//                var uriEncodedQuery = encodeURIComponent($('#input01').val());
            var seeAllHack = {
                title: '',
                link: '<a href="#/search/" + uriEncodedQuery + "" style="white-space: nowrap; display:none;">See All&nbsp;</a>',
                value: $('#input01').val()

            };

            rtn.push(seeAllHack);
            /*    var seeArticles = {
             title: 'S&P Capital IQ Research and Articles',
             link: '<a href="#/search/" + uriEncodedQuery + "" style="white-space: nowrap">See All</a>',
             value: ''

             };*/

            //  rtn.splice(6,0,seeArticles);

            return rtn;
    };
    return {
        getSearchList: getSearchList,
        parseResponse: parseResponse,


        getTickerInformation: function (ticker, successCallback, errorCallback) {
            // call auto suggest to get the latest ticker matching
            var url = getSearchList('/es/ac/power_search/_search?pretty=true&q=ticker', ticker);
            $resource(url).get().$promise.then(function (data) {
                var tickerList = parseResponse(data,false);
                // grab the first matching at index[0]
                var values = {ticker: ticker, type: (tickerList[0].security_type || 'blank'), report_ind: tickerList[0].report_ind, sppwId: (tickerList[0].sppw_id || 'blank'),region:(tickerList[0].region || '') };
                successCallback(values);
            }, function (error) {
                if (errorCallback) {
                    errorCallback(error);

        }
                else {

                }


            });
        }

    };
});


function examineJSONResponse(response, $log){

   // $log.debug('examineJSONResponse and remove unwanted characters');
    // look for all http response that has first character of ( in it, and strip it out and convert it to json
    if (response.data && Object.prototype.toString.call(response.data) === '[object String]' &&  response.data.trim().charAt(0) === '(')   {
        response.data = response.data.trim().substring(1, response.data.length).trim();    // remove first {
        response.data = response.data.trim().substring(0, response.data.length-1).trim();  // remove the last )
        response.data =  JSON.parse( response.data );
       // $log.debug('removed ( and ) characters from response');

    }

    return response;
}

/** http response interceptors to get ride of ( json ) **/
msaiqApp.factory('HttpInterceptor', function ($q, $log) {
    return {
        response: function (response) {
           // $log.info('HttpInterceptor');

            // do something on success
            if(response.headers()['content-type'] === 'application/json; charset=utf-8' || response.headers()['content-type'] ===  'text/plain; charset=UTF-8')
            {
                $log.debug('HttpInterceptor JSON');
                // Validate response if not ok reject
                var data = examineJSONResponse(response, $log);

                if(!data) {
                 //   $log.info('myHttpInterceptor return reject');
                    return $q.reject(response);
                }
            }
          //  $log.info('HttpInterceptor return response');
            return response;
        },
        responseError: function (response) {
            // do something on error
            return $q.reject(response);
        }
    };
});

msaiqApp.config(function ($httpProvider) {
    $httpProvider.interceptors.push('HttpInterceptor');
});