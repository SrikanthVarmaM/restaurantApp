'use strict';

msaiqApp.controller('ThomsonLoadingCtrl', function ($scope, $log,$window, ThomsonService, articleResourceFactory, $timeout) {

   // $window.alert('Loading Controller');
    $log.info('Loading Controller, initializes calls when index page loads');

    // call thomson service at each homepage load
    ThomsonService.initialize();

    // keep alive session
    // 300000 - 5 mins, 60000 - 1 min, 10000 - 10 seconds
    var refreshIntervalMilli = 300000;
    var keepAliveCounter = 0;
    var keepAlive = function(){
        articleResourceFactory.trendsAndIdeasSpotLightResource.get();
        keepAliveCounter++;
        $log.debug('Loading Controller, Keep Session Alive: ' + keepAliveCounter + ' , ' + new Date());
        $timeout(keepAlive, refreshIntervalMilli);
    };
    keepAlive();
      /*--------------------------------------------------- log analyse entitlements--------------------------------------------*/



});