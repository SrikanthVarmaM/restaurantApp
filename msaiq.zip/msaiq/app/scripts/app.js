'use strict';
/*jshint unused: false */

var msaiqApp = angular.module('msaiqApp', ['ngTable', 'ngRoute', 'ngResource', 'ngSanitize', 'ngCookies', 'lr.upload','placeholderShim','mgcrea.ngStrap']);
//msaiqApp.config(function ($routeProvider) {
//    $routeProvider
//      .when('/x', {
//        templateUrl: 'views/main.html',
//        controller: 'MainCtrl'
//      })
//
//      .when('/home', {
//        templateUrl: 'site/landing_page/landing_page.html',
//        controller: 'LandingPageCtrl'
//      })
//
//      .otherwise({
//        redirectTo: '/home'
//      });
//  });
//
//msaiqApp.filter('fixAllCaps', function() {
//  return function(input, scope) {
//    if(input){
//      return input.toLowerCase();
//    }
//    // return input.substring(0,1).toUpperCase()+input.substring(1);
//  };
//});
//
//msaiqApp.config(function($sceProvider) {
//  // Completely disable SCE to support IE7.
//  $sceProvider.enabled(false);
//});
