'use strict';
msaiqApp.service('EntitlementService', function (_, userResourceResourceFactory, $q, $rootScope, $log) {
    var self = this;
    /*-------------------------------------------------------------------------------------------------------------
     variables exposed to outside classes
     --------------------------------------------------------------------------------------------------------------*/
    self.deferred = $q.defer();
    self.deferred1 = $q.defer();//this is a separate instance of deferred object used for clientcustomization .
    self.apCon = {resolved: false};
    self.clientCustomization = {resolved: false};
    /*--------------------------------------------------------------------------------------------------------------
     ajax requests to get 1. entitlements for the users , 2 . partner name of the user
     -------------------------------------------------------------------------------------------------------------*/
    self.loadEnt = function () {
        if (self.apCon.resolved) {
            return;//avoid repeatative loading
        }
        userResourceResourceFactory.entitlementResource.getArrayReq({}, function (response) {
            if (response.resourceList) {
                buildapCon(response.resourceList);  //process user entitlements to build the json object (self.apCon)  that will be used by outside htmls to decide visibility

            }
        }, function (err) {
            $log.info("failed here");
        });

        // if the partner code value is already set in previous calls, omitt the call
        if ($rootScope.partnerIdm==undefined) {
            $log.info("Search for IDM Group Name to set up customization");
            userResourceResourceFactory.userCompanyResource.getArrayReq({}, function (response) {
                if (response.resourceList) {
                    $rootScope.company = response.resourceList.COMPANY;

                    var groupNm;
                    var numOfSeperators = -1;
                    var prefix = "MSA_" + $rootScope.company;
                    var groupsArr = response.resourceList.GROUP.split(":");
                    for (var i = 0; i < groupsArr.length; i++) {
                        var thisNumSeparator = (groupsArr[i].split("_").length - 1)
                        if (groupsArr[i].substring(0, prefix.length) == prefix && thisNumSeparator > numOfSeperators
                            ) {
                            numOfSeperators = thisNumSeparator;
                            groupNm = groupsArr[i];
                        }
                    }
                    $rootScope.partnerIdm = groupNm;

                    buildClientCustomization($rootScope.partnerIdm);
                }

            }, function (err) {
                $log.info("client customization failed ");
            });
        } else {
            buildClientCustomization($rootScope.partnerIdm);
        }

    };
    /*----------------------------------------------------------------------------------------------------------------
     Internal data processing functions : not exposed to outsiders-
     -----------------------------------------------------------------------------------------------------------------*/

    var buildapCon = function (entArr) {
        var usrEntObj = convertArrToObj(entArr);

        //---------all complex business logic goes in here in function----------

        usrEntObj.hasAnyStock = function () {
            return  usrEntObj.msa_us_stock || usrEntObj.msa_canadian_stock || usrEntObj.msa_asian_stock || usrEntObj.msa_european_stock;
        };
        usrEntObj.hasDomesticStock = function () {
            return  usrEntObj.msa_us_stock || usrEntObj.msa_canadian_stock || false;
        };

        // domestic stock includes US and Canada
        usrEntObj.isDomesticStock = function(region){
            return (region === 'US' || region === 'UNITED STATES' || region === 'U.S. Domestic' || region === 'CANADA' || region === 'CANADA-ADR');
        };
        usrEntObj.hasThisRegionStock = function (region) {
            if (region === 'US' || region === 'UNITED STATES' || region === 'U.S. Domestic') {
                return  (usrEntObj.msa_us_stock || false);
            }
            if (region === 'CANADA' || region === 'CANADA-ADR') {
                return  (usrEntObj.msa_canadian_stock || false);
            }
            if (region === 'EUROPE') {
                return  (usrEntObj.msa_european_stock || false);
            }
            if (region === 'ASIA') {
                return  (usrEntObj.msa_asian_stock || false);
            }

            return false;
        };
        usrEntObj.hasAnyFund = function () {
            return usrEntObj.msa_fund || usrEntObj.msa_global_fund || usrEntObj.msa_fmr;
        };
        usrEntObj.hasThisRegionFund = function (region) {
            if (region === 'UNITED STATES') {
                return usrEntObj.msa_fund;
            } else {
                return usrEntObj.msa_global_fund || usrEntObj.msa_fmr;
            }
        };
        usrEntObj.showWatchList = function (){
            // have stocks / etfs and funds
            if (usrEntObj.hasAnyStock()){
                return true;
            }else if (usrEntObj.isSnapshotEnabledOnly()){
                return false; // no domestic stocks entitlement, only snapshot, do not show watchlist
            } else if (usrEntObj.hasAnyFund() || usrEntObj.msa_etf){  // not sure to set this
                return true;
            } else   {
                return true; // default is to show watchlist
            }

        };
        usrEntObj.getRouteDefault = function () {
            if (usrEntObj.msa_marketscope) {
                return "/home";
            }
            else if (usrEntObj.hasAnyStock()) {
                return "/stocks/starstocks/5";
            }
            else if (usrEntObj.msa_etf) {
                return "/etf/etfLanding";

            }
            else if (usrEntObj.hasAnyFund()) {
                return "/fund/fundsLanding";

            }
            else if (usrEntObj.msa_sector) {
                return "/marketscope/sectors";

            } else {
                return " ";
            }
        };
        usrEntObj.isSnapshotEnabledOnly = function() {
            // snapshot entitlement and no domestic stocks entitlement
           return (usrEntObj.msa_snapshot || false) && !usrEntObj.hasDomesticStock();
        };

        //---------building the json object now ----------

        self.apCon.leftNavLinks = {
            articlesPage: usrEntObj.msa_marketscope,
            sectors: usrEntObj.msa_marketscope || usrEntObj.msa_sector,
            outlookLink: usrEntObj.msa_outlook_reports

        };
        self.apCon.rightSection = {
            relatedHeadlines: usrEntObj.msa_marketscope,
            relatedTrendsIdeas: usrEntObj.msa_marketscope

        };
        self.apCon.sectorsPage = {
            recentlyUpdatedUSIndustrySurvey: usrEntObj.msa_industry_survey || usrEntObj.msa_sector,
            recentlyUpdatedGlobalIndustrySurvey: usrEntObj.msa_industry_survey_global || usrEntObj.msa_sector

        };
        self.apCon.subSectorsMessage = {
            subSectorMessage: usrEntObj.hasAnyStock(),
            notSubSectorMessage: !usrEntObj.hasAnyStock()
        };
        self.apCon.portfolioHomePage = {
            etfPortfolio: usrEntObj.msa_etf
        };
        self.apCon.technicalAnalysisHome = {
            technicalTrends: usrEntObj.hasAnyStock()
        };
        self.apCon.etfPortfolioPage = {
            seeAllPortfolio: usrEntObj.msa_marketscope
        };
        self.apCon.marketMoversPage = {
            downloadUSIndustrySurvey: usrEntObj.msa_industry_survey || usrEntObj.hasAnyStock()

        };
        self.apCon.quickview = {
            relatedNews: usrEntObj.msa_marketscope || usrEntObj.msa_snapshot
        };
        self.apCon.toolBar = {
            "home": usrEntObj.msa_marketscope,
            "stocksLink": usrEntObj.hasAnyStock(),
            "etfLink": usrEntObj.msa_etf,
            "optionLink": usrEntObj.msa_options,
            "fundLink": usrEntObj.hasAnyFund(),
            "bondLink": usrEntObj.msa_bond

        };
        self.apCon.userResource = {
            "alertLink": ((usrEntObj.msa_alert) && (!usrEntObj.isSnapshotEnabledOnly()) && (usrEntObj.hasAnyStock() || usrEntObj.hasAnyFund() || usrEntObj.msa_etf  )),
            "hypoLink": usrEntObj.msa_hypo,
            "excelReportLink": usrEntObj.msa_excel_report,
            "watchlist": usrEntObj.showWatchList(),
            "stockAlertLink": (usrEntObj.msa_alert && usrEntObj.hasAnyStock()),
            "toolsButton": (((usrEntObj.msa_alert) && (usrEntObj.hasAnyStock() || usrEntObj.hasAnyFund() || usrEntObj.msa_etf  )) || usrEntObj.msa_hypo || (usrEntObj.hasAnyStock() || usrEntObj.hasAnyFund() || usrEntObj.msa_etf  ))
        };
        self.apCon.admin = {
            "adminLink": usrEntObj.msa_admin,
            "superTestLink": usrEntObj.msa_supertest,
            "salesAdminLink": usrEntObj.msa_sales_admin,
            "outlookAdminLink": usrEntObj.msa_outlook_admin,
            "clientAdminLink": usrEntObj.msa_settings_partner_admin

        };
        self.apCon.pageIndex = {
            marketscope: usrEntObj.msa_marketscope,
            stock: usrEntObj.hasAnyStock()

        };
        self.apCon.userResourceFund = {
            "alertLink": (usrEntObj.msa_alert)

        };
        self.apCon.emailChangeDisabled = usrEntObj.msa_email_change_restrict;//TODO add logic in alert popup not to let user change email if this is true


        self.apCon.quickviewLinks = {
            stock: function (region) {
                return   (usrEntObj.hasThisRegionStock(region) || (usrEntObj.isDomesticStock(region) && usrEntObj.msa_snapshot));
            },
            etf: function () {
                return   usrEntObj.msa_etf;
            },
            fund: function () {
                return usrEntObj.hasAnyFund();
            },
            bond: function () {
                return usrEntObj.msa_bond;

            }

        };
        self.apCon.autoSuggest = {
            stock: function (region) {
                return   (usrEntObj.hasThisRegionStock(region) || (usrEntObj.isDomesticStock(region) && usrEntObj.msa_snapshot))
            },

            etf: function () {
                return   usrEntObj.msa_etf;
            },

            fund: function (region) {
                return   usrEntObj.hasThisRegionFund(region);

            },
            bond: function () {
                return  usrEntObj.msa_bond;
            }
        };
        self.apCon.equityDetailsPage = {
            stock: function (region) {
                return   usrEntObj.hasThisRegionStock(region) || (!usrEntObj.msa_snapshot);
            },
            etf: function () {
                return   usrEntObj.msa_etf;
            },


            fund: function () {
                return usrEntObj.hasAnyFund();
            },
            bond: function () {
                return usrEntObj.msa_bond;

            }

        };
        /* --------For all download report link except those on the security details &
         qv  pages as those on qv/details page  are driven by parent(qv/details) visibility only.*/
        self.apCon.downloadReportsLink = {
            stock: function (region) {
                return  usrEntObj.hasThisRegionStock(region) || (!usrEntObj.msa_snapshot);
            },
            etf: function () {
                return   usrEntObj.msa_etf;
            },

            fund: function () {
                return usrEntObj.hasAnyFund();
            },
            bond: function () {
                return  usrEntObj.msa_bond;
            },
            usIndSurv: usrEntObj.msa_industry_survey || usrEntObj.msa_sector,
            globalIndSurv: usrEntObj.msa_industry_survey_global || usrEntObj.msa_sector,
            anyIndustrySurvey: usrEntObj.msa_industry_survey || usrEntObj.msa_sector || usrEntObj.msa_industry_survey_global

        };

        self.apCon.snapshotEnabledOnly = usrEntObj.isSnapshotEnabledOnly();

        self.apCon.routeDefault = usrEntObj.getRouteDefault();

        self.apCon.resolved = true;
        self.deferred.resolve(self.apCon);

    };

    var buildClientCustomization = function (partner_idm) {
        self.clientCustomization = {

            bondsQuickview: {
                hideRelatedNews: (partner_idm || '').toLowerCase() === 'msa_thomson reuters_syndicated_odc' ||
                    (partner_idm || '').toLowerCase() === 'msa_thomson reuters_syndicated_uz2'
            },
            portfolio: {
                hideNeuralFairValuePortFolio: (partner_idm || '').toLowerCase() === 'msa_thomson reuters_syndicated_odc' ||
                    (partner_idm || '').toLowerCase() === 'msa_thomson reuters_syndicated_uz2'
            }
        };
        self.clientCustomization.resolved = true;
        self.deferred1.resolve(self.clientCustomization);
    };
    var convertArrToObj = function (arr) {
        var obj = {};
        var temp;
        for (var i = 0; i < arr.length; i++) {
            if (arr[i]) {
                temp = arr[i].replace(/ - /g, '_'); //removes spaces
                temp = temp.replace(/ /g, '_');
                obj[temp] = true;
            }
        }
        return obj;
    };
});
