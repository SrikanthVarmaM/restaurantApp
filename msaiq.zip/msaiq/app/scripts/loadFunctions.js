'use strict';

function getCookie(c_name)
{
    var c_value = document.cookie;
    var c_start = c_value.indexOf(' ' + c_name + '=');
    if (c_start === -1)  {  c_start = c_value.indexOf(c_name + '='); }
    if (c_start === -1) {  c_value = null; }
    else {
        c_start = c_value.indexOf('=', c_start) + 1;
        var c_end = c_value.indexOf(';', c_start);
        if (c_end === -1){  c_end = c_value.length; }
        c_value = unescape(c_value.substring(c_start,c_end));
    }
    return c_value;
}
function trimCookie(cookieString){
    if (cookieString){
        var cookies = cookieString.trim().split('&');
        var headers = {};
        for (var i = 0; i < cookies.length; i++) {
            var splits = cookies[i].split('=');
            headers[splits[0]] = splits[1];
        }
        return headers;
    }else{
        return null;
    }
}

/*
    <script>
    // TICKER PASSING, find out thomson is from Smart or Thick Client
    try{
        var userAgent = navigator.userAgent;
        // specialize is MSIE7.0 -  Thick ;  MSIE8.0 -  Smart
        if (userAgent.indexOf('MSIE 8.0') > 0)  {
        document.write("<script type='text/javascript' src='external/scripts/FsiSmart.js'><\/script>");
        //  alert(' userAgent :' + userAgent + ', loaded Smart');
        } else{
        // load Thick by default
        document.write("<script type='text/javascript' src='external/scripts/FsiThick.js'><\/script>");
        // alert(' userAgent :' + userAgent + ', loaded Thick by default');
        }

    }catch(err){
        console.log('unable to retrieve headers' + err.message);
        //  window.alert('Issue on getting headers ' + err.message);
        }

    </script>
*/