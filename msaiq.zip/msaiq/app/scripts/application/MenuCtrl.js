'use strict';

msaiqApp.controller('MenuCtrl', function ($scope, $rootScope,$routeParams) {
    $scope.currentSelection = '';
    $scope.currentPage = '';
    $scope.copyrightYear= new Date().getFullYear();
    $rootScope.$on('$routeChangeSuccess',
        function (angularEvent,
                  currentRoute) {
            if(currentRoute.$$route && currentRoute.$$route.originalPath){
                var path = currentRoute.$$route.originalPath;
                var pathComponents = path.split('/');

                if(pathComponents.length > 0){
                    $scope.currentSelection  = pathComponents[1];
                    if($scope.currentSelection === 'admin' || $scope.currentSelection === 'outlookAdmin' || $scope.currentSelection === 'msaErrorPage' || $scope.currentSelection === 'clientAdmin') {
                        $scope.$parent.userInfoLinkManager = pathComponents[1]
                    }
                }

                if(pathComponents.length > 1){
                    $scope.currentPage = pathComponents[2];
                }

                /* exceptions - all left menu marketscopes is highlighted as home */
                 if ($scope.currentSelection && $scope.currentSelection === 'marketscope'){
                    if((($scope.currentPage==='seeAllHeadlines'|| $scope.currentPage === 'seeAllSharedClasses') && $routeParams.equityType==='funds') || ($scope.currentPage==='focusFUNDOfMonthDetails')){
                        $scope.currentSelection='fund';
                    }
                    else if(($scope.currentPage==='seeAllHeadlines' && $routeParams.equityType==='etf') || ( $scope.currentPage==='focusETFOfMonthDetails')){
                        $scope.currentSelection='etf';
                    }
                    else if($scope.currentPage==='seeAllHeadlines' && $routeParams.equityType==='stocks'){
                        $scope.currentSelection=$routeParams.equityType;
                    }
                    else{
                            $scope.currentSelection = 'home';
                    }
                }
            }

            // var pageKey = currentRoute.pageKey;
//            $('.pagekey').toggleClass('active', false);
//            $('.pagekey_' + pageKey).toggleClass('active', true);
        });


});