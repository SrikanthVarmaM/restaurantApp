'use strict';

msaiqApp.controller('MenuCtrl', function ($scope, $location) {
    $scope.currentSelection = 'Home';

    $scope.selected = function (selected) {
        $scope.currentSelection = selected;
        if (selected === 'Home') {
            $location.path('/home');
        } else if (selected === 'Stocks') {
            $location.path('/stocks/starPerformance');
        } else if (selected === 'Etf') {
            $location.path('/etf/focusOfTheMonth');
        } else if (selected === 'Funds') {
            $location.path('/fund/fundsLanding');
        }
    };

    $scope.$on('menuShow',function(event,message) {
            $scope.currentSelection = message;
    });
    $scope.copyrightYear= new Date().getFullYear();

});