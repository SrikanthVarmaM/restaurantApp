'use strict';
/*global $:false, _:false, Hogan:false, ga:false */

msaiqApp.factory('$', function () {
    return $;
});

msaiqApp.factory('_', function () {
    return _;
});

msaiqApp.factory('Hogan', function () {
        return Hogan;
    }
);

msaiqApp.factory('ga', function () {
    return ga;
});


