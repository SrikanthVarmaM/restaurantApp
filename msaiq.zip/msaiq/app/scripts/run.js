'use strict';

msaiqApp.run(function ($rootScope, $location, $route, ga, $window, $cookies, userResourceResourceFactory, $, AUTH_EVENTS, $log, LoginService,EntitlementService,UserInfoLinkServices) {


    $rootScope.checkHumaneMargins = function () {

        if ($(window).width() < 1185) {
            return true;

        } else {
            return false;
        }

    };

    $rootScope.loadingData = false;
    $rootScope.userIsIntlEntitled = false;
    $rootScope.startTime = new Date().getTime();
    $rootScope.currentUserEntitlement = userResourceResourceFactory.entitlementResource.getArrayReq({});

    $rootScope.currentUserEntitlement.$promise.then(function (response) {

        if (response.resourceList !== null) {
            for (var i = 0; i < response.resourceList.length; i++) {

                if (response.resourceList[i] == 'msa - european marketscope') {
                    $rootScope.userIsIntlEntitled = true;
                    break;
                }
            }

        }
    });

    $rootScope.gaCodeRaw = userResourceResourceFactory.googleAnalyticsConfigResource.getArrayReq({});

    $rootScope.gaCodeRaw.$promise.then(function (response) {

        if (response.resourceList !== null) {
            $rootScope.gaUACode = response.resourceList.MSA_GOOGLE_ANALYTICS_UA_CODE;
            $log.info('Google Analytics UA  Code = '+  $rootScope.gaUACode);
            ga('create',   $rootScope.gaUACode, 'auto');

            omnitureUID=response.resourceList.OMNITURE_ANALYTICS_UID;
            omnitureInternalServer=response.resourceList.OMNITURE_INTERNAL_SERVERS;

            var script = document.createElement('script');
            script.async = false;
            script.type = 'text/javascript';
            script.src = 'external/scripts/s_code.js';
            // document.head.appendChild(script);
            (document.getElementsByTagName('head')[0]||document.body).appendChild(script);


        }

    });
    $rootScope.$on('$locationChangeStart',function(evt) {

        document.cookie="msa_fe=true; path=/";
        if(!$cookies.ObSSOCookie){
            if(!$location.$$path || $location.$$path === '/home') {
                $location.path('/home');
            } else if($location.$$path.indexOf('msaErrorPage') > -1 || $location.$$path.indexOf('remoteLogin.html') > -1 || $location.$$path.indexOf('seamlessQV') > -1|| $location.$$absUrl.indexOf('quickview') > -1){
                 return;
            } else {
               // $location.path('/home');
                UserInfoLinkServices.openUserAuthenticateWindow();
            }
        } else {
            if(!jQuery.isEmptyObject($rootScope.loginUserInformation)){
                if(jQuery.isEmptyObject($rootScope.loginUserInformation.userDetails)){
                    loadUserInformation();
                }
            }
        }
    });

    $rootScope.$watch(function() { return $cookies.ObSSOCookie;},function(cookie){
        if($cookies.ObSSOCookie) {
            if(!jQuery.isEmptyObject($rootScope.loginUserInformation)){
                if(jQuery.isEmptyObject($rootScope.loginUserInformation.userDetails)){
                    loadUserInformation();
                }
            }
        }
    },true);

    /*

    //---------------------------AJAX tracking----------------------------//

    var startTime = new Date().getTime();
    var temp = {};
    temp.origOpen = XMLHttpRequest.prototype.open;
    temp.origSend = XMLHttpRequest.prototype.send;


    function onReadyStateChangeAugmented() {

        if (this._onreadystatechange && this.readyState === 4) {

            var finishTime = new Date().getTime();
            //var totalTime = finishTime - startTime;
            var d = new Date($rootScope.startTime).getTime();
            var totalTime = finishTime - d;
            //   $log.info(this.url);
           // $log.info("this : "+this.responseText);


            if (this.status !== 200) {
                //    $log.info(this.status);
                ga('send', 'event', 'AJAX Resource Error', 'window.location.hash', 'url: ' + this.url + '  status: ' + this.status + '  method: ' +  this.method + '  error location:  ' + window.location.href, {

                    'dimension1': $rootScope.currentUser,
                    'dimension2': $rootScope.partner_name,
                    'dimension3': $rootScope.company,
                    'dimension4': this.status,
                    'dimension5': 'total time: ' + totalTime + ' milliseconds',
                    'dimension6':$rootScope.partnerIdm

                });

            } else {
                if (this.url.toLowerCase().indexOf('sp/msa/articles') !== -1 || this.url.toLowerCase().indexOf('ticker') !== -1) {
                    //   $log.info('-----------' + this.url);
                    $rootScope.loadingData = true;
                }

                ga('send', 'event', 'AJAX Resource Loaded', window.location.hash, this.url, {


                    'dimension1': $rootScope.currentUser,
                    'dimension2': $rootScope.partner_name,
                    'dimension3': $rootScope.company,
                    'dimension4': this.status,
                    'dimension5': 'total time: ' + totalTime + ' milliseconds',
                    'dimension6':  $rootScope.partnerIdm
                });
            }

            return this._onreadystatechange.apply(this, arguments);
        }
    }


    XMLHttpRequest.prototype.open = function (a, b) {
        if (!a) {
            var a = '';
        }
        if (!b) {
            var b = '';
        }

        temp.origOpen.apply(this, arguments);
        temp.method = a;
        temp.url = b;

        if (a.toLowerCase() === 'get') {
            temp.data = b.split('?');
            temp.data = temp.data[1];
        }

    };

    XMLHttpRequest.prototype.send = function (a) {
        if (temp.method.toLowerCase() === 'post') {
            temp.data = a;
        }

        if (this.onreadystatechange) {
            this.url = temp.url;
            this.method = temp.method;
            this.data = temp.data;
            this._onreadystatechange = this.onreadystatechange;
        }

        this.onreadystatechange = onReadyStateChangeAugmented;

        temp.origSend.apply(this, arguments);

    };

    */

    //-----------------------------------seamless quickview code -------------------------------------------- --------
    //--------------------------------------------------------------------------------------------------------------

    LoginService.deferred.promise.then(function (result) {
        getLoggedInUserInformation();


        $rootScope.loginUserInformation = {};
        if (result.errorObject.errorMessage != null) {
            $rootScope.errorObject = result.errorObject;
            $location.path('msaErrorPage');
            $('#main-wrapper').removeClass('initial-hide');
            $('#main-header').removeClass('initial-hide');
            return;
        }
        if (result.quickViewMode) {
            $location.path('/bonds/qv/' + result.parameters.asset.cusip + '/seamlessQV/' + result.parameters.seamlessLink.partnercode);
            return;
        }
        if(result.loginUserDetail == null) {
            $rootScope.loginUserInformation.entitlements =  {};
            $rootScope.loginUserInformation.userDetails = {};
            $rootScope.loginUserInformation.userAuthenticationStatus ='';
        }
        EntitlementService.loadEnt();
        EntitlementService.deferred.promise.then(function(entResult){
            if(result.loginUserDetail != null ){
                $rootScope.loginUserInformation.entitlements =  entResult.admin;
                $rootScope.loginUserInformation.userDetails = result.loginUserDetail;
                $rootScope.loginUserInformation.userAuthenticationStatus = AUTH_EVENTS.loginSuccess
            }else{
                $rootScope.loginUserInformation.entitlements =  {};
                $rootScope.loginUserInformation.userDetails = {};
                $rootScope.loginUserInformation.userAuthenticationStatus = '';
            }
        });

        $('#main-wrapper').removeClass('initial-hide');
        $('#main-header').removeClass('initial-hide');
    });

    var loadUserInformation = function(){
        var loginUserDetail = userResourceResourceFactory.loginUserDetailsResource.getArrayReq();
        loginUserDetail.$promise.then(function(loginUser){
            if(loginUser.resourceList){
                EntitlementService.loadEnt();
                EntitlementService.deferred.promise.then(function(entResult){
                    $rootScope.loginUserInformation.entitlements =  entResult.admin;
                    $rootScope.loginUserInformation.userDetails = loginUser.resourceList;
                    $rootScope.loginUserInformation.userAuthenticationStatus = AUTH_EVENTS.loginSuccess
                });
            }
        });

    }

    var getLoggedInUserInformation = function(){
        $rootScope.currentUserData = userResourceResourceFactory.loginResource.getArrayReq({});
        $rootScope.currentUserCompany = userResourceResourceFactory.userCompanyResource.getArrayReq({});

        $rootScope.currentUserData.$promise.then(function (response) {

            if (response.resourceList !== null) {
                $rootScope.currentUser = response.resourceList.ERIGHTS_USERID;
                $rootScope.partner_name = response.resourceList.PARTNER_NAME;
            }

        });

        $rootScope.currentUserCompany.$promise.then(function (response) {

            if (response.resourceList !== null) {
                $rootScope.company = response.resourceList.COMPANY;

                $log.info('-----------------------------COMPANY: ' + response.resourceList.COMPANY);

                var  groupNm; var numOfSeperators=-1;
                var prefix="MSA_"+$rootScope.company;
                var  groupsArr = response.resourceList.GROUP.split(":");
                for (var i=0;i<groupsArr.length;i++){
                    var thisNumSeparator = (groupsArr[i].split("_").length - 1)
                    if (groupsArr[i].substring(0,prefix.length)==prefix && thisNumSeparator >numOfSeperators
                        ){
                        numOfSeperators =  thisNumSeparator;
                        groupNm=groupsArr[i];
                    }
                }
                $log.info('-----------------------------GROUP: ' +groupNm);
                $rootScope.partnerIdm=groupNm;

            }

        });
        $rootScope.$on('$routeChangeSuccess', function (angularEvent,
                                                        currentRoute) {

            $rootScope.startTime = new Date().getTime();

            var path = currentRoute.$$route.originalPath;
            var pathComponents = path.split('/');
            var realPath=$location.path();
            var realPathComponent=$location.path().split('/');


            // START OF GOOGLE ANALYTICS //
            $log.info('-----------------------------Username: ' + $rootScope.currentUser);
            $log.info('-----------------------------Partner Name: ' + $rootScope.partner_name);
            $log.info('-----------------------------Company: ' + $rootScope.company);
            $log.info('-----------------------------Partner IDM: ' + $rootScope.partnerIdm);
            ga('send', 'pageview', {
                'page': '/'+realPathComponent[1]+(realPathComponent[2]?'/':'')+(realPathComponent[2]||''),
                'title': 'My Page',
                'dimension1': $rootScope.currentUser,
                'dimension2': $rootScope.partner_name,
                'dimension3': $rootScope.company,
                'dimension6':$rootScope.partnerIdm
            });

            // END OF GOOGLE ANALYTICS //

            // START OF OMNITURE//

            s.linkTrackVars = 'pageName,prop1,eVar1,prop2,eVar2,prop3,eVar3,prop4,eVar4,prop15,eVar15';
            s.pageName='/'+realPathComponent[1]+(realPathComponent[2]?'/':'')+(realPathComponent[2]||'');
            s.eVar1=s.prop1=$rootScope.currentUser;
            s.eVar2=s.prop2=$rootScope.company;
            s.eVar3=s.prop3='Page';
            s.eVar4=s.prop4= (pathComponents[1]==='home'?'US Home':pathComponents[1]);  // ENTITLEMENT Stock, Marketscope, Funds
            s.eVar15=s.prop15=''; //  TICKER SYMBOL

            if(realPath.indexOf('stocks/details')!=-1 || realPath.indexOf('etf/details')!=-1 || realPath.indexOf('fund/details')!=-1)
            {
                $log.info('tracking ticker  :' + realPathComponent[4]);
                s.eVar15=s.prop15=realPathComponent[4]; //  TICKER SYMBOL

            }
            s.t();
            //s.tl(this, 'o', 'Content Share');
            //event.preventDefault(); // or return false here

            //END OF OMNITURE //
        });
    };


    $rootScope.trackGA = function(path){
        // Google anaytics code to track PDF downloaded
        $log.info('tracking GA');
        ga('send', 'pageview', {
            'page': path,
            'title': 'MSA PDF',
            'dimension1': $rootScope.currentUser,
            'dimension2': $rootScope.partner_name,
            'dimension3': $rootScope.company,
            'dimension6':$rootScope.partnerIdm
        });
        // Google Analytics Code ENDs
    };
});