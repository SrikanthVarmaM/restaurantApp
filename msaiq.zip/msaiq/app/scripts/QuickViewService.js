'use strict';


msaiqApp.factory('QuickViewService', function(createDialog, $log,bondsResourceFactory,ga,$rootScope,$location) {
    return {
        openETFQV: function(data){
            this.trackLinkOmniture(data.ticker,'/etf/etfQuickView','etf');
            createDialog('site/etf/etfQuickView/etfQuickView.html',{
                    id : 'ETFQuickView',
                    title:'',
                    headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                   // success: {label: 'Yay', fn: function() {console.log('Successfully closed complex modal');}},
                    controller: 'EtfQuickViewCtrl',

                    footerTemplate: '<div></div>' // default is a close button
                }, data

            );
        },
        openBondsQuickView: function(values){
            var self=this;
            var checkBondType = bondsResourceFactory.getBondTypeResource.get({cusip:values.cusip});
            checkBondType.$promise.then(function(response){
                if (response.type === "CORP")  {
                    self.openCorpBondsQV({cusip:values.cusip,active:response.active, partner:values.partner,source:values.source,user:values.user,company:values.company,partnerIdm:values.partnerIdm});
                } else if (response.type === "MUNI") {
                    self.openMuniBondsQV({cusip:values.cusip,active:response.active, partner:values.partner,source:values.source,user:values.user,company:values.company,partnerIdm:values.partnerIdm});
                }
                else  {
                    self.openMuniBondsQV({cusip:'',active:null,partner:""});
                }
            },
            function(error){
                self.openMuniBondsQV({cusip:'',active:null,partner: ""});
            });
        },
        openMuniBondsQV: function(data){
            this.trackLinkOmniture(data.cusip,'/bonds/bondsQV','bond');

            createDialog('site/bonds/bondsQV/municipalBonds/muniBondsQuickView.html',{
                    id : 'bondsQuickView',
                    title:'',
                    headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                    controller: 'MuniBondsQVCtrl',
                    footerTemplate: '<div></div>', // default is a close button
                    closeBrowser : data.mode === 'seamlessQV'
                }, data
            );
        },
        openCorpBondsQV: function(data){
            this.trackLinkOmniture(data.cusip,'/bonds/bondsQV','bond');

            createDialog('site/bonds/bondsQV/corporateBonds/corpBondsQuickView.html',{
                    id : 'bondsQuickView',
                    title:'',
                    headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                    controller: 'CorpBondsQVCtrl',
                    footerTemplate: '<div></div>', // default is a close button ,
                    closeBrowser : data.mode === 'seamlessQV'
                }, data
            );
        },
        openStockQV: function(data){
            this.trackLinkOmniture(data.ticker,'/stocks/stockQuickview','stock');

            createDialog('site/stocks/stockQuickview/stockQuickView.html',{
                    id : 'StockQuickView',
                    title:'',
                    headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                    // success: {label: 'Yay', fn: function() {console.log('Successfully closed complex modal');}},
                    controller: 'stockQuickViewCtrl',

                    footerTemplate: '<div></div>' // default is a close button
                }, data

            );
        },
        openQV: function(data){

            /* modelParam = 'sppwId: {{sppwId}}', ticker: '{{ticker}}', report_ind: 'qual/quant/none', type: 'etf || stock' */
            try {
            $log.debug('QVService opening : sppwId:' + data.sppwId + ', ticker: ' + data.ticker + ', report_ind: ' + data.report_ind + ', type: ' + data.type);

                if (data.type.toLowerCase() === 'etf' || data.type.toLowerCase() === 'e'  || data.type.toLowerCase() === 'exchange traded fund'){
                this.openETFQV(data);
                }else if (data.type.toLowerCase() === 'stock' || data.type.toLowerCase() === 's'  || data.type.toLowerCase() === 'stocks') {
                this.openStockQV(data);
            } else if (data.type.toLowerCase() === 'fund' ||  data.type.toLowerCase() === 'f' ||   data.type.toLowerCase() === 'funds') {
                    this.openFundsQV(data);
            }
                else if (data.type.toLowerCase() === 'bond' || data.type.toLowerCase() === 'b' ||  data.type.toLowerCase() === 'bonds') {
                    this.openBondsQuickView(data);
                }
            } catch(e){
                $log.debug("error in opening qv :parsing parameters ")  ;
            }

        },
        openAlertWindow: function (data) {
            createDialog('site/alert/alertEditWindow/alertEditWindowTemplate.html', {
                    id: 'editAlertSection',
                    title: '',
                    headerTemplate: '<h4 class="modal-title">{{headerText}} {{getName()}}</h4>',
                    headerCSSClass: 'sp-aurora-dark-background',
                    //headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                    // success: {label: 'Yay', fn: function() {console.log('Successfully closed complex modal');}},
                    controller: 'alertEditWindowController',
                   bodyCSSClass :'remove-padding-bottom' ,
                    footerTemplate: '<div > ' +

                        '<button ng-disabled="ifClearAllDisabled()" type="button" ng-click="clearAll()" class="btn  t2-button btn-xs clear-all-button">&nbsp;Clear All  </button>' +

                        '<button data-dismiss="modal" ng-disabled="ifDeletable()" type="button" class="btn btn-xs btn-danger extra-space-horiz float-right" ng-click="deleteAlertC()">' +
                        '<span class="glyphicon glyphicon-trash"></span>&nbsp;Delete  </button> ' +
                        '<button type="button" ng-disabled="ifClearAllDisabled()" ng-click="validateAndSave()" class="btn btn-xs btn-success float-right">' +
                        '<span    class="glyphicon glyphicon-floppy-save"></span>&nbsp;Save  </button>' +
                        '</div> ' // default is a close button
                },
                data
            );
        } ,
        openAlertConfirmWindow: function (data) {
            createDialog('site/alert/alertEditWindow/alertConfirmTmpl.html', {
                    id: 'confirmModal',
                    title: '',
                    headerTemplate: '<div></div>',
                    headerCSSClass: 'sp-aurora-dark-background',
                    //headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                     success: {label: 'Yes', fn: function() {
                         if (data.action === 'save') {
                             data.source.saveAlert();
                         } else {
                             data.source.deleteAlert();
                         }
                         }},
                   cancel: {label: 'No'},
                    controller: 'alertConfirmController',
                    bodyCSSClass :'remove-padding-bottom',
                    footerCSSClass:'padding-right-5',
                    modalClass : 'modal alert-modal-z' ,
                    backdropClass :  'modal-backdrop  alert-modal-backdrop-z'

                },
                data
            );
        },

        openFundsQV: function(data){
            this.trackLinkOmniture(data.ticker,'/funds/fundsQuickview','fund');
            createDialog('site/funds/fundsQuickView/fundsQuickView.html',{
                    id : 'fundsQuickView',
                    title:'',
                    headerImage: 'qv-header', // this is custom, indicates what's the css class after close button. like images
                    backdrop: true,
                    // success: {label: 'Yay', fn: function() {console.log('Successfully closed complex modal');}},
                    controller: 'fundsQuickViewCtrl',

                    footerTemplate: '<div></div>' // default is a close button
                },
                data
            );
        },
        trackLinkOmniture : function(ticker, url,entitlement){

            var realPath=$location.path();
            var realPathComponent=$location.path().split('/');


            ga('send', 'pageview', {
                'page': url,
                'title': 'My Page',
                'dimension1': $rootScope.currentUser,
                'dimension2': $rootScope.partner_name,
                'dimension3': $rootScope.company,
                'dimension6':$rootScope.partnerIdm
            });



            s.linkTrackVars = 'pageName,prop1,eVar1,prop2,eVar2,prop3,eVar3,prop4,eVar4,prop15,eVar15';
            s.pageName=url;
            s.eVar2=s.prop2=$rootScope.company;
            s.eVar3=s.prop3='Page';
            s.eVar4=s.prop4=(realPathComponent[1]==='home'?'US Home':realPathComponent[1]); // ENTITLEMENT Stock, Marketscope, Funds
            s.eVar15=s.prop15=ticker; //  TICKER SYMBOL
            s.eVar1=s.prop1=$rootScope.currentUser;
            s.t();

        }

    };
});