'use strict';
/*jshint unused: false */

msaiqApp.filter('fixAllCaps', function() {
  return function(input, scope) {
    if(input){
        // cz - for now have everything upper case
        return input.toUpperCase();
      //return input.toLowerCase().replace( /(^| )(\w)/g, function(x){return x.toUpperCase();} );
    }
    // fix S&p
    // fix stocks (aapl) = [AAPL]
    // fix acronyms. I.b.m
    // fix articles. a, the,
    // Mfri, Inc
    // eps Gaap
    // return input.substring(0,1).toUpperCase()+input.substring(1);
  };
});
