'use strict';
/**
 * Created with IntelliJ IDEA.
 * User: nkakkireni
 * Date: 1/16/14
 * Time: 4:37 PM
 * To change this template use File | Settings | File Templates.
 */
msaiqApp.filter('getCallFeature', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input, callFreq) {
        try {
            var call_feature =emptyCheckFilter(input,'-');
            if(call_feature != '-'){
                if (call_feature=== 'NONC')  {
                    call_feature = 'Non-Callable';
                }else if (call_feature === 'CALI' || call_feature === 'CALV' || call_feature === 'CALL') {
                    call_feature = 'Callable';
                } else {
                    call_feature = '-';
                }
                var   call_freq =emptyCheckFilter(callFreq,'-');
                // append call frequency
                if (call_freq != '-') {
                    if (call_freq === 'AT') {
                        call_feature = call_feature + ' Anytime';
                    } else if (call_freq === 'MO') {
                        call_feature = call_feature + ' Monthly';
                    } else if (call_freq === 'QU') {
                        call_feature = call_feature + ' Quarterly';
                    } else if (call_freq === 'SA') {
                        call_feature = call_feature + ' Semiannually';
                    } else if (call_freq === 'WK') {
                        call_feature = call_feature + ' Weekly';
                    } else if (call_freq === 'YR') {
                        call_feature = call_feature + ' Annually';
                    } else if (call_freq === 'TM') {
                        call_feature = call_feature + ' One Time';
                    }
                }
            } else{
                call_feature = '-';
            }

            return  call_feature;

        } catch (e) { return '-'   } ;
    };
});

msaiqApp.filter('amountFormat', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter');
    var roundToNDecimalFilter=$filter('roundToNDecimalFilter');
    return function(input) {
        try {
            var amount =emptyCheckFilter(input,'-');
            if(amount != '-'){
                var million = 1000000;
                var billion = 1000000000;
                var thousand = 1000;

                if (amount >= million && amount < billion) {
                    return roundToNDecimalFilter(amount / million, 2) + ' Mil.';
                } else if (amount >= billion) {
                    return roundToNDecimalFilter(amount / billion, 2) + ' Bil.';
                } else {
                    return roundToNDecimalFilter(amount / thousand, 2) + ' K.';
                }

            }else{
                amount = '-';
            }

            return  amount;

        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('bondType', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter');
    return function(input) {
        try {
            var type =emptyCheckFilter(input,'Data Unavailable');
            if(type != 'Data Unavailable'){
                if (type === 'CORP') {
                    return 'Corporate';
                } else if (type === 'GLOB') {
                    return 'Foreign';
                } else if (type === 'GOVT') {
                    return 'Government';
                } else if (type === 'MUNI') {
                    return 'Municipal';
                } else {
                    return type;
                }
            }
            return  type;

        } catch (e) { return '-';  }
    };
});
msaiqApp.filter('copunFreq', function(){
    return function(val) {
        try {
            if (val === 'SA') {
                return 'Semiannual';
            }
            if (val === 'MAT') {
                return 'At Maturity';
            }
            if (val === 'QU') {
                return 'Quarterly';
            }
            if (val === 'WK') {
                return 'Weekly';
            }
            if (val === 'MO') {
                return 'Monthly';
            }
            if (val === 'YR') {
                return 'Annual';
            }
            if (val === 'UNK') {
                return 'Unknown';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('ratingTitle', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data.standard_fc_lt_rating,'-') != '-') {
                return  'Foreign Long-Term';
            }
            else if (emptyCheckFilter(data.standard_lc_lt_rating,'-') != '-') {
                return  'Local Long-Term';
            }
            else if (emptyCheckFilter(data.standard_fc_st_rating,'-') != '-') {
                return  'Foreign Short-Term';
            }
            else if (emptyCheckFilter(data.standard_lc_st_rating,'-') != '-') {
                return  'Local Short-Term';
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('ratingDate', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data.standard_fc_lt_rating,'-') != '-') {
                return  data.standard_fc_lt_rating_dt;
            }
            else if (emptyCheckFilter(data.standard_lc_lt_rating,'-') != '-') {
                return  data.standard_lc_lt_rating_dt;
            }
            else if (emptyCheckFilter(data.standard_fc_st_rating,'-') != '-') {
                return data.standard_fc_st_rating_dt;
            }
            else if (emptyCheckFilter(data.standard_lc_st_rating,'-') != '-') {
                return  data.standard_lc_st_rating_dt;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('rating', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data.standard_fc_lt_rating,'-') != '-') {
                return data.standard_fc_lt_rating;
            }
            else if (emptyCheckFilter(data.standard_lc_lt_rating,'-') != '-') {
                return  data.standard_lc_lt_rating;
            }
            else if (emptyCheckFilter(data.standard_fc_st_rating,'-') != '-') {
                return  data.standard_fc_st_rating;
            }
            else if (emptyCheckFilter(data.standard_lc_st_rating,'-') != '-') {
                return data.standard_lc_st_rating;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('outlook', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            var retStringCr, retStringOl;
            if (emptyCheckFilter(data.standard_fc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_fc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.standard_fc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.standard_lc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_lc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.standard_lc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.standard_fc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_fc_stcw,'-');
                retStringOl = emptyCheckFilter(data.standard_fc_st_outlook,'-');
            }
            else if (emptyCheckFilter(data.standard_lc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_lc_stcw,'-');
                retStringOl = emptyCheckFilter(data.standard_lc_st_outlook,'-');

            } else {
                retStringCr = emptyCheckFilter(retStringCr,'-');
                retStringOl = emptyCheckFilter(retStringOl,'-');
            }
            if (retStringCr != 'NM' && retStringCr != '-') {
                return retStringCr;
            }
            else if (retStringOl != 'NM' && retStringOl != '-') {
                return retStringOl;
            }
            else if (retStringOl === 'NM') {
                return retStringOl;
            }
            else if (retStringCr === 'NM') {
                return retStringCr;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('outlookDate', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            var retStringCr, retStringOl;
            if (emptyCheckFilter(data.standard_fc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_fc_ltcw_dt,'-');
                retStringOl = emptyCheckFilter(data.standard_fc_lt_outlook_dt,'-');
            }
            else if (emptyCheckFilter(data.standard_lc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_lc_ltcw_dt,'-');
                retStringOl = emptyCheckFilter(data.standard_lc_lt_outlook_dt,'-');
            }
            else if (emptyCheckFilter(data.standard_fc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_fc_stcw_dt,'-');
                retStringOl = emptyCheckFilter(data.standard_fc_st_outlook_dt,'-');
            }
            else if (emptyCheckFilter(data.standard_lc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_lc_stcw_dt,'-');
                retStringOl = emptyCheckFilter(data.standard_lc_st_outlook_dt,'-');

            } else {
                retStringCr = emptyCheckFilter(retStringCr,'-');
                retStringOl = emptyCheckFilter(retStringOl,'-');
            }
            if (retStringCr != 'NM' && retStringCr != '-') {
                return retStringCr;
            }
            else if (retStringOl != 'NM' && retStringOl != '-') {
                return retStringOl;
            }
            else if (retStringOl === 'NM') {
                return retStringOl;
            }
            else if (retStringCr === 'NM') {
                return retStringCr;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});
msaiqApp.filter('getSeniority', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input) {
        try {
            var   input =emptyCheckFilter(input,'-');
            if (input != '-') {
                if (input === "JR") {
                    return "Junior";
                }
                else if (input == "JS") {
                    return "Junior Subordinate";
                }
                else if (input == "SR") {
                    return "Senior";
                }
                else if (input == "SS") {
                    return "Senior Subordinate";
                }
                else if (input == "SU") {
                    return "Subordinate";
                }
            } else{
                return '-';
            }
        } catch (e) { return '-'   } ;
    };
});

msaiqApp.filter('ratingTypeIssue', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data,'-') === '-') {
                return 'EMPTY_DATA';
            }
            var retStringCr, retStringOl;
            if (emptyCheckFilter(data.standard_fc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_fc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.standard_fc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.standard_lc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_lc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.standard_lc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.standard_fc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_fc_stcw,'-');
                retStringOl = emptyCheckFilter(data.standard_fc_st_outlook,'-');
            }
            else if (emptyCheckFilter(data.standard_lc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.standard_lc_stcw,'-');
                retStringOl = emptyCheckFilter(data.standard_lc_st_outlook,'-');
            }
            else {
                retStringCr = emptyCheckFilter(retStringCr,'-');
                retStringOl = emptyCheckFilter(retStringOl,'-');
            }
            if (retStringCr != 'NM' && retStringCr != '-') {
                return 'CreditWatch';
            }
            else if (retStringOl != 'NM' && retStringOl != '-') {
                return 'Outlook';
            }
            else if (retStringOl === 'NM') {
                return 'Outlook';
            }
            else if (retStringCr === 'NM') {
                return 'CreditWatch';
            }
            else {
                return 'EMPTY_STRING';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('ratingTypeIssuer', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data,'-') === '-') {
                return 'EMPTY_DATA';
            }
            var retStringCr, retStringOl;
            if (emptyCheckFilter(data.icr_fc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_fc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.icr_fc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.icr_lc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_lc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.icr_lc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.icr_fc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_fc_stcw,'-');
                retStringOl = emptyCheckFilter(data.icr_fc_st_outlook,'-');
            }
            else if (emptyCheckFilter(data.icr_lc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_lc_stcw,'-');
                retStringOl = emptyCheckFilter(data.icr_lc_st_outlook,'-');
            } else {
                retStringCr = emptyCheckFilter(retStringCr,'-');
                retStringOl = emptyCheckFilter(retStringOl,'-');
            }
            if (retStringCr != 'NM' && retStringCr != '-') {
                return 'CreditWatch';
            }
            else if (retStringOl != 'NM' && retStringOl != '-') {
                return 'Outlook';
            }
            else if (retStringOl === 'NM') {
                return 'Outlook';
            }
            else if (retStringCr === 'NM') {
                return 'CreditWatch';
            }
            else {
                return 'EMPTY_STRING';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('outlookHeaderText', function($filter){
    return function(data) {
        try {
            var ratingTitle = $filter('ratingTitle');
            var ratingIssue = $filter('ratingTypeIssue');
            var ratingIssuer = $filter('ratingTypeIssuer');

            if (ratingTitle(data) === 'Foreign Short-Term' || ratingTitle(data) === 'Local Short-Term') {
                if (ratingTitle(data) === 'Foreign Short-Term' || ratingTitle === 'Local Short-Term') {
                    return 'CreditWatch/' + '<br>' + 'Outlook';
                }
            }
            if (ratingIssue(data) != 'EMPTY_STRING' && ratingIssuer(data) === ratingIssue(data)) {
                return ratingIssuer(data);
            }
            if (ratingIssue(data) === 'EMPTY_STRING' && ratingIssuer(data) != 'EMPTY_STRING') {
                return ratingIssuer(data);
            }
            if (ratingIssuer(data) === 'EMPTY_STRING' && ratingIssue(data) != 'EMPTY_STRING') {
                return ratingIssue(data);
            }
            return 'CreditWatch/' + '<br>' + 'Outlook';
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('outlookDateHeaderText', function($filter){
    return function(data) {
        try {
            var ratingTitle = $filter('ratingTitle');
            var ratingIssue = $filter('ratingTypeIssue');
            var ratingIssuer = $filter('ratingTypeIssuer');

            if (ratingTitle(data) === 'Foreign Short-Term' || ratingTitle(data) === 'Local Short-Term') {
                if (ratingTitle(data) === 'Foreign Short-Term' || ratingTitle === 'Local Short-Term') {
                    return 'CreditWatch/' + '<br>' + 'Outlook Date';
                }
            }
            if (ratingIssue(data) != 'EMPTY_STRING' && ratingIssuer(data) === ratingIssue(data)) {
                return ratingIssuer(data) + ' Date';
            }
            if (ratingIssue(data) === 'EMPTY_STRING' && ratingIssuer(data) != 'EMPTY_STRING') {
                return ratingIssuer(data) + ' Date';
            }
            if (ratingIssuer(data) === 'EMPTY_STRING' && ratingIssue(data) != 'EMPTY_STRING') {
                return ratingIssue(data) + ' Date';
            }

            return 'CreditWatch/' + '<br>' + 'Outlook Date';
        } catch (e) { return '-';  }
    };
});



msaiqApp.filter('newsType', function(){
    return function(val) {
        try {
            if (val === 'SUMMARY_ANALYSIS') {
                return 'Analysis';
            } else if (val === 'RATING_ACTION') {
                return 'Rating Action';
            } else if (val === 'COMMENTS') {
                return 'Commentary'
            } else if(val === 'BULLETIN'){
                return 'Bulletins';
            }
        } catch (e) { return '-';  }
    };
});
msaiqApp.filter('getPutFeature', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    var putFeatureMappingFilter=$filter('getPutFeatureMapping');
    var checkExpiredFilter=$filter('checkExpired');
    return function(input) {
        try {
            if(emptyCheckFilter(input,'-') != '-'){
                return '-';
            }
            // check for put schedule
            if ((emptyCheckFilter(input.put_schedule_exists,'-') != '-') && (emptyCheckFilter(input.put_schedule,'-') != '-') &&(input.put_schedule_exists == 'Y')) {
                // zero rows
                if (input.put_schedule.length < 1 || (emptyCheckFilter(input.put_schedule[0].put_type,'-') === '-')) {
                    return '-';
                }

                // more than one row, check for values: distinct array will be done in the backend
                var distinct_count = 1;
                var distinct_index = 0;
                var expired_count = 0;

                // sort it - need to verify sort on which field
                input.put_schedule.sort();

                var val_length = input.put_schedule.length;

                for (var i = 0; i < val_length; i++) {
                    if ((emptyCheckFilter(input.put_schedule[i].put_type,'-') != '-')  && !checkExpiredFilter(input.put_schedule[i].put_end_date)) {

                        if (i + 1 < val_length) {
                            // check for distinct  , on next
                            if ((input.put_schedule[i].put_type != input.put_schedule[i + 1].put_type) ||
                                (input.put_schedule[i].put_frequency_code != input.put_schedule[i + 1].put_frequency_code) ||
                                (input.put_schedule[i].put_price != input.put_schedule[i + 1].put_price)) {
                                // future rows are same type, freq and price
                                distinct_count++;
                            } else {
                                // same one, set pointer
                                distinct_index = i;
                            }
                        }
                    } else {
                        expired_count++;
                    }
                }

                if (distinct_count == 1 && expired_count < val_length) {
                    // only one distinct
                    return  putFeatureMappingFilter(input.put_schedule[distinct_index].put_type, input.put_schedule[distinct_index].put_frequency_code);
                } else if (distinct_count > 1) {
                    // only one are not expired, return that value
                    return 'Puts Exists';
                } else {
                    // all are expired
                    return '-';
                }
            }else {
                // all are expired
                return '-';
            }

        } catch (e) { return '-' ;  } ;
    };
});
msaiqApp.filter('getPutFeatureMapping', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input, put_frequency) {
        try {
            var put_feature =emptyCheckFilter(input,'-');
            if(put_feature != '-'){
                if (input === 'PUTL' || input === 'PTOL' || input === 'PTSL' || input === 'PTVL') {
                    put_feature = 'Limited Put';
                } else if (input === 'PUTR') {
                    put_feature = 'Repurchase Put';
                } else if (input === 'PUTM' || input === 'PTSM' || input === 'PTOM') {
                    put_feature = 'Mandatory Put';
                } else if (input === 'PTVM') {
                    put_feature = 'Var Mandatory Put';
                } else if (input === 'PUTO' || input === 'PTOO' || input === 'PTSO') {
                    put_feature = 'Optional Put';
                } else if (input == 'PTVO') {
                    put_feature = 'Var Optional Put';
                } else if (input === 'PUTC' || input === 'PTSC' || input === 'PTOC') {
                    put_feature = 'Conditional Put';
                } else {
                    put_feature = '';
                }
            }
            var put_frequency =emptyCheckFilter(put_frequency,'-');
            if(put_frequency != '-'){
                if (put_frequency === '1DY') {
                    put_feature = put_feature + ' Daily';
                } else if (put_frequency === '1MO') {
                    put_feature = put_feature + ' Monthly';
                } else if (put_frequency === 'YR') {
                    put_feature = put_feature + ' Annually';
                } else if (put_frequency === 'QU') {
                    put_feature = put_feature + ' Quarterly';
                } else if (put_frequency === 'SA') {
                    put_feature = put_feature + ' Semiannually';
                } else if (put_frequency === 'TM') {
                    put_feature = put_feature + ' One Time';
                } else if (put_frequency.search(/[2-9](DY|YR|MO)/) >= 0) {
                    // validate format with '@'    #DY #MO #YR         where # = [2-9]
                    // remove the last two char to get the values
                    var freqtype = put_frequency.substring(put_frequency.length - 2, put_frequency.length);
                    var freqNum = put_frequency.substring(0, put_frequency.length - 2);
                    if (freqtype === 'DY') {
                        put_feature = put_feature + ' Every ' + freqNum + ' Days';
                    } else if (freqtype === 'MO') {
                        put_feature = put_feature + ' Every ' + freqNum + ' Mths';
                    } else if (freqtype === 'YR') {
                        put_feature = put_feature + ' Every ' + freqNum + ' Yrs';
                    }
                }
            }
            else{
            put_feature = '-';
            }

            return  put_feature;

        } catch (e) { return '-'   } ;
    };
});



msaiqApp.filter('bondsClassType', function(){
    return function(data) {
        try {
            if (data === "AUTH") { return "Authority";
            } else if (data === "BAN") { return "Bond Anticipation Note";
            } else if (data === "BLDG") { return "Building";
            }else if (data === "CAP") { return "Capital Loan Notes";
            }else if (data === "COPS") { return "Certificates Of Participation";
            }else if (data === "CP") { return "Corporate Purpose";
            }else if (data === "DRAN") { return "Drainage District ";
            }else if (data === "EDR"){ return "Economic Development Revenue";}
            else if (data === "EDUC"){ return "Education";}
            else if (data === "ENVR"){ return "Environment";}
            else if (data === "EQPT"){ return "Equipment";}
            else if (data === "FED"){ return "Federal Aid Note";}
            else if (data === "FIRE"){ return "Fire District";}
            else if (data === "FLWD"){ return "Flood, Water, Sewer Disposal";}
            else if (data === "GAME"){ return "Racetrack/Casino";}
            else if (data === "GP"){ return "General Purpose";}
            else if (data === "GRNT"){ return "Grant Anticipation Note";}
            else if (data === "HLTH"){ return "Health";}
            else if (data === "HSG"){ return "Housing";}
            else if (data === "IDR"){ return "Industrial Development Revenue";}
            else if (data === "IMPT"){ return "Improvement";}
            else if (data === "LIBR"){ return "Library District";}
            else if (data === "MET"){ return "Metropolitan District";}
            else if (data === "MISC"){ return "Miscellaneous";}
            else if (data === "MUBB"){ return "Municipal Bond Bank";}
            else if (data === "MUD"){ return "Municipal Utilities District";}
            else if (data === "PARK"){ return "Park District";}
            else if (data === "PKG"){ return "Parking Authority";}
            else if (data === "PCR"){ return "Pollution Control Revenue";}
            else if (data === "PHA"){ return "Public Housing Authority";}
            else if (data === "POOL"){ return "Pool Financing Authority";}
            else if (data === "PROM"){ return "Promissory Note";}
            else if (data === "PUD"){ return "Public Utility District";}
            else if (data === "RAN"){ return "Revenue Anticipation Note";}
            else if (data === "REC"){ return "Recreation Authority";}
            else if (data === "SAN"){ return "Sanitation District";}
            else if (data === "SCH"){ return "School District";}
            else if (data === "SPAS"){ return "Special Assessment";}
            else if (data === "SPLO"){ return "Special Obligation";}
            else if (data === "STAN"){ return "State Anticipation Notes";}
            else if (data === "STFD"){ return "State & Federal Anticipation Note";}
            else if (data === "STGR"){ return "State & Grant Anticipation Note";}
            else if (data === "STOR"){ return "State Store";}
            else if (data === "TAN"){ return "Tax Anticipation Note";}
            else if (data === "TAX"){ return "Tax-Revenue";}
            else if (data === "TEMP"){ return "Temporary Notes";}
            else if (data === "TRAN"){ return "Transportation";}
            else if (data === "TRIB"){ return "Tribal Bonds";}
            else if (data === "TRN"){ return "Tax & Revenue Anticipation";}
            else if (data === "UTIL"){ return "Utility";}
            else if (data === "VET"){ return "Veterans";}
            else if (data === "VP"){ return "Various Purpose";}
            else if (data === "WARR"){ return "Warrants";}
            else {
                return "-";
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('bondsSubClassType', function(){
    return function(data) {
        try {
            if (data === "ACUT"){ return "Acute Care";}
            else if (data === "AIR"){ return "Airline/Airport";}
            else if (data === "AIRC"){ return "Aircraft (Mnfc/Supplies)";}
            else if (data === "AIRT"){ return "Air Transport";}
            else if (data === "ALLC"){ return "Tax Allocation";}
            else if (data === "ASST"){ return "Assisted Living";}
            else if (data === "ATMS"){ return "Atmosphere/Space";}
            else if (data === "AUTH"){ return "Authority";}
            else if (data === "AUTO"){ return "Automotive (Mnfc/Supplies)";}
            else if (data === "BLDG"){ return "Building";}
            else if (data === "BLSU"){ return "Building Supplies";}
            else if (data === "BUS"){ return "Bus";}
            else if (data === "CCRC"){ return "Continuing Care Retirement Center";}
            else if (data === "CEMT"){ return "Cement";}
            else if (data === "CFAC"){ return "Correctional Facility";}
            else if (data === "CHEM"){ return "Chemical";}
            else if (data === "CNST"){ return "Construction";}
            else if (data === "COLL"){ return "College";}
            else if (data === "COMB"){ return "Combined";}
            else if (data === "COMP"){ return "Computer (Mnfc/Supplies)";}
            else if (data === "CONV"){ return "Convention Center";}
            else if (data === "DELQ"){ return "Delinquent (Property Tax)";}
            else if (data === "DEV"){ return "Development";}
            else if (data === "DIST"){ return "District";}
            else if (data === "EDR"){ return "Economic Development";}
            else if (data === "EDUC"){ return "Education";}
            else if (data === "ELEC"){ return "Electric";}
            else if (data === "ENGY"){ return "Energy Conservation";}
            else if (data === "ENVR"){ return "Environment";}
            else if (data === "EQPT"){ return "Equipment";}
            else if (data === "EXIT"){ return "Excise Tax (Sales, Beer, Luxury)";}
            else if (data === "FAC"){ return "Facility";}
            else if (data === "FF"){ return "Freight Forwarding";}
            else if (data === "FINL"){ return "Financial";}
            else if (data === "FIRE"){ return "Fire";}
            else if (data === "FLD"){ return "Flood";}
            else if (data === "FOOD"){ return "Food Products";}
            else if (data === "FRAN"){ return "Franchise Tax";}
            else if (data === "FURN"){ return "Furniture";}
            else if (data === "GAME"){ return "Gaming";}
            else if (data === "GAS"){ return "Natural Gas";}
            else if (data === "GOLF"){ return "Golf";}
            else if (data === "GU"){ return "General Utility";}
            else if (data === "HARB"){ return "Harbor/Channel";}
            else if (data === "HLTH"){ return "Health";}
            else if (data === "HOSP"){ return "Hospital";}
            else if (data === "HSG"){ return "Housing";}
            else if (data === "HTL"){ return "Hotel/Motel/Inn";}
            else if (data === "HWY"){ return "Highway (no toll is paid)";}
            else if (data === "IDR"){ return "Industrial Development";}
            else if (data === "IMPT"){ return "Improvement";}
            else if (data === "LAND"){ return "Preservation/Conservation";}
            else if (data === "LEAS"){ return "Lease";}
            else if (data === "LIFE"){ return "Life Care";}
            else if (data === "LIQ­"){ return "Liquor (Ohio)";}
            else if (data === "LUMB"){ return "Lumber";}
            else if (data === "MALL"){ return "Mall";}
            else if (data === "MASS"){ return "Mass Transit";}
            else if (data === "METL"){ return "Metal (Mnfc/Supplies)";}
            else if (data === "MING"){ return "Mining";}
            else if (data === "MNFC"){ return "Manufacturing";}
            else if (data === "MTR"){ return "Motor";}
            else if (data === "MULT"){ return "Multi-family";}
            else if (data === "MUNI"){ return "Municipal";}
            else if (data === "NONP"){ return "Non-profit";}
            else if (data === "NUCL"){ return "Nuclear";}
            else if (data === "NURS"){ return "Nursing Home";}
            else if (data === "OFF"){ return "Office";}
            else if (data === "OILG"){ return "Oil/Gas";}
            else if (data === "OSTE"){ return "Osteopathic";}
            else if (data === "PA"){ return "Port Authority";}
            else if (data === "PCR"){ return "Pollution Control";}
            else if (data === "PFAC"){ return "Public Facilities Authority";}
            else if (data === "PFIN"){ return "Public Finance Authority";}
            else if (data === "PHAR"){ return "Pharmaceutical";}
            else if (data === "PKG"){ return "Parking Authority/Garage";}
            else if (data === "PLAS"){ return "Plastics";}
            else if (data === "POOL"){ return "Pool/Loan";}
            else if (data === "PPR"){ return "Paper/Forest Products";}
            else if (data === "PRIV"){ return "Private College";}
            else if (data === "PSYC"){ return "Psychiatric";}
            else if (data === "PUB"){ return "Public University";}
            else if (data === "PUBL"){ return "Publishing";}
            else if (data === "PWR"){ return "Power";}
            else if (data === "PWRU"){ return "Public Power/Utility";}
            else if (data === "RAIL"){ return "Railroad";}
            else if (data === "RE"){ return "Real Estate";}
            else if (data === "REC"){ return "Recreational Facility";}
            else if (data === "RECL"){ return "Recycling";}
            else if (data === "REDV"){ return "Redevelopment";}
            else if (data === "REHA"){ return "Rehabilitation";}
            else if (data === "REST"){ return "Restaurant";}
            else if (data === "ROAD"){ return "Roadway/Street";}
            else if (data === "RSRC"){ return "Resource Recovery";}
            else if (data === "RST"){ return "Restaurant";}
            else if (data === "RTL"){ return "Retail";}
            else if (data === "RUBB"){ return "Rubber";}
            else if (data === "SCH"){ return "School";}
            else if (data === "SERV"){ return "Services";}
            else if (data === "SHIP"){ return "Shipping";}
            else if (data === "SING"){ return "Single-family";}
            else if (data === "SMKT"){ return "Supermarket";}
            else if (data === "SPL"){ return "Special Tax (i.e. California, neither unlimited or limited tax)";}
            else if (data === "SRHG"){ return "Senior housing";}
            else if (data === "STAD"){ return "Stadium";}
            else if (data === "STL"){ return "Steel";}
            else if (data === "STUD"){ return "Student Loan";}
            else if (data === "SWD"){ return "Solid Waste Disposal";}
            else if (data === "SWR"){ return "Sewer";}
            else if (data === "SYST"){ return "Hospital System Bonds";}
            else if (data === "TAXI"){ return "Tax Increment";}
            else if (data === "TECH"){ return "Technology";}
            else if (data === "TELE"){ return "Telecommunication";}
            else if (data === "TERM"){ return "Marine Terminal";}
            else if (data === "TOB"){ return "Tobacco";}
            else if (data === "TOBA"){ return "State Appropriated Tobacco";}
            else if (data === "TOLL"){ return "Bridge & Toll Road";}
            else if (data === "TPK"){ return "Turnpike";}
            else if (data === "TRAN"){ return "Transportation";}
            else if (data === "TRUC"){ return "Trucking";}
            else if (data === "UNIV"){ return "University";}
            else if (data === "UTIL"){ return "Utility";}
            else if (data === "VP"){ return "Various Purpose";}
            else if (data === "WTR"){ return "Water";}
                else {return "-";}
        } catch (e) { return '-';  }
    };
});


msaiqApp.filter('bondsPurposeType', function(){
    return function(data) {
        try {
            if (data === "GO") {
                return "General obligation";
            } else if (data === "DB") {
                return "Double barrel";
            } else if (data === "REV") {
                return "Revenue";
            } else {
                return "-";
            }
        } catch (e) { return '-';  }
    };
});
msaiqApp.filter('getSPRatingIssuer', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input) {
        try {
            if(emptyCheckFilter(input,'-') != '-'){
                if (emptyCheckFilter(input.icr_fc_lt_rating,'-') != '-') {
                    return input.icr_fc_lt_rating;
                }else if (emptyCheckFilter(input.icr_lc_lt_rating,'-') != '-') {
                    return input.icr_lc_lt_rating;
                }else if (emptyCheckFilter(input.icr_fc_st_rating,'-') != '-') {
                    return input.icr_fc_st_rating;
                }else if (emptyCheckFilter(input.icr_lc_st_rating,'-') != '-') {
                    return input.icr_lc_st_rating;
                }else {
                    return '-';
                }
            }else {
                return '-';
            }
        } catch (e) { return '-' ;  } ;
    };
});
msaiqApp.filter('getSectorName', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input) {
        try {
            if (emptyCheckFilter(input.gics_sector_name) != '-') {
                return input.gics_sector_name;
            }
            else if (emptyCheckFilter(input.ultimate_parent_gics_sector_name)){
              return  input.ultimate_parent_gics_sector_name
            }else {
                return "-";
            }

        } catch (e) { return '-' ;  } ;
    };
});
msaiqApp.filter('getIndustryName', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input) {
        try {
            if (emptyCheckFilter(input.gics_industry_name) != '-') {
                return input.gics_industry_name;
            }
            else if (emptyCheckFilter(input.ultimate_parent_gics_industry_name)){
                return  input.ultimate_parent_gics_industry_name
            }else {
                return "-";
            }

        } catch (e) { return '-' ;  } ;
    };
});

msaiqApp.filter('getCreditWatchIssuer', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input) {
        try {
            if (emptyCheckFilter(input.icr_fc_ltcw,'-') != '-') {
                return input.icr_fc_ltcw;
            }else if (emptyCheckFilter(input.icr_lc_ltcw,'-') != '-') {
                return input.icr_lc_ltcw;
            }else if (emptyCheckFilter(input.icr_fc_stcw,'-') != '-') {
                return input.icr_fc_stcw;
            }else if (emptyCheckFilter(input.icr_lc_stcw,'-') != '-') {
                return input.icr_lc_stcw;
            }else {
                return '-';
            }
        } catch (e) { return '-' ;  } ;
    };
});
msaiqApp.filter('getOutlookIssuer', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(input) {
        try {
            if (emptyCheckFilter(input.icr_fc_lt_outlook,'-') != '-') {
                return input.icr_fc_lt_outlook;
            }else if (emptyCheckFilter(input.icr_lc_lt_outlook,'-') != '-') {
                return input.icr_lc_lt_outlook;
            }else if (emptyCheckFilter(input.icr_fc_st_outlook,'-') != '-') {
                return input.icr_fc_st_outlook;
            }else if (emptyCheckFilter(input.icr_lc_st_outlook,'-') != '-') {
                return input.icr_lc_st_outlook;
            }else {
                return '-';
            }
        } catch (e) { return '-' ;  } ;
    };
});
msaiqApp.filter('getCDSPrice', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    var roundToNDecimalFilter=$filter('roundToNDecimalFilter');
    var msadatefilter=$filter('msadatefilter');
    return function(input) {
        try {
            if ((emptyCheckFilter(input.mv1_price,'-') != '-') && (emptyCheckFilter(input.mv1_price_date,'-') != '-')) {
                return roundToNDecimalFilter(input.mv1_price , 2) + '@' + msadatefilter(input.mv1_price_date,'dd-MMM-yyyy');;
            }else {
                return '-';
            }
        } catch (e) { return '-' ;  } ;
    };
});
msaiqApp.filter('issuer_key_ratio_date', function($filter) {

    return function(d) {
        try {
            var dtArr= d.split(" ");
            var d1= dtArr[0]+"-"+dtArr[1]+"-"+dtArr[2];
            d = Date.parse(d1);
            d= new Date(d);//hate to do this but microsoftajax.js is overriding date format method
            var partialMonth = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            return d.getDate()+"-"+ partialMonth[d.getMonth()]+"-"+ d.getFullYear() ;

        } catch (e) { return '-' ;  } ;
    };
});




msaiqApp.filter('ratingIssuerTitle', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data.icr_fc_lt_rating,'-') != '-') {
                return  'Foreign Long-Term';
            }
            else if (emptyCheckFilter(data.icr_lc_lt_rating,'-') != '-') {
                return  'Local Long-Term';
            }
            else if (emptyCheckFilter(data.icr_fc_st_rating,'-') != '-') {
                return  'Foreign Short-Term';
            }
            else if (emptyCheckFilter(data.icr_lc_st_rating,'-') != '-') {
                return  'Local Short-Term';
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('ratingIssuerDate', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data.icr_fc_lt_rating,'-') != '-') {
                return  data.icr_fc_lt_rating_date;
            }
            else if (emptyCheckFilter(data.icr_lc_lt_rating,'-') != '-') {
                return  data.icr_lc_lt_rating_date;
            }
            else if (emptyCheckFilter(data.icr_fc_st_rating,'-') != '-') {
                return data.icr_fc_st_rating_date;
            }
            else if (emptyCheckFilter(data.icr_lc_st_rating,'-') != '-') {
                return  data.icr_lc_st_rating_date;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('ratingIssuer', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            if (emptyCheckFilter(data.icr_fc_lt_rating,'-') != '-') {
                return data.icr_fc_lt_rating;
            }
            else if(emptyCheckFilter(data.icr_lc_lt_rating,'-') != '-') {
                return  data.icr_lc_lt_rating;
            }
            else if(emptyCheckFilter(data.icr_fc_st_rating,'-') != '-') {
                return data.icr_fc_st_rating;
            }
            else if(emptyCheckFilter(data.icr_lc_st_rating,'-') != '-') {
                return data.icr_lc_st_rating;
            }else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('outlookIssuer', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            var retStringCr, retStringOl;
            if (emptyCheckFilter(data.icr_fc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_fc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.icr_fc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.icr_lc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_lc_ltcw,'-');
                retStringOl = emptyCheckFilter(data.icr_lc_lt_outlook,'-');
            }
            else if (emptyCheckFilter(data.icr_fc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_fc_stcw,'-');
                retStringOl = emptyCheckFilter(data.icr_fc_st_outlook,'-');
            }
            else if (emptyCheckFilter(data.icr_lc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_lc_stcw,'-');
                retStringOl = emptyCheckFilter(data.icr_lc_st_outlook,'-');
            }
            else{
                retStringCr = emptyCheckFilter(retStringCr,'-');
                retStringOl = emptyCheckFilter(retStringOl,'-');
            }
            if (retStringCr != 'NM' && retStringCr != '-') {
                return retStringCr;
            }
            else if (retStringOl != 'NM' && retStringOl != '-') {
                return retStringOl;
            }
            else if (retStringOl === 'NM') {
                return retStringOl;
            }
            else if (retStringCr === 'NM') {
                return retStringCr;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});

msaiqApp.filter('outlookIssuerDate', function($filter){
    return function(data) {
        try {
            var emptyCheckFilter=$filter('emptyCheckFilter');
            var retStringCr, retStringOl;
            if (emptyCheckFilter(data.icr_fc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_fc_ltcw_date,'-');
                retStringOl = emptyCheckFilter(data.icr_fc_lt_outlook_date,'-');
            }
            else if (emptyCheckFilter(data.icr_lc_lt_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_lc_ltcw_date,'-');
                retStringOl = emptyCheckFilter(data.icr_lc_lt_outlook_date,'-');
            }
            else if (emptyCheckFilter(data.icr_fc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_fc_stcw_date,'-');
                retStringOl = emptyCheckFilter(data.icr_fc_st_outlook_date,'-');
            }
            else if (emptyCheckFilter(data.icr_lc_st_rating,'-') != '-') {
                retStringCr = emptyCheckFilter(data.icr_lc_stcw_date,'-');
                retStringOl = emptyCheckFilter(data.icr_lc_st_outlook_date,'-');

            } else {
                retStringCr = emptyCheckFilter(retStringCr,'-');
                retStringOl = emptyCheckFilter(retStringOl,'-');
            }
            if (retStringCr != 'NM' && retStringCr != '-') {
                return retStringCr;
            }
            else if (retStringOl != 'NM' && retStringOl != '-') {
                return retStringOl;
            }
            else if (retStringOl === 'NM') {
                return retStringOl;
            }
            else if (retStringCr === 'NM') {
                return retStringCr;
            }
            else {
                return '-';
            }
        } catch (e) { return '-';  }
    };
});