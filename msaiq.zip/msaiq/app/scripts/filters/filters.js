'use strict';
/*jshint unused: false */

msaiqApp.filter('findEntityType', function() {
    return function(typeValue) {
        typeValue = escape(typeValue);
        if (typeValue.toLowerCase() === 'etf' || typeValue.toLowerCase() === 'etfs'  || typeValue.toLowerCase() === 'e'  ){
            return 'ETF';
        } else if (typeValue.toLowerCase() === 'stock' || typeValue.toLowerCase() === 'stocks'  || typeValue.toLowerCase() === 's'  ){
            return 'STOCKS';
        } else if (typeValue.toLowerCase() === 'fund' || typeValue.toLowerCase() === 'FUNDS'  || typeValue.toLowerCase() === 'f'  ){
            return 'FUND';
        }  else if (typeValue.toLowerCase() === 'bond' || typeValue.toLowerCase() === 'BONDS'  || typeValue.toLowerCase() === 'b'  ){
            return 'BOND';
        } else{
            return (typeValue || '');
        }
    };
});

msaiqApp.filter('unique', function() {
    return function (arr, field) {
        return _.uniq(arr, function(a) { return a[field]; });
    };
});

msaiqApp.filter('articleCodeText', function() {
    return function(articleCode) {

        if (articleCode === 'MOVER' ){
            return 'MARKETMOVERS';
        } else if(articleCode === 'SVIEW'){
            return 'BROKER VIEWS & NEWS';
        } else if(articleCode === 'RNOTS'){
            return 'RESEARCH NOTES';
        }else if(articleCode === 'FEOM'){
            return 'FOCUS ETF OF THE MONTH';
        }else if(articleCode === 'FSOW'){
            return 'FOCUS STOCK OF THE WEEK';
        }else if (articleCode === 'TREND'){
              return 'TRENDS & IDEAS';
        }else if (articleCode === 'ECRCM'){
            return 'STREET TALK';
        }else if (articleCode === 'ECOCL'){
            return 'ECONOMY WATCH';
        }else {
            return (articleCode || '');
        }
    };
});
msaiqApp.filter('sortOnYear', function() {
    return function(input,field) {
        if (input === null || typeof (input) === 'undefined') {
            return input;
        }
        var  compare =function(a,b) {
            if (a.year < b.year)
                return 1;
            if (a.year > b.year)
                return -1;
            return 0;
        }

        input.sort(compare);
        return input;

    }
});
msaiqApp.filter('isEmptyArray', function() {
    return function(data) {
        if (data === null) {
            return true;
        }
        else if (typeof(data) === 'undefined') {
            return true;
        }
        else if (data.length === 0) {
            return true;
        }
        else {
            return false   ;
        }


    }
});
msaiqApp.filter('changeDateFormat', function() {
    return function(date, format) {
        try{

            var getDateObject=function(date) { var fullMonth = [ ' ','January', 'February', 'March', 'April', 'May', 'June', 'July',
                'August', 'September', 'October', 'November', 'December'];

                try {
                    var d = date.split('T')[0];
                    if (d ===date)  {
                        d =  date.split(' ')[0];
                    }
                    d = d.split('-');
                    var strDate = d[2];
                    var strMonth = d[1];
                    var strYear = d[0];
                    var intMonth = parseFloat(strMonth);

                    var dateString = fullMonth[intMonth] + ' ' + strDate + ', ' + strYear;

                    return new Date(dateString);

                } catch (e) {
                    return date;
                }} ;


            var partialMonth = [ ' ','Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var fullMonth = [ ' ','January', 'February', 'March', 'April', 'May', 'June', 'July',
                'August', 'September', 'October', 'November', 'December'];
            if (date && date != '' && date != 'Data Unavailable' && date != 'N/A' && date != '-' && typeof(date) != "undefined") {
                try {

                    if (format === "Y-m-d H:i:s")   {
                        if(Date.parse){
                            var asOfDate = Date.parse( date, "Y-m-d H:i:s");
                            if(asOfDate===undefined)  {
                                asOfDate = Date.parse( date, "Y-m-d H:i:s");
                                if(asOfDate===undefined){
                                    return "-";
                                }
                            }
                            var ampm = asOfDate.getHours() >= 12 ? 'PM' : 'AM';
                            return asOfDate.format("h:i") + ' ' + ampm + ' ET';
                        }  else {
                            return '-';
                        }
                    }

                    var d = getDateObject(date);
                    var dateFormatted = format.replace('m', d.getMonth()+1);
                    dateFormatted = format.replace('x', d.getMonth()+1 <=9?'0'+(d.getMonth()+1):d.getMonth()+1);
                    dateFormatted = dateFormatted.replace('d', d.getDate());
                    dateFormatted = dateFormatted.replace('z', d.getDate() <=9?'0'+d.getDate():d.getDate());

                    dateFormatted = dateFormatted.replace('y', d.getFullYear());
                    dateFormatted = dateFormatted.replace('k', (d.getFullYear() + '').substring(2, 4));
                    dateFormatted = dateFormatted.replace('M', partialMonth[d.getMonth()]);
                    dateFormatted = dateFormatted.replace('F', fullMonth[d.getMonth()+1]);
                    return dateFormatted;
                } catch (e) {
                    return date;
                }
            } else {
                return '-';
            }
        } catch (e) { logger.error(e);  if(throwErrorsToClient){throw e;} } return '-';

    }
});
msaiqApp.filter('epsNextDateRenderer', function() {
    return function(date, format) {
        try{

            var getDateObject=function(date) { var fullMonth = [ ' ','January', 'February', 'March', 'April', 'May', 'June', 'July',
                'August', 'September', 'October', 'November', 'December'];

                try {
                    var d = date.split('T')[0];
                    if (d ===date)  {
                        d =  date.split(' ')[0];
                    }
                    d = d.split('/');
                    var strDate = d[1];
                    var strMonth = d[0];
                    var strYear = d[2];
                    /*In IE we need to mention decimal or octal . Reg : 26688*/
                    var intMonth = parseInt(strMonth,10);

                    var dateString = fullMonth[intMonth] + ' ' + strDate + ', ' + strYear;

                    return new Date(dateString);

                } catch (e) {
                    return date;
                }} ;


            var partialMonth = [ ' ','Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var fullMonth = [ ' ','January', 'February', 'March', 'April', 'May', 'June', 'July',
                'August', 'September', 'October', 'November', 'December'];
            if (date && date != '' && date != 'Data Unavailable' && date != 'N/A' && date != '-' && typeof(date) != "undefined") {
                try {

                    if (format === "Y-m-d H:i:s")   {
                        if(Date.parse){
                            var asOfDate = Date.parse( date, "Y-m-d H:i:s");
                            if(asOfDate===undefined)  {
                                asOfDate = Date.parse( date, "Y-m-d H:i:s");
                                if(asOfDate===undefined){
                                    return "-";
                                }
                            }
                            var ampm = asOfDate.getHours() >= 12 ? 'PM' : 'AM';
                            return asOfDate.format("h:i") + ' ' + ampm + ' ET';
                        }  else {
                            return '-';
                        }
                    }

                    var d = getDateObject(date);
                    var prefix;
                    if (d.getDate() >0 && d.getDate() <11){
                        prefix= "Early";
                    }
                    if (d.getDate() >10 && d.getDate() <21){
                        prefix= "Mid";
                    }
                    if (d.getDate() >21 ){
                        prefix= "Late";
                    }
                    return prefix + " " + fullMonth[d.getMonth()+1];

                } catch (e) {
                    return date;
                }
            } else {
                return '-';
            }
        } catch (e) { logger.error(e);  if(throwErrorsToClient){throw e;} } return '-';

    }
});



msaiqApp.filter('absoluteFilter', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(val) {

        try {


            var   floatValSp =emptyCheckFilter(val,"-");
            if (floatValSp=== "-")  {
                return "-";
            }

            if (typeof(val) === "string" && val === "Data Unavailable") {

                return "-";
            }
            if (isNaN(val)) {
                return "-";
            }

            if (typeof(val) === "number") {
                floatValSp = Math.abs(val)  ;


            }

            if (typeof(val) === "string") {
                val = parseFloat(val);
                floatValSp = Math.abs(val)  ;

            }
            return  floatValSp;

        } catch (e) {    } return '-';


    }
});

msaiqApp.filter('roundToNDecimalFilter', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter');
    return function(val,n) {
        try {
            var   floatValSp =emptyCheckFilter(val,'-');
            if (floatValSp=== '-') { return '-'; }
            if (typeof(val) === 'string' && val === 'Data Unavailable') { return '-'; }
            if (isNaN(val)) { return '-'; }
            if (typeof(n) !== 'number') { return val; }
            if (typeof(val) === 'number') {
                floatValSp = Math.round(val * Math.pow(10, n)) / Math.pow(10, n);
                // make sure rounding
                floatValSp = floatValSp.toFixed(n);
            }
            if (typeof(val) === 'string') {
                val = parseFloat(val);
                floatValSp = Math.round(val * Math.pow(10, n)) / Math.pow(10, n);
                // make sure rounding
                floatValSp = floatValSp.toFixed(n);
            }
            return  floatValSp;
        } catch (e) {    } return '-';
    };
});

msaiqApp.filter('rankValue', function() {
    return function(rankValue) {

        if (rankValue === 1){
            return 'STRONG SELL';
        }
        else if (rankValue === 2){
            return 'SELL';
        }
        else if (rankValue === 3){
            return 'HOLD';
        }
        else if (rankValue === 4 ){
            return 'BUY';
        }
        else if (rankValue === 5){
             return 'STRONG BUY';
        }
        else{
            return 'NOT RANKED';
        }
    };
});

msaiqApp.filter('investStyle', function() {
    return function(styleSize) {

        if (styleSize === 'S'){
            return 'SMALL-CAP';
        }else if (styleSize === 'L'){
            return 'LARGE-CAP';
        }else if (styleSize === 'M'){
            return 'MID-CAP';
        }else{
            return '-';
        }
    };
});

msaiqApp.filter('decodeHTML', function($sce, _) {
    return function(input) {

        if (!input){
            return '';
        }
        else{
            var str = _.unescape(input);
            str = str.replace(/&apos;/g,'\'');
            str = str.replace(/&amp;/g,'&');
            str = str.replace(/&#039;/g,'\'');
            str = str.replace(/&#034;/g,'"');
            return  str;
        }
    };
});

msaiqApp.filter('default', function() {
    return function(input, defaultValue) {
        if (input && input!=='null' && input!=='0.00' && input!=='0' && input!=='0.0'){
            return input;
        } else { return defaultValue; }
    };
});
msaiqApp.filter('percentFilter', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(data) {
        if (emptyCheckFilter(data)===true) {
            return '-';
        }  else if (data === '-') {
            return '-';
        } else {
            return data +'%' ;
        }
    };
});

msaiqApp.filter('msadatefilter', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter');
    var dateFilter =  $filter('date');
    return function(data,toDateFormat) {
        if (emptyCheckFilter(data,'-')==='-') {
            return '-';
        }  else {
            var parsedDate = data.split('-').join('/');
            var strippedDate = parsedDate.replace(/\.0/, '');
            return dateFilter(Date.parse(strippedDate),toDateFormat);
        }
    };
});

msaiqApp.filter('translateArticleCodeForRouting', function($filter) {
    return function(input) {
        if (input === 'SVIEW'){
            return 'brokerViews';
        }else if (input === 'MOVER'){
            return 'marketMovers';
        }else if (input === 'TREND'){
            return 'trendsAndIdeas';
        }else if (input === 'ECRCM'){
            return 'streetTalk';
        }  else if (input === 'RNOTS'){
            return 'researchNotes';
        }else if(input === 'FEOM'){
            return 'focusETFOfMonth';
        }else if(input === 'FSOW'){
            return 'focusStockOfWeek';
        }
        else if(input === 'FFOM'){
            return 'focusFUNDOfMonth';
        }
        /*else if (input === 'ECOCL'){
            return 'economyWatch';
        }*/else {
            return '';
        }
    };
});

msaiqApp.filter('emptyCheckFilterCathy', function() {
    return function(data,defaultVal) {
        var returnVal=true;
        if (defaultVal) { returnVal=defaultVal; }
        try{
            if (data === null) { return returnVal; }
            else if (typeof(data) === 'undefined') { return returnVal; }
            else if (data.length === 0) { return returnVal; }
            else if (typeof (data) === 'string') {
                if (data === '' || data === '-' || data === 'Data Unavailable') { return returnVal; }
                else { return defaultVal?data:false; }
            }
            else if (typeof(data) === 'object') {
                if (Object.prototype.toString.call(data) === '[object Date]') { return defaultVal?data:false; }
                var count = 0;
                for (var k in data) {
                    if (data.hasOwnProperty(k)) { count++; }
                }
                if (count === 0) { return defaultVal?data:false; }
            }
            return defaultVal?data:false;
        } catch (e) {  } return returnVal;
    };
});


msaiqApp.filter('emptyCheckFilter', function() {
    return function(data,defaultVal) {
        var returnVal=true;
        if (defaultVal) { returnVal=defaultVal; }
        try{
            if (data === null) { return returnVal; }
            else if (typeof(data) === 'undefined') { return returnVal; }
            else if (data.length === 0) { return returnVal; }
            else if (typeof (data) === 'string') {
                if (data === '' || data === '-' || data === 'Data Unavailable' || data==="Unknown") { return returnVal; }
                else { return defaultVal?data:false; }
            }
            else if (typeof(data) === 'object') {
                if (Object.prototype.toString.call(data) === '[object Date]') { return defaultVal?data:false; }
                var count = 0;
                for (var k in data) {
                    if (data.hasOwnProperty(k)) { count++; }
                }
                if (count === 0) { return defaultVal?data:false; }
            }
            return defaultVal?data:false;
        } catch (e) {  } return returnVal;
    };
});

msaiqApp.filter('etfPercentFilter', function ($filter) {
    var emptyCheckFilter = $filter('emptyCheckFilter');
    var numberFilter = $filter('number');
    return function (data) {
        if (emptyCheckFilter(data, '-') === '-') {
            return '-';
        } else if (isNaN(data) === true || data > 1000) {
            return data;
        } else {
            return numberFilter(data, 2) + '%';
        }
    };
});
msaiqApp.filter('rankingFilter', function ($filter) {
    return function(overallIndVal) {
        if (overallIndVal === 1){
            return 'Underweight';
        }
        else if (overallIndVal === 2){
            return 'Underweight';
        }
        else if (overallIndVal === 3){
            return 'Marketweight';
        }
        else if (overallIndVal === 4 ){
            return 'Overweight';
        }
        else if (overallIndVal === 5) {
            return 'Overweight';
        }
        else{
            return '-';
        }
    };
});
msaiqApp.filter('currencyFilter', function ($filter) {
    var emptyCheckFilter = $filter('emptyCheckFilter');
    var currencyFilter = $filter('currency');
    return function (data) {
        if (emptyCheckFilter(data, '-') === '-') {
            return '-';
        }
        else if (data === 0 || data === 0.00) {
            return '-';
        }
        else if (data < 0) {
            return '$'+data;
        }
        else {
            return currencyFilter(data);
        }
    };
});
msaiqApp.filter('getNestedKey', function() {
    return function(obj,path) {
        var current = obj;
        var pathArray = path.split('.');
        for (var i = 0; i < pathArray.length; i++) {
            current = current[pathArray[i]];
        }
        return current;
    };
});

msaiqApp.filter('isDataEntitled', function(EntitlementService,$filter) {
    var getNestedKeyFilter=$filter('getNestedKey');
    return function(data,key) {
        if (EntitlementService.clientCustomization.resolved && getNestedKeyFilter(EntitlementService.clientCustomization,key)){
            for (var item in data){
               if (data[item].portfolioId=='NFRVL') {
                   data.splice( item, 1 );

               }
            }
        }
        return data;
    };
});
msaiqApp.filter('settingsFilter', function($filter) {
    return function(data,settingsList) {
        var result = [];
        angular.forEach(data, function(item){
            if(settingsList.indexOf(item.portfolioId) >= 0) {
                result.push(item);
            }
        });
        return result;
    };
});
msaiqApp.filter('etfRankingRenderer', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter');
    return function(data) {
        if (emptyCheckFilter(data,'-')==='-') {
            return '-';
        }  else {
            switch(data){
                case 1:
                    return 'Not Available';
                case 2:
                    return 'Underweight';
                case 3:
                    return 'Marketweight';
                case 4:
                    return 'Overweight';
                case 'NA':
                    return 'Not Available';
            }
        }
    };
});

msaiqApp.filter('zeroCheckFilter', function ($filter) {
    var emptyCheckFilter = $filter('emptyCheckFilter');
    return function (data) {
        if (emptyCheckFilter(data, '-') === '-') {
            return '-';
        } else if ( data === '0' ||  data === '0.00' || data === 0 || data === 0.00) {
            return '-';
        }else{
            return data;
        }
    };
});

msaiqApp.filter('defaultZero', function($filter) {
    return function(input, defaultVal) {
        if (!input || input === '0.00' || input === '0.0000'|| input === '0' || input === '(0)'){
            return defaultVal;
        }else{
            return input;
        }
    };
});

msaiqApp.filter('defaultNumber', function($filter) {
    return function(input, defaultVal, precision) {
        if (input === undefined || input === null || input==='null'){
            return defaultVal;
        }else if (input === 0 || input === 0.0 || input === '0' || input === '0.00' || input === '0.0000'){
            return defaultVal;
        }else{
            // filter number two values
            return ($filter('number')(input, precision))+'%';
        }
    };
});


msaiqApp.filter('yesOrNo', function() {
    return function(input) {
        if (input) {
            return((input.toLowerCase()==='y')?'Yes':'No');
        }else{
            return 'N/A';
        }
    };
});

msaiqApp.filter('showBar', function() {
    return function(value, index, precision) {
        if (!precision) { precision=1;}
        if (index < value/precision){
            return 'pct_bar';
        }else{
            return 'no_pct_bar';
        }
    };
});


msaiqApp.filter('lessThanOne', function() {
    return function(input) {
        return (input && input < 1.0)?('< 1'):(input);
    };
});

msaiqApp.filter('numberToWordFilter', function() {
    return function(number) {
        if (number === '1' ){
            return 'One';
        } else if(number === '2'){
            return 'Two';
        } else if(number === '3'){
            return 'Three';
        }else if(number === '4'){
            return 'Four';
        }else if(number === '5'){
            return 'Five';
        }
        else {
            return (number || '');
        }
    };
});

msaiqApp.filter('regionFilter', function() {
    return function(region) {
        if (region === 'US' ){
            return 'United States';
        } else {
            return region;
        }
    };
});

msaiqApp.filter('noRankFilter', function() {
    return function(rank) {
        if (rank === '' ){
            return 'NR';
        } else if (rank === 'null') {
            return 'NA';
        } else {
            return rank;
        }
    };
});

msaiqApp.filter('etfCapsFilter', function() {
    return function(input) {
        if (input.toLowerCase() === 'etfs' ){
            return 'ETFs';
        } else {
            return input;
        }
    };
});

msaiqApp.filter('percentChange', function() {
    return function(input) {
        if (input > 0){
            return 'positive';
        }else if (input === 0) {
            return 'neutral';
        }else{
            return 'negative';
        }
    };
});

msaiqApp.filter('getImage', function() {
    return function(input, value) {

        if (input && value && input.toLowerCase() === value.toLowerCase()) {
            return 'images/'+ value.toLowerCase() + '_on.gif';
        }else{
            return 'images/' + value.toLowerCase() + '.gif';
        }
    };
});

msaiqApp.filter('getOn', function() {
    return function(input, value) {
        if (input && value && (input.toLowerCase() == value.toLowerCase()) ){
            return '_on';
        }
        return '';
    };
});

msaiqApp.filter('typeConvert', function() {
    return function(value) {

        if (value === 'Positive'){
            return 'OVERWEIGHT';
        } else if(value === 'Neutral'){
            return 'MARKETWEIGHT';
        }else if (value === 'Negative'){
            return 'UNDERWEIGHT';
        }else {
            return (value || '');
        }
    };
});

msaiqApp.filter('truncate', function() {
    return function (text, length, end) {
        if (isNaN(length))
            length = 200;

        if (end === undefined)
            end = "...";

        if (text.length <= length || text.length - end.length <= length) {
            return text;
        }
        else {
            return String(text).substring(0, length-end.length) + end;
        }
    };
});

msaiqApp.filter('numberFilter', function ($filter) {
    var emptyCheckFilter = $filter('emptyCheckFilter');
    var numberFilter = $filter('number');
    return function (data) {
        if (emptyCheckFilter(data, '-') === '-') {
            return '-';
        }
        else if (data === 0 || data === 0.00) {
            return '-';
        }
        else if (data < 0) {
            return '$'+data;
        }
        else {
            return numberFilter(data);
        }
    };
});

msaiqApp.filter('dollarFilter', function($filter) {
    var emptyCheckFilter = $filter('emptyCheckFilter');
    return function(data) {
        if (emptyCheckFilter(data, '-') === '-') {
            return '-';
        }
        else if (data === 0 || data === 0.00) {
            return '-';
        }
        else if (data < 0) {
            return '$'+data;
        }
        else{
            return '$'+data;
        }

    };
});

msaiqApp.filter('fundPercentFilter', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(data) {
        if (emptyCheckFilter(data)===true) {
            return '--';
        }  else if (data === '0' || data === '0.00' || data === '0.0') {
            return '--';
        } else {
            return data +'%' ;
        }
    };
});


msaiqApp.filter('zeroDecimalsToZero', function($filter) {
    var emptyCheckFilter=$filter('emptyCheckFilter')  ;
    return function(data) {
        if (emptyCheckFilter(data)===true) {
            return '-';
        }  else if (data === 0 || data === '0.00' || data === '0.0') {
            return '0';
        } else {
            return data;
        }
    };
});

msaiqApp.filter('fundDefault', function($filter) {
    var defaultFilter=$filter('default');
    return function(input, defaultValue) {
        if (defaultFilter(input)=== '--' || input === 'Funds') {
            return '--';
        }  else {
            return input;
        }
    };
});

msaiqApp.filter('doubleHypen', function($filter) {
    var defaultFilter=$filter('default');
    return function(input, defaultValue) {
        if (defaultFilter(input)=== '-') {
            return '--';
        }  else {
            return input;
        }
    };
});

msaiqApp.filter('space', function($filter) {
    var doubleHypen=$filter('doubleHypen');
    return function(input, defaultValue) {
        if (doubleHypen(input)=== '--') {
            return ' ';
        }  else {
            return input;
        }
    };
});
msaiqApp.filter('perfQuartileConvert', function($filter) {
    var defaultFilter=$filter('default');
    return function(input, defaultValue) {
     if(input){
        switch(input){
            case 4:
                return 'Top quartile';
            case 3:
                return '2nd quartile';
            case 2:
                return '3rd quartile';
            case 1:
                return 'Bottom quartile';
            default:
                return defaultValue;
        }
     }
    };
});
msaiqApp.filter('trueFilter', function() {
    return function(input) {
        if (input === true) {
            return '-';
        }  else {
            return input;
        }
    };
});

msaiqApp.filter('fundHeadingFilter', function() {
    return function(input) {
        var result ='';
        switch (input) {
            case 'RankinCategory':
                result = 'Rank in category';
                break;
            case 'RankinPeerGroup':
                result = 'in Peer Group';
                break;
            case 'TotalReturnRank1Yr':
                result = '1 Yr';
                break;
            case 'TotalReturnRank3Yr':
                result = '3 Yr';
                break;
            case 'TotalReturnRank5Yr':
                result = '5 Yr';
                break;
            case 'TotalReturnRank10Yr':
                result = '10 Yr';
                break;
        }
        return result;
    };
});
msaiqApp.filter('getDateObject', function() {
    return function(input) {
        var fullMonth = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July',
            'August', 'September', 'October', 'November', 'December'];

        try {
            var d = date.split("T")[0];
            d = d.split("-");
            var strDate = d[2];
            var strMonth = d[1];
            var strYear = d[0];
            var intMonth = parseInt(strMonth);

            var dateString = fullMonth[intMonth] + ' ' + strDate + ', ' + strYear;

            return new Date(dateString);

        } catch (e) {
            return date;
        }
    };
});
msaiqApp.filter('checkExpired', function($filter) {
    var dateObjectFilter = $filter('getDateObject');
    return function(input) {
        var d = dateObjectFilter(input);
        d.setHours(0, 0, 0, 0);
        var today = new Date();
        today.setHours(0, 0, 0, 0);

        if (d >= today) {
            return false; // not epxired
        } else {
            return true;  // expired
        }
    };
});
msaiqApp.filter('orderObjectBy', function(){
    return function(input) {
        return input.sort(function(a1,b1){
            var ratingArray = ['AAA', 'AA+', 'AA', 'AA-', 'A+', 'A', 'A-', 'BBB+', 'BBB', 'BBB-', 'BB+', 'BB', 'BB-', 'B+', 'B', 'B-', 'CCC+', 'CCC', 'CCC-', 'CC', 'R', 'SD', 'D', 'NR', '-','Data Unavailable'];

            var a = a1.creditRating;
            var b = b1.creditRating;

            if (ratingArray.indexOf(a) === ratingArray.indexOf(b)) {
                if (a1.peerGroupCompanyName === b1.peerGroupCompanyName) { return 0;
                } if (a1.peerGroupCompanyName < b1.peerGroupCompanyName) { return -1;
                } else { return 1; }
            }
            if (ratingArray.indexOf(a) < ratingArray.indexOf(b)) {
                return -1;
            }
            return 1;
        });
    };
});

msaiqApp.filter('ellipsisBodyText', function($filter) {
    var decodeHTML = $filter('decodeHTML');
    return function (text, limit) {
        var decodedHtml = decodeHTML(text);
        decodedHtml = decodedHtml.replace('<div','<span');
        decodedHtml = decodedHtml.replace('</div','</span');
        if(decodedHtml.length > 0) {
            return decodedHtml.toString().substr(0, limit);
        }
    };
});

msaiqApp.filter('typeAHeadSearch', function($filter) {
    var decodeHTML = $filter('decodeHTML');
    return function (ngRepeatObj, value) {
        value = decodeHTML(value);
        if(value){
            var tempArray = []
            angular.forEach(ngRepeatObj, function(item){
                if(decodeHTML(item.name).toLowerCase().substr(0,value.length).match(value.toLowerCase())){
                    tempArray.push(item);
                }
            });
            return tempArray;
        } else {
            return ngRepeatObj;
        }
    };
});

msaiqApp.filter('formatNumberFilter', function($filter,$log) {

    return function(inputValueObj,precision) {
        try {
            var value = inputValueObj;
            if (value === 0 && inputValueObj.formatZero) {
                return value.toFixed(2);
            }
            if (value === "" || value === null || value + '' === 'undefined') {
                return '-';
            }
            else
            if (value === 0) {
                return '0';
            }

            var decimalSeparator = '.';
            var thousandSeparator = ',';

            var value = (+value);
            if (!value || typeof value !== 'number')
                return value;

            if (precision != null &&  typeof precision == 'number') {
                var floatValSp = Math.ceil(value * Math.pow(10, precision)) / Math.pow(10, precision);
                value = floatValSp.toFixed(precision);
            } else
                value = value.toFixed(2);
            value = value + '';

            var decimalValue = '';

            var x = value.split(decimalSeparator);
            var x1 = x[0];

            if (x.length > 1 && x[1].length == 1) {
                if(inputValueObj.yield)
                    decimalValue = x[1];
                else
                    decimalValue = x[1] < 10 ? x[1] + '0' : x[1];
            }

        else
        if (x.length == 1)
            decimalValue = '';
        else
            decimalValue = x[1];
        var x2 = x.length > 1 ? decimalSeparator + decimalValue : '';
        var rgx = /(\d+)(\d{3})/;

        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + thousandSeparator + '$2');
        }

        return x1 + x2;



        } catch (e) {    } return '-';
    };
});
msaiqApp.filter('monitorAlertStatus', function() {
    return function (suspend, record) {
        if(suspend === 'Y'){
            return 'SUSPENDED';
        } else if(suspend === 'N' && record.status === 'R') {
            return record.monitoName+'_ERROR';
        } else if(suspend === 'N' && record.status === 'G') {
            return 'OK';
        }
        if(suspend === 'Y')
            return 'SUSPENDED';
        else if(suspend === 'N'){
            if(record.status === 'R') return record.monitoName+'_ERROR';
            else if(record.status === 'G') return 'OK';
            else if(record.status === 'Y') return record.monitoName+'_WARNING';
        }
    };
});

msaiqApp.filter('monitorAlertStatusCls', function() {
    return function (suspend, record) {
        if(suspend === 'Y')
            return 'monitor-alert-status_SUSPENDED';
        else if(suspend === 'N'){
            if(record.status === 'R') return 'monitor-alert-status_ERROR';
            else if(record.status === 'G') return 'monitor-alert-status_OK';
            else if(record.status === 'Y') return 'monitor-alert-status_WARNING';
        }
    };
});
msaiqApp.filter('yesOrNoWithEmpty', function() {
        return function(input) {
            if (input != '' && input.toLowerCase()==='y') {
                return'Yes';
            }else if (input != '' && input.toLowerCase()==='n') {
                return'No';
            }else{
                return input;
            }
        };

});
msaiqApp.filter('encryptionFilter', function() {
    return function(input) {
        if (input != '' && input=='3DES') {
            return'DESede';
        }else if (input != '' && input=='3DES/ECB/PKCS5Padding') {
            return'DESede/ECB/PKCS5Padding';
        }else if (input != '' && input=='3DES/CBC/PKCS5Padding') {
            return'DESede/CBC/PKCS5Padding';
        }else if (input != '' && input=='3DES/ECB/NoPadding') {
            return'DESede/ECB/NoPadding';
        }else if (input != '' && input=='3DES/CBC/NoPadding') {
            return'DESede/CBC/NoPadding';
        }else{
            return input;
        }
    };
});
msaiqApp.filter('reverseEncryptionFilter', function() {
    return function(input) {
        if (input != '' && input=='DESede') {
            return'3DES';
        }else if (input != '' && input=='DESede/ECB/PKCS5Padding') {
            return'3DES/ECB/PKCS5Padding';
        }else if (input != '' && input=='DESede/CBC/PKCS5Padding') {
            return'3DES/CBC/PKCS5Padding';
        }else if (input != '' && input=='DESede/ECB/NoPadding') {
            return'3DES/ECB/NoPadding';
        }else if (input != '' && input=='DESede/CBC/NoPadding') {
            return'3DES/CBC/NoPadding';
        }else{
            return input;
        }
    };
});

msaiqApp.filter('convertToPlain', function($sce, _) {
    return function(input) {

        if (!input){
            return '';
        }
        else{
            var str = _.unescape(input);
            str = str.replace(/<br>/g,'');
            str = str.replace(/<BR>/g,'');
            str = str.replace(/<br\/\>/g, '')
            str = str.replace(/&nbsp;/g,'');
            str = str.replace(/&#039;/g,'\'');
            str = str.replace(/&apos;/g,'\'');
            str = str.replace(/&amp;/g,'&');


            return  str;
        }
    };
});