'use strict';

window.onerror = function (message, file, line) {


    ga('send', 'event', 'Window OnError', 'file: ' + file + '\n\n line:' + line + '\n\n message: ' + message + '\n\n on page: ' + window.location.href);
};

function takeOverConsole() {
    var console = window.console;
    if (!console) {
        return;
    }

    function intercept() {
        var original = console['error'];
        console['error'] = function () {


            ga('send', 'event', 'Console-Logged Error', arguments[0], window.location.href);

            // do sneaky stuff
            if (original.apply) {
                // Do this for normal browsers
                original.apply(console, arguments);
            } else {
                // Do this for IE
                var message = Array.prototype.slice.apply(arguments).join(' ');
                original(message);
            }
        };
    }
    intercept();


}

takeOverConsole();