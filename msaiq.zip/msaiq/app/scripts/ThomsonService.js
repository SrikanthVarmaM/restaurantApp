'use strict';
/** services for this app **/

msaiqApp.factory('ThomsonService', function($log, $resource, $route, $window, $location, AutoSuggestService, QuickViewService, bondsResourceFactory) {
    var ctxService= null;
    return {
        openQuickView: function(values){

            QuickViewService.openQV({'sppwId':values.sppwId, 'ticker': values.ticker, report_ind: (values.report_ind || 'undefined'), 'type': (values.type.toLowerCase() || 'stock') });


        },

        openDetailPage: function(values){
            try{
                $log.debug('ThomsonService: ** TEST2 ** Detail page loads here  for type: ' + values.type + ', ticker: ' + values.ticker + ', sppwid: ' + values.sppwId);
                //$window.alert(('ThomsonService: ** TEST2 ** Detail page loads here for type: ' + values.type + ', ticker: ' + values.ticker + ', sppwid: ' + values.sppwId);
                /*    //$window.alert(('sppwid: ' + values.sppwId); */
                //$window.alert(('ticker: ' +values.ticker );
               // var url = '#/'+( values.type || 'stock').toLowerCase() + '/details/' +values.sppwId+ '/' +values.ticker;
                var path = '/'+ values.type.toLowerCase()   + '/details/' + values.sppwId + '/' + values.ticker;
                var url = '#' + path;

                $log.debug('openDetailPage: type head select url:' + path);
                //$window.alert(('openDetailPage: location setting:' + path);
               // $window.location.href =  url;
                $location.path(path);
                //$window.alert(('openDetailPage: setting window location '+ url);
                $window.location.href = url;
                //$window.alert(('openDetailPage: reload');
                $route.reload();

            }catch(err){
                //$window.alert( ('openDetailPage - Exception ' + err.message);
                $log.info('openDetailPage -  exception=' + err.message);

            }
        },
        initialize: function(){
            try{
                $log.debug('at ThomsonService initialize');

                //$window.alert(('Initializing Thomson ctxService ' + Tfsi);

                ctxService = Tfsi.ServiceFactory.getService('IContext');
            }catch(err){
               //$window.alert(('Context initialization failed! Will not able to pass information back from Thomson One to MSA ' + err.message);
                $log.info('ThomsonService: Context initialization failed! Will not able to pass information back from Thomson One to MSA ' + err.message);
                return;
            }

            if (!ctxService){
                //$window.alert(('Context initialization failed! Will not able to pass information back from Thomson One to MSA ');
                $log.info('ThomsonService: Context initialization failed! Will not able to pass information back from Thomson One to MSA ');
                return;
            }else{
                ctxService.setContextHandler(this.handleContextChange());
            }
        },
        handleContextChange: function(symbol){
            if (!symbol){
                symbol = this.getContextSymbol();
            }
            if (symbol){
                //$window.alert(('handleContextChange: showing information for symbol: ' + (symbol || 'blank'));
                // call QuickViewManager
           AutoSuggestService.getTickerInformation(symbol, this.openQuickView);
                // call detail page here
              // this.getTickerInformation(symbol, this.openDetailPage);
            }else{
                //$window.alert(('handleContextChange: no symbol found, do nothing');
            }
        },
        getContextSymbol: function(){

            try{
                var context = ctxService.getContexts();
                var item = context.get_Item('Entity');
                var entityValue = item.get_Value();
                var attrs = new Tfsi.StringDictionary();
                attrs.add('type','All');     // change from Quotation to All
                attrs.add('attribute','SYMBOL');
                var symbolOnly = entityValue.get_Value(attrs);
                if(!symbolOnly || symbolOnly === null || symbolOnly === 'null') {
                    //$window.alert(('getContextSymbol: SymbolOnly entity value: ' + entityValue._contextValues[0]._value);
                    $log.debug('ThomsonService: getContextSymbol: SymbolOnly entity value: ' + entityValue._contextValues[0]._value);
                    return entityValue._contextValues[0]._value;
                } else {
                    //$window.alert(('getContextSymbol: SymbolOnly  value: ' + symbolOnly);
                    $log.debug('ThomsonService: getContextSymbol: SymbolOnly  value: ' + symbolOnly);
                    return symbolOnly;
                }

            }catch(err){
               //$window.alert( ('getContextSymbol - Unable to get symbol: exception: ' + err.message);
                $log.info('ThomsonService: getContextSymbol - Unable to get symbol: exception=' + err.message);
                return '';
            }
        },
        setContext: function(symbol){
            // Create an array.
            try{

             //  $window.alert(('setContext: Tfsi ' + Tfsi);

                var context = new Tfsi.KeyedItemDictionary();
            //    $window.alert(('setContext: context ' + context + ' for ' + symbol);
                // set Entity context
                context.add('Entity', symbol);
             //   $window.alert(('ThomsonService: ** TEST ** sending ticker to Thomson ' + symbol);
                $log.info('ThomsonService: ** TEST ** sending ticker to Thomson ' + symbol);

                ctxService.setContexts(context, true);
           //    $window.alert(('setContext: ctxService setContexts true');
            }catch(err){
              ////$window.alert(('setContext - Catch Exception, Unable to send thomson symbol update ' + err.message);
              $log.info('ThomsonService: setContext - Catch Exception, Unable to send thomson symbol update ' + err.message);
            }
        }

    };

});
