'use strict';

msaiqApp.factory('bondsResourceFactory', function ($resource) {
    return{
        grmBondsBasicInfoResource:$resource('/assets-service/bonds/:cusip.json?datasets=grm_basic_info', {cusip:'@cusip'}),
        grmParticipantsInfoResource:$resource('/assets-service/bonds/:cusip.json?datasets=participant_info&pageSize=:pageSize&pageNum=:pageNum', {cusip:'@cusip',pageSize:'@pageSize',pageNum:'@pageNum'}),
        grmComparableBondsResource:$resource('/assets-service/bonds/:cusip.json?datasets=comparative_performance&pageSize=:pageSize&pageNum=:pageNum', {cusip:'@cusip',pageSize:'@pageSize',pageNum:'@pageNum'}),
        relatedIssuesDataResource:$resource('/SP/msa/issuerSecurities.html?dir=ASC&sort=description&start=:start&limit=:limit&orgId=:orgId', {orgId:'@orgId',start:'@start',limit:'@limit'}),
        relatedIssuesDataFromAssetServicesResource:$resource('/assets-service/bonds/:cusip.json?datasets=related_issues&dir=ASC&sort=description&pageSize=:pageSize&pageNum=:pageNum&orgId=:orgId', {cusip:'@cusip',pageSize:'@pageSize',pageNum:'@pageNum',orgId:'@orgId'}),
        relatedNewsDataResource:$resource('/SP/msa/creditResearchArticles.html?creditResearchType=:creditResearchType&summaryAnalysisTotal=:summaryAnalysisTot&orgId=:orgId', {orgId:'@orgId', creditResearchType: '@creditResearchType', summaryAnalysisTot:'@summaryAnalysisTot'}),
        relatedNewsDataFromAssetServicesResource:$resource('/assets-service/bonds/:cusip.json?datasets=related_news&creditResearchType=:creditResearchType&summaryAnalysisTot=:summaryAnalysisTot&orgId=:orgId', {orgId:'@orgId', creditResearchType: '@creditResearchType', summaryAnalysisTot:'@summaryAnalysisTot',cusip:'@cusip'}),
        grmPriceToDateResource:$resource('/assets-service/bonds/:cusip.json?datasets=price_todate', {cusip:'@cusip'}),
        checkReportExistsResource:$resource('/assets-service/bonds/reports/_checkAvailability/:cusip.json', {cusip:'@cusip'}),
        getBondTypeResource: $resource('/assets-service/bonds/bondtype/:cusip.json', {cusip:'@cusip'}),
        gdsDataResource:$resource('/assets-service/bonds/:cusip.json?datasets=basic_data', {cusip:'@cusip'}),
        //issuerDetailsResource:$resource('/SP/msa/issuerDetails.html?cusip=:cusip', {cusip:'@cusip'}),
        getOrgIDByIdentifierResource:$resource('/assets-service/bonds/:cusip.json?datasets=issuer_orgid', {cusip:'@cusip'}),

        issuerDetailsResource:$resource('/assets-service/bonds/:cusip.json?datasets=issuer_orgid', {cusip:'@cusip'}),
        issueInfoResource:$resource('/SP/msa/service/bonds/issueInfo/:cusip', {cusip:'@cusip'}),
        quartileDataResource:$resource('/SP/msa/service/bonds/quartile/:cusip', {cusip:'@cusip'}),
        issuerSummaryResource:$resource('/SP/msa/service/bonds/issuer/:issuerNumber?item=issuerSummary', {issuerNumber:'@issuerNumber'},{
        getArrayReq : {
            method:'GET', isArray:false ,transformResponse: function (data) {
                return  {htmlData : data};
            }
        }
    }),
        getIssueCiqResource:$resource('/SP/msa/assets/bonds/ciq/:gvkey/:cusip/:isin.json',{isin:'@isin',cusip:'@cusip',gvkey:'@gvkey'}),
        getPeerAnalysisResource:$resource('/assets-service/bonds/459200AP6.json?datasets=peers&issuerNumber=:issuerNumber', {issuerNumber:'@issuerNumber'}),
        weaknessDataResource:$resource('/SP/msa/service/bonds/issuer/:issuerNumber?item=weeknesses', {issuerNumber:'@issuerNumber'},{
            getArrayReq : {
                method:'GET', isArray:false ,transformResponse: function (data) {
                    return  {htmlData : data};
                }
            }
        }),
        strengthDataResource: $resource('/SP/msa/service/bonds/issuer/:issuerNumber?item=strengths', {issuerNumber:'@issuerNumber'}, {
            getArrayReq : {
                method:'GET', isArray:false ,transformResponse: function (data) {
                return  {htmlData : data};
                }
            }
        })
    };
});