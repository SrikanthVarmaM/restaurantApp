'use strict';

//articleCode=TREND&timeInterval=90&equityType=S
msaiqApp.factory('assetsResourceFactory', function ($resource) {
//  return $resource('/SP/msa/homeLandingPage.html?articleCode=GHOME&country=%20&timeInterval=120000');
    return{
        stockDetailsResource:$resource('/SP/msa/securityDetails.html?sppwId=:sppwId&sourceArticle=:source', {sppwId: '@sppwId', source:'@source'}),
       // etfDetailsResource:$resource('/es/issues/_search?type=ETF&q=sppw_id::sppwid', {sppwid: '@sppwid'}),
        etfDetailsResource:$resource('/es/issues/_search?type=ETF&default_operator=OR&q=ticker::ticker%20_id::sppwid', {ticker: '@ticker', sppwid: '@sppwid'}),
        stockDetailsESResource:$resource('/es/issues/_search?type=stock&q=_id::sppwid', {sppwid: '@sppwid'}),
        stockSecurityDetailsResource:$resource('/SP/msa/securityDetails.html?sppwId=:sppwId&ticker=:ticker&reportIndicator=:reportIndicator', {sppwId: '@sppwId', ticker:'@ticker',reportIndicator :'@reportIndicator'}),
        fundsDetailsESResource:$resource('/es/issues/_search?type=Funds&q=tik_symbl::ticker', {ticker: '@ticker'}),
        OptionsDataResource:$resource('/SP/msa/options.html', {securityType:'OPTIONS'},{
            doPostReq : {
                method:'POST', isArray:false ,transformResponse: function (data) {
                    return  {optionsURL : data};
                }
            }
        }),
        hypoToolResource:$resource('/SP/msa/hypoTool.html', {},{
            doPostReq : {
                method:'POST', isArray:false ,transformResponse: function (data) {
                    return  {hypoURL : data};
                }
            }
        })
    };
});

