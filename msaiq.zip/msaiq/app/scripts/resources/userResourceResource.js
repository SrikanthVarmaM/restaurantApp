'use strict';
msaiqApp.factory('userResourceResourceFactory', function ($resource, $cookies,_) {
    //$cookies.ObSSOCookie = 'C3AtzdwAQK2dGeN2SIvlAxKgxkAw2Y4FYv/hLBCg+JdAjxwfK6JUvTE7t6j6EXCy6Rfh7h/ejfpf3fxLm1kkK7QzLgvMiNfhsEBjLmnMzEEzpM1Be48D/Oo9FfmQmspxkBc1RX3Bg+VuLLNQufqptuaoUwFaClEJ+CjX2nFGqHuOPtupbuyqJvnD8zORYNJO1M6wyGnt3/w3/ES4v+ZcGGpyLhGdczQ9Mev7fuYVWxxXWkGoRPo77zpaurYhhURfoutEHSm2OmH/RgC2JZNzkA==';


    return{
        securityResource: $resource('/SP/msa/securityDetails.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
            }
        }),
        alertResource: $resource('/SP/msa/alerts.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
            }
        }),
        watchlistResource: $resource('/SP/msa/watchLists.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        portFolioResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
            }
        }),
        entitlementResource: $resource('/SP/msa/service/currentUser/entitlements.json', {},{
            getArrayReq : {
                method:"GET", isArray:false ,transformResponse: function (data, headers) {
                    var returnData = _.isEmpty(data) ? null : JSON.parse(data);
                    return  {resourceList : returnData};
                }
            }
        }),
        logoutUserResource: $resource('/SP/msa/validate_login.html?logout=true'),
        loginUserDetailsResource: $resource('/SP/msa/service/currentUser/userDetails.json',{},{
            getArrayReq : {
                method:"GET", isArray:false ,transformResponse: function (data, headers) {
                    var returnData = _.isEmpty(data) ? null : JSON.parse(data);
                    return  {resourceList : returnData};
                }
            }
        }),
        seamlessLoginResource : $resource('/SP/msa/remoteLogin.html?', {}),
        loginResource: $resource('/SP/msa/service/currentUser/isLoggedIn.json', {}, {
            getArrayReq : {
                method:"GET", isArray:false ,transformResponse: function (data, headers) {
                    var returnData = _.isEmpty(data) ? null : JSON.parse(data);
                    return  {resourceList : returnData};
                }
            }
        }),
        userCompanyResource: $resource('/SP/msa/service/currentUser/analyticsUserInfo.json', {}, {
            getArrayReq : {
                method:"POST", isArray:false ,transformResponse: function (data, headers) {
                    var returnData = _.isEmpty(data) ? null : JSON.parse(data);
                    return  {resourceList : returnData};
                }
            }
        }),
        userLoginResource: $resource('/SP/msa/validate_login.html', {}, {
            postReq: {
                method: "POST" ,isArray:false , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'} ,transformRequest : function(data){
                    return $.param(data, true);
                }, transformResponse: function (data) {
                    return  {loginResponse : data};
                }
            }
        }),
        userSettingsResource: $resource('/SP/msa/userSettings.html', {}, {
            postReq: {
                method: "POST" ,isArray:false , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        userResetPasswordResource: $resource('/SP/msa/resetPassword.html', {}, {
            postReq: {
                method: "POST" ,isArray:false , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                },
                transformResponse : function(data){
                    return  {resetPasswordResponse : data};
                }
            }
        }),
        sendMailResource: $resource('/SP/msa/submitLog.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        searchOutlookUserResource: $resource('/SP/msa/admin/searchOutlookuser.html', {}, {
            postReq: {
                method: "POST" ,isArray:false , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        updateOutlookUserResource: $resource('/SP/msa/admin/updateOutlookUser.html', {}, {
            postReq: {
                method: "POST" ,isArray:false , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }) ,
        googleAnalyticsConfigResource: $resource('/SP/msa/service/currentUser/googleAnalyticsDeploymentEnv.json', {}, {
            getArrayReq : {
                method:"GET", isArray:false ,transformResponse: function (data, headers) {
                    var returnData = _.isEmpty(data) ? null : JSON.parse(data);
                    return  {resourceList : returnData};
                }
            }

        }),
        getPartnerCodesResource: $resource('/SP/msa/admin/getPartnerCodes.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        monitoringAlertsResource: $resource('/SP/msa/admin/monitor.html', {}, {
            postReq: {
                method: "POST" , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        linkExternalAccountsResource: $resource('/SP/msa/admin/linkExternalAccounts.html', {}, {
            postReq: {
                method: "POST" , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        savePartnerCodesResource: $resource('/SP/msa/admin/savePartnerDetails.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        trialReportingResource: $resource('/SP/msa/admin/trialReportGenerate.html', {}, {
            postReq: {
                method: "POST" , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        updateEncryptionResource: $resource('/SP/msa/admin/encryptionUtility.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        getUserListInOimGroupResource: $resource('/SP/msa/admin/getUsersInOimGroup.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        userEmailResource:$resource('/SP/msa/admin/getUserEmail.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getAppPropertiesResource:$resource('/SP/msa/admin/appProperties.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getUserAdminDataResource:$resource('/SP/msa/admin/getUserAdminData.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getMsaUserAdminResource:$resource('/SP/msa/admin/msaUserAdmin.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',Accept:'*/*'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getClientUserAdminEditViewResource:$resource('/SP/msa/admin/user/view.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',Accept:'*/*'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getClientUserAdminSaveEditResource:$resource('/SP/msa/admin/user/save.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',Accept:'*/*'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getPDFDisclosureResource:$resource('/SP/msa/setPDFDisclosure.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',Accept:'*/*'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        ),
        getUserListInGroupResource: $resource('/SP/msa/admin/getUsersInGroup.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        savePartnerCustomizationsResource:$resource('/SP/msa/admin/savePartnerCustomizations.html',{},{
                postReq: {
                    method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',Accept:'*/*'},transformRequest : function(data){
                        return $.param(data, true);
                    }
                }
            }
        )

    };
});