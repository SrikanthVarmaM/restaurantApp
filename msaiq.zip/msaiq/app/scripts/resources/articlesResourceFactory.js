'use strict';

//articleCode=TREND&timeInterval=90&equityType=S
msaiqApp.factory('articleResourceFactory', function ($resource) {
//  return $resource('/SP/msa/homeLandingPage.html?articleCode=GHOME&country=%20&timeInterval=120000');
    return {

        homeLandingPageResource: $resource('/SP/msa/homeLandingPage.html?articleCode=:articleCode&country=%20&timeInterval=120000', {articleCode: '@articleCode'}),
        articlesSimpleDetailsResource: $resource('/SP/msa/articleDetails.html?articleId=:articleId', {articleId: '@articleId'}),
        articlesDetailsResource: $resource('/SP/msa/articleDetails.html?articleCode=:articleCode&articleId=:articleId', {articleCode: '@articleCode', articleId: '@articleId'}),
        articleLandingPageResource: $resource('/SP/msa/articles.html?articleCode=:articleCode', {articleCode: '@articleCode'}),
        articleListRequestTypeResource: $resource('/SP/msa/articles.html?articleCode=:articleCode&requestType=:requestType&start=:start&limit=:limit&sort=:sort&dir=:dir', { articleCode: '@articleCode', requestType: '@requestType', start: '@start', limit: '@limit', sort: '@sort', dir: '@dir'}),
        articleListRequestTypeWatchlistResource: $resource('/SP/msa/articles.html?start=:start&limit=:limit&articleCode=:articleCode&sppwIds=:sppwIds&requestType=:requestType&timeInterval=:timeInterval&symbol=:symbol&gicsCode=:gicsCode&author=:author&sort=lastPublishDate&dir=DESC',{start: '@start',limit:'@limit',articleCode:'@articleCode',sppwIds:'@sppwIds',requestType:'@requestType',symbol:'@symbol',gicsCode:'@gicsCode',author:'@author',timeInterval:'@timeInterval'}),
        articleListTimePeriodResource: $resource('/SP/msa/articles.html?articleCode=:articleCode&timeInterval=:timeInterval&start=:start&limit=:limit&sort=:sort&dir=:dir', { articleCode: '@articleCode', timeInterval: '@timeInterval', start: '@start', limit: '@limit', sort: '@sort', dir: '@dir'}),
        articleLandingPageTakeAwayResource: $resource('/SP/msa/articles.html?articleCode=:articleCode&noOfTakeAways=:noOfTakeAways', {articleCode: '@articleCode', noOfTakeAways: '@noOfTakeAways'}),
        etfRelatedArticlesResource: $resource('/SP/msa/etfArticles.html?start=0&limit=20&sppwIds=603262&articleCode=RHEAD&articleId=&symbol=:ticker&requestType=all-related-headlines&gicsSector=&timeInterval=&equityType=ETF&top10HoldingsTickers', {ticker: '@ticker'}),
        stocksRelatedArticlesResource: $resource('/SP/msa/articles.html?start=0&limit=20&sppwIds=:sppwid&articleCode=RHEAD&articleId=&symbol=:ticker&requestType=all-related-headlines&gicsSector=&timeInterval=&equityType=S&top10HoldingsTickers', {sppwid: '@sppwid', ticker: '@ticker'}),
        marketscopePdfCheckAvailability:$resource('/assets-service/marketscope/_checkAvailability/:articleId', {articleId: '@articleId'}),
        stockScreenOfTheWeek: $resource('/SP/msa/articles.html?articleCode=SSOW&limit=1&requestType=DETAIL&sort=lastPublishDate&dir=DESC&start=0'),
        stockScreenOfTheWeekSecurities: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=id&screenerParameters%5B0%5D.operation1Value=115363&screenerParameters%5B0%5D.operation1Value=3955&screenerParameters%5B0%5D.operation1Value=9314&screenerParameters%5B0%5D.operation1Value=4888&screenerParameters%5B0%5D.operation1Value=6045&screenerParameters%5B0%5D.operation1Value=770&screenerParameters%5B0%5D.operation1Value=2172&screenerParameters%5B0%5D.operation1Value=5842&screenerParameters%5B0%5D.operation1Value=4947&screenerParameters%5B0%5D.customRenderer=idRenderer&equityType=STOCKS&limit=10&sort=securityName&dir=ASC'),
        relatedPeersResource: $resource('/SP/msa/getRelatedPeers.html?ticker=:ticker&sppwId=:sppwId', {ticker: '@ticker', sppwId: '@sppwId'}),
        relatedEtfPeersResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.inferedPropertyName=holdingsRegion&screenerParameters%5B0%5D.operation1Value=:holdingsRegion&screenerParameters%5B0%5D.propertyName=holdingsRegion&screenerParameters%5B1%5D.inferedPropertyName=overallInd&screenerParameters%5B1%5D.operation1Value=Overweight&screenerParameters%5B1%5D.propertyName=overallInd&screenerParameters%5B2%5D.inferedPropertyName=etfType&screenerParameters%5B2%5D.operation1Value=:etfType&screenerParameters%5B2%5D.propertyName=etfType&equityType=ETFS&dir=DESC&limit=5&start=0&sort=sortableMarketCap&resort=false'),
        relatedDetailsPeersResource: $resource('/SP/msa/getRelatedPeers.html'),
        fundsRelatedPeersResource:$resource('/SP/msa/getRelatedPeers.html?requestType=:requestType&sppwId=:sppwId&ticker=:ticker',{requestType: '@requestType',sppwId:'@sppwId',ticker:'@ticker'}),
        fundsRelatedShareClass: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=RELATED_SHARED_CLASSES&screenerParameters%5B0%5D.operation1Value=:sppwId&start=:start&limit=:limit&equityType=FUNDS&sort=securityName&dir=ASC',{start: '@start', limit: '@limit', operation1Value:'@sppwId'}),
        relatedEtfPeersResourceOpt: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.inferedPropertyName=:inferedPropertyName_0&screenerParameters%5B0%5D.operation1Value=:operation1Value_0&screenerParameters%5B0%5D.propertyName=:propertyName_0&screenerParameters%5B1%5D.inferedPropertyName=:inferedPropertyName_1&screenerParameters%5B1%5D.operation1Value=:operation1Value_1&screenerParameters%5B1%5D.propertyName=:propertyName_1&screenerParameters%5B2%5D.inferedPropertyName=:inferedPropertyName_2&screenerParameters%5B2%5D.operation1Value=:operation1Value_2&screenerParameters%5B2%5D.propertyName=:propertyName_2&equityType=ETFS&dir=:dir&limit=:limit&start=:start&sort=:sort&resort=:resort',
           {inferedPropertyName_0: '@inferedPropertyName_0', operation1Value_0: '@operation1Value_0', propertyName_0: '@propertyName_0',
            inferedPropertyName_1: '@inferedPropertyName_1', operation1Value_1: '@operation1Value_1', propertyName_1: '@propertyName_1',
            inferedPropertyName_2: '@inferedPropertyName_2', operation1Value_2: '@operation1Value_2', propertyName_2: '@propertyName_2',
            start:'@start', limit:'@limit', sort:'@sort', dir: '@dir', resort: '@resort'
        }),

        relatedHeadlinesResource: $resource('/SP/msa/articles.html?sppwIds=:sppwIds&cusip=&orgId=&symbol=:tickers&articleId=:articleId&requestType=relatedTop5Headlines&articleCode=RHEAD&top10HoldingsTickers=&issueTypeId=S', {tickers: '@tickers', sppwIds: '@sppwIds', articleId: '@articleId'}),
        fundsRelatedHeadlinesResource: $resource('/SP/msa/articles.html?sppwIds=:sppwIds&cusip=&orgId=&symbol=:tickers&articleId=:articleId&requestType=fundRelatedTop5Headlines&articleCode=RHEAD&top10HoldingsTickers=&issueTypeId=', {tickers: '@tickers', sppwIds: '@sppwIds', articleId: '@articleId'}),
        fundsRelatedTIResource: $resource('/SP/msa/articles.html?equityType=TREND&sppwIds=:sppwIds&symbol=:tickers&requestType=relatedFundTop5Trends&articleCode=RHEAD&gicsSector=&start=0&limit=5&timeInterval=90', {tickers: '@tickers', sppwIds: '@sppwIds'}),
        relatedEtfHeadlinesResource: $resource('/SP/msa/etfArticles.html?sppwIds=:sppwId&cusip=&orgId=&symbol=:ticker&articleId=:articleId&requestType=relatedTop5Headlines&articleCode=RHEAD&top10HoldingsTickers=&issueTypeId', {ticker: '@ticker', sppwId: '@sppwId', articleId: '@articleId'}),
        seeAllEtfHeadlinesResource: $resource('/SP/msa/etfArticles.html?start=:start&limit=20&sppwIds=:sppwId&cusip=&orgId=&symbol=:ticker&articleId=:articleId&requestType=all-related-headlines&articleCode=RHEAD&top10HoldingsTickers=:topTen&sort=lastPublishDate&dir=DESC', {ticker: '@ticker', sppwId: '@sppwId', articleId: '@articleId', topTen: '@topTen',start:'start'}),
        seeAllStockHeadlinesWithoutArticleID: $resource('/SP/msa/articles.html?start=:start&limit=20&sppwIds=:sppwId&articleCode=RHEAD&issueTypeId=S&articleId=&symbol=:ticker&requestType=all-related-headlines&gicsSector=&timeInterval=&equityType=Stock&top10HoldingsTickers=&sort=lastPublishDate&dir=DESC', { sppwId: '@sppwId',start:'start',ticker:'ticker'}),
        seeAllStockHeadlinesWithArticleID: $resource('/SP/msa/articles.html?start=:start&limit=20&sppwIds=:sppwId&articleCode=RHEAD&issueTypeId=S&articleId=:articleId&symbol=:ticker&requestType=all-related-headlines&gicsSector=&timeInterval=&equityType=Stock&top10HoldingsTickers=&sort=lastPublishDate&dir=DESC', { sppwId: '@sppwId',start:'start',ticker:'ticker',articleId:'articleId'}),
        relatedTIResource: $resource('/SP/msa/articles.html?equityType=TREND&sppwIds=:sppwIds&symbol=:tickers&requestType=relatedStockTop5Trends&articleCode=RHEAD&gicsSector=Information%20Technology&start=0&limit=5&timeInterval=90', {tickers: '@tickers', sppwIds: '@sppwIds'}),
        relatedEtfTIResource: $resource('/SP/msa/articles.html?equityType=TREND&sppwIds=:sppwId&symbol=:ticker&requestType=relatedETFTop5Trends&articleCode=RHEAD&gicsSector=Not%20Categorized&start=0&limit=5&timeInterval=90', {ticker: '@ticker', sppwId: '@sppwId'}),
        relatedDetailsTIResource: $resource('/SP/msa/articles.html?equityType=TREND&sppwIds=:sppwIds&requestType=TrendsDetailTop5Trends&articleCode=RHEAD&gicsSector=&start=0&limit=5&timeInterval=90&articleId=:articleId', {sppwIds: '@sppwIds', articleId: '@articleId'}),
        relateSectorsResource: $resource('/SP/msa/getRelatedSectors.html?articleId=:articleId&issueTypeId=:type', {articleId: '@articleId', type: '@type'}),
        seeFullArticleDetailsGLOOK: $resource('/SP/msa/articles.html?timeInterval=90&articleCode=GLOOK&start=:start&limit=:limit&sort=lastPublishDate&dir=DESC', {start:'@start',limit:'@limit'}),
        marketIntelligenceResource:  $resource('/SP/msa/marketIntelligence.html?articleCode=:articleCode&articleId=:articleId', {articleCode: '@articleCode'}),
        marketIntelligenceDetailResource:  $resource('/SP/msa/marketIntelligence.html?articleCode=:articleCode&articleId=:articleId', {articleCode: '@articleCode', articleId: '@articleId'}),
        articleDataResource: $resource('/SP/msa/articles.html?articleCode=:articleCode&limit=:limit&start=:start', {articleCode: '@articleCode', start: '@start', limit: '@limit'}),
        articleIdDataResource: $resource('/SP/msa/articles.html?articleCode=:articleCode&articleId=:articleId&limit=:limit&start=:start', {articleCode: '@articleCode', articleId: '@articleId', start: '@start', limit: '@limit'}),
        economyWatchResource: $resource('/SP/msa/calendar/getEconomyWatchEvents.html?dir=ASC&limit=:limit&sort=id.eventdate&start=:start', {start: '@start', limit: '@limit'}),
        economyWatchArticleResource: $resource('/SP/msa/economyWatch.html?articleCode=:articleCode', {articleCode: '@articleCode'}),
        economyWatchDetailResource: $resource('/SP/msa/economyWatch.html?articleCode=:articleCode', {articleCode: '@articleCode', articleId: '@articleId'}),
        portfolioInfoResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html?key=:key&availablePortfoliosOnlandingPage=:available', {key: '@key', available: '@available'}),
        portfolioDetailsResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html?key=:key&portfolioCode=:portfolioCode&articleId=:articleId', {key: '@key', portfolioCode: '@portfolioCode', articleId: '@articleId'}),
        portfolioGridResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html?key=:key&portfolioCode=:portfolioCode&selectedTab=:selectedTab&start=0&limit=20&addnlSortParameters%5B0%5D.sortProperty=:sortProperty&addnlSortParameters%5B0%5D.sortDirection=:sortDirection&sort=:sort&dir=:dir', {key: '@key', portfolioCode: '@portfolioCode', selectedTab: '@selectedTab', sortProperty: '@sortProperty', sortDirection: '@sortDirection', sort: '@sort', dir: '@dir'}),
        pageIndexResourceTest: $resource('scripts/config/page_index.json'),
        morningBriefingPageResource:$resource('/SP/msa/morningBriefing.html?articleCode=:articleCode', {articleCode: '@articleCode'},{isSpotLightPage: '@isSpotLightPage'}),
        sectorIndustryReports:$resource('/SP/msa/getIndustryReports.html?region=:region&limit=:limit&start=:start', {region: '@region',start:'@start',limit:'@limit'}),
        sectorTrendsAndIdeasPDFReport:$resource('/SP/msa/getTrendsAndProjection.html?region=:region',{region: '@region'}),
        sectorDetailsResource:$resource('/SP/msa/sector.html?gicCd=:gicCd&sectorName=:sectorName&sectorDetail=:sectorDetail',{sectorDetail: '@sectorDetail',sectorName:'@sectorName',gicCd: '@gicCd'}),
        sectorScreenResults:$resource('/SP/msa/screenerResults.html?dir=:formDataParam&screenerParameters%5B2%5D.operation1Value=:gicCd&screenerParameters%5B1%5D.operation1Value=:sectorCode',{gicCd:'@gicCd',sectorCode:'@sectorCode',formDataParam:'@formDataParam'}),
        sectorRelatedPeersResource:$resource('/SP/msa/getRelatedPeers.html?requestType=:requestType&sppwId=:sppwId',{requestType: '@requestType',sppwId:'@sppwId'}),
        sectorFullIndustryReports:$resource('/SP/msa/getIndustryReports.html?region=:region&limit=:limit&start=:start&sort=surveyName&dir=ASC', {region: '@region',start:'@start',limit:'@limit'}),
        sectorArticleListSTOVL:$resource('/SP/msa/articles.html?start=:start&limit=:limit&articleCode=:articleCode&timeInterval=90&sort=lastPublishDate&dir=DESC',{start:'@start',limit: '@limit',articleCode: '@articleCode'}),
        portfolioConfigResource:$resource('scripts/config/portfolio_config.json'),
        msaPortfolioInfoResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html?key=:key&availablePortfoliosOnlandingPage=:available', {key: '@key', available: '@available'}),
        portfolioArticleDetailsResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html?articleId=:articleId&portfolioCode=:portfolioCode&key=:key',{key:'@key',portfolioCode:'@portfolioCode',articleId:'@articleId'}),
        starStocksResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=starRank&screenerParameters%5B0%5D.propertyLabel=STARS&screenerParameters%5B0%5D.operation1Value=:operation1Value&screenerParameters%5B0%5D.customRenderer=starRankRenderer&start=:start&limit=:limit&equityType=STOCKS&sort=securityName&dir=ASC',{start: '@start', limit: '@limit', operation1Value:'@operation1Value'}),
        fairValueResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=fairvalueRank&screenerParameters%5B0%5D.operation1Value-displayValue=:operation1Value&screenerParameters%5B0%5D.propertyLabel=S%26P%20Fair%20Value%20Rank&screenerParameters%5B0%5D.operator1Type=%3D&screenerParameters%5B0%5D.operation1Value=:operation1Value&screenerParameters%5B0%5D.operator2Type=%3C%3D&screenerParameters%5B0%5D.conjunctionType=and&screenerParameters%5B0%5D.inferedPropertyName=fairvalueRank&start=:start&limit=:limit&equityType=STOCKS&sort=securityName&dir=ASC',{start: '@start', limit: '@limit', operation1Value:'@operation1Value'}),
        stocksStarsChangeResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=nextStarRank&screenerParameters%5B0%5D.propertyLabel=New%20Ranking&screenerParameters%5B0%5D.operation1Value=%23%23NO_OPERATION%23%23&screenerParameters%5B0%5D.customRenderer=starRankRenderer&screenerParameters%5B1%5D.propertyName=previousStarRank&screenerParameters%5B1%5D.propertyLabel=Old%20Ranking&screenerParameters%5B1%5D.operation1Value=%23%23NO_OPERATION%23%23&screenerParameters%5B1%5D.customRenderer=starRankRenderer&screenerParameters%5B2%5D.propertyName=starRankDate&screenerParameters%5B2%5D.propertyLabel=Date&screenerParameters%5B2%5D.operation1Value=%23%23NOT_NULL%23%23&screenerParameters%5B2%5D.customRenderer=dateRenderer&screenerParameters%5B3%5D.propertyName=starRank&screenerParameters%5B3%5D.propertyLabel=Research%20Notes%20Link&screenerParameters%5B3%5D.operation1Value=90&screenerParameters%5B3%5D.customRenderer=researchNotesLinkRenderer&screenerParameters%5B3%5D.nativeCondition=((issue_typ%20is%20null%20or%20issue_typ!%3D\'Pre\')%20and%20STAR_RKNG_DT%20%3E%20(sysdate%20-%20operation1Value))&start=:start&limit=:limit&equityType=STOCKS&addnlSortParameters%5B0%5D.sortProperty=sortableNextStarRank&addnlSortParameters%5B0%5D.sortDirection=DESC&sort=starRankDate&dir=DESC',{start: '@start', limit: '@limit'}),
        stocksStarsRecentReportResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=reportAddedDate&screenerParameters%5B0%5D.propertyLabel=Date%20Added&screenerParameters%5B0%5D.operation1Value=%23%23NOT_NULL%23%23&screenerParameters%5B0%5D.customRenderer=dateRenderer&screenerParameters%5B1%5D.propertyName=reportCount&screenerParameters%5B1%5D.operator1Type=%3E&screenerParameters%5B1%5D.operation1Value=0&start=:start&limit=:limit&equityType=STOCKS&sort=reportAddedDate&dir=DESC',{start: '@start', limit: '@limit'}),
        stocksStarsChangeResearchResource: $resource('/SP/msa/getStarChangeRN.html?symbol=:symbol&starRankDate=:starRankDate&currentStarRank=:starRank&sppwId=:sppwId', {symbol: '@symbol', starRankDate: '@starRankDate', starRank: '@starRank', sppwId: '@sppwId'}),
        etfRankingResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=overallIndVal&screenerParameters%5B0%5D.propertyLabel=Overall%20S%26P%20Ranking&screenerParameters%5B0%5D.operation1Value=:operation1Value&screenerParameters%5B0%5D.customRenderer=weightRenderer&start=:start&limit=:limit&equityType=ETFS&sort=securityName&dir=ASC',{start: '@start', limit: '@limit', operation1Value:'@operation1Value'}),
        trendsAndIdeasSpotLightResource:$resource('/SP/msa/trendsAndIdeasSpotlight.html',{articleCode:'TREND',start:0,limit:3,noOfTakeAways:0}),
        mostViewedArticlesResource:$resource('/SP/msa/mostViewedArticles.html?region=:region',{region: '@region'}),
        recentlyUpdatedArticlesResource:$resource('/SP/msa/recentlyUpdatedReport.html?securityType=:securityType',{securityType: '@securityType'}),
        getFXData:$resource('/SP/msa/homeLandingPage.html',{articleCode:'FXIND',start:0,limit:1}),
        getBondsData:$resource('/SP/msa/homeLandingPage.html',{articleCode:'BONDS',start:0,limit:1}),
        getIndexData:$resource('/SP/msa/marketscan/indexGraphs.html',{'statCode': 'IndexStats'}),

        trendsAndIdeasResource: $resource('/SP/msa/trendsAndIdeas/allArticles.html?articleCode=:articleCode&timeInterval=30&equityType=:equityType&noOfTakeAways=2',{articleCode:'@articleCode', equityType:'@equityType'}),
        trendsAndIdeasEquityResource: $resource('/SP/msa/trendsAndIdeas/equityArticles.html?articleCode=:articleCode&timeInterval=30&equityType=:equityType&noOfTakeAways=2&topic=:topic',{articleCode:'@articleCode',equityType:'@equityType',topic:'@topic'}),
        trendsAndIdeasFixedResource: $resource('/SP/msa/articles.html?articleCode=:articleCode&timeInterval=30&requestType=:requestType&issueType=:issueType&topic=:topic&noOfTakeAways=2',{articleCode:'@articleCode',requestType:'@requestType',issueType:'@issueType',topic:'@topic'}),

        articleCountResource: $resource('/SP/msa/trendsAndIdeas/articleCountByTopics.html?articleCode=:articleCode&timeInterval=90&equityType=:equityType',{articleCode:'@articleCode',equityType:'@equityType'}),
        articleTopicResource: $resource('/SP/msa/trendsAndIdeas/articleDetailsInTopic.html?articleCode=:articleCode&timeInterval=90&requestType=:requestType&equityType=:equityType&topic=:topic',{articleCode:'@articleCode',requestType:'@requestType',equityType:'@equityType',topic:'@topic'}),
        articlesFilterResource: $resource('/SP/msa/articlesFilter.html?articleCode=GLBTREND&timeInterval=90'),
        filterArticlesResource: $resource('/SP/msa/trendsAndIdeas/filterArticles.html?start=0&limit=:limit&articleCode=:articleCode&sppwIds=:sppwIds&requestType=:requestType&timeInterval=90&symbol=:symbol&gicsCode=:gicsCode&author=:author&sort=lastPublishDate&dir=DESC',{limit:'@limit',articleCode:'@articleCode',sppwIds:'@sppwIds',requestType:'@requestType',symbol:'@symbol',gicsCode:'@gicsCode',author:'@author'}),
        watchListsResource: $resource('/SP/msa/watchLists.html?operationCode=READ'),
        starFundsResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=starsRank3Yr&screenerParameters%5B0%5D.propertyLabel=Star&screenerParameters%5B0%5D.operation1Value=:operation1Value&screenerParameters%5B0%5D.customRenderer=starRankRenderer&start=:start&limit=:limit&equityType=FUNDS&sort=securityName&dir=ASC',{start: '@start', limit: '@limit', operation1Value:'@operation1Value'}),
        seeAllFundHeadlines: $resource('/SP/msa/articles.html?start=:start&limit=:limit&sppwIds=:sppwId&articleCode=RHEAD&issueTypeId=&articleId=:articleId&symbol=:ticker&requestType=fundAllRelatedHeadlines&gicsSector=&timeInterval=&equityType=FUNDS&top10HoldingsTickers=', { sppwId: '@sppwId',start:'@start',limit:'@limit',ticker:'@ticker',articleId:'@articleId'}),
        portfolioSubTabResource: $resource('/SP/msa/portfolio/getPortfolioInfo.html', {}, {
            postReq: {
                method: "POST", headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        }),
        indicesDataResource: $resource('/SP/msa/indexDetails.html?requestType=:requestType',{requestType: '@requestType'}),
        indicesDetailsDataResource: $resource('/SP/msa/indexDetails.html?requestType=:requestType&indexSymbol=:indexSymbol&sppwId=:sppwId',{requestType: '@requestType',indexSymbol:'@indexSymbol',sppwId:'@sppwId'}),
        indicesStockDataResource: $resource('/SP/msa/screenerResults.html?screenerParameters%5B0%5D.propertyName=index&screenerParameters%5B0%5D.operation1Value=:operationValue&screenerParameters%5B0%5D.customRenderer=membershipRenderer&screenerParameters%5B0%5D.propertyLabel=Index Membership&screenerParameters%5B0%5D.operator1Type=&screenerParameters%5B0%5D.inferedPropertyName=index&equityType=STOCKS&start=:start&limit=20&sort=securityName&dir=ASC&skipEntitlement=Y', { start: '@start', operationValue:'@operationValue'}),
        assetWatchlistResource: $resource('/SP/msa/screenerResults.html', {}, {
            postReq: {
                method: "POST" , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'} ,transformRequest : function(data){
                    return $.param(data);
                }
            }
        }),
        assetWatchlistCrudResource : $resource('/SP/msa/watchLists.html', {}, {
            postReq: {
                method: "POST" , headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'} ,transformRequest : function(data){
                    return $.param(data, true);
                }
            }
        })
        //relateSectorsResource:$resource('data/relatedSectors.json')
        //relatedTIResource:$resource('data/relatedTI.json'),
        //relatedHeadlinesResource:$resource('data/relatedHeadlines.json'),
        //stocksRelatedArticleResource:$resource('data/stocksRelatedArticles.json'),
        //etfRelatedArticlesResource:$resource('data/etfRelatedArticles.json'),

    };
});